"""hyblend_hub.py -- sincronia entre os addons Hyblend (Toolkit, Character
Creator, Prefabs e os que vierem).

ESTE ARQUIVO É IDÊNTICO EM TODOS OS ADDONS HYBLEND. Mudou num -> copiar pros
outros sem trocar nada (o que é de cada addon entra por register()).

Cada addon continua independente (nenhum importa o outro). O que eles
dividem mora num objeto em `sys.modules` (_SHARED), criado pelo primeiro
addon que carregar; os outros só se inscrevem:

  * Seletor: com 2+ addons presentes, uma faixa no topo da aba "Hyblend"
    troca qual addon aparece (só UM por vez). Addon conhecido (KNOWN) que
    não está instalado aparece desligado. Um addon sozinho = sem faixa,
    tudo como antes. Desenho: GPU = framework/switcher.py; nativo =
    painel do addon "líder" (o primeiro presente em KNOWN), draw_native().
  * UI por GPU: UMA escolha pra todos (use_gpu_ui de cada addon lê e grava
    aqui). Padrão: ligada no Blender 5.0+. Idem o tamanho do painel
    ("Panel Size", largura e altura): SETTINGS + prop_get/prop_set.
  * Pasta do Hytale: UMA pra todos. Cada addon continua com os próprios
    campos nas Preferences, mas mudou num -> share_hytale() grava aqui e
    copia pros outros (on_hytale); no boot, adopt_hytale() aplica a
    compartilhada (ou semeia com a do addon, se ainda não houver).
  * Config em Documentos/Hyblend/Config/ui.json ({"gpu_ui": bool,
    "active": id, "panel_size"/"panel_width"/"panel_height": float,
    "hytale_mode": "AUTO"|"MANUAL", "hytale_dir": str}); sem o arquivo (ou
    sem permissão), vale o padrão e fica só na memória.

Addon novo: register_addon("id", "Rótulo", ...) no register() dele e
unregister_addon("id") no unregister() (seletor nativo, inscrição, pasta
do Hytale no boot -- tudo); pra aparecer DESLIGADO nos outros quando não
estiver instalado, acrescentar (id, rótulo) em KNOWN aqui (e copiar o
arquivo pros outros addons).

Compatibilidade entre versões: o objeto compartilhado é criado pela cópia
que carregar PRIMEIRO (pode ser mais velha que a sua). Campo novo de
inscrição/estado = sempre lido com getattr(..., padrão).

Sem lógica de UI de addon nenhum aqui: só estado + avisos (callbacks).
"""

import json
import math
import os
import sys
import tempfile
import traceback
import types

PROTOCOL = 1
# (id, rótulo) na ordem da faixa. Também é a prioridade do "líder" e do
# addon ativo padrão.
KNOWN = (
    ("toolkit", "Toolkit"),
    ("character_creator", "Character Creator"),
    ("prefabs", "Prefabs"),
)
_SHARED_NAME = "_hyblend_hub_shared"
CONFIG_DIR = ("Hyblend", "Config")
CONFIG_FILE = "ui.json"
GPU_MIN_BLENDER = (5, 0, 0)
SAVE_DELAY = 0.5            # gravação agrupada (arrastar o slider de tamanho nas Preferences muda a cada passo)
# Configurações compartilhadas por get/set (chave do ui.json -> padrão)
SETTINGS = {"panel_size": 1.0, "panel_width": 0.0, "panel_height": 0.0}


def _shared():
    shared = sys.modules.get(_SHARED_NAME)
    if shared is None:
        shared = types.ModuleType(_SHARED_NAME)
        shared.protocol = PROTOCOL
        shared.providers = {}          # id -> types.SimpleNamespace (ver register)
        shared.config = None           # dict carregado do ui.json (None = ainda não lido)
        sys.modules[_SHARED_NAME] = shared
    return shared


# --------------------------------------------------------------------------
# Config (Documentos/Hyblend/Config/ui.json)
# --------------------------------------------------------------------------

def documents_dir():
    """Pasta "Documentos" do usuário: a regra ÚNICA dos addons Hyblend (config,
    caches, presets, templates -- tudo em <Documentos>/Hyblend/...)."""
    home = os.path.expanduser("~")
    for name in ("Documents", "Documentos"):
        path = os.path.join(home, name)
        if os.path.isdir(path):
            return path
    return os.path.join(home, "Documents")


def config_path():
    return os.path.join(documents_dir(), *CONFIG_DIR, CONFIG_FILE)


# Tipo de cada chave conhecida do ui.json (SETTINGS = número). Valor de tipo
# errado (arquivo editado à mão, outra versão) é descartado na leitura --
# vale o padrão. Chave desconhecida (versão mais nova) fica intacta.
_KEY_TYPES = {"gpu_ui": bool, "active": str, "hytale_mode": str, "hytale_dir": str}


def _clean(data):
    out = {}
    for key, value in data.items():
        if key in SETTINGS:
            if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
                out[key] = float(value)
        elif key in _KEY_TYPES:
            if isinstance(value, _KEY_TYPES[key]):
                out[key] = value
        else:
            out[key] = value
    if out.get("hytale_mode", "AUTO") not in ("AUTO", "MANUAL"):
        out.pop("hytale_mode")
    return out


def _read(path):
    """dict do arquivo; {} se não existe; None se não deu pra ler (sem
    permissão, travado...). JSON corrompido: guardado como .bad, vale {}."""
    try:
        with open(path, encoding="utf-8") as f:
            loaded = json.load(f)
        return loaded if isinstance(loaded, dict) else {}
    except FileNotFoundError:
        return {}
    except ValueError:
        try:
            os.replace(path, path + ".bad")
        except OSError:
            pass
        return {}
    except OSError:
        return None


def _config():
    shared = _shared()
    if shared.config is None:
        data = _read(config_path())
        # Não deu pra LER (existe, mas sem acesso): não gravar por cima.
        shared.readonly = data is None
        shared.config = _clean(data or {})
    return shared.config


def _set(key, value):
    """Grava uma chave na config da memória (e marca pra ir pro disco).
    True se mudou."""
    config = _config()
    if key in config and config[key] == value:
        return False
    config[key] = value
    dirty = getattr(_shared(), "dirty", None)
    if dirty is None:
        dirty = _shared().dirty = set()
    dirty.add(key)
    return True


def _save_tick():
    _save()
    return None


def _save_later():
    """Grava daqui a SAVE_DELAY s (agrupa mudanças seguidas). Sem bpy
    (teste/boot), grava na hora."""
    try:
        import bpy
        if not bpy.app.timers.is_registered(_save_tick):
            bpy.app.timers.register(_save_tick, first_interval=SAVE_DELAY, persistent=True)
    except Exception:
        _save()


def flush():
    """Grava agora o que estiver pendente (unregister do addon)."""
    try:
        import bpy
        if bpy.app.timers.is_registered(_save_tick):
            bpy.app.timers.unregister(_save_tick)
            _save()
    except Exception:
        pass


def _save():
    """Grava SÓ as chaves que mudaram nesta sessão por cima do que está no
    disco (outro Blender aberto pode ter gravado outras nesse meio-tempo)."""
    shared = _shared()
    config = _config()
    dirty = getattr(shared, "dirty", None)
    if not dirty:
        return
    path = config_path()
    # Lê de novo o que está no disco: arquivo que existe mas não abre agora
    # (travado pelo antivírus/OneDrive...) = não grava (fica pendente; a
    # próxima mudança tenta de novo). Voltou a abrir = deixa de ser só-leitura.
    disk = _read(path)
    if disk is None:
        return
    shared.readonly = False
    tmp = None
    try:
        merged = dict(disk)
        merged.update({key: config[key] for key in dirty if key in config})
        folder = os.path.dirname(path)
        os.makedirs(folder, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix="ui.", suffix=".tmp", dir=folder)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(merged, f, indent=2, sort_keys=True)
        os.replace(tmp, path)
        tmp = None
        dirty.clear()
    except OSError:
        traceback.print_exc()          # sem permissão: continua só na memória
    finally:
        if tmp is not None:
            try:
                os.remove(tmp)
            except OSError:
                pass


# --------------------------------------------------------------------------
# Inscrição dos addons
# --------------------------------------------------------------------------

def _call(fn, *args, default=None):
    if fn is None:
        return default
    try:
        return fn(*args)
    except Exception:
        traceback.print_exc()
        return default


def register(ident, label, *, owner=None, available=None, reason=None, gpu_showing=None, refresh=None,
             on_gpu_changed=None, on_hytale=None):
    """Inscreve um addon. `owner` = nome do pacote do addon (ADDON_PACKAGE):
    se o register() dele falhar DEPOIS desta inscrição, o Blender tira o
    módulo de sys.modules SEM chamar unregister() -- a inscrição órfã é
    descartada sozinha (_providers). Callbacks (todos opcionais, chamados com try):
      available(context) -> bool    pode ser escolhido agora? (ex.: Toolkit sem o jogo = False)
      reason(context) -> str        tooltip do botão quando indisponível
      gpu_showing(context) -> bool  a UI por GPU DESTE addon está na tela
                                    (o seletor nativo some, a faixa por GPU assume)
      refresh()                     algo do hub mudou: reconstruir telas/redesenhar
      on_gpu_changed(context)       a escolha da UI por GPU ou o tamanho do painel
                                    mudou (ligar/derrubar hosts, aplicar tamanho)
      on_hytale(mode, pasta)        a pasta do Hytale compartilhada mudou: gravar nos
                                    campos DESTE addon (compare antes de escrever)
    """
    shared = _shared()
    shared.providers[ident] = types.SimpleNamespace(
        ident=ident, label=label, owner=owner, available=available, reason=reason, gpu_showing=gpu_showing,
        refresh=refresh, on_gpu_changed=on_gpu_changed, on_hytale=on_hytale)
    _refresh_all()


def unregister(ident, owner=None):
    """Tira a inscrição. Com `owner`, só se for a MESMA (duas cópias do mesmo
    addon -- ex.: legado + extensão -- não se derrubam)."""
    providers = _shared().providers
    provider = providers.get(ident)
    if provider is not None and (owner is None or getattr(provider, "owner", None) in (None, owner)):
        del providers[ident]
    flush()
    _refresh_all()


def _providers():
    """{id: inscrição} só dos addons vivos (descarta órfãos, ver register)."""
    providers = _shared().providers
    dead = [i for i, p in providers.items() if getattr(p, "owner", None) and p.owner not in sys.modules]
    for ident in dead:
        del providers[ident]
    return providers


def _order(ident):
    for i, (known, _) in enumerate(KNOWN):
        if known == ident:
            return (i, "")
    return (len(KNOWN), ident)


def present():
    """Addons inscritos, na ordem da faixa."""
    return sorted(_providers().values(), key=lambda p: _order(p.ident))


def switcher_visible():
    """Faixa só com 2+ addons presentes."""
    return len(_providers()) >= 2


def leader():
    """Id do addon que desenha o seletor NATIVO (o primeiro presente)."""
    providers = present()
    return providers[0].ident if providers else None


def _cb(provider, name):
    """Callback da inscrição (None se não tem -- cópia mais velha do hub)."""
    return getattr(provider, name, None)


def _available(provider, context):
    fn = _cb(provider, "available")
    return bool(_call(fn, context, default=True)) if fn else True


def active(context=None):
    """Id do addon escolhido. O salvo, se presente e disponível; senão o
    primeiro disponível (ordem de KNOWN); senão o primeiro presente."""
    context = context or _context()
    providers = present()
    if not providers:
        return None
    saved = _config().get("active")
    by_id = {p.ident: p for p in providers}
    if saved in by_id and _available(by_id[saved], context):
        return saved
    for p in providers:
        if _available(p, context):
            return p.ident
    return providers[0].ident


def is_active(ident, context=None):
    """Este addon deve aparecer na aba? Sem faixa (sozinho): sempre."""
    if not switcher_visible():
        return True
    return active(context) == ident


def set_active(ident, context=None):
    """Troca o addon da aba (clique no seletor). Grava na config."""
    provider = _providers().get(ident)
    if provider is None:
        return False
    if not _available(provider, context or _context()):
        return False
    if _set("active", ident):
        _save()
    _refresh_all()
    return True


def entries(context=None):
    """[(id, rótulo, habilitado, ativo, tooltip)] pra faixa (GPU e nativa):
    todos os KNOWN (ausente = desligado) + inscritos que não estão em KNOWN."""
    context = context or _context()
    providers = {p.ident: p for p in present()}
    current = active(context)
    out = []
    for ident, label in KNOWN:
        provider = providers.pop(ident, None)
        if provider is None:
            out.append((ident, label, False, False, "Hyblend %s is not installed" % label))
            continue
        out.append(_entry(provider, current, context))
    for provider in sorted(providers.values(), key=lambda p: _order(p.ident)):
        out.append(_entry(provider, current, context))
    return out


def _entry(provider, current, context):
    ok = _available(provider, context)
    if ok:
        tip = "Show Hyblend %s" % provider.label
    else:
        tip = _call(_cb(provider, "reason"), context, default="") or "Hyblend %s is not available" % provider.label
    return (provider.ident, provider.label, ok, provider.ident == current, tip)


def tooltip(ident, context=None):
    for entry in entries(context):
        if entry[0] == ident:
            return entry[4]
    return ""


# --------------------------------------------------------------------------
# UI por GPU: uma escolha pra todos
# --------------------------------------------------------------------------

def gpu_supported():
    import bpy
    return bpy.app.version >= GPU_MIN_BLENDER


def gpu_enabled():
    """A escolha (ligada/desligada), sem olhar suporte. Padrão: ligada no 5.0+."""
    value = _config().get("gpu_ui")
    if value is None:
        return gpu_supported()
    return bool(value)


def set_gpu_enabled(value, context=None):
    """Grava e avisa TODOS os addons (cada um liga/derruba os hosts dele)."""
    if _set("gpu_ui", bool(value)):
        _save()
    context = context or _context()
    for provider in present():
        _call(_cb(provider, "on_gpu_changed"), context)
    _refresh_all()


# Pra usar direto como get/set de BoolProperty: use_gpu_ui = BoolProperty(get=..., set=..., default=True)
def prop_get_gpu(_self):
    # Sem suporte (4.5): a caixinha (desligada) aparece desmarcada, mesmo com
    # "ligada" salva por um Blender 5.x.
    return gpu_enabled() and gpu_supported()


def prop_set_gpu(_self, value):
    set_gpu_enabled(value)


# --------------------------------------------------------------------------
# Tamanho do painel (e outras configurações compartilhadas por get/set)
# --------------------------------------------------------------------------

def setting(key):
    value = _config().get(key)
    return SETTINGS[key] if value is None else value


def set_setting(key, value, context=None):
    """Grava (agrupado) e avisa TODOS os addons (on_gpu_changed: cada um
    aplica o tamanho novo nos hosts dele)."""
    if setting(key) == value or not _set(key, value):
        return
    _save_later()
    context = context or _context()
    for provider in present():
        _call(_cb(provider, "on_gpu_changed"), context)
    _refresh_all()


def prop_get(key):
    """get= de uma FloatProperty compartilhada (ex.: gpu_ui_scale -> "panel_size")."""
    def get(_self):
        return float(setting(key))
    return get


def prop_set(key):
    def set_(_self, value):
        set_setting(key, float(value))
    return set_


# --------------------------------------------------------------------------
# Pasta do Hytale (espelhada nos campos de cada addon)
# --------------------------------------------------------------------------

def _sharing():
    return bool(getattr(_shared(), "sharing", False))


def _set_sharing(value):
    _shared().sharing = value


def hytale_shared():
    """(modo, pasta) compartilhados, ou None se nenhum addon gravou ainda."""
    config = _config()
    if "hytale_mode" not in config:
        return None
    return config["hytale_mode"], config.get("hytale_dir", "")


def share_hytale(source, mode, path):
    """O addon `source` mudou a pasta (update= dos campos dele): grava aqui e
    aplica nos outros. Chamado enquanto o hub está aplicando a pasta (os
    updates que isso causa em QUALQUER addon) = ignorado -- a trava fica no
    objeto compartilhado, não nesta cópia do arquivo."""
    if _sharing():
        return
    mode = "MANUAL" if mode == "MANUAL" else "AUTO"
    path = path or ""
    changed = _set("hytale_mode", mode)
    changed = _set("hytale_dir", path) or changed
    if changed:
        _save()
    _apply_hytale(mode, path, skip=source)
    _refresh_all()


def _write_fields(prefs, mode, path):
    """Grava (modo, pasta) nos campos hytale_path_mode/hytale_path de um
    addon SEM re-compartilhar. A pasta é sempre gravada (mesmo igual): o
    update do addon descarta o caminho resolvido em cache -- "Locate Game"
    com a mesma pasta re-testa o disco."""
    if prefs is None:
        return
    was = _sharing()
    _set_sharing(True)
    try:
        if prefs.hytale_path_mode != mode:
            prefs.hytale_path_mode = mode
        prefs.hytale_path = path
    finally:
        _set_sharing(was)


def set_hytale(ident, package, mode, path):
    """Grava a pasta nos campos do addon (mode None = mantém o modo) e
    compartilha UMA vez (sem o estado intermediário "modo novo, pasta velha")."""
    prefs = prefs_of(package)
    if prefs is None:
        return
    mode = prefs.hytale_path_mode if mode is None else mode
    _write_fields(prefs, mode, path)
    share_hytale(ident, mode, path)


def _is_dir(path):
    try:
        return bool(path) and os.path.isdir(os.path.expanduser(path))
    except (OSError, ValueError):
        return False


def adopt_hytale(ident, mode, path):
    """Boot do addon (timer, fora do register): aplica a pasta compartilhada
    nele. Sem compartilhada ainda -- ou se a compartilhada não existe NESTE
    computador e a do addon existe -- a do addon vira a compartilhada
    (migração: quem já tinha uma pasta configurada não perde nada)."""
    shared = hytale_shared()
    if shared is not None and not (_is_dir(path) and not _is_dir(shared[1])):
        _apply_hytale(*shared, only=ident)
    elif path:
        share_hytale(ident, mode, path)


def _apply_hytale(mode, path, skip=None, only=None):
    was = _sharing()
    _set_sharing(True)
    try:
        for provider in present():
            if provider.ident == skip or (only is not None and provider.ident != only):
                continue
            _call(_cb(provider, "on_hytale"), mode, path)
    finally:
        _set_sharing(was)


# --------------------------------------------------------------------------
# Seletor nativo (UILayout) -- desenhado pelo addon líder
# --------------------------------------------------------------------------

def native_visible(ident, context):
    """O painel-seletor nativo DESTE addon aparece? Só o líder desenha, só
    com 2+ addons, e só quando a UI por GPU do addon ativo não está na tela
    (ela traz a própria faixa)."""
    if not switcher_visible() or leader() != ident:
        return False
    # Nenhum addon disponível (ex.: sem a pasta do jogo, todos travados e com
    # a aba escondida): a faixa não aparece sozinha com tudo desligado.
    if not any(_available(p, context) for p in present()):
        return False
    provider = _providers().get(active(context))
    return not (provider is not None and _call(_cb(provider, "gpu_showing"), context, default=False))


def draw_native(layout, context, operator_idname):
    """Linha de botões (o ativo afundado; ausente/indisponível desligado).
    `operator_idname` = operador hub_select do addon líder (prop `target`)."""
    row = layout.row(align=False)
    row.scale_y = 1.25
    for ident, label, enabled, is_current, _tip in entries(context):
        cell = row.row(align=True)
        cell.enabled = enabled
        op = cell.operator(operator_idname, text=label, depress=is_current)
        op.target = ident


def make_classes(namespace, ident, category="Hyblend"):
    """(operador hub_select, painel-seletor nativo) com nomes do addon.
    Registrar os dois no register() do addon (o painel ANTES dos outros
    painéis da aba, bl_order 0)."""
    import bpy

    ns_upper = namespace.upper()

    def execute(self, context):
        if not set_active(self.target, context):
            return {"CANCELLED"}
        return {"FINISHED"}

    def description(cls, context, properties):
        return tooltip(properties.target, context)

    operator = type("%s_OT_hub_select" % ns_upper, (bpy.types.Operator,), {
        "bl_idname": namespace + ".hub_select",
        "bl_label": "Hyblend Addon",
        "bl_description": "Show this Hyblend addon in the Hyblend tab",
        "bl_options": {"INTERNAL"},
        "__annotations__": {"target": bpy.props.StringProperty(options={"SKIP_SAVE", "HIDDEN"})},
        "execute": execute,
        "description": classmethod(description),
    })

    def poll(cls, context):
        return native_visible(ident, context)

    def draw(self, context):
        draw_native(self.layout, context, operator.bl_idname)

    panel = type("%s_PT_hub_switcher" % ns_upper, (bpy.types.Panel,), {
        "bl_idname": "%s_PT_hub_switcher" % ns_upper,
        "bl_label": "Hyblend",
        "bl_space_type": "VIEW_3D",
        "bl_region_type": "UI",
        "bl_category": category,
        "bl_options": {"HIDE_HEADER"},
        "bl_order": 0,
        "poll": classmethod(poll),
        "draw": draw,
    })
    return operator, panel


# --------------------------------------------------------------------------
# Preferences: blocos IGUAIS nos addons (pasta do Hytale, UI por GPU) e o
# operador "Locate Game". Textos em inglês por padrão; o Toolkit passa os
# traduzidos (texts=).
# --------------------------------------------------------------------------

HYTALE_TEXTS = {
    "box": "Hytale Folder (required)",
    "required": "{addon} needs Hytale installed. Locate the game folder to unlock the add-on.",
    "locate": "Locate Game",
    "found": "Hytale folder: {path}",
    "invalid": "Not a Hytale folder (Assets.zip not found inside it)",
    "missing": "No Hytale folder yet",
}
HYTALE_MODE_ITEMS = (
    ("AUTO", "Automatic", "Find the Hytale folder in the default install location (%APPDATA%/Hytale)"),
    ("MANUAL", "Manual", "Choose the Hytale folder yourself (if the game is installed elsewhere)"),
)
HYTALE_MODE_DESCRIPTION = ("Where to find the Hytale folder. The add-on needs it to work, and reads the game's "
                           "files, interface art and fonts from it (nothing from the game ships with the add-on). "
                           "Shared by all Hyblend addons")
HYTALE_PATH_DESCRIPTION = ("The game's Hytale folder (the one containing \"install\"). In Automatic mode it is "
                           "filled in on its own. Shared by all Hyblend addons: changing it here changes it in the "
                           "others too")
GPU_TEXTS = {
    "box": "GPU Interface (N-Panel)",
    "use": "Experimental GPU Interface",
    "requires": "Requires Blender {required} or newer (current: {current})",
    "size": "Panel Size",
    "width": "Panel Width",
    "height": "Panel Height",
}


def draw_hytale_folder(layout, prefs, found, locate_idname, addon_name, texts=None, icon="FILE_FOLDER",
                       locate_props=None):
    """Caixa "Hytale Folder" (a do Toolkit): aviso sem o jogo, Automático/
    Manual, campo da pasta, "Locate Game" e o estado. `prefs` tem as props
    hytale_path_mode / hytale_path; `found` = Path da instalação ou None."""
    import textwrap
    t = dict(HYTALE_TEXTS, **(texts or {}))
    box = layout.box()
    box.label(text=t["box"], icon=icon)
    if found is None:
        warn = box.column(align=True)
        warn.alert = True
        for i, line in enumerate(textwrap.wrap(t["required"].format(addon=addon_name), 72)):
            warn.label(text=line, icon="ERROR" if i == 0 else "BLANK1")
    box.row().prop(prefs, "hytale_path_mode", expand=True)
    row = box.row(align=True)
    row.enabled = prefs.hytale_path_mode == "MANUAL"
    row.prop(prefs, "hytale_path", text="")
    op = box.operator(locate_idname, text=t["locate"], icon="VIEWZOOM")
    for key, value in (locate_props or {}).items():
        setattr(op, key, value)
    if found is not None:
        box.label(text=t["found"].format(path=str(found)), icon="CHECKMARK")
    elif prefs.hytale_path:
        box.label(text=t["invalid"], icon="ERROR")
    else:
        box.label(text=t["missing"], icon="INFO")
    return box


def draw_gpu_settings(layout, prefs, supported, min_blender, texts=None):
    """Conteúdo do bloco "GPU Interface (N-Panel)" (o do Toolkit): liga/desliga,
    Panel Size, Panel Width | Panel Height. Os valores são compartilhados."""
    import bpy
    t = dict(GPU_TEXTS, **(texts or {}))
    col = layout.column()
    row = col.row()
    row.enabled = supported
    row.prop(prefs, "use_gpu_ui", text=t["use"])
    if not supported:
        col.label(text=t["requires"].format(required="%d.%d" % tuple(min_blender[:2]),
                                            current=bpy.app.version_string), icon="ERROR")
        return
    sub = col.column()
    sub.active = bool(prefs.use_gpu_ui)
    sub.prop(prefs, "gpu_ui_scale", text=t["size"])
    size = sub.row(align=True)
    size.prop(prefs, "gpu_ui_panel_width", text=t["width"])
    size.prop(prefs, "gpu_ui_panel_height", text=t["height"])


GPU_HOST_TEXTS = {
    "failed": "The GPU interface failed to load",
    "retry": "Try Again",
    "use_classic": "Use Classic Panel",
    "loading": "Loading interface\u2026",
}


def draw_gpu_host_status(layout, status, error, retry_idname, disable_idname, texts=None):
    """O que o painel-gancho da UI por GPU mostra por baixo do host (IGUAL nos
    addons): com erro, o aviso + o motivo (última linha, quebrada) + "Try
    Again" / "Use Classic Panel"; montando, "Loading interface…"."""
    import textwrap
    t = dict(GPU_HOST_TEXTS, **(texts or {}))
    if status == "ERROR":
        box = layout.box()
        box.label(text=t["failed"], icon="ERROR")
        if error:
            col = box.column(align=True)
            col.scale_y = 0.8
            for line in textwrap.wrap(error, 48)[:4]:
                col.label(text=line)
        box.operator(retry_idname, text=t["retry"], icon="FILE_REFRESH")
        box.operator(disable_idname, text=t["use_classic"], icon="LOOP_BACK")
    elif status != "READY":
        layout.label(text=t["loading"])


def draw_experimental(layout, namespace, sections, title="Experimental"):
    """Aba colapsável "Experimental" (layout.panel; o Blender guarda aberto/
    fechado) com uma sub-aba por recurso: sections = [(id, título, ícone,
    draw(layout))]. Igual à do Toolkit."""
    header, body = layout.panel("%s_prefs_experimental" % namespace, default_closed=True)
    header.label(text=title, icon="EXPERIMENTAL")
    if body is None:
        return
    for ident, label, icon, draw in sections:
        sub_header, sub_body = body.panel("%s_prefs_%s" % (namespace, ident), default_closed=False)
        sub_header.label(text=label, icon=icon)
        if sub_body is not None:
            draw(sub_body)


def make_locate_operator(namespace, ident, package, default_dir, find_dir, texts=None):
    """Operador "<ns>.locate_game" = o "Locate Game" do Toolkit: tenta o
    local padrão (grava a pasta, mantém o modo); sem achar, abre o seletor
    de pasta (aceita a pasta Hytale ou qualquer coisa dentro dela; grava em
    Manual). default_dir() -> Path|None, find_dir(caminho) -> Path|None.
    A pasta vai pros campos do addon `package` e pros outros addons."""
    import bpy
    t = dict(LOCATE_TEXTS, **(texts or {}))

    def invoke(self, context, event):
        found = default_dir()
        if found is not None:
            set_hytale(ident, package, None, str(found))
            self.report({"INFO"}, str(found))
            return {"FINISHED"}
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        found = find_dir(bpy.path.abspath(self.directory)) if self.directory else None
        if found is None:
            self.report({"WARNING"}, t["invalid"])
            return {"CANCELLED"}
        set_hytale(ident, package, "MANUAL", str(found))
        self.report({"INFO"}, str(found))
        return {"FINISHED"}

    return type("%s_OT_locate_game" % namespace.upper(), (bpy.types.Operator,), {
        "bl_idname": namespace + ".locate_game",
        "bl_label": t["label"],
        "bl_description": t["description"],
        "bl_options": {"INTERNAL"},
        "__annotations__": {"directory": bpy.props.StringProperty(subtype="DIR_PATH", options={"SKIP_SAVE"})},
        "invoke": invoke,
        "execute": execute,
    })


LOCATE_TEXTS = {
    "label": "Locate Game",
    "description": "Find the Hytale folder: tries the default install location, otherwise lets you choose it",
    "invalid": "That is not the Hytale folder (the one containing \"install\")",
}


# --------------------------------------------------------------------------
# Ligação padrão de um addon Hyblend (o que os três faziam igual)
# --------------------------------------------------------------------------

_ADDONS = {}          # id -> {"classes": [...], "adopt": timer} (desta cópia do arquivo)


def prefs_of(package):
    """AddonPreferences do addon (None durante register/unregister)."""
    try:
        import bpy
        addon = bpy.context.preferences.addons.get(package)
    except Exception:
        return None
    return getattr(addon, "preferences", None) if addon is not None else None


def register_addon(ident, label, package, namespace, *, game_found, gpu_ui, reason=None, migrate=None):
    """Tudo que um addon Hyblend faz no hub, de uma vez (chamar no register(),
    ANTES dos painéis da aba):
      * seletor nativo (operador <ns>.hub_select + painel bl_order 0);
      * inscrição: disponível = game_found(); gpu_ui = o módulo
        interface/gpu_ui do addon (is_enabled, host_ok, hub_refresh,
        on_preference_changed); pasta compartilhada -> campos do addon;
      * timer de boot (persistente: sobrevive ao .blend aberto pela linha de
        comando): migrate(prefs) opcional (só sem pasta compartilhada ainda)
        e adopt_hytale.
    `reason` = tooltip do botão quando o jogo não foi achado."""
    import bpy
    classes = list(make_classes(namespace, ident))
    for cls in classes:
        bpy.utils.register_class(cls)

    def gpu_showing(context):
        return gpu_ui.is_enabled(context) and game_found() and gpu_ui.host_ok(context)

    def adopt():
        prefs = prefs_of(package)
        if prefs is not None:
            if migrate is not None and hytale_shared() is None:
                # Só antes de existir pasta compartilhada, e sem re-compartilhar
                # (o adopt abaixo decide o que vale pra todos).
                was = _sharing()
                _set_sharing(True)
                try:
                    _call(migrate, prefs)
                finally:
                    _set_sharing(was)
            adopt_hytale(ident, prefs.hytale_path_mode, prefs.hytale_path)
        return None

    _ADDONS[ident] = {"classes": classes, "adopt": adopt}
    register(ident, label, owner=package, available=lambda context: game_found(),
             reason=(lambda context: reason) if reason else None, gpu_showing=gpu_showing,
             refresh=gpu_ui.hub_refresh, on_gpu_changed=gpu_ui.on_preference_changed,
             on_hytale=lambda mode, path: _write_fields(prefs_of(package), mode, path))
    bpy.app.timers.register(adopt, first_interval=0.05, persistent=True)


def unregister_addon(ident, package=None):
    import bpy
    entry = _ADDONS.pop(ident, None)
    if entry is not None and bpy.app.timers.is_registered(entry["adopt"]):
        bpy.app.timers.unregister(entry["adopt"])
    unregister(ident, owner=package)
    for cls in reversed(entry["classes"] if entry else ()):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


# --------------------------------------------------------------------------
# Texturas extraídas do Assets.zip (CC e Prefabs)
# --------------------------------------------------------------------------

def restore_cached_images(cache_dir, extract, only_missing=True):
    """Imagens do .blend que apontam pra arquivos extraídos do Assets.zip
    (dentro de `cache_dir`, não empacotadas): re-extrai -- extract(caminho
    relativo com "/") -- e recarrega. only_missing=False: todas (depois de
    "Clear Cache", pra pegar a versão nova do jogo). Devolve quantas."""
    import bpy
    root = os.path.normcase(os.path.abspath(str(cache_dir)))
    fixed = 0
    for image in bpy.data.images:
        if image.source != "FILE" or image.packed_file is not None or image.library is not None:
            continue
        path = os.path.abspath(bpy.path.abspath(image.filepath))
        if not os.path.normcase(path).startswith(root + os.sep):
            continue
        if only_missing and os.path.isfile(path):
            continue
        try:
            extract(os.path.relpath(path, str(cache_dir)).replace(os.sep, "/"))
        except Exception:
            traceback.print_exc()
            continue
        if os.path.isfile(path):
            image.reload()
            fixed += 1
    return fixed


# --------------------------------------------------------------------------
# Redesenho
# --------------------------------------------------------------------------

def _context():
    import bpy
    return bpy.context


def redraw_view3d(context=None):
    """tag_redraw em toda 3D View (todas as janelas)."""
    try:
        import bpy
        wm = (context or bpy.context).window_manager
    except Exception:
        return
    for window in (wm.windows if wm else ()):
        screen = getattr(window, "screen", None)
        for area in (screen.areas if screen else ()):
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _refresh_all():
    for provider in present():
        _call(_cb(provider, "refresh"))
    redraw_view3d()
