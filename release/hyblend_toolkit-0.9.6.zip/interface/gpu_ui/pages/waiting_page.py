"""Tela do núcleo sem addon com tela (o Anim): o Toolkit é só a base, as ferramentas ficam nos addons + a aba Info."""

from ..widgets import Paragraph, card
from .. import classic_module
from . import info_page


def build(ui):
    t = ui.t
    notice = card(
        Paragraph(t("panel.core_waiting_body"), size=11),
        ui.url_button("waiting.get", classic_module().ADDONS_URL, t("panel.core_waiting_button"),
                      icon="link", image=info_page.brand_icon("github")),
        title=t("panel.core_waiting_title"), icon="info",
    )
    return [notice] + info_page.build(ui)
