"""Ícones procedurais de RESERVA do Character Creator (sem a pasta do jogo).

Os desenhos são os MESMOS de antes da troca de framework (eram o
framework/icons.py antigo do CC): registrados POR CIMA dos do framework
unificado (framework/icons.py, igual nos 3 addons Hyblend), então o
visual do CC não muda. Importado por gpu_ui.register() (_install_image_icons).

Cada ícone é uma função `f(x, y) -> bool` com x, y em [-1, 1] (Y para
cima): True = o ponto é pintado. No Character Creator eles são RESERVA:
tudo que tem ícone real do jogo usa o PNG real (ver data.py).
"""

import math

from .framework import icons as _framework_icons


def icon(*names):
    return _framework_icons.icon(*names)


def seg(px, py, ax, ay, bx, by):
    """Distância do ponto ao segmento AB."""
    dx, dy = bx - ax, by - ay
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
    return math.hypot(px - (ax + dx * t), py - (ay + dy * t))


# --------------------------------------------------------------------------
# Do protótipo
# --------------------------------------------------------------------------

@icon("dot")
def _dot(x, y):
    return math.hypot(x, y) <= 0.3


@icon("sparkle")
def _sparkle(x, y):      # estrela de 4 pontas = astroide |x|^(2/3) + |y|^(2/3) <= r^(2/3)
    big = abs(x + 0.14) ** 0.66 + abs(y + 0.14) ** 0.66 <= 0.84 ** 0.66
    return big or abs(x - 0.6) ** 0.66 + abs(y - 0.6) ** 0.66 <= 0.36 ** 0.66


@icon("box")
def _box(x, y):
    m = max(abs(x), abs(y))
    return 0.56 <= m <= 0.78 or (abs(y - 0.12) < 0.08 and abs(x) < 0.6)


@icon("search")
def _search(x, y):
    return (abs(math.hypot(x + 0.14, y - 0.14) - 0.46) < 0.1
            or seg(x, y, 0.22, -0.22, 0.74, -0.74) < 0.11)


@icon("circle")
def _circle(x, y):
    return math.hypot(x, y) <= 0.66


@icon("sun")
def _sun(x, y):
    r = math.hypot(x, y)
    a = math.atan2(y, x) % (math.pi / 4)
    return r <= 0.38 or (0.58 < r < 0.86 and min(a, math.pi / 4 - a) * r < 0.07)


@icon("camera")
def _camera(x, y):
    return (-0.78 <= x <= 0.3 and abs(y) <= 0.42) or \
           (0.3 < x <= 0.82 and abs(y) <= 0.12 + (x - 0.3) * 0.6)


@icon("check")
def _check(x, y):
    return (seg(x, y, -0.62, 0.0, -0.18, -0.46) < 0.13
            or seg(x, y, -0.18, -0.46, 0.66, 0.5) < 0.13)


@icon("move")
def _move(x, y):         # cruz com setas (pan)
    arm = (abs(x) < 0.08 and abs(y) < 0.72) or (abs(y) < 0.08 and abs(x) < 0.72)
    tip = min(abs(x) + abs(y - 0.62), abs(x) + abs(y + 0.62),
              abs(y) + abs(x - 0.62), abs(y) + abs(x + 0.62)) < 0.26
    return arm or tip


@icon("persp")
def _persp(x, y):        # trapézio (perspectiva)
    return abs(y) <= 0.55 and abs(abs(x) - (0.35 + 0.35 * (y + 0.55) / 1.1)) < 0.11 \
        or (abs(abs(y) - 0.55) < 0.1 and abs(x) <= 0.35 + 0.35 * (y + 0.55) / 1.1)


@icon("ortho")
def _ortho(x, y):        # quadrado (ortográfica)
    return abs(max(abs(x), abs(y)) - 0.58) < 0.1


def _padlock(opened):
    def shape(x, y):
        body = abs(x) <= 0.55 and -0.75 <= y <= 0.05
        shift = 0.38 if opened else 0.0
        shackle = y > 0.05 and abs(math.hypot(x - shift, y - 0.12) - 0.36) < 0.09 \
            and (y > 0.12 or not opened or x > 0)
        return body or shackle
    return shape


icon("lock")(_padlock(False))
icon("unlock")(_padlock(True))


@icon("x")
def _x(x, y):
    return seg(x, y, -0.55, -0.55, 0.55, 0.55) < 0.14 or seg(x, y, -0.55, 0.55, 0.55, -0.55) < 0.14


@icon("chevron")
def _chevron(x, y):      # ">" fino
    return seg(x, y, -0.3, 0.6, 0.3, 0.0) < 0.15 or seg(x, y, 0.3, 0.0, -0.3, -0.6) < 0.15


@icon("caret")
def _caret(x, y):        # triângulo cheio apontando para a direita
    return -0.35 <= x <= 0.5 and abs(y) <= (0.5 - x) * 0.6


@icon("link")
def _link(x, y):         # dois elos de corrente na diagonal
    a = seg(x, y, -0.5, -0.5, -0.08, -0.08)
    b = seg(x, y, 0.08, 0.08, 0.5, 0.5)
    return abs(a - 0.24) < 0.09 or abs(b - 0.24) < 0.09 or seg(x, y, -0.15, -0.15, 0.15, 0.15) < 0.09


# --------------------------------------------------------------------------
# Extras do Hyblend CC (reserva: sem ícone real do jogo equivalente)
# --------------------------------------------------------------------------

@icon("chevron_down")
def _chevron_down(x, y):
    return seg(x, y, -0.6, 0.3, 0.0, -0.3) < 0.15 or seg(x, y, 0.0, -0.3, 0.6, 0.3) < 0.15


@icon("chevron_up")
def _chevron_up(x, y):
    return seg(x, y, -0.6, -0.3, 0.0, 0.3) < 0.15 or seg(x, y, 0.0, 0.3, 0.6, -0.3) < 0.15


@icon("gear")
def _gear(x, y):
    r = math.hypot(x, y)
    a = math.atan2(y, x) % (math.pi / 4)
    tooth = min(a, math.pi / 4 - a) * r < 0.14 and r < 0.9
    return (0.3 < r < 0.66) or (tooth and r >= 0.66)


@icon("rig")
def _rig(x, y):          # boneco de palito (armature)
    return (math.hypot(x, y - 0.55) < 0.22
            or seg(x, y, 0.0, 0.33, 0.0, -0.3) < 0.1
            or seg(x, y, -0.55, 0.1, 0.55, 0.1) < 0.09
            or seg(x, y, 0.0, -0.3, -0.45, -0.85) < 0.1
            or seg(x, y, 0.0, -0.3, 0.45, -0.85) < 0.1)


@icon("user")
def _user(x, y):         # cabeça + ombros
    return math.hypot(x, y - 0.35) < 0.3 or (y < -0.05 and math.hypot(x, y + 0.75) < 0.62 and y > -0.8)


@icon("bookmark")
def _bookmark(x, y):     # preset
    return abs(x) <= 0.5 and -0.8 <= y <= 0.8 and not (y < -0.2 and abs(x) < (-0.2 - y) * 0.8)


@icon("save")
def _save(x, y):
    return (abs(max(abs(x), abs(y)) - 0.66) < 0.11) or (abs(x) < 0.35 and 0.2 < y < 0.55)


@icon("load")
def _load(x, y):         # seta pra baixo numa bandeja
    return (seg(x, y, 0.0, 0.8, 0.0, -0.3) < 0.11 or seg(x, y, -0.4, 0.05, 0.0, -0.35) < 0.11
            or seg(x, y, 0.4, 0.05, 0.0, -0.35) < 0.11 or (abs(y + 0.7) < 0.09 and abs(x) < 0.75))


@icon("trash")
def _trash(x, y):
    return ((abs(abs(x) - 0.45 + (y + 0.8) * 0.1) < 0.1 and -0.8 < y < 0.4)
            or (abs(y + 0.8) < 0.09 and abs(x) < 0.4) or (abs(y - 0.5) < 0.09 and abs(x) < 0.7)
            or (abs(y - 0.68) < 0.08 and abs(x) < 0.25))


@icon("refresh")
def _refresh(x, y):
    r = math.hypot(x, y)
    ang = math.atan2(y, x)
    ring = abs(r - 0.55) < 0.11 and not (0.2 < ang < 1.1)
    head = seg(x, y, 0.62, 0.62, 0.62, 0.15) < 0.1 or seg(x, y, 0.62, 0.15, 0.15, 0.15) < 0.1
    return ring or head


@icon("folder")
def _folder(x, y):
    return (abs(x) <= 0.8 and -0.65 <= y <= 0.4) or (-0.8 <= x <= -0.1 and 0.4 < y <= 0.6)


@icon("plus")
def _plus(x, y):
    return (abs(x) < 0.12 and abs(y) < 0.7) or (abs(y) < 0.12 and abs(x) < 0.7)


@icon("info")
def _info(x, y):
    return (abs(x) < 0.12 and -0.7 < y < 0.2) or math.hypot(x, y - 0.5) < 0.15


@icon("error")
def _error(x, y):
    return (abs(x) < 0.12 and -0.2 < y < 0.75) or math.hypot(x, y + 0.6) < 0.15
