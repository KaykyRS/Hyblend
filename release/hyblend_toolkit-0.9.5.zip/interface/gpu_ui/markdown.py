"""Markdown (estilo GitHub) -> blocos com trechos estilizados. Python puro.

Usado pelo Changelog: a descrição de cada release do GitHub é Markdown.

Blocos:   ("h", nível 1-6, trechos)        # Título  /  Título + === ou ---
          ("p", trechos)                    parágrafo (linhas seguidas se juntam)
          ("li", profundidade, marcador, marcado, trechos)
                                            - * + item / 1. item / - [ ] tarefa
          ("quote", trechos)                > citação
          ("code", [linhas])                ``` bloco ``` ou recuo de 4 espaços
          ("hr",)                           --- *** ___
          ("table", [[trechos por célula], ...], tem_cabeçalho)
Trechos:  (texto, estilos, url) -- estilos é um frozenset com "b" (negrito),
          "i" (itálico), "s" (riscado), "code" e "link" (url preenchida).

Ignorados de propósito: imagens ![...](...), tags HTML (o texto dentro fica),
emoji (as fontes do jogo não têm: virariam quadrados).
"""

import html
import re

_EMOJI = re.compile("[\U0001F000-\U0001FAFF\U00002600-\U000027BF\U0001F900-\U0001F9FF️‍]")
_SHORTCODE = re.compile(r"(?<!\w):[a-z0-9_+\-]+:(?!\w)")       # :tada: do GitHub

# ---------------------------------------------------------------- inline

_INLINE = re.compile(
    r"(?P<esc>\\[\\`*_{}\[\]()#+\-.!~>|])"
    r"|(?P<code>`+)(?P<code_txt>.+?)(?P=code)"
    r"|(?P<img>!\[[^\]]*\]\([^)]*\))"
    r"|\[(?P<link_txt>[^\]]+)\]\((?P<link_url>[^)\s]+)(?:\s+\"[^\"]*\")?\)"
    r"|<(?P<auto>https?://[^>\s]+)>"
    r"|(?P<bare>https?://[^\s<>()\[\]]+[^\s<>()\[\].,;:!?'\"])"
    r"|(?P<bi>\*\*\*|___)(?=\S)(?P<bi_txt>.+?)(?<=\S)(?P=bi)"
    r"|(?P<b>\*\*|__)(?=\S)(?P<b_txt>.+?)(?<=\S)(?P=b)"
    r"|~~(?=\S)(?P<s_txt>.+?)(?<=\S)~~"
    r"|\*(?=\S)(?P<i_txt>[^*]+?)(?<=\S)\*"
    r"|(?<![A-Za-z0-9_])_(?=\S)(?P<u_txt>[^_]+?)(?<=\S)_(?![A-Za-z0-9_])"
    r"|(?P<tag></?[A-Za-z][^>]*>)"
)


def inline(text, styles=frozenset(), url=None):
    """Texto de uma linha/parágrafo -> [(texto, estilos, url)]."""
    out = []
    pos = 0

    def plain(chunk):
        if chunk:
            chunk = _SHORTCODE.sub("", _EMOJI.sub("", html.unescape(chunk)))
            if chunk:
                out.append((chunk, styles, url))

    for m in _INLINE.finditer(text):
        plain(text[pos:m.start()])
        pos = m.end()
        g = m.groupdict()
        if g["esc"]:
            out.append((g["esc"][1], styles, url))
        elif g["code"]:
            out.append((g["code_txt"].strip(), styles | {"code"}, url))
        elif g["img"]:
            continue                                     # imagens: fora
        elif g["link_txt"] is not None:
            out.extend(inline(g["link_txt"], styles | {"link"}, g["link_url"]))
        elif g["auto"] or g["bare"]:
            link = g["auto"] or g["bare"]
            out.append((link, styles | {"link"}, link))
        elif g["bi_txt"] is not None:
            out.extend(inline(g["bi_txt"], styles | {"b", "i"}, url))
        elif g["b_txt"] is not None:
            out.extend(inline(g["b_txt"], styles | {"b"}, url))
        elif g["s_txt"] is not None:
            out.extend(inline(g["s_txt"], styles | {"s"}, url))
        elif g["i_txt"] is not None:
            out.extend(inline(g["i_txt"], styles | {"i"}, url))
        elif g["u_txt"] is not None:
            out.extend(inline(g["u_txt"], styles | {"i"}, url))
        elif g["tag"]:
            if re.match(r"<br\s*/?>", g["tag"], re.I):
                out.append(("\n", styles, url))
            # outras tags HTML: some só a tag, o texto em volta fica
    plain(text[pos:])
    return _merge(out)


def _merge(spans):
    merged = []
    for text, styles, url in spans:
        if "code" not in styles:                          # `código` mantém os espaços
            text = re.sub(r"[ \t]{2,}", " ", text)
        if merged and merged[-1][1] == styles and merged[-1][2] == url:
            merged[-1] = (merged[-1][0] + text, styles, url)
        else:
            merged.append((text, frozenset(styles), url))
    # bordas do bloco sem espaço (sobra de emoji/tag removidos)
    if merged:
        merged[0] = (merged[0][0].lstrip(), merged[0][1], merged[0][2])
        merged[-1] = (merged[-1][0].rstrip(), merged[-1][1], merged[-1][2])
    return [s for s in merged if s[0]]


# ---------------------------------------------------------------- blocos

_HEADING = re.compile(r"^ {0,3}(#{1,6})[ \t]+(.*?)[ \t]*#*[ \t]*$")
_HR = re.compile(r"^ {0,3}((\*[ \t]*){3,}|(-[ \t]*){3,}|(_[ \t]*){3,})$")
_LIST = re.compile(r"^(?P<indent>[ \t]*)(?P<marker>[-*+]|\d{1,9}[.)])[ \t]+(?P<rest>.*)$")
_TASK = re.compile(r"^\[(?P<mark>[ xX])\][ \t]+(?P<rest>.*)$")
_QUOTE = re.compile(r"^ {0,3}>[ \t]?(.*)$")
_FENCE = re.compile(r"^ {0,3}(```|~~~)")
_SETEXT = re.compile(r"^ {0,3}(=+|-+)[ \t]*$")
_TABLE_SEP = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")


def _indent_width(text):
    return len(text.expandtabs(4))


def _cells(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [inline(c.strip()) for c in re.split(r"(?<!\\)\|", line)]


def parse(text):
    lines = (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
    blocks = []
    para = []

    def flush():
        if para:
            joined = " ".join(s.strip() for s in para)
            spans = inline(joined)
            if any(t.strip() for t, _, _ in spans):
                blocks.append(("p", spans))
            para.clear()

    indents = []                # recuos das listas abertas (profundidade = posição na pilha)
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped:
            flush()
            i += 1
            continue
        if not _LIST.match(line) and not line[:1] in " \t":
            indents.clear()                               # bloco fora de lista fecha as listas
        if _FENCE.match(line):                            # ``` bloco de código ```
            flush()
            fence = _FENCE.match(line).group(1)
            code = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith(fence):
                code.append(lines[i].rstrip())
                i += 1
            blocks.append(("code", code))
            i += 1
            continue
        if para and _SETEXT.match(line):                  # Título\n=== (ou ---)
            level = 1 if line.strip().startswith("=") else 2
            spans = inline(" ".join(s.strip() for s in para))
            para.clear()
            blocks.append(("h", level, spans))
            i += 1
            continue
        heading = _HEADING.match(line)
        if heading:
            flush()
            blocks.append(("h", len(heading.group(1)), inline(heading.group(2))))
            i += 1
            continue
        if _HR.match(line):
            flush()
            blocks.append(("hr",))
            i += 1
            continue
        if "|" in line and i + 1 < len(lines) and _TABLE_SEP.match(lines[i + 1]):   # tabela
            flush()
            rows = [_cells(line)]
            i += 2
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                rows.append(_cells(lines[i]))
                i += 1
            blocks.append(("table", rows, True))
            continue
        quote = _QUOTE.match(line)
        if quote:
            flush()
            text_lines = []
            while i < len(lines) and _QUOTE.match(lines[i]):
                text_lines.append(_QUOTE.match(lines[i]).group(1))
                i += 1
            for chunk in "\n".join(text_lines).split("\n\n"):
                if chunk.strip():
                    blocks.append(("quote", inline(" ".join(s.strip() for s in chunk.split("\n")))))
            continue
        item = _LIST.match(line)
        # no meio de parágrafo, número só abre lista se for "1." (como no GitHub):
        # "Lançado em\n2026. Aproveite" continua sendo parágrafo
        if item and not (para and item.group("marker")[0].isdigit() and item.group("marker")[:-1] != "1"):
            flush()
            # Profundidade pelo RECUO RELATIVO (2 ou 4 espaços por nível, tanto faz):
            # recuo maior que o do item aberto = um nível abaixo.
            indent = _indent_width(item.group("indent"))
            while indents and indent < indents[-1]:
                indents.pop()
            if not indents or indent > indents[-1]:
                indents.append(indent)
            depth = min(3, len(indents) - 1)
            marker = item.group("marker")
            rest = item.group("rest")
            checked = None
            task = _TASK.match(rest)
            if task:
                checked, rest = task.group("mark") != " ", task.group("rest")
            parts = [rest]
            i += 1
            # continuação do item (linha recuada que não é outro item/bloco)
            while (i < len(lines) and lines[i].strip() and lines[i][:1] in " \t" and not _LIST.match(lines[i])
                   and not _FENCE.match(lines[i])):
                parts.append(lines[i].strip())
                i += 1
            ordered = marker[:-1] if marker[0].isdigit() else None
            blocks.append(("li", depth, ordered, checked, inline(" ".join(parts))))
            continue
        if line.startswith(("    ", "\t")) and not para:          # código recuado
            code = []
            while i < len(lines) and (lines[i].startswith(("    ", "\t")) or not lines[i].strip()):
                code.append(lines[i][4:] if lines[i].startswith("    ") else lines[i].lstrip("\t"))
                i += 1
            while code and not code[-1].strip():
                code.pop()
            blocks.append(("code", code))
            continue
        para.append(line)
        i += 1
    flush()
    return blocks


