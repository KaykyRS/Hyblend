import contextlib
import itertools
import json
import math
import os
import re

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Armature, Operator, PropertyGroup
from mathutils import Quaternion, Vector

from ..common import (
    game_found,
    BONE_RENAMED_FROM_PROP,
    BONE_RIGGER_CREATED_PROP,
    BONE_SHAPE_JSON_PROP,
    BONE_SHAPE_OFFSET_PROP,
    FPS_HYTALE,
    SUFFIX_CTRL,
    SUFFIX_IK,
    SUFFIX_MCH,
    UNIT_SCALE_DEFAULT,
    armature_model_format,
    bone_file_name,
    effective_unit_scale,
    import_rest_matrix,
    is_active_armature,
    quat_to_dict,
    shape_offsets,
    vec3,
    vec_to_dict,
)
from ..rigger.constants import PROP_RIG_LAYER
from ..anim.stretch_fit import export_delta, file_position
from ..anim.blocky_curves import KIND_ORIENTATION, KIND_POSITION, KIND_STRETCH, Channel
from ..translations import (
    get_language,
    localized_props,
    register_localized_class,
    register_refresh_hook,
    tooltip,
    tr,
    unregister_localized_class,
    unregister_refresh_hook,
)

# --- .blockyanim (hytale-blockbench-plugin, blockyanim.ts): duration em frames a 60 FPS; delta relativo à rest no espaço do pai ---
# position/shapeStretch {x,y,z}, orientation {x,y,z,w}, shapeUvOffset {x,y} em pixels do atlas.

# Bones originais = os da Export Bone Collection (sufixo de nome não é confiável).
EXPORT_COLLECTION_NAME_DEFAULT = "Hytale Export"
# Use Original Bone Positions do último export do modelo: o .blockyanim mede contra a mesma rest.
ARMATURE_ORIGINAL_POSITIONS_PROP = "hytale_export_original_positions"
UV_OFFSET_SOURCE_BONE_DEFAULT = "ui.texture_picker"
UV_OFFSET_TARGET_BONE_DEFAULT = ""

# Sufixos do fallback sem a Export Bone Collection (de common.py).
CONTROL_SUFFIXES = (SUFFIX_MCH, SUFFIX_CTRL, SUFFIX_IK)


def is_original_bone_name(name):
    return not any(name.endswith(suf) for suf in CONTROL_SUFFIXES)


# Configurações de export guardadas na Armature (painel Export); reatribuídas no register (ver _redo_armature_property_assignments).
def _export_settings_props(lang):
    return {
        "export_collection_name": StringProperty(
            name="Export Bone Collection",
            description=tr("exporter.prop.export_settings_collection_name", lang),
            default=EXPORT_COLLECTION_NAME_DEFAULT,
        ),
    }


@localized_props(_export_settings_props)
class HYTALE_export_settings(PropertyGroup):
    pass


# Um Texture Picker exportado (independente dos outros); "name" espelha uv_offset_target_bone pra lista.
def _texture_picker_export_item_props(lang):
    return {
        "uv_offset_source_bone": StringProperty(
            name="UV Control Bone",
            description=tr("exporter.prop.texture_picker_source_bone", lang),
            default=UV_OFFSET_SOURCE_BONE_DEFAULT,
        ),
        "uv_offset_target_bone": StringProperty(
            name="Target Bone (shapeUvOffset)",
            description=tr("exporter.prop.texture_picker_target_bone", lang),
            default=UV_OFFSET_TARGET_BONE_DEFAULT,
        ),
        # Bones extras (vírgula) que recebem o mesmo shapeUvOffset; o Create Texture Picker preenche.
        "uv_offset_target_bones_extra": StringProperty(
            name="Companion Target Bones (shapeUvOffset)",
            description=tr("exporter.prop.texture_picker_target_bones_extra", lang),
            default="",
        ),
        "uv_offset_step_x": FloatProperty(
            name="Grid Step X",
            description=tr("exporter.prop.texture_picker_step_x", lang),
            default=0.1,
        ),
        "uv_offset_px_x": FloatProperty(
            name="Pixels per Step X",
            description=tr("exporter.prop.texture_picker_px_x", lang),
            default=20.0,
        ),
        "uv_offset_step_y": FloatProperty(
            name="Grid Step Y",
            description=tr("exporter.prop.texture_picker_step_y", lang),
            default=-0.045,
        ),
        "uv_offset_px_y": FloatProperty(
            name="Pixels per Step Y",
            description=tr("exporter.prop.texture_picker_px_y", lang),
            default=-10.0,
        ),
    }


@localized_props(_texture_picker_export_item_props)
class HYTALE_texture_picker_export_item(PropertyGroup):
    pass


def get_export_settings(armature_obj):
    """armature.data.hytale_export_settings, ou os defaults se ainda não existir."""
    data = getattr(armature_obj, "data", None)
    settings = getattr(data, "hytale_export_settings", None)
    if settings is None:
        # Instância "solta" (não vinculada a nenhuma Armature real) só
        # pra fornecer os defaults -- nunca é lida/gravada de verdade.
        settings = HYTALE_export_settings()
    return settings


def get_texture_picker_exports(armature_obj):
    """armature.data.hytale_texture_picker_exports, ou lista vazia (nunca None)."""
    data = getattr(armature_obj, "data", None)
    exports = getattr(data, "hytale_texture_picker_exports", None)
    return exports if exports is not None else []


# Lista + Add/Remove dos Texture Pickers exportados (normalmente preenchida pelo Create Texture Picker).


class HYTALE_UL_texture_picker_exports(bpy.types.UIList):
    bl_idname = "HYTALE_UL_texture_picker_exports"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=item.uv_offset_target_bone or "(no target bone)", icon="IMAGE_DATA")


class EXPORT_OT_texture_picker_export_add(Operator):
    """Adiciona uma entrada vazia (normalmente o Create Texture Picker já cuida)."""

    bl_idname = "armature.hytale_texture_picker_export_add"
    bl_label = "Add Texture Picker Export"
    description = tooltip("exporter.tooltip.texture_picker_export_add")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def execute(self, context):
        armature = context.active_object.data
        exports = armature.hytale_texture_picker_exports
        item = exports.add()
        item.uv_offset_source_bone = UV_OFFSET_SOURCE_BONE_DEFAULT
        armature.hytale_texture_picker_exports_index = len(exports) - 1
        return {"FINISHED"}


class EXPORT_OT_texture_picker_export_remove(Operator):
    """Remove uma instância da lista pelo índice (padrão: a ativa)."""

    bl_idname = "armature.hytale_texture_picker_export_remove"
    bl_label = "Remove Texture Picker Export"
    description = tooltip("exporter.tooltip.texture_picker_export_remove")
    bl_options = {"REGISTER", "UNDO"}

    index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return is_active_armature(context) and len(obj.data.hytale_texture_picker_exports) > 0

    def execute(self, context):
        armature = context.active_object.data
        exports = armature.hytale_texture_picker_exports
        index = self.index if self.index >= 0 else armature.hytale_texture_picker_exports_index
        if 0 <= index < len(exports):
            exports.remove(index)
            armature.hytale_texture_picker_exports_index = max(0, min(armature.hytale_texture_picker_exports_index, len(exports) - 1))
        return {"FINISHED"}


def exported_bone_name(armature_obj, name, use_original_names=False):
    """Nome gravado no arquivo: o original do import (BONE_ORIGINAL_NAME_PROP / Use Original Names) ou o do Blender."""
    bone = armature_obj.data.bones.get(name)
    if bone is None:
        return name
    if bone.get(BONE_RENAMED_FROM_PROP) and not use_original_names:
        return name
    return bone_file_name(bone) or name


def bones_in_collection(armature_obj, collection_name):
    """Nomes dos bones da Bone Collection; None se ela não existe (diferente de vazia)."""
    data = armature_obj.data
    collections = getattr(data, "collections", None)
    if collections is None or collection_name not in collections:
        return None
    names = set()
    for bone in data.bones:
        if any(c.name == collection_name for c in bone.collections):
            names.add(bone.name)
    return names


def resolve_exportable_bone_names(operator, obj, export_settings):
    """Bones originais pela Export Bone Collection (sem ela, por sufixo, com aviso); None se não achar nenhum."""
    collection_name = export_settings.export_collection_name
    collection_names = bones_in_collection(obj, collection_name)
    if collection_names is not None:
        if not collection_names:
            operator.report(
                {"ERROR"},
                f"Bone Collection '{collection_name}' exists but has "
                f"no bones assigned to it.",
            )
            return None
        return collection_names

    # Bone gerado pelo rig (camadas, Origin automático, Root "New Bone") não existe no modelo.
    exportable_names = {
        b.name for b in obj.data.bones
        if is_original_bone_name(b.name) and not b.get(BONE_RIGGER_CREATED_PROP) and PROP_RIG_LAYER not in b.keys()
    }
    operator.report(
        {"WARNING"},
        f"Bone Collection '{collection_name}' not found -- "
        f"falling back to guessing bones by name suffix (_MCH/_CTRL/_IK). "
        f"Set it in the 'Hytale Export' panel (Object Properties).",
    )
    if not exportable_names:
        operator.report({"ERROR"}, "No 'original' (suffix-less) bones found.")
        return None
    return exportable_names


def collect_meshes_recursive(collection, out, _seen_collections=None):
    """Junta em `out` toda malha de `collection` e sub-collections (sem loop em collection linkada em si mesma)."""
    if _seen_collections is None:
        _seen_collections = set()
    if collection.name in _seen_collections:
        return
    _seen_collections.add(collection.name)
    for obj in collection.objects:
        if obj.type == "MESH":
            out.add(obj)
    for child in collection.children:
        collect_meshes_recursive(child, out, _seen_collections)


def gather_character_meshes(armature_obj, include_attachments=True):
    """Malhas de referência da Armature, pelas collections que o importer gravou; set vazio se não houver."""
    meshes = set()
    main_name = armature_obj.get("hytale_meshes_main_collection")
    if main_name:
        main_collection = bpy.data.collections.get(main_name)
        if main_collection is not None:
            collect_meshes_recursive(main_collection, meshes)
    if include_attachments:
        attach_name = armature_obj.get("hytale_meshes_attachments_collection")
        if attach_name:
            attach_collection = bpy.data.collections.get(attach_name)
            if attach_collection is not None:
                collect_meshes_recursive(attach_collection, meshes)
    return meshes


@contextlib.contextmanager
def temporary_deform_flags(armature_data, exportable_names):
    """Durante o bloco, use_deform só nos bones originais (FBX deform only); restaura no fim, mesmo com erro."""
    original = {bone.name: bone.use_deform for bone in armature_data.bones}
    try:
        for bone in armature_data.bones:
            bone.use_deform = bone.name in exportable_names
        yield
    finally:
        for bone in armature_data.bones:
            if bone.name in original:
                bone.use_deform = original[bone.name]


def sample_uv_offset_px(control_pbone, opts):
    """Location do bone de controle -> offset em pixels (snap igual ao do shader), inteiros: o jogo recusa "32.0"."""
    loc = control_pbone.location
    step_x = opts.uv_offset_step_x
    step_y = opts.uv_offset_step_y
    px_x = round(loc.x / step_x) * opts.uv_offset_px_x if step_x != 0 else 0.0
    px_y = round(loc.y / step_y) * opts.uv_offset_px_y if step_y != 0 else 0.0
    return int(round(px_x)), int(round(px_y))


# Escolha dos keyframes: amostra todo frame e guarda só os keys que mudam a curva do jogo, por bone e canal.

# Quanto o arquivo pode se afastar da pose do Blender: abaixo do que se vê.
EXPORT_TOLERANCE_PX = 0.02
EXPORT_TOLERANCE_DEG = 0.05
EXPORT_TOLERANCE_STRETCH = 0.0005
# My Keyframes Only: erro aceito antes de pôr um key extra (px / graus / escala). Apertado: o erro de cada
# bone soma na cadeia (com 2° a spine e a cabeça tremiam).
KEYS_TOLERANCE_PX = 0.05
KEYS_TOLERANCE_DEG = 0.25
KEYS_TOLERANCE_STRETCH = 0.002
# Canal que nunca sai disso vira identidade (ruído de float/IK).
NOISE_FLOOR_PX = 0.001
NOISE_FLOOR_DEG = 0.05
NOISE_FLOOR_STRETCH = 0.001
# Ruído abaixo disso sai exato (0 / 1): o plugin do Blockbench lê ângulo minúsculo ("1e-9") como vários graus.
SNAP_QUAT = 2e-4
SNAP_PX = 1e-4
SNAP_STRETCH = 1e-5
BLOCKBENCH_TINY_DEG = 1e-5  # ângulo (graus) que o JS escreveria em notação científica, com folga
OUTPUT_DECIMALS = 6


def fix_quaternion_sign(quat, prev_quat):
    """Alinha o sinal do quaternion com o frame anterior (senão o jogo interpola pelo caminho longo); o 1º com w >= 0."""
    if prev_quat is None:
        return -quat if quat.w < 0 else quat
    return -quat if quat.dot(prev_quat) < 0 else quat


def snap_noise(kind, value):
    """Valor com o ruído de conta tirado: componente quase parado vira 0 (rotação/posição) ou 1 (stretch)."""
    if kind == KIND_ORIENTATION:
        quat = Quaternion([value.w] + [0.0 if abs(c) < SNAP_QUAT else c for c in (value.x, value.y, value.z)])
        return quat.normalized()
    if kind == KIND_POSITION:
        return Vector([0.0 if abs(c) < SNAP_PX else c for c in value])
    return Vector([1.0 if abs(c - 1.0) < SNAP_STRETCH else c for c in value])


def _distance(kind, a, b):
    """Erro entre dois valores do canal, na unidade da tolerância dele."""
    if kind == KIND_ORIENTATION:
        angle = math.degrees(a.rotation_difference(b).angle)
        return min(angle, 360.0 - angle)
    return (a - b).length


def _tolerance(kind, loose=False):
    """Erro aceito do canal; `loose` = My Keyframes Only (menos keys extras, diferença ainda invisível)."""
    if loose:
        return {KIND_POSITION: KEYS_TOLERANCE_PX, KIND_ORIENTATION: KEYS_TOLERANCE_DEG}.get(
            kind, KEYS_TOLERANCE_STRETCH
        )
    return {KIND_POSITION: EXPORT_TOLERANCE_PX, KIND_ORIENTATION: EXPORT_TOLERANCE_DEG}.get(
        kind, EXPORT_TOLERANCE_STRETCH
    )


def _linear_keys(samples, kind):
    """Keys pra interpolação linear (Ramer-Douglas-Peucker): extremos + o frame mais longe da reta enquanto passar da tolerância."""
    n = len(samples)
    if n < 3:
        return list(range(n))
    tol = _tolerance(kind)
    keep = {0, n - 1}
    stack = [(0, n - 1)]
    while stack:
        start, end = stack.pop()
        if end <= start + 1:
            continue
        t0, v0 = samples[start]
        t1, v1 = samples[end]
        worst, worst_i = -1.0, -1
        for i in range(start + 1, end):
            t, v = samples[i]
            frac = (t - t0) / (t1 - t0) if t1 != t0 else 0.0
            ref = v0.slerp(v1, frac) if kind == KIND_ORIENTATION else v0.lerp(v1, frac)
            d = _distance(kind, v, ref)
            if d > worst:
                worst, worst_i = d, i
        if worst > tol:
            keep.add(worst_i)
            stack.append((start, worst_i))
            stack.append((worst_i, end))
    return sorted(keep)


def _value_dict(kind, value):
    return quat_to_dict(value) if kind == KIND_ORIENTATION else vec_to_dict(value)


def _blockbench_euler(x, y, z, w):
    """Graus que o plugin do Blockbench grava pra essa rotação (THREE.Euler.setFromQuaternion, ordem ZYX)."""
    n = math.sqrt(x * x + y * y + z * z + w * w) or 1.0
    x, y, z, w = x / n, y / n, z / n, w / n
    m31 = 2.0 * (x * z - w * y)
    angles = (
        math.atan2(2.0 * (y * z + w * x), 1.0 - 2.0 * (x * x + y * y)),
        math.asin(-max(-1.0, min(1.0, m31))),
        math.atan2(2.0 * (x * y + w * z), 1.0 - 2.0 * (y * y + z * z)),
    )
    return [math.degrees(a) for a in angles]


def _file_value(kind, value):
    """Valor como sai no arquivo; rotação arredondada e, se algum ângulo do Blockbench sair minúsculo (vira "1e-9",
    que ele lê como vários graus), mexida na última casa até não sair (erro ~0,0001°)."""
    if kind != KIND_ORIENTATION:
        return vec_to_dict(value)
    step = 10.0 ** -OUTPUT_DECIMALS
    base = [round(c, OUTPUT_DECIMALS) for c in (value.x, value.y, value.z, value.w)]
    for nudge in itertools.product((0, 1, -1), repeat=4):
        candidate = [round(c + d * step, OUTPUT_DECIMALS) + 0.0 for c, d in zip(base, nudge)]
        if not any(0.0 < abs(a) < BLOCKBENCH_TINY_DEG for a in _blockbench_euler(*candidate)):
            base = candidate
            break
    return dict(zip("xyzw", base))


def _game_keys(samples, candidates, kind, duration, looping, types):
    """Keys que o jogo (com esses tipos) leva até a curva do Blender: os `candidates` menos os que não mudam a curva,
    mais o pior frame de cada trecho que ainda passa da tolerância."""
    tol = _tolerance(kind, loose=True)
    keep = sorted(set(candidates) | {0, len(samples) - 1})

    def channel(indices):
        keys = [
            {"time": samples[i][0], "delta": _value_dict(kind, samples[i][1]), "interpolationType": types[i]}
            for i in indices
        ]
        return Channel(keys, kind, duration, looping)

    def local_error(indices, lo, hi):
        curve = channel(indices)
        return max((_distance(kind, curve.evaluate(t), v) for t, v in samples[lo:hi + 1]), default=0.0)

    changed = True
    while changed and len(keep) > 2:
        changed = False
        j = 1
        while j < len(keep) - 1:
            # Catmull-Rom olha 2 keys pra cada lado; perto das pontas o loop
            # dá a volta, então confere tudo.
            near_edge = j < 3 or j > len(keep) - 4
            lo = 0 if near_edge else keep[j - 2]
            hi = len(samples) - 1 if near_edge else keep[j + 2]
            candidate = keep[:j] + keep[j + 1:]
            if local_error(candidate, lo, hi) <= max(tol, local_error(keep, lo, hi)):
                keep = candidate
                changed = True
            else:
                j += 1

    while True:
        curve = channel(keep)
        errors = [_distance(kind, curve.evaluate(t), v) for t, v in samples]
        added = []
        for a, b in zip(keep, keep[1:]):
            worst = max(range(a + 1, b), key=errors.__getitem__, default=None)
            if worst is not None and errors[worst] > tol:
                added.append(worst)
        if not added:
            return keep
        keep = sorted(set(keep) | set(added))


def _is_still(samples, i, kind):
    """O Blender quase parado nesse frame (ali o ease da rotação "smooth" do jogo combina)."""
    tol = _tolerance(kind)
    near = [samples[j][1] for j in (i - 1, i + 1) if 0 <= j < len(samples)]
    return all(_distance(kind, samples[i][1], v) < tol for v in near)


def _smooth_keys(samples, candidates, kind, duration, looping):
    """My Keyframes Only: (índices, tipos) nos frames chaveados + keys extras só onde o jogo se afastaria do Blender;
    fica a variante com menos keys (tudo smooth, tudo linear e, na rotação, smooth só onde o Blender para)."""
    n = len(samples)
    variants = [["smooth"] * n, ["linear"] * n]
    if kind == KIND_ORIENTATION:
        variants.append(["smooth" if _is_still(samples, i, kind) else "linear" for i in range(n)])
    best = None
    for types in variants:
        keep = _game_keys(samples, candidates, kind, duration, looping, types)
        if best is None or len(keep) < len(best[0]):
            best = (keep, [types[i] for i in keep])
    return best


def local_matrix(matrix_by_bone, bone_name, parent_name):
    """Matriz relativa ao pai, dado um dict {nome: matriz em armature-space}.
    Bone sem pai: 'local' == 'armature space' (mesma convenção do import)."""
    m = matrix_by_bone[bone_name]
    if parent_name is None:
        return m
    return matrix_by_bone[parent_name].inverted() @ m


def rest_matrices(armature_obj):
    """Matriz de repouso (armature-space) de cada bone, a partir de
    Bone.matrix_local (não muda com a pose atual, não precisa de Edit Mode)."""
    out = {}
    for bone in armature_obj.data.bones:
        out[bone.name] = bone.matrix_local.copy()
    return out


def pose_matrices(armature_obj):
    """Matriz da pose atual (pós-constraints, armature-space) de cada bone; chamar depois de frame_set."""
    out = {}
    for pbone in armature_obj.pose.bones:
        out[pbone.name] = pbone.matrix.copy()
    return out


def original_rest_matrices(armature_obj, rest_by_bone, bone_names):
    """Use Original Bone Positions: troca a rest atual pela do import (BONE_IMPORT_REST_PROP); devolve os bones trocados."""
    missing = []
    for name in bone_names:
        bone = armature_obj.data.bones.get(name)
        imported = import_rest_matrix(bone) if bone is not None else None
        if imported is None:
            missing.append(name)
        else:
            rest_by_bone[name] = imported
    return missing


def armature_unit_scale(armature_obj, character_unit_scale):
    """Escala efetiva: Unit Scale de Character (64/bloco); Prop (32/bloco) usa o dobro."""
    return effective_unit_scale(character_unit_scale, armature_model_format(armature_obj))


def compute_deltas(armature_obj, rest_by_bone, pose_by_bone, exportable_names, unit_scale, offsets=None):
    """(posição, quaternion, stretch) de cada bone como o jogo lê: contra o pai sem escala (o jogo não herda),
    posição no espaço do pai e stretch pelo centro da caixa (`offsets`, de shape_offsets)."""
    results = {}
    offsets = offsets or {}
    inv_scale = 1.0 / armature_unit_scale(armature_obj, unit_scale)
    for pbone in armature_obj.pose.bones:
        name = pbone.name
        if name not in exportable_names:
            continue
        parent_name = pbone.parent.name if pbone.parent else None
        rest_local = local_matrix(rest_by_bone, name, parent_name)
        parent = pose_by_bone[parent_name] if parent_name is not None else None
        pos, quat, scale = export_delta(
            parent, rest_local, pose_by_bone[name], offsets.get(name), offsets.get(parent_name)
        )
        results[name] = (file_position(rest_local, pos) * inv_scale, quat, scale)
    return results


# --- Amostragem de frames ---


def _iter_action_fcurves(action):
    """Toda F-Curve da Action: layers/strips/channelbags no 5.0+, Action.fcurves no 4.5."""
    if hasattr(action, "fcurves"):
        yield from action.fcurves
        return
    for layer in action.layers:
        for strip in layer.strips:
            if strip.type != "KEYFRAME":
                continue
            for channelbag in strip.channelbags:
                yield from channelbag.fcurves


def collect_all_keyframe_frames(action, frame_start, frame_end):
    """Frames com algum keyframe na Action (qualquer controle) dentro do range: candidatos do My Keyframes Only."""
    frames = set()
    for fcurve in _iter_action_fcurves(action):
        for kp in fcurve.keyframe_points:
            f = kp.co.x
            if frame_start <= f <= frame_end:
                frames.add(round(f))
    return frames


def frame_to_hytale_time(frame, frame_start, fps):
    """Frame do Blender -> 'time' do .blockyanim (inteiro a 60 FPS, 0 no início do range exportado)."""
    seconds = (frame - frame_start) / fps
    return round(seconds * FPS_HYTALE)


def sanitize_filename(name):
    """Nomes de Action podem ter caracteres inválidos em nome de arquivo
    (: / \\ etc) -- troca por '_'."""
    cleaned = re.sub(r'[<>:"/\\|?*]', "_", name).strip()
    return cleaned or "animation"


def round_floats_for_output(obj, decimals):
    """Arredonda todo float da estrutura (só encurta o texto do arquivo)."""
    if isinstance(obj, float):
        return round(obj, decimals) + 0.0  # + 0.0: -0.0 vira 0.0
    if isinstance(obj, dict):
        return {k: round_floats_for_output(v, decimals) for k, v in obj.items()}
    if isinstance(obj, list):
        return [round_floats_for_output(v, decimals) for v in obj]
    return obj


def _is_flat_dict(d):
    """True se 'd' só tem valores escalares (vira uma linha só)."""
    return isinstance(d, dict) and all(not isinstance(v, (dict, list)) for v in d.values())


def dump_pretty_blockyanim(content, indent=2):
    """JSON legível estilo Blockbench: dict só de escalares numa linha, o resto indentado."""

    def encode(o, level):
        pad = " " * (indent * level)
        pad_in = " " * (indent * (level + 1))
        if isinstance(o, dict):
            if not o:
                return "{}"
            if _is_flat_dict(o):
                items = ", ".join(f"{json.dumps(k)}: {json.dumps(v)}" for k, v in o.items())
                return "{" + items + "}"
            lines = [f"{pad_in}{json.dumps(k)}: {encode(v, level + 1)}" for k, v in o.items()]
            return "{\n" + ",\n".join(lines) + "\n" + pad + "}"
        if isinstance(o, list):
            if not o:
                return "[]"
            lines = [f"{pad_in}{encode(v, level + 1)}" for v in o]
            return "[\n" + ",\n".join(lines) + "\n" + pad + "]"
        return json.dumps(o)

    return encode(content, 0)


def action_export_range(action):
    """(início, fim) exportados: o range manual da Action, senão do 1º ao último keyframe."""
    frame_start = int(round(action.frame_range[0]))
    frame_end = int(round(action.frame_range[1]))
    return frame_start, max(frame_end, frame_start + 1)


def _texture_picker_entries(obj, action, node_animations, opts):
    """Texture Pickers da Action (bone de controle + alvos); instância com problema é avisada e pulada."""
    entries = []
    for uv_item in get_texture_picker_exports(obj):
        control_pbone = obj.pose.bones.get(uv_item.uv_offset_source_bone)
        if control_pbone is None:
            opts.report(
                {"WARNING"},
                f"Texture Picker: control bone '{uv_item.uv_offset_source_bone}' not found -- skipping "
                f"this instance (target '{uv_item.uv_offset_target_bone}') in Action '{action.name}'.",
            )
            continue
        if uv_item.uv_offset_target_bone not in node_animations:
            opts.report(
                {"WARNING"},
                f"Texture Picker: target bone '{uv_item.uv_offset_target_bone}' isn't exported -- skipping "
                f"this instance in Action '{action.name}'.",
            )
            continue
        target_bones = [uv_item.uv_offset_target_bone]
        for extra_name in (uv_item.uv_offset_target_bones_extra or "").split(","):
            extra_name = extra_name.strip()
            if not extra_name or extra_name in target_bones:
                continue
            if extra_name not in node_animations:
                opts.report(
                    {"WARNING"},
                    f"Texture Picker: extra bone '{extra_name}' isn't exported -- skipping that target in "
                    f"Action '{action.name}'.",
                )
                continue
            target_bones.append(extra_name)
        entries.append({"control_pbone": control_pbone, "target_bones": target_bones, "settings": uv_item})
    return entries


def animation_rest(obj, exportable_names):
    """(rest_by_bone, pivot_offsets) da animação, batendo com o .blockymodel (rest do import com Use Original Bone Positions)."""
    rest_by_bone = rest_matrices(obj)
    if not obj.data.get(ARMATURE_ORIGINAL_POSITIONS_PROP, True):
        return rest_by_bone, {}
    current = dict(rest_by_bone)
    original_rest_matrices(obj, rest_by_bone, exportable_names)
    pivot_offsets = {}
    for name in exportable_names:
        offset = current[name].inverted() @ rest_by_bone[name]
        if any(abs(offset[i][j] - (1.0 if i == j else 0.0)) > 1e-6 for i in range(4) for j in range(4)):
            pivot_offsets[name] = offset
    return rest_by_bone, pivot_offsets


def sample_action(context, obj, action, exportable_names, rest_by_bone, pivot_offsets, opts):
    """Amostra todo frame e escolhe os keys (EXACT: linear igual ao Blender; KEYS: os keyframes + extras onde
    precisa); (node_animations, duração)."""
    scene = context.scene
    fps = scene.render.fps / scene.render.fps_base
    frame_start, frame_end = action_export_range(action)
    frames = list(range(frame_start, frame_end + 1))
    duration = max(1, round((frame_end - frame_start) / fps * FPS_HYTALE))
    looping = action.use_cyclic

    node_animations = {
        # shapeVisible/shapeUvOffset sempre presentes, mesmo vazios, como
        # nos arquivos oficiais (o jogo pode não aceitar sem a chave).
        name: {"position": [], "orientation": [], "shapeStretch": [], "shapeVisible": [], "shapeUvOffset": []}
        for name in exportable_names
    }
    samples = {kind: {name: [] for name in exportable_names} for kind in (KIND_POSITION, KIND_ORIENTATION, KIND_STRETCH)}
    last_quat = {}
    uv_entries = _texture_picker_entries(obj, action, node_animations, opts)
    last_uv = {}
    offsets = shape_offsets(obj, rest_by_bone, exportable_names, armature_unit_scale(obj, UNIT_SCALE_DEFAULT))

    sampled_frames = []
    for frame in frames:
        hytale_time = frame_to_hytale_time(frame, frame_start, fps)
        if sampled_frames and hytale_time == frame_to_hytale_time(sampled_frames[-1], frame_start, fps):
            continue  # cena acima de 60 FPS: dois frames no mesmo tempo do arquivo
        sampled_frames.append(frame)
        scene.frame_set(frame)
        context.view_layer.update()
        poses = pose_matrices(obj)
        for name, offset in pivot_offsets.items():
            poses[name] = poses[name] @ offset
        deltas = compute_deltas(obj, rest_by_bone, poses, exportable_names, UNIT_SCALE_DEFAULT, offsets)

        for name, (pos, quat, scale) in deltas.items():
            quat = snap_noise(KIND_ORIENTATION, fix_quaternion_sign(quat, last_quat.get(name)))
            last_quat[name] = quat
            pos, scale = snap_noise(KIND_POSITION, pos), snap_noise(KIND_STRETCH, scale)
            samples[KIND_POSITION][name].append((hytale_time, pos))
            samples[KIND_ORIENTATION][name].append((hytale_time, quat))
            samples[KIND_STRETCH][name].append((hytale_time, scale))

        # Texture Picker: degraus (o jogo não interpola UV) -- só grava quando
        # muda, e sempre no primeiro e no último frame.
        for index, entry in enumerate(uv_entries):
            value = sample_uv_offset_px(entry["control_pbone"], entry["settings"])
            if frame in (frame_start, frame_end) or last_uv.get(index) != value:
                for target_name in entry["target_bones"]:
                    node_animations[target_name]["shapeUvOffset"].append(
                        {"time": hytale_time, "delta": {"x": value[0], "y": value[1]}, "interpolationType": "linear"}
                    )
            last_uv[index] = value

    keyed = collect_all_keyframe_frames(action, frame_start, frame_end) if opts.keyframe_mode == "KEYS" else set()
    # Action sem keyframe (só drivers/constraints): não tem o que preservar,
    # vai como "Same as Blender".
    candidates = [i for i, frame in enumerate(sampled_frames) if frame in keyed]

    identity = {
        KIND_POSITION: Vector((0.0, 0.0, 0.0)),
        KIND_ORIENTATION: Quaternion((1.0, 0.0, 0.0, 0.0)),
        KIND_STRETCH: Vector((1.0, 1.0, 1.0)),
    }
    floor = {KIND_POSITION: NOISE_FLOOR_PX, KIND_ORIENTATION: NOISE_FLOOR_DEG, KIND_STRETCH: NOISE_FLOOR_STRETCH}
    for kind, by_bone in samples.items():
        for name, channel in by_bone.items():
            # Canal que nunca sai de perto da identidade (medido inteiro) é ruído e fica de fora.
            if not channel or all(_distance(kind, v, identity[kind]) < floor[kind] for _t, v in channel):
                continue
            if keyed:
                keep, types = _smooth_keys(channel, candidates, kind, duration, looping)
            else:
                keep = _linear_keys(channel, kind)
                types = ["linear"] * len(keep)
            if all(_distance(kind, channel[i][1], identity[kind]) < floor[kind] for i in keep):
                continue  # só keys parados: o canal não faz diferença no jogo
            node_animations[name][kind] = [
                {"time": channel[i][0], "delta": _file_value(kind, channel[i][1]), "interpolationType": interp}
                for i, interp in zip(keep, types)
            ]

    use_original_names = getattr(opts, "use_original_names", False)
    cleaned = {
        exported_bone_name(obj, name, use_original_names): chans
        for name, chans in node_animations.items()
        if chans["position"] or chans["orientation"] or chans["shapeStretch"] or chans["shapeUvOffset"]
    }
    return cleaned, duration


# Lista de Actions do export, com checkbox e Select/Deselect All.


class HYTALE_action_export_item(PropertyGroup):
    action_name: StringProperty()
    export: BoolProperty(default=False)


class HYTALE_UL_action_export_list(bpy.types.UIList):
    bl_idname = "HYTALE_UL_action_export_list"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        row = layout.row(align=True)
        row.prop(item, "export", text="")
        row.label(text=item.action_name)
        # .blockyanim: o loop mora na própria Action ("Cyclic Animation" do
        # Blender, que o import já marca) -- clicável aqui na lista.
        action = bpy.data.actions.get(item.action_name)
        if action is not None and hasattr(data, "keyframe_mode"):
            row.prop(action, "use_cyclic", text="", icon="FILE_REFRESH" if action.use_cyclic else "FORWARD")


class HYTALE_OT_select_all_actions(Operator):
    """Marca/desmarca todas as Actions da lista (só com o diálogo de export aberto)."""

    bl_idname = "hytale.select_all_actions"
    bl_label = "Select/Deselect All"
    description = tooltip("exporter.tooltip.select_all_actions")
    bl_options = {"INTERNAL"}

    value: BoolProperty(default=True)

    def execute(self, context):
        op = context.active_operator
        if op is None or not hasattr(op, "action_items"):
            self.report({"WARNING"}, "Export dialog isn't open.")
            return {"CANCELLED"}
        for item in op.action_items:
            item.export = self.value
        return {"FINISHED"}


# Export em lote: um .blockyanim por Action marcada, na pasta escolhida.


# Todas as properties do operador vêm daqui (@localized_props reconstrói a
# classe quando o idioma muda). Não persistem no .blend.
def _blockyanim_export_props(lang):
    return {
        "directory": StringProperty(subtype="DIR_PATH"),
        "action_items": CollectionProperty(type=HYTALE_action_export_item),
        "action_items_index": IntProperty(),
        "keyframe_mode": EnumProperty(
            name="Keyframes",
            description=tr("exporter.prop.blockyanim_keyframe_mode", lang),
            items=[
                ("EXACT", "Same as Blender", tr("exporter.prop.blockyanim_keyframe_mode_item_exact", lang)),
                ("KEYS", "My Keyframes Only", tr("exporter.prop.blockyanim_keyframe_mode_item_keys", lang)),
            ],
            default="EXACT",
        ),
        # Mesma opção do .blockymodel -- ver exported_bone_name().
        "use_original_names": BoolProperty(
            name="Use Original Names",
            description=tr("exporter.prop.use_original_names", lang),
            default=False,
        ),
    }


# poll()/invoke() comuns aos 4 operadores de export (Armature ativa).


def _require_active_armature(operator, context):
    """Valida que há um Armature ativo/selecionado, reportando o erro padrão
    se não houver. Retorna o Armature, ou None (já reportado) caso contrário."""
    if not is_active_armature(context):
        operator.report({"ERROR"}, "Select/activate the Armature you want to export first.")
        return None
    return context.active_object


def _invoke_model_export_dialog(operator, context, extension):
    """invoke() dos exports de arquivo único: valida o Armature, filepath padrão e file browser."""
    obj = _require_active_armature(operator, context)
    if obj is None:
        return {"CANCELLED"}
    base_dir = os.path.dirname(bpy.data.filepath) if bpy.data.filepath else os.path.expanduser("~")
    operator.filepath = os.path.join(base_dir, sanitize_filename(obj.name) + extension)
    context.window_manager.fileselect_add(operator)
    return {"RUNNING_MODAL"}


def _invoke_action_export_dialog(operator, context):
    """invoke() dos exports em lote: valida o Armature, lista as Actions (marca a ativa) e abre o browser de pasta."""
    obj = _require_active_armature(operator, context)
    if obj is None:
        return {"CANCELLED"}

    current_action_name = None
    if obj.animation_data and obj.animation_data.action:
        current_action_name = obj.animation_data.action.name

    operator.action_items.clear()
    for action in sorted(bpy.data.actions, key=lambda a: a.name.lower()):
        item = operator.action_items.add()
        item.action_name = action.name
        item.export = action.name == current_action_name

    operator.directory = os.path.dirname(bpy.data.filepath) if bpy.data.filepath else os.path.expanduser("~")
    context.window_manager.fileselect_add(operator)
    return {"RUNNING_MODAL"}


def _draw_use_original_names(operator, context, layout):
    """Checkbox "Use Original Names" (.blockymodel/.blockyanim) -- só
    habilitada quando algum bone foi renomeado pelo Rename Bones."""
    obj = context.active_object
    renamed = obj is not None and obj.type == "ARMATURE" and any(
        b.get(BONE_RENAMED_FROM_PROP) for b in obj.data.bones
    )
    row = layout.row()
    row.enabled = renamed
    row.prop(operator, "use_original_names")


def _draw_actions_export_box(operator, layout):
    """draw() da caixa 'Actions to Export' dos exports em lote."""
    actions_box = layout.box()
    actions_box.label(text="Actions to Export", icon="ACTION")
    row = actions_box.row(align=True)
    op_all = row.operator(HYTALE_OT_select_all_actions.bl_idname, text="Select All")
    op_all.value = True
    op_none = row.operator(HYTALE_OT_select_all_actions.bl_idname, text="Deselect All")
    op_none.value = False
    actions_box.template_list(
        "HYTALE_UL_action_export_list", "",
        operator, "action_items",
        operator, "action_items_index",
        rows=8,
    )
    n_selected = sum(1 for it in operator.action_items if it.export)
    actions_box.label(text=f"{n_selected} action(s) selected")


@localized_props(_blockyanim_export_props)
class EXPORT_OT_hytale_blockyanim(Operator):
    """Batch-export one or more Actions of the selected/active Armature to Hytale's .blockyanim format -- one file per Action, into a chosen folder"""

    bl_idname = "export_scene.hytale_blockyanim"
    bl_label = "Export Hytale Animations (.blockyanim)"
    description = tooltip("exporter.tooltip.blockyanim")
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return game_found() and is_active_armature(context)   # sem o jogo: travado (common.game_found)

    def invoke(self, context, event):
        return _invoke_action_export_dialog(self, context)

    def draw(self, context):
        layout = self.layout

        _draw_actions_export_box(self, layout)

        general_box = layout.box()
        general_box.prop(self, "keyframe_mode")
        _draw_use_original_names(self, context, general_box)

    def execute(self, context):
        obj = _require_active_armature(self, context)
        if obj is None:
            return {"CANCELLED"}
        if obj.animation_data is None:
            obj.animation_data_create()

        selected_items = [it for it in self.action_items if it.export]
        if not selected_items:
            self.report({"ERROR"}, "No Action selected -- check at least one in the list.")
            return {"CANCELLED"}

        if not self.directory:
            self.report({"ERROR"}, "No output folder selected.")
            return {"CANCELLED"}
        os.makedirs(self.directory, exist_ok=True)

        export_settings = get_export_settings(obj)

        exportable_names = resolve_exportable_bone_names(self, obj, export_settings)
        if exportable_names is None:
            return {"CANCELLED"}

        rest_by_bone, pivot_offsets = animation_rest(obj, exportable_names)

        original_action = obj.animation_data.action
        original_frame = context.scene.frame_current

        exported_files = []
        try:
            for item in selected_items:
                action = bpy.data.actions.get(item.action_name)
                if action is None:
                    self.report({"WARNING"}, f"Action '{item.action_name}' not found anymore, skipping.")
                    continue

                obj.animation_data.action = action
                node_animations, duration = sample_action(
                    context, obj, action, exportable_names, rest_by_bone, pivot_offsets, self
                )
                content = {
                    "formatVersion": 1,
                    "duration": duration,
                    "holdLastKeyframe": not action.use_cyclic,
                    "nodeAnimations": node_animations,
                }

                filename = sanitize_filename(action.name) + ".blockyanim"
                filepath = os.path.join(self.directory, filename)
                with open(filepath, "w", encoding="utf-8", newline="\n") as f:
                    json.dump(round_floats_for_output(content, OUTPUT_DECIMALS), f, separators=(",", ":"))
                exported_files.append(filename)
        finally:
            obj.animation_data.action = original_action
            context.scene.frame_set(original_frame)
            context.view_layer.update()

        if not exported_files:
            self.report({"ERROR"}, "Nothing was exported.")
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"Exported {len(exported_files)} file(s) to '{self.directory}': " + ", ".join(exported_files),
        )
        return {"FINISHED"}


# --- Export .blockymodel ---


# Raiz com format/lod e todo node com id e shape completo (conferido num export do Blockbench); ver finalize_shape_for_export.


_SHAPE_DEFAULTS = {
    "stretch": {"x": 1, "y": 1, "z": 1},
    "unwrapMode": "custom",
    "visible": True,
    "doubleSided": False,
    "shadingMode": "flat",
}


def finalize_shape_for_export(shape_core):
    """Shape completo (todas as chaves do formato) a partir do shape guardado; o que já existe tem prioridade."""
    shape_core = shape_core or {}
    result = {"type": shape_core.get("type", "none")}
    result["offset"] = shape_core.get("offset", {"x": 0.0, "y": 0.0, "z": 0.0})
    result["stretch"] = shape_core.get("stretch", _SHAPE_DEFAULTS["stretch"])
    settings = dict(shape_core.get("settings", {}))
    settings.setdefault("isPiece", False)
    result["settings"] = settings
    result["textureLayout"] = shape_core.get("textureLayout", {})
    result["unwrapMode"] = shape_core.get("unwrapMode", _SHAPE_DEFAULTS["unwrapMode"])
    result["visible"] = shape_core.get("visible", _SHAPE_DEFAULTS["visible"])
    result["doubleSided"] = shape_core.get("doubleSided", _SHAPE_DEFAULTS["doubleSided"])
    result["shadingMode"] = shape_core.get("shadingMode", _SHAPE_DEFAULTS["shadingMode"])
    return result


# Tolerâncias do "mover só o pivô": abaixo disso (ruído ~1e-7) o bone conta como não mexido.
PIVOT_SHIFT_MIN_GAME_UNITS = 1e-4
PIVOT_ROTATION_TOLERANCE_RAD = 1e-4


def pivot_only_shift(bone, current_rest, unit_scale):
    """(delta, girou?) do pivô desde o import: (None, False) sem mudança, (Vector, False) só moveu, (None, True) girou."""
    imported = import_rest_matrix(bone)
    if imported is None:
        return None, False
    try:
        relative = imported.inverted() @ current_rest
    except ValueError:
        return None, False
    delta, rotation, _scale = relative.decompose()
    angle = rotation.angle
    angle = min(angle, 2.0 * math.pi - angle)  # q e -q são a mesma rotação
    if angle > PIVOT_ROTATION_TOLERANCE_RAD:
        return None, True
    if delta.length / unit_scale < PIVOT_SHIFT_MIN_GAME_UNITS:
        return None, False
    return delta, False


def _shape_has_geometry(shape):
    return bool(shape) and shape.get("type", "none") not in ("none", None)


def build_export_node_tree(
    armature_obj, exportable_names, unit_scale, rest_by_bone, use_original_names=False, pivot_report=None
):
    """Árvore de nodes dos bones exportáveis (+ peças extras como filhos); pivô movido compensa o offset. (root_nodes, warnings)."""
    unit_scale = armature_unit_scale(armature_obj, unit_scale)
    bones_by_name = {b.name: b for b in armature_obj.data.bones}
    warnings = []
    next_id = [1]  # lista (não int) só pra ser mutável dentro de build_node
    if pivot_report is not None:
        pivot_report.setdefault("shifted", [])
        pivot_report.setdefault("rotated", [])
    # delta do pivô (unid. Blender, espaço do bone) de cada bone cujo
    # shape.offset foi compensado -- lido também pelos filhos (parent_offset).
    pivot_deltas = {}

    def parent_offset_of(parent_name):
        offset = Vector((0.0, 0.0, 0.0))
        stored = bones_by_name[parent_name].get(BONE_SHAPE_OFFSET_PROP)
        if stored is not None:
            offset = Vector(stored)
        delta = pivot_deltas.get(parent_name)
        if delta is not None:
            offset = offset - delta
        return offset

    def nearest_exportable_parent(bone):
        p = bone.parent
        while p is not None and p.name not in exportable_names:
            p = p.parent
        return p.name if p is not None else None

    children_by_parent = {}
    for name in exportable_names:
        parent_name = nearest_exportable_parent(bones_by_name[name])
        children_by_parent.setdefault(parent_name, []).append(name)

    def build_node(name):
        bone = bones_by_name[name]
        parent_name = nearest_exportable_parent(bone)

        rest_local = local_matrix(rest_by_bone, name, parent_name)
        pos_local, rot_local, _scale = rest_local.decompose()

        parent_offset = parent_offset_of(parent_name) if parent_name is not None else Vector((0.0, 0.0, 0.0))

        raw_pos = (pos_local - parent_offset) / unit_scale

        shape_json = bone.get(BONE_SHAPE_JSON_PROP)
        primary_shape = {}
        extra_pieces = []
        if shape_json:
            try:
                parsed = json.loads(shape_json)
                if isinstance(parsed, list):
                    # Formato novo: [shape_do_proprio_bone, {shape,
                    # position, orientation} de cada cubo extra...]
                    if parsed:
                        primary_shape = parsed[0] or {}
                        extra_pieces = [p for p in parsed[1:] if isinstance(p, dict)]
                else:
                    # Dado antigo (dict único): shape válido, sem várias peças.
                    primary_shape = parsed or {}
            except (TypeError, ValueError):
                warnings.append(name)
        else:
            warnings.append(name)

        # Pivô movido: só compensa com algo visível no bone (cubo ou peça extra).
        delta, rotated = pivot_only_shift(bone, rest_by_bone[name], unit_scale)
        if rotated and pivot_report is not None and (_shape_has_geometry(primary_shape) or extra_pieces):
            pivot_report["rotated"].append(name)
        if delta is not None and (_shape_has_geometry(primary_shape) or extra_pieces):
            old_offset = vec3(primary_shape.get("offset", {}))
            primary_shape = dict(primary_shape)
            primary_shape["offset"] = vec_to_dict(old_offset - delta / unit_scale)
            pivot_deltas[name] = delta
            if pivot_report is not None:
                pivot_report["shifted"].append(name)

        node = {
            "id": str(next_id[0]),
            "name": exported_bone_name(armature_obj, name, use_original_names),
            "position": vec_to_dict(raw_pos),
            "orientation": quat_to_dict(rot_local),
            # "shape" é obrigatório em todo node (o plugin lê node.shape.type sempre).
            "shape": finalize_shape_for_export(primary_shape),
        }
        next_id[0] += 1

        children = [build_node(child) for child in sorted(children_by_parent.get(name, []))]

        # Peças extras do import viram nodes filhos (só no arquivo, rígidas no bone).
        base_name = exported_bone_name(armature_obj, name, use_original_names)
        for i, piece in enumerate(extra_pieces):
            children.append({
                "id": str(next_id[0]),
                "name": f"{base_name}_piece{i + 2}",
                "position": piece.get("position", {"x": 0.0, "y": 0.0, "z": 0.0}),
                "orientation": piece.get("orientation", {"x": 0.0, "y": 0.0, "z": 0.0, "w": 1.0}),
                "shape": finalize_shape_for_export(piece.get("shape")),
            })
            next_id[0] += 1

        if children:
            node["children"] = children
        return node

    roots = sorted(children_by_parent.get(None, []))
    return [build_node(r) for r in roots], warnings


def _blockymodel_export_props(lang):
    return {
        "filepath": StringProperty(subtype="FILE_PATH"),
        "unit_scale": FloatProperty(
            name="Blender Units per Game Unit",
            description=tr("exporter.prop.blockymodel_unit_scale", lang),
            default=UNIT_SCALE_DEFAULT,
            min=0.0001,
            max=10.0,
        ),
        "output_decimal_places": IntProperty(
            name="Decimal Places",
            description=tr("exporter.prop.blockymodel_output_decimal_places", lang),
            default=6,
            min=1,
            max=12,
        ),
        "pretty_print_json": BoolProperty(
            name="Readable JSON",
            description=tr("exporter.prop.blockymodel_pretty_print_json", lang),
            default=False,
        ),
        # Bones renomeados pelo "Rename Bones" (All Bones) saem com o nome
        # novo; ligado, saem com o nome de antes do rename (o do jogo).
        "use_original_names": BoolProperty(
            name="Use Original Names",
            description=tr("exporter.prop.use_original_names", lang),
            default=False,
        ),
        "export_texture": BoolProperty(
            name="Export Texture",
            description=tr("exporter.prop.blockymodel_export_texture", lang),
            default=True,
        ),
        # Ligado: cada bone sai na posição/rotação do IMPORT
        # (BONE_IMPORT_REST_PROP), ignorando o que foi mexido no Edit Mode.
        "use_original_bone_positions": BoolProperty(
            name="Use Original Bone Positions",
            description=tr("exporter.prop.blockymodel_use_original_bone_positions", lang),
            default=True,
        ),
    }


def _material_texture_image(armature_obj):
    """Imagem LIGADA no material das malhas desta Armature (a principal --
    variantes empilhadas sem conexão ficam de fora), ou None."""
    for mesh_obj in bpy.data.objects:
        if mesh_obj.type != "MESH" or mesh_obj.parent != armature_obj:
            continue
        for slot in mesh_obj.material_slots:
            mat = slot.material
            if mat is None or not mat.use_nodes or mat.node_tree is None:
                continue
            for node in mat.node_tree.nodes:
                if node.type == "TEX_IMAGE" and node.image is not None and any(o.is_linked for o in node.outputs):
                    return node.image
    return None


def _image_file_on_disk(image):
    """Caminho do arquivo de onde a imagem veio, se ela for um arquivo que
    existe em disco e NÃO estiver só empacotada/gerada. None senão."""
    if image.packed_file is not None or image.source != "FILE":
        return None
    path = bpy.path.abspath(image.filepath) if image.filepath else ""
    return path if path and os.path.isfile(path) else None


def export_model_texture(operator, armature_obj, model_filepath):
    """Salva a textura embutida como <modelo>.png ao lado do .blockymodel (<modelo>_hytale.png se já existir); arquivo em disco não é tocado."""
    image = _material_texture_image(armature_obj)
    if image is None or _image_file_on_disk(image):
        return
    folder = os.path.dirname(os.path.abspath(model_filepath))
    stem = os.path.splitext(os.path.basename(model_filepath))[0]
    target = os.path.join(folder, stem + ".png")
    collided = os.path.exists(target)
    if collided:
        target = os.path.join(folder, stem + "_hytale.png")
    try:
        data = bytes(image.packed_file.data) if image.packed_file is not None else b""
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            with open(target, "wb") as f:
                f.write(data)
        else:
            copy = image.copy()
            try:
                copy.filepath_raw = target
                copy.file_format = "PNG"
                copy.save()
            finally:
                bpy.data.images.remove(copy)
    except (OSError, RuntimeError) as exc:
        operator.report({"WARNING"}, f"Could not save the texture next to the model: {exc}")
        return
    w, h = image.size
    if collided:
        operator.report(
            {"WARNING"},
            f"'{stem}.png' already exists in this folder (maybe the original texture) -- the model's "
            f"texture ({w}x{h}) was saved as '{os.path.basename(target)}' instead. Blockbench picks "
            f"'{stem}.png' first: replace it, or export to another folder.",
        )
    else:
        operator.report({"INFO"}, f"Texture saved next to the model: '{os.path.basename(target)}' ({w}x{h}).")


@localized_props(_blockymodel_export_props)
class EXPORT_OT_hytale_blockymodel(Operator):
    """Export the selected/active Armature's rest pose (bind pose) to Hytale's .blockymodel format -- position/orientation come from the current bone transforms, shape/UV data comes from what was captured when the character was imported"""

    bl_idname = "export_scene.hytale_blockymodel"
    bl_label = "Export Hytale Model (.blockymodel)"
    description = tooltip("exporter.tooltip.blockymodel")
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return game_found() and is_active_armature(context)   # sem o jogo: travado (common.game_found)

    def invoke(self, context, event):
        obj = context.active_object
        if obj is not None and obj.type == "ARMATURE":
            self.use_original_bone_positions = bool(obj.data.get(ARMATURE_ORIGINAL_POSITIONS_PROP, True))
        return _invoke_model_export_dialog(self, context, ".blockymodel")

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "unit_scale")
        layout.prop(self, "output_decimal_places")
        layout.prop(self, "pretty_print_json")
        layout.prop(self, "export_texture")
        layout.prop(self, "use_original_bone_positions")
        _draw_use_original_names(self, context, layout)

    def execute(self, context):
        obj = _require_active_armature(self, context)
        if obj is None:
            return {"CANCELLED"}
        if not self.filepath:
            self.report({"ERROR"}, "No output file selected.")
            return {"CANCELLED"}

        export_settings = get_export_settings(obj)
        exportable_names = resolve_exportable_bone_names(self, obj, export_settings)
        if exportable_names is None:
            return {"CANCELLED"}

        obj.data[ARMATURE_ORIGINAL_POSITIONS_PROP] = bool(self.use_original_bone_positions)
        rest_by_bone = rest_matrices(obj)
        if self.use_original_bone_positions:
            missing = original_rest_matrices(obj, rest_by_bone, exportable_names)
            if missing:
                distinct = sorted(missing)
                preview = ", ".join(distinct[:5]) + (f" (+{len(distinct) - 5})" if len(distinct) > 5 else "")
                self.report(
                    {"WARNING"},
                    tr("exporter.runtime.blockymodel_no_original_positions", get_language(context)).format(
                        count=len(distinct), names=preview
                    ),
                )
        pivot_report = {}
        root_nodes, warnings = build_export_node_tree(
            obj, exportable_names, self.unit_scale, rest_by_bone, self.use_original_names, pivot_report
        )

        if not root_nodes:
            self.report(
                {"ERROR"},
                "Nothing to export -- no root bone found in the exportable set "
                "(every exportable bone has an exportable ancestor?).",
            )
            return {"CANCELLED"}

        # format = o do import (character/prop); lod "auto" como o Blockbench.
        content = {"nodes": root_nodes, "format": armature_model_format(obj), "lod": "auto"}

        filepath = self.filepath
        if not filepath.lower().endswith(".blockymodel"):
            filepath += ".blockymodel"

        # newline="\n" -- mesmo motivo do .blockyanim (ver comentário
        # grande em EXPORT_OT_hytale_blockyanim.execute()).
        with open(filepath, "w", encoding="utf-8", newline="\n") as f:
            rounded = round_floats_for_output(content, self.output_decimal_places)
            if self.pretty_print_json:
                f.write(dump_pretty_blockyanim(rounded))
            else:
                json.dump(rounded, f, separators=(",", ":"))

        if self.export_texture:
            export_model_texture(self, obj, filepath)

        if warnings:
            distinct = sorted(set(warnings))
            preview = ", ".join(distinct[:5])
            more = f" (+{len(distinct) - 5} more)" if len(distinct) > 5 else ""
            self.report(
                {"WARNING"},
                f"{len(distinct)} bone(s) had no shape data saved (imported before this "
                f"feature, or created manually) -- exported as pivot-only, shape/UV lost: "
                f"{preview}{more}. Re-import the original .blockymodel to fix this.",
            )

        lang = get_language(context)
        for key, level, names in (
            ("exporter.runtime.blockymodel_pivot_rotated", "WARNING", pivot_report.get("rotated")),
            ("exporter.runtime.blockymodel_pivot_shifted", "INFO", pivot_report.get("shifted")),
        ):
            if names:
                distinct = sorted(set(names))
                preview = ", ".join(distinct[:5]) + (f" (+{len(distinct) - 5})" if len(distinct) > 5 else "")
                self.report({level}, tr(key, lang).format(count=len(distinct), names=preview))

        self.report(
            {"INFO"},
            f"Exported '{os.path.basename(filepath)}' ({len(exportable_names)} bone(s)).",
        )
        return {"FINISHED"}


# --- Export FBX: o exportador nativo só com os bones originais (use_deform temporário + deform only) ---
# Nome desambiguado (.dupNN) sai com o nome do Blender no FBX.


def _fbx_shared_props(lang):
    return {
        "include_meshes": BoolProperty(
            name="Include Reference Meshes",
            description=tr("exporter.prop.fbx_include_meshes", lang),
            default=True,
        ),
        "include_attachments": BoolProperty(
            name="Include Mesh Attachments",
            description=tr("exporter.prop.fbx_include_attachments", lang),
            default=True,
        ),
        "match_game_units": BoolProperty(
            name="Scale to Game Units",
            description=tr("exporter.prop.fbx_match_game_units", lang),
            default=False,
        ),
        "unit_scale": FloatProperty(
            name="Blender Units per Game Unit",
            description=tr("exporter.prop.fbx_unit_scale", lang),
            default=UNIT_SCALE_DEFAULT,
            min=0.0001,
            max=10.0,
        ),
        "apply_transform": BoolProperty(
            name="Apply Object Transform",
            description=tr("exporter.prop.fbx_apply_transform", lang),
            default=False,
        ),
        "add_leaf_bones": BoolProperty(
            name="Add Leaf Bones",
            description=tr("exporter.prop.fbx_add_leaf_bones", lang),
            default=False,
        ),
        "embed_textures": BoolProperty(
            name="Embed Textures",
            description=tr("exporter.prop.fbx_embed_textures", lang),
            default=False,
        ),
    }


def _draw_fbx_shared(self, layout):
    """draw() comum dos dois operadores FBX."""
    mesh_box = layout.box()
    mesh_box.label(text="Meshes", icon="MESH_DATA")
    mesh_box.prop(self, "include_meshes")
    sub = mesh_box.column()
    sub.enabled = self.include_meshes
    sub.prop(self, "include_attachments")
    sub.prop(self, "embed_textures")

    rig_box = layout.box()
    rig_box.label(text="Rig & Format", icon="ARMATURE_DATA")
    rig_box.prop(self, "match_game_units")
    scale_sub = rig_box.column()
    scale_sub.enabled = self.match_game_units
    scale_sub.prop(self, "unit_scale")
    rig_box.prop(self, "apply_transform")
    rig_box.prop(self, "add_leaf_bones")


def run_hytale_fbx_export(operator, context, obj, filepath, exportable_names, action=None):
    """Export FBX nativo com os bones do Hytale; com `action`, faz bake dela, senão só a Rest Pose. True/False."""
    # O addon FBX pode estar desligado.
    if not hasattr(bpy.ops.export_scene, "fbx"):
        operator.report(
            {"ERROR"},
            "Blender's built-in FBX exporter (io_scene_fbx) isn't enabled -- turn it on in "
            "Edit > Preferences > Add-ons and try again.",
        )
        return False

    meshes = gather_character_meshes(obj, operator.include_attachments) if operator.include_meshes else set()

    original_action = obj.animation_data.action if obj.animation_data else None
    if action is not None:
        if obj.animation_data is None:
            obj.animation_data_create()
        obj.animation_data.action = action

    original_selection = list(context.selected_objects)
    original_active = context.view_layer.objects.active

    # Deseleciona objeto a objeto: select_all() pode falhar fora do 3D Viewport.
    for scene_obj in bpy.data.objects:
        scene_obj.select_set(False)
    obj.select_set(True)
    for mesh_obj in meshes:
        mesh_obj.select_set(True)
    context.view_layer.objects.active = obj

    global_scale = (1.0 / armature_unit_scale(obj, operator.unit_scale)) if operator.match_game_units else 1.0

    try:
        with temporary_deform_flags(obj.data, exportable_names):
            bpy.ops.export_scene.fbx(
                filepath=filepath,
                check_existing=False,
                use_selection=True,
                object_types={"ARMATURE", "MESH"},
                use_armature_deform_only=True,
                add_leaf_bones=operator.add_leaf_bones,
                primary_bone_axis="Y",
                secondary_bone_axis="X",
                global_scale=global_scale,
                apply_unit_scale=True,
                bake_space_transform=operator.apply_transform,
                mesh_smooth_type="FACE",
                use_mesh_modifiers=True,
                use_triangles=False,
                use_custom_props=False,
                bake_anim=action is not None,
                bake_anim_use_all_actions=False,
                bake_anim_use_nla_strips=False,
                bake_anim_force_startend_keying=True,
                bake_anim_step=1.0,
                path_mode="COPY" if operator.embed_textures else "AUTO",
                embed_textures=operator.embed_textures,
            )
    finally:
        for scene_obj in bpy.data.objects:
            scene_obj.select_set(False)
        for scene_obj in original_selection:
            scene_obj.select_set(True)
        context.view_layer.objects.active = original_active
        if action is not None and obj.animation_data is not None:
            obj.animation_data.action = original_action

    return True


def _fbx_model_props(lang):
    return {
        "filepath": StringProperty(subtype="FILE_PATH"),
        **_fbx_shared_props(lang),
    }


@localized_props(_fbx_model_props)
class EXPORT_OT_hytale_fbx_model(Operator):
    """Export the selected/active Armature's rest pose (bind pose) -- and, optionally, its reference meshes -- to a single .fbx file. No animation is included; use 'Hytale Animations (.fbx)' for that"""

    bl_idname = "export_scene.hytale_fbx_model"
    bl_label = "Export Hytale Model (.fbx)"
    description = tooltip("exporter.tooltip.fbx_model")
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return game_found() and is_active_armature(context)   # sem o jogo: travado (common.game_found)

    def invoke(self, context, event):
        return _invoke_model_export_dialog(self, context, ".fbx")

    def draw(self, context):
        _draw_fbx_shared(self, self.layout)

    def execute(self, context):
        obj = _require_active_armature(self, context)
        if obj is None:
            return {"CANCELLED"}
        if not self.filepath:
            self.report({"ERROR"}, "No output file selected.")
            return {"CANCELLED"}

        filepath = self.filepath
        if not filepath.lower().endswith(".fbx"):
            filepath += ".fbx"

        export_settings = get_export_settings(obj)
        exportable_names = resolve_exportable_bone_names(self, obj, export_settings)
        if exportable_names is None:
            return {"CANCELLED"}

        ok = run_hytale_fbx_export(self, context, obj, filepath, exportable_names, action=None)
        if not ok:
            return {"CANCELLED"}

        self.report({"INFO"}, f"Exported '{os.path.basename(filepath)}'.")
        return {"FINISHED"}


def _fbx_anim_props(lang):
    return {
        "directory": StringProperty(subtype="DIR_PATH"),
        "action_items": CollectionProperty(type=HYTALE_action_export_item),
        "action_items_index": IntProperty(),
        **_fbx_shared_props(lang),
    }


@localized_props(_fbx_anim_props)
class EXPORT_OT_hytale_fbx_anim(Operator):
    """Batch-export one or more Actions of the selected/active Armature to .fbx -- one file per Action (rig + baked animation, and optionally the reference meshes), into a chosen folder"""

    bl_idname = "export_scene.hytale_fbx_anim"
    bl_label = "Export Hytale Animations (.fbx)"
    description = tooltip("exporter.tooltip.fbx_anim")
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return game_found() and is_active_armature(context)   # sem o jogo: travado (common.game_found)

    def invoke(self, context, event):
        return _invoke_action_export_dialog(self, context)

    def draw(self, context):
        layout = self.layout

        _draw_actions_export_box(self, layout)

        _draw_fbx_shared(self, layout)

    def execute(self, context):
        obj = _require_active_armature(self, context)
        if obj is None:
            return {"CANCELLED"}

        selected_items = [it for it in self.action_items if it.export]
        if not selected_items:
            self.report({"ERROR"}, "No Action selected -- check at least one in the list.")
            return {"CANCELLED"}

        if not self.directory:
            self.report({"ERROR"}, "No output folder selected.")
            return {"CANCELLED"}
        os.makedirs(self.directory, exist_ok=True)

        export_settings = get_export_settings(obj)
        exportable_names = resolve_exportable_bone_names(self, obj, export_settings)
        if exportable_names is None:
            return {"CANCELLED"}

        exported_files = []
        for item in selected_items:
            action = bpy.data.actions.get(item.action_name)
            if action is None:
                self.report({"WARNING"}, f"Action '{item.action_name}' not found anymore, skipping.")
                continue

            filename = sanitize_filename(action.name) + ".fbx"
            filepath = os.path.join(self.directory, filename)
            ok = run_hytale_fbx_export(self, context, obj, filepath, exportable_names, action=action)
            if not ok:
                return {"CANCELLED"}
            exported_files.append(filename)

        if not exported_files:
            self.report({"ERROR"}, "Nothing was exported.")
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"Exported {len(exported_files)} file(s) to '{self.directory}': " + ", ".join(exported_files),
        )
        return {"FINISHED"}


def menu_func_export(self, context):
    if not game_found():          # sem a pasta do jogo: nada do addon nos menus
        return
    self.layout.operator(EXPORT_OT_hytale_blockyanim.bl_idname, text="Hytale Animations (.blockyanim)")
    self.layout.operator(EXPORT_OT_hytale_blockymodel.bl_idname, text="Hytale Model (.blockymodel)")
    self.layout.operator(EXPORT_OT_hytale_fbx_model.bl_idname, text="Hytale Model (.fbx)")
    self.layout.operator(EXPORT_OT_hytale_fbx_anim.bl_idname, text="Hytale Animations (.fbx)")


classes = (
    HYTALE_export_settings,
    HYTALE_texture_picker_export_item,
    HYTALE_UL_texture_picker_exports,
    EXPORT_OT_texture_picker_export_add,
    EXPORT_OT_texture_picker_export_remove,
    HYTALE_action_export_item,
    HYTALE_UL_action_export_list,
    HYTALE_OT_select_all_actions,
    EXPORT_OT_hytale_blockyanim,
    EXPORT_OT_hytale_blockymodel,
    EXPORT_OT_hytale_fbx_model,
    EXPORT_OT_hytale_fbx_anim,
)


def _redo_armature_property_assignments():
    """Reatribui as properties da Armature (de novo após troca de idioma, pra apontarem pro RNA certo)."""
    Armature.hytale_export_settings = PointerProperty(type=HYTALE_export_settings)
    Armature.hytale_texture_picker_exports = CollectionProperty(type=HYTALE_texture_picker_export_item)


def register():
    for cls in classes:
        register_localized_class(cls)
    _redo_armature_property_assignments()
    Armature.hytale_texture_picker_exports_index = IntProperty(default=0)
    register_refresh_hook(_redo_armature_property_assignments)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    unregister_refresh_hook(_redo_armature_property_assignments)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    del Armature.hytale_texture_picker_exports_index
    del Armature.hytale_texture_picker_exports
    del Armature.hytale_export_settings
    for cls in reversed(classes):
        unregister_localized_class(cls)


if __name__ == "__main__":
    register()
