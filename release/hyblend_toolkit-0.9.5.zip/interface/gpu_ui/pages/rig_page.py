"""Aba Rig -- Setup / Bone Settings / Advanced, espelhando
HYTALE_PT_main._draw_rig* (mesmas properties, mesmos operadores, mesmos
estados especiais: Vertex Edit ativo, Shape Edit "preso" em outro
Armature, Vertex Edit órfão)."""

from ..framework.core import Column, Label, Row, Style
from ..widgets import CONTROL_H, Hint, ListRow, card, list_box, list_with_buttons
from ....common import is_active_armature
from ....rigger import (
    RIG_OT_hytale_bone_collection_add,
    RIG_OT_hytale_bone_collection_load_defaults,
    RIG_OT_hytale_bone_collection_move,
    RIG_OT_hytale_bone_collection_remove,
    RIG_OT_hytale_bone_collection_reset_grid,
    RIG_OT_hytale_camera_create,
    RIG_OT_hytale_camera_remove,
    RIG_OT_hytale_clear_generated,
    RIG_OT_hytale_collection_template_apply,
    RIG_OT_hytale_collection_template_delete,
    RIG_OT_hytale_collection_template_save,
    RIG_OT_hytale_generate_rig,
    RIG_OT_hytale_ik_chain_add,
    RIG_OT_hytale_ik_chain_auto_detect,
    RIG_OT_hytale_ik_chain_load_defaults,
    RIG_OT_hytale_ik_chain_move,
    RIG_OT_hytale_ik_chain_pick_bone,
    RIG_OT_hytale_ik_chain_remove,
    RIG_OT_hytale_mirror_shape,
    RIG_OT_hytale_rig_template_delete,
    RIG_OT_hytale_rig_template_save,
    RIG_OT_hytale_shape_edit_mode_enter,
    RIG_OT_hytale_shape_edit_mode_finish,
    RIG_OT_hytale_shape_edit_mode_reselect,
    RIG_OT_hytale_shape_template_apply,
    RIG_OT_hytale_shape_template_delete,
    RIG_OT_hytale_shape_template_save,
    RIG_OT_hytale_shape_vertex_edit_mode_enter,
    RIG_OT_hytale_shape_vertex_edit_mode_finish,
    RIG_OT_hytale_texture_picker_create,
    RIG_OT_hytale_texture_picker_remove,
    RIG_OT_hytale_use_selected_as_widget,
    RIG_OT_hytale_validate_rig,
    SECTION_ROOT,
    _resolve_collection_section_name,
    find_armature_stuck_in_shape_edit_mode,
)
from ....rigger.rename import RIG_OT_hytale_rename_bones, RIG_OT_hytale_revert_bone_names, rename_toggle_prop
from ....templates import TEMPLATES_OT_open_user_folder, TEMPLATES_OT_reload
from .common import bone_field

# Mesmos rótulos/ícones do painel clássico e do menu "+"
CHAIN_ICONS = {
    "ROOT": "origin", "ARM": "arm", "LEG": "arm", "CHAIN": "chain", "HEAD": "head",
    "SPINE": "spine", "ATTACHMENTS": "attach", "TEXTURE_PICKER": "image",
}
# Ordem do menu "+" (RIG_MT_hytale_ik_chain_add_menu)
ADD_MENU = (("Head", "HEAD"), ("Spine", "SPINE"), ("Arm", "ARM"), ("Leg", "LEG"), ("Chain", "CHAIN"),
            ("Root", "ROOT"), ("Attachments", "ATTACHMENTS"), ("Texture Picker", "TEXTURE_PICKER"))
LIMB_FIELD_LABELS = {
    "ARM": {"parent_override": "panel.field_arm_shoulder", "root_bone": "panel.field_arm_upper",
            "pole_bone": "panel.field_arm_forearm", "tip_bone": "panel.field_arm_hand"},
    "LEG": {"parent_override": "panel.field_leg_pelvis", "root_bone": "panel.field_leg_thigh",
            "pole_bone": "panel.field_leg_calf", "tip_bone": "panel.field_leg_foot"},
}
SUBTAB_ICONS = {"SETUP": "gear", "BONE_SETTINGS": "bone", "ADVANCED": "layers"}


def build(ui):
    t = ui.t
    obj = ui.context.active_object

    # Vertex Edit Mode troca o objeto ativo pra malha do widget
    if obj is not None and obj.type == "MESH" and obj.get("hytale_vertex_edit_armature"):
        bone_name = obj.get("hytale_vertex_edit_bone", "")
        return [
            card(
                Hint(t("panel.label_vertex_edit_active"), icon="edit", tone="info"),
                Label(bone_name, style=Style(height=20)) if bone_name else None,
                Label(obj.name, color=ui.theme.text_muted, size=11, style=Style(height=18)),
            ),
            ui.op("rig.vfinish", RIG_OT_hytale_shape_vertex_edit_mode_finish,
                  t("panel.btn_shape_vertex_edit_finish"), icon="check", variant="primary", height=38),
        ]

    widgets = [Hint(t("panel.warn_rig_experimental"), icon="experimental", tone="warning")]

    if not is_active_armature(ui.context):
        stuck = find_armature_stuck_in_shape_edit_mode(ui.context)
        if stuck is not None:
            widgets.append(card(
                Hint(t("panel.hint_shape_edit_active_elsewhere").format(name=stuck.name), icon="info"),
                ui.op("rig.reselect", RIG_OT_hytale_shape_edit_mode_reselect, t("panel.btn_shape_edit_mode_reselect"),
                      icon="rig", props={"armature_name": stuck.name}),
            ))
        else:
            widgets.append(card(Hint(t("panel.hint_rig_none"), icon="error", tone="danger")))
        return widgets

    armature = obj.data
    wm = ui.wm
    widgets.append(ui.enum(wm, "hytale_rig_subtab", key="rig.subtab", expand=True, icons=SUBTAB_ICONS))
    subtab = wm.hytale_rig_subtab
    if subtab == "SETUP":
        widgets += _setup(ui, armature)
    elif subtab == "BONE_SETTINGS":
        widgets += _bone_settings(ui, obj, armature)
    elif subtab == "ADVANCED":
        widgets += _advanced(ui, armature)
    return widgets


# --------------------------------------------------------------------------
# Setup
# --------------------------------------------------------------------------

def _setup(ui, armature):
    t = ui.t
    trash, trash_list = ui.menu(
        "rig.clear", "", "trash",
        [ui.op_item("Only Rig", "rig", RIG_OT_hytale_clear_generated, {"mode": "ONLY_RIG"}),
         ui.op_item("Delete All", "trash", RIG_OT_hytale_clear_generated, {"mode": "DELETE_ALL"})],
        variant="danger", height=40, width=40,
        tooltip=_menu_tooltip(ui, "rigger.tooltip.clear_generated_menu"))
    widgets = [card(
        Row(ui.op("rig.create", RIG_OT_hytale_generate_rig, t("panel.btn_create_rig"), icon="rig",
                  variant="primary", height=40, flex=1, toast=True),
            trash, style=Style(gap=6)),
        trash_list,
        ui.op("rig.validate", RIG_OT_hytale_validate_rig, t("panel.btn_validate_rig"), icon="search", height=30),
    )]

    if not armature.hytale_shape_edit_mode:
        widgets.append(ui.op("rig.shape_enter", RIG_OT_hytale_shape_edit_mode_enter, t("panel.btn_shape_edit_enter"),
                             icon="shape", height=32))
        return widgets

    # Vertex Edit órfão: único caminho de saída desse estado
    if armature.hytale_shape_vertex_edit_mode:
        widgets.append(card(
            Hint(t("panel.hint_vertex_edit_orphaned"), icon="error", tone="danger"),
            ui.op("rig.vfinish2", RIG_OT_hytale_shape_vertex_edit_mode_finish, t("panel.btn_shape_vertex_edit_finish"),
                  icon="check"),
        ))
        return widgets

    widgets.append(ui.op("rig.shape_finish", RIG_OT_hytale_shape_edit_mode_finish, t("panel.btn_shape_edit_finish"),
                         icon="check", variant="primary", height=32))
    active_pb = ui.context.active_pose_bone
    if active_pb is None:
        widgets.append(card(Hint(t("panel.hint_shape_edit_no_active_bone"), icon="info")))
    else:
        widgets.append(card(
            ui.op("rig.vedit", RIG_OT_hytale_shape_vertex_edit_mode_enter, t("panel.btn_shape_vertex_edit_enter"),
                  icon="edit"),
            ui.op("rig.mirror", RIG_OT_hytale_mirror_shape, t("panel.btn_mirror_shape"), icon="mirror"),
            ui.op("rig.use_sel", RIG_OT_hytale_use_selected_as_widget, t("panel.btn_use_selected_as_widget"),
                  icon="mesh"),
            _small_label(ui, t("panel.field_shape_translation")),
            ui.vector(active_pb, "custom_shape_translation"),
            _small_label(ui, t("panel.field_shape_rotation")),
            ui.vector(active_pb, "custom_shape_rotation_euler"),
            _small_label(ui, t("panel.field_shape_scale")),
            ui.vector(active_pb, "custom_shape_scale_xyz"),
            title=active_pb.name, icon="bone",
        ))
    return widgets


def _small_label(ui, text):
    return Label(text, size=11, color=ui.theme.text_muted, style=Style(height=18, padding=(2, 0, 0, 0)))


def _menu_tooltip(ui, key):
    return lambda: ui.t(key)


# --------------------------------------------------------------------------
# Bone Settings
# --------------------------------------------------------------------------

def _bone_settings(ui, obj, armature):
    t = ui.t
    chains = armature.hytale_ik_chains
    index = armature.hytale_ik_chains_index

    def select(i):
        return lambda f: ui.set(f, armature, "hytale_ik_chains_index", i, final=False)

    def rename(i):
        def run(f):
            ui.set(f, armature, "hytale_ik_chains_index", i, final=False)
            f.state["_rename_chain"] = i
        return run

    # Duplo clique numa linha = renomear (o label da entrada) no lugar.
    renaming = ui.state.get("_rename_chain")
    if renaming is not None and ui.state.get("_rename_chain_started") \
            and ui.f.focus != "chain.rename.%d" % renaming:
        ui.state.pop("_rename_chain", None)       # Enter/Esc/clique fora: acabou
        ui.state.pop("_rename_chain_started", None)
        renaming = None
    rows = []
    for i, item in enumerate(chains):
        if renaming == i:
            field = ui.text(item, "label", key="chain.rename.%d" % i, icon=CHAIN_ICONS.get(item.chain_type, "bone"))
            if not ui.state.get("_rename_chain_started"):
                field.begin_edit(ui.f, item.label)
                ui.state["_rename_chain_started"] = True
            rows.append(field)
            continue
        rows.append(ListRow("chain.%d" % i, item.label or item.chain_type, select(i),
                            icon=CHAIN_ICONS.get(item.chain_type, "bone"), selected=(i == index),
                            on_double=rename(i), detail=_chain_type_name(item)))
    content = Column(rows, style=Style(gap=2)) if rows else Label(
        "—", color=ui.theme.text_muted, align="CENTER", style=Style(height=26))

    add_items = [ui.op_item(label, CHAIN_ICONS[kind], RIG_OT_hytale_ik_chain_add, {"chain_type": kind})
                 for label, kind in ADD_MENU]
    add_button, add_list = ui.menu("chain.add", "", "plus", add_items,
                                   tooltip=_menu_tooltip(ui, "rigger.tooltip.ik_chain_add_menu"))
    chain_list = list_with_buttons(list_box(content, 6, "chain.scroll"), [
        add_button,
        ui.op("chain.remove", RIG_OT_hytale_ik_chain_remove, "", icon="minus"),
        ui.op("chain.up", RIG_OT_hytale_ik_chain_move, "", icon="arrow_up", props={"direction": "UP"}),
        ui.op("chain.down", RIG_OT_hytale_ik_chain_move, "", icon="arrow_down", props={"direction": "DOWN"}),
    ])
    parts = [chain_list, add_list,
             ui.op("chain.detect", RIG_OT_hytale_ik_chain_auto_detect, t("panel.btn_auto_detect_bones"),
                   icon="search", height=30)]
    if any(c.chain_type in ("ARM", "LEG") for c in chains):
        parts.append(ui.toggle(armature, "hytale_apply_ik_joint_fix", t("panel.apply_ik_joint_fix")))

    main = [card(parts, title=t("panel.ik_chains_box"), icon="arm")]
    if 0 <= index < len(chains):
        main.append(_chain_form(ui, obj, armature, chains[index], index))
    main.append(_rename_box(ui, armature))
    return main


def _chain_type_name(item):
    p = item.bl_rna.properties["chain_type"]
    for enum_item in p.enum_items:
        if enum_item.identifier == item.chain_type:
            return enum_item.name
    return item.chain_type


def _chain_form(ui, obj, armature, item, index):
    """Formulário da entrada selecionada -- um bloco por chain_type."""
    t = ui.t
    rename_on = bool(getattr(armature, "hytale_rename_enabled", False))

    def rename_box(field_name):
        toggle = rename_toggle_prop(item, field_name) if rename_on else None
        return ui.check(item, toggle) if toggle else None

    def picker(field_name, label):
        return bone_field(ui, item, field_name, label,
                          picker=(RIG_OT_hytale_ik_chain_pick_bone, {"chain_index": index, "field": field_name}),
                          extra=[rename_box(field_name)])

    def bones_group(*children):
        return card(list(children), title=t("panel.bone_settings_group_bones"), icon="bone", gap=6)

    collection = ui.labeled(t("panel.field_collection"), ui.enum(item, "collection_override"))
    form = [ui.labeled(t("panel.field_chain_type"), ui.enum(item, "chain_type", expand=False, icons=CHAIN_ICONS))]
    kind = item.chain_type

    if kind == "ROOT":
        rows = [ui.number(item, "root_count", t("panel.field_root_count"))]
        for i in range(1, item.root_count + 1):
            field_name, create_name = "root_bone_%d" % i, "root_create_%d" % i
            label = t("panel.field_root_origin") if i == 1 else "%s %d" % (t("panel.field_root"), i)
            creating = getattr(item, create_name)
            pick = None if creating else (RIG_OT_hytale_ik_chain_pick_bone, {"chain_index": index, "field": field_name})
            rows.append(bone_field(ui, item, field_name, label, picker=pick,
                                   extra=[ui.toggle_button(item, create_name, icon="plus"), rename_box(field_name)]))
        form += [bones_group(*rows),
                 Hint(t("panel.hint_root_order"), icon="info"),
                 Hint(t("panel.hint_root_new_bone"), icon="info"),
                 collection]
    elif kind == "CHAIN":
        form += [
            bones_group(picker("parent_override", t("panel.field_tail_parent")),
                        picker("root_bone", t("panel.field_tail_start")),
                        picker("tip_bone", t("panel.field_tail_end"))),
            ui.labeled(t("panel.field_tail_tip_rotation_axis"), ui.enum(item, "tail_tip_rotation_axis")),
            ui.number(item, "tail_tip_rotation_deg", t("panel.field_tail_tip_rotation_deg")),
            ui.toggle(item, "tail_use_connect", t("panel.field_tail_use_connect")),
            Hint(t("panel.hint_tail_no_ik"), icon="info"),
            collection,
        ]
    elif kind == "HEAD":
        necks = [picker("neck_bone_%d" % n, t("panel.field_neck_%d" % n)) for n in range(1, item.neck_count + 1)]
        form.append(bones_group(ui.number(item, "neck_count", t("panel.field_neck_count")), *necks,
                                picker("head_bone", t("panel.field_head_bone")),
                                picker("head_end_bone", t("panel.field_head_end_bone"))))
        if sum(1 for c in armature.hytale_ik_chains if c.chain_type == "HEAD") > 1:
            form.append(ui.toggle(item, "head_is_main", t("panel.field_head_is_main")))
        form.append(ui.toggle(item, "head_follow_enabled", t("panel.field_head_follow_enabled")))

        def camera():
            rows = [ui.toggle(item, "head_camera_enabled", t("panel.field_head_camera_enabled"))]
            if item.head_camera_enabled:
                rows += [
                    picker("head_camera_parent_bone", t("panel.field_head_camera_parent_bone")),
                    _small_label(ui, t("panel.head_camera_offset_label")),
                    Row(ui.number(item, "head_camera_offset_x", t("panel.field_head_camera_offset_x")),
                        ui.number(item, "head_camera_offset_y", t("panel.field_head_camera_offset_y")),
                        ui.number(item, "head_camera_offset_z", t("panel.field_head_camera_offset_z")),
                        style=Style(gap=4)),
                    _small_label(ui, t("panel.head_camera_rotation_label")),
                    Row(ui.number(item, "head_camera_rotation_x", t("panel.field_head_camera_rotation_x")),
                        ui.number(item, "head_camera_rotation_y", t("panel.field_head_camera_rotation_y")),
                        ui.number(item, "head_camera_rotation_z", t("panel.field_head_camera_rotation_z")),
                        style=Style(gap=4)),
                    ui.number(item, "head_camera_fov", t("panel.field_head_camera_fov")),
                    Hint(t("panel.hint_head_camera"), icon="info"),
                ]
            # Create/Remove sempre visíveis (Remove independe do toggle)
            rows.append(Row(ui.op("cam.create", RIG_OT_hytale_camera_create, _op_label(RIG_OT_hytale_camera_create),
                                  icon="camera", flex=1),
                            ui.op("cam.remove", RIG_OT_hytale_camera_remove, "", icon="close"),
                            style=Style(gap=4)))
            return rows
        form.append(card(ui.section("hytale_show_head_camera", t("panel.head_camera_section"), "camera", camera),
                         gap=0))
        form.append(collection)
    elif kind == "SPINE":
        spines = [picker("spine_bone_%d" % n, t("panel.field_spine_%d" % n))
                  for n in range(1, max(0, item.spine_count - 1) + 1)]
        form += [
            bones_group(ui.number(item, "spine_count", t("panel.field_spine_count")),
                        picker("pelvis_bone", t("panel.field_pelvis_bone")), *spines),
            ui.toggle(item, "spine_ctrl_enabled", t("panel.field_spine_ctrl_enabled")),
            Hint(t("panel.hint_spine_no_ik"), icon="info"),
            collection,
        ]
    elif kind == "ATTACHMENTS":
        base = t("panel.field_attachment")
        slots = [picker("attachment_bone_%d" % n, base if n == 1 else "%s %d" % (base, n))
                 for n in range(1, item.attachments_count + 1)]
        form += [
            bones_group(ui.number(item, "attachments_count", t("panel.field_attachments_count")), *slots),
            Hint(t("panel.hint_attachments_no_ik"), icon="info"),
            collection,
        ]
    elif kind == "TEXTURE_PICKER":
        form.append(bones_group(picker("texture_picker_bone", t("panel.field_texture_picker_bone")),
                                picker("texture_picker_ui_parent_bone", t("panel.field_texture_picker_ui_parent_bone"))))

        def plane():
            return [ui.number(item, "texture_picker_plane_scale", t("panel.field_texture_picker_plane_scale")),
                    Row(ui.number(item, "texture_picker_plane_offset_x", t("panel.field_texture_picker_plane_offset_x")),
                        ui.number(item, "texture_picker_plane_offset_y", t("panel.field_texture_picker_plane_offset_y")),
                        style=Style(gap=4))]

        def companions():
            base = t("panel.field_texture_picker_extra_bone")
            rows = [ui.number(item, "texture_picker_extra_bone_count", t("panel.field_texture_picker_extra_count"))]
            rows += [picker("texture_picker_extra_bone_%d" % n, base if n == 1 else "%s %d" % (base, n))
                     for n in range(1, item.texture_picker_extra_bone_count + 1)]
            if item.texture_picker_extra_bone_count == 0:
                rows.append(Hint(t("panel.hint_texture_picker_companions_empty"), icon="info"))
            return rows

        def grid():
            return [Row(ui.number(item, "texture_picker_grid_cols", t("panel.field_texture_picker_grid_cols")),
                        ui.number(item, "texture_picker_grid_rows", t("panel.field_texture_picker_grid_rows")),
                        style=Style(gap=4)),
                    Row(ui.number(item, "texture_picker_grid_cell_width", t("panel.field_texture_picker_grid_cell_width")),
                        ui.number(item, "texture_picker_grid_cell_height", t("panel.field_texture_picker_grid_cell_height")),
                        style=Style(gap=4))]
        form += [
            card(ui.section("hytale_show_texture_picker_plane", t("panel.texture_picker_section_plane"), "image", plane),
                 ui.section("hytale_show_texture_picker_companions", t("panel.texture_picker_section_companions"),
                            "link", companions),
                 ui.section("hytale_show_texture_picker_grid", t("panel.texture_picker_section_grid"), "grid", grid),
                 gap=2),
            Row(ui.op("tp.create", RIG_OT_hytale_texture_picker_create, _op_label(RIG_OT_hytale_texture_picker_create),
                      icon="image", variant="primary", height=34, flex=1),
                ui.op("tp.remove", RIG_OT_hytale_texture_picker_remove, "", icon="close", height=34),
                style=Style(gap=4)),
            Hint(t("panel.hint_texture_picker_no_ik"), icon="info"),
            collection,
        ]
    else:   # ARM / LEG (fallback ARM cobre chain_type desconhecido)
        labels = LIMB_FIELD_LABELS.get(kind, LIMB_FIELD_LABELS["ARM"])
        form.append(bones_group(
            picker("parent_override", t(labels["parent_override"])),
            picker("root_bone", t(labels["root_bone"])),
            picker("pole_bone", t(labels["pole_bone"])),
            picker("tip_bone", t(labels["tip_bone"])),
            ui.labeled(t("panel.field_side"), ui.enum(item, "side")),
        ))

        def pole():
            rows = [ui.number(item, "pole_distance", t("panel.field_pole_distance")),
                    ui.labeled(t("panel.field_pole_angle_mode"), ui.enum(item, "pole_angle_mode"))]
            if item.pole_angle_mode == "MANUAL":
                rows.append(ui.number(item, "pole_angle_manual", t("panel.field_pole_angle_manual")))
            elif item.pole_angle_mode == "AUTO":
                rows.append(ui.number(item, "pole_angle_fine_tune", t("panel.field_pole_angle_fine_tune")))
            elif item.pole_angle_mode == "PRESET":
                rows.append(ui.labeled(t("panel.field_pole_angle_preset_name"),
                                       ui.text(item, "pole_angle_preset_name")))
            rows.append(ui.toggle(item, "pole_invert", t("panel.field_pole_in_front")))
            return rows
        form += [card(ui.section("hytale_show_pole_settings", t("panel.bone_settings_group_pole"), "gear", pole),
                      gap=0),
                 collection]

    title = item.label or kind
    return card(form, title=title, icon=CHAIN_ICONS.get(kind, "bone"), tone="accent")


def _op_label(cls):
    return getattr(cls, "bl_label", "")


def _rename_box(ui, armature):
    t = ui.t
    parts = [ui.toggle(armature, "hytale_rename_enabled", t("panel.field_rename_enabled"))]
    if armature.hytale_rename_enabled:
        parts.append(Row(
            ui.enum(armature, "hytale_rename_mode", expand=True),
            ui.op("rename.revert", RIG_OT_hytale_revert_bone_names, "", icon="undo"),
            style=Style(gap=4)))
        # o Segmented precisa de flex pra dividir a linha com o botão
        seg = parts[-1].children[0]
        seg.style = Style(height=CONTROL_H, flex=1.0)
        hint_key = "panel.hint_rename_only_ctrl" if armature.hytale_rename_mode == "ONLY_CTRL" else "panel.hint_rename"
        parts.append(Hint(t(hint_key), icon="info"))
        parts.append(ui.op("rename.apply", RIG_OT_hytale_rename_bones, t("panel.btn_rename_bones"), icon="sort",
                           height=32))
    return card(parts, gap=6)


# --------------------------------------------------------------------------
# Advanced
# --------------------------------------------------------------------------

def _advanced(ui, armature):
    t = ui.t

    def collections():
        rows_ui = []
        items = armature.hytale_bone_collections
        if not armature.hytale_bone_collections_initialized and len(items) == 0:
            rows_ui.append(ui.op("bc.defaults", RIG_OT_hytale_bone_collection_load_defaults,
                                 t("panel.btn_load_default_collections"), icon="import"))
        if len(items) > 0:
            rows_ui.append(ui.op("bc.reset_grid", RIG_OT_hytale_bone_collection_reset_grid,
                                 t("panel.btn_reset_bone_collection_grid"), icon="refresh"))
        index = armature.hytale_bone_collections_index

        def select(i):
            return lambda f: ui.set(f, armature, "hytale_bone_collections_index", i, final=False)

        list_rows = []
        for i, entry in enumerate(items):
            if entry.entry_type == "SECTION":
                detail = "Root" if entry.parent in ("", SECTION_ROOT) else entry.parent
                icon = "collection"
            else:
                detail = _resolve_collection_section_name(armature, entry)
                icon = "bone"
            list_rows.append(ListRow("bc.%d" % i, entry.name, select(i), icon=icon, detail=detail,
                                     selected=(i == index)))
        content = Column(list_rows, style=Style(gap=2)) if list_rows else Label(
            "—", color=ui.theme.text_muted, align="CENTER", style=Style(height=26))
        rows_ui.append(list_with_buttons(list_box(content, 7, "bc.scroll"), [
            ui.op("bc.add", RIG_OT_hytale_bone_collection_add, "", icon="plus"),
            ui.op("bc.remove", RIG_OT_hytale_bone_collection_remove, "", icon="minus"),
            ui.op("bc.up", RIG_OT_hytale_bone_collection_move, "", icon="arrow_up", props={"direction": "UP"}),
            ui.op("bc.down", RIG_OT_hytale_bone_collection_move, "", icon="arrow_down", props={"direction": "DOWN"}),
        ]))
        if 0 <= index < len(items):
            selected = items[index]
            detail_rows = [
                ui.labeled(selected.bl_rna.properties["name"].name, ui.text(selected, "name")),
                ui.labeled(t("panel.field_entry_type"), ui.enum(selected, "entry_type", expand=True)),
            ]
            if selected.entry_type == "SECTION":
                detail_rows += [ui.labeled(t("panel.field_parent"), ui.enum(selected, "parent")),
                                ui.number(selected, "row", t("panel.field_section_order"))]
            else:
                detail_rows += [ui.labeled(t("panel.field_section"), ui.enum(selected, "parent")),
                                ui.toggle(selected, "show_in_animation_tab", t("panel.field_show_in_animation")),
                                Row(ui.number(selected, "row", t("panel.field_grid_row")),
                                    ui.number(selected, "column", t("panel.field_grid_column")),
                                    style=Style(gap=4))]
            rows_ui.append(card(detail_rows, title=t("panel.bone_collection_options_for").format(name=selected.name),
                                icon="gear", tone="accent", gap=6))
        rows_ui.append(Hint(t("panel.hint_bone_collections"), icon="info"))
        return rows_ui

    def templates():
        wm = ui.wm
        rows_ui = []
        for kind, selected_attr, apply_op, delete_op, save_op, label_key, active_name, icon in (
            ("rig", "hytale_rig_template_selected", RIG_OT_hytale_ik_chain_load_defaults,
             RIG_OT_hytale_rig_template_delete, RIG_OT_hytale_rig_template_save,
             "panel.active_rig_template", armature.hytale_active_rig_template, "rig"),
            ("shape", "hytale_shape_template_selected", RIG_OT_hytale_shape_template_apply,
             RIG_OT_hytale_shape_template_delete, RIG_OT_hytale_shape_template_save,
             "panel.active_shape_template", armature.hytale_active_shape_template, "mesh"),
            ("coll", "hytale_collection_template_selected", RIG_OT_hytale_collection_template_apply,
             RIG_OT_hytale_collection_template_delete, RIG_OT_hytale_collection_template_save,
             "panel.active_collection_template", armature.hytale_active_collection_template, "layers"),
        ):
            status = Row(
                _icon_label(ui, icon),
                Label("%s %s" % (t(label_key), active_name or t("panel.template_none")), size=11.5,
                      style=Style(flex=1)),
                style=Style(gap=6, align="center", height=22))
            rows_ui.append(status)
            dropdown = ui.enum(wm, selected_attr, key="tmpl.%s" % kind, expand=False)
            buttons = Row(
                ui.op("tmpl.%s.apply" % kind, apply_op, "", icon="import"),
                ui.op("tmpl.%s.delete" % kind, delete_op, "", icon="trash"),
                ui.op("tmpl.%s.save" % kind, save_op, "", icon="export"),
                style=Style(gap=3, width=3 * CONTROL_H + 6))
            rows_ui.append(Row(
                Label(t("panel.load_template_action"), size=11.5, color=ui.theme.text_muted,
                      style=Style(width=46, height=CONTROL_H)),
                _flex(dropdown), buttons, style=Style(gap=4, align="start")))
        rows_ui.append(Row(
            ui.op("tmpl.reload", TEMPLATES_OT_reload, t("panel.btn_reload_templates"), icon="refresh", flex=1),
            ui.op("tmpl.folder", TEMPLATES_OT_open_user_folder, t("panel.btn_open_templates_folder"), icon="folder",
                  flex=1),
            style=Style(gap=4)))
        return rows_ui

    return [
        card(ui.section("hytale_show_bone_collections", t("panel.bone_collections_box"), "layers", collections), gap=0),
        card(ui.section("hytale_show_templates", t("panel.templates_box"), "folder", templates), gap=0),
    ]


def _flex(widget):
    widget.style = Style(**{**{k: getattr(widget.style, k) for k in widget.style.__dataclass_fields__},
                            "flex": 1.0, "width": None})
    return widget


def _icon_label(ui, icon):
    from ..framework.core import Icon
    return Icon(icon, size=13, color=ui.theme.text_muted, style=Style(width=16, height=22))
