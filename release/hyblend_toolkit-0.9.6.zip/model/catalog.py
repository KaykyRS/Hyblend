"""Personagens/criaturas do jogo: os JSON de Server/Models (Model, Texture, Icon, anexos), lidos direto do
Assets.zip, e o import do personagem completo (corpo + anexos, cada um com a textura dele).

Herança: "Parent" = outro id de Server/Models; o filho sobrescreve as chaves do pai (Kweebec_Sapling_Red herda o
Model do Kweebec_Sapling e troca a Texture). Anexos: DefaultAttachments (todos) + RandomAttachmentSets (de cada
grupo, o de MAIOR Weight, empate = o primeiro do arquivo; padrão 1; "null" = nenhum).
Icon só conta se o PRÓPRIO JSON tiver (herdado do pai mostraria a cor errada numa variante).
IMPORTANTE: nada daqui no desenho (lê o zip); a Home chama por timer/operador.
"""

import json
import os
import posixpath
import zipfile
from pathlib import Path

from .. import hyblend_hub
from ..assets_source import ZipAssetsSource

MODELS_DIR = ("Server", "Models")
GRADIENT_SETS = "Cosmetics/CharacterCreator/GradientSets.json"
# Fora da biblioteca: não são personagens (pastas em qualquer nível e pedaços do id).
SKIP_FOLDERS = {"projectiles", "deployables", "test", "vehicles", "scifi", "showcase"}
SKIP_ID_PARTS = ("marker", "test", "preview", "warp")
_MAX_PARENTS = 8

_state = {"zip": None, "source": None, "index": None, "gradients": None, "characters": None}


class CatalogError(Exception):
    """Mensagem por key de tradução: CatalogError(key, **campos)."""

    def __init__(self, key, **fields):
        super().__init__(key)
        self.key = key
        self.fields = fields


def cache_dir():
    return os.path.join(hyblend_hub.documents_dir(), "Hyblend", "Toolkit", "assets_cache")


def source():
    """ZipAssetsSource do Assets.zip da pasta do Hytale atual (refeito se a pasta mudar)."""
    from ..interface.gpu_ui import game, hytale_install
    hytale_dir = game.hytale_dir()
    if hytale_dir is None:
        raise CatalogError("model.error.no_game")
    zip_path = hytale_install.resolve(hytale_dir, hytale_install.ASSETS_ZIP)
    if _state["zip"] != zip_path or _state["source"] is None:
        forget()
        try:
            _state["source"] = ZipAssetsSource(zip_path, Path(cache_dir()))
        except (OSError, zipfile.BadZipFile) as exc:
            raise CatalogError("model.error.assets_zip", error=exc) from exc
        _state["zip"] = zip_path
    return _state["source"]


def forget():
    """Fecha o zip e esquece o índice (pasta do Hytale mudou, unregister)."""
    if _state["source"] is not None:
        try:
            _state["source"].close()
        except OSError:
            pass
    _state.update(zip=None, source=None, index=None, gradients=None, characters=None)


def _skipped(rel_parts, ident):
    low = ident.lower()
    return any(p.lower() in SKIP_FOLDERS for p in rel_parts) or any(s in low for s in SKIP_ID_PARTS)


def index():
    """{id: (caminho no zip, categoria)} de todo JSON de Server/Models (o 1º id repetido vence)."""
    if _state["index"] is None:
        out = {}
        base = len("/".join(MODELS_DIR)) + 1
        for path in source().list_files(*MODELS_DIR):
            if not path.lower().endswith(".json"):
                continue
            parts = path[base:].split("/")
            ident = posixpath.splitext(parts[-1])[0]
            out.setdefault(ident, (path, parts[0] if len(parts) > 1 else ""))
        _state["index"] = out
    return _state["index"]


def raw(ident):
    """JSON do id sem herança, ou None."""
    entry = index().get(ident)
    if entry is None:
        return None
    try:
        text = source().read_text(entry[0])
        data = json.loads(text) if text else None
    except ValueError:          # inclui UnicodeDecodeError
        return None
    return data if isinstance(data, dict) else None


def resolved(ident):
    """JSON com a herança do Parent aplicada (o filho vence), ou None."""
    chain = []
    current = ident
    while current and len(chain) < _MAX_PARENTS:
        data = raw(current)
        if data is None or current in (c[0] for c in chain):
            break
        chain.append((current, data))
        current = data.get("Parent")
    if not chain:
        return None
    merged = {}
    for _, data in reversed(chain):
        merged.update(data)
    merged.pop("Parent", None)
    merged["Icon"] = chain[0][1].get("Icon")
    return merged


def characters():
    """[{id, category, icon}] dos personagens/criaturas (com Model, fora as pastas de SKIP), por categoria e id.
    Cacheado até a pasta do jogo mudar (forget)."""
    if _state["characters"] is not None and _state["source"] is source():
        return _state["characters"]
    out = []
    for ident, (path, category) in index().items():
        parts = path.split("/")[len(MODELS_DIR):-1]
        if _skipped(parts, ident):
            continue
        data = resolved(ident)
        if not data or not data.get("Model"):
            continue
        out.append({"id": ident, "category": category, "icon": data.get("Icon") or ""})
    out.sort(key=lambda c: (c["category"].lower(), c["id"].lower()))
    _state["characters"] = out
    return out


def pick_attachments(data):
    """[{Model, Texture, ...}] que o personagem usa por padrão (ver o topo do arquivo)."""
    chosen = [a for a in (data.get("DefaultAttachments") or []) if isinstance(a, dict) and a.get("Model")]
    for options in (data.get("RandomAttachmentSets") or {}).values():
        if not isinstance(options, dict):
            continue
        best, best_weight = None, None
        for option in options.values():
            if not isinstance(option, dict):
                continue
            try:
                weight = float(option.get("Weight", 1.0))
            except (TypeError, ValueError):
                weight = 1.0
            if best_weight is None or weight > best_weight:
                best, best_weight = option, weight
        if best is not None and best.get("Model"):
            chosen.append(best)
    return chosen


def gradient_ramp(set_id, gradient_id):
    """Caminho (relativo a Common/) da rampa de um GradientSet/GradientId, ou None."""
    if _state["gradients"] is None:
        sets = {}
        try:
            for entry in json.loads(source().read_text(GRADIENT_SETS) or "[]"):
                sets[entry.get("Id")] = {k: v.get("Texture") for k, v in (entry.get("Gradients") or {}).items()}
        except (ValueError, AttributeError, TypeError):
            sets = {}
        _state["gradients"] = sets
    return (_state["gradients"].get(set_id) or {}).get(gradient_id)


def common_file(rel):
    """Arquivo de Assets/Common/ extraído pro cache (Path) ou None se não existir no zip."""
    if not rel:
        return None
    path = source().resolve_common(*rel.replace("\\", "/").split("/"))
    return path if path.is_file() else None


def read_model(rel):
    """JSON de um .blockymodel de Common/, ou levanta CatalogError."""
    try:
        text = source().read_text("Common/" + rel.replace("\\", "/"))
        if text is None:
            raise CatalogError("model.error.model_missing", path=rel)
        data = json.loads(text)
    except ValueError as exc:
        raise CatalogError("model.error.read", error=exc) from exc
    if not isinstance(data, dict) or not data.get("nodes"):
        raise CatalogError("model.error.no_nodes")
    return data
