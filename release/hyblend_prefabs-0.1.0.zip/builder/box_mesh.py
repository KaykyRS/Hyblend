"""box_mesh.py -- gera a geometria (Mesh Blender) de uma peca a partir do
dict "shape" cru do .blockymodel. A matematica de UV foi portada e validada
numericamente contra exports reais do Blockbench -- ver DEVELOPER_NOTES.md
("UV de box/quad") antes de mexer aqui."""

from __future__ import annotations

import bmesh
import bpy
from mathutils import Vector

FACE_AXES_BY_FIXED_AXIS = {
    "z": (0, 1),  # (x, y) -> front/back
    "y": (0, 2),  # (x, z) -> top/bottom
    "x": (2, 1),  # (z, y) -> left/right
}

BOX_FACE_FIXED_AXIS = {
    "front": "z",
    "back": "z",
    "top": "y",
    "bottom": "y",
    "left": "x",
    "right": "x",
}

BOX_FACES_LOOP_ORDER = [
    ("back", (0, 1, 2, 3)),
    ("front", (4, 7, 6, 5)),
    ("bottom", (0, 4, 5, 1)),
    ("right", (1, 5, 6, 2)),
    ("top", (2, 6, 7, 3)),
    ("left", (3, 7, 4, 0)),
]

OPPOSITE_FACE = {
    "front": "back", "back": "front",
    "top": "bottom", "bottom": "top",
    "left": "right", "right": "left",
}

NORMAL_TO_HYTALE_FACE_KEY = {
    "+Z": "front", "-Z": "back",
    "+X": "right", "-X": "left",
    "+Y": "top", "-Y": "bottom",
}

# Sinal "base" (s,t -> pixel) de cada face, sem rotacao/espelho.
BOX_FACE_BASE_SIGN = {
    "back": (-1, -1),
    "right": (-1, -1),
    "front": (+1, -1),
    "left": (+1, -1),
    "top": (+1, +1),
    "bottom": (+1, -1),
}


def face_size_raw(size_raw, fixed_axis):
    """Largura/altura (unidades de jogo, sem escala) da face cujo eixo
    fixo e `fixed_axis`."""
    au, av = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
    comps = (size_raw.x, size_raw.y, size_raw.z)
    return comps[au], comps[av]


def _blockbench_uv_rect(fw, fh, angle, mirror, offset):
    """Retangulo [x1,y1,x2,y2] em pixels que o textureLayout de uma face
    descreve. Port do algoritmo do plugin oficial Blockbench<->Hytale."""
    ux = offset.get("x", 0.0)
    uy = offset.get("y", 0.0)
    uv_size = [fw, fh]
    mx = bool(mirror.get("x"))
    my = bool(mirror.get("y"))
    uv_mirror = [-1.0 if mx else 1.0, -1.0 if my else 1.0]
    k = angle or 0

    if k == 90:
        uv_size[0], uv_size[1] = uv_size[1], uv_size[0]
        uv_mirror[0], uv_mirror[1] = uv_mirror[1], uv_mirror[0]
        uv_mirror[0] *= -1
        x1, y1 = ux, uy + uv_size[1] * uv_mirror[1]
        x2, y2 = ux + uv_size[0] * uv_mirror[0], uy
    elif k == 270:
        uv_size[0], uv_size[1] = uv_size[1], uv_size[0]
        uv_mirror[0], uv_mirror[1] = uv_mirror[1], uv_mirror[0]
        uv_mirror[1] *= -1
        x1, y1 = ux + uv_size[0] * uv_mirror[0], uy
        x2, y2 = ux, uy + uv_size[1] * uv_mirror[1]
    elif k == 180:
        uv_mirror[0] *= -1
        uv_mirror[1] *= -1
        x1, y1 = ux + uv_size[0] * uv_mirror[0], uy + uv_size[1] * uv_mirror[1]
        x2, y2 = ux, uy
    else:
        x1, y1 = ux, uy
        x2, y2 = ux + uv_size[0] * uv_mirror[0], uy + uv_size[1] * uv_mirror[1]

    return x1, y1, x2, y2


def compute_face_uv(local_co, half_extents, axis_u, axis_v, face_key, tex_offset, face_w, face_h, mirror, angle, atlas_w, atlas_h):
    """UV de um vertice de uma face."""
    hu = half_extents[axis_u] or 1.0
    hv = half_extents[axis_v] or 1.0
    s = (local_co[axis_u] + hu) / (2.0 * hu)
    t = (local_co[axis_v] + hv) / (2.0 * hv)

    bs, bt = BOX_FACE_BASE_SIGN.get(face_key, (1, -1))
    s_bb = s if bs > 0 else 1.0 - s
    t_bb = t if bt > 0 else 1.0 - t

    k = int(round((angle or 0) / 90.0)) % 4
    for _ in range(k):
        s_bb, t_bb = t_bb, 1.0 - s_bb

    x1, y1, x2, y2 = _blockbench_uv_rect(face_w, face_h, angle, mirror, tex_offset)
    px = x1 + (x2 - x1) * s_bb
    py = y1 + (y2 - y1) * t_bb

    u = px / atlas_w
    v = 1.0 - (py / atlas_h)
    return u, v


def orient_faces_outward(bm, center=(0.0, 0.0, 0.0)) -> None:
    """Garante que TODA face aponta pra FORA de `center` (normal no mesmo
    sentido do vetor centro -> centro da face). So muda a ORDEM dos cantos
    da face (bmesh.ops.reverse_faces leva a UV de cada canto junto), entao
    geometria e textura ficam identicas.

    Bug real corrigido (dev-0.2.1): a ordem de vertices em BOX_FACES_LOOP_ORDER
    produzia as 6 faces apontando pra DENTRO (normais invertidas em todo
    cubo/caixa do addon desde a dev-0.1.0 -- vermelho no overlay "Face
    Orientation", iluminacao errada, e o "Remove Hidden Faces" do Optimizer
    apagava a face errada). Regra geometrica em vez de trocar a tabela: vale
    pra qualquer espelhamento (stretch negativo) sem caso especial."""
    from mathutils import Vector

    c = Vector(center)
    bm.normal_update()
    wrong = [f for f in bm.faces if f.normal.dot(f.calc_center_median() - c) < 0.0]
    if wrong:
        bmesh.ops.reverse_faces(bm, faces=wrong)
    bm.normal_update()


def make_box_mesh(name, size_scaled, size_raw, shape, atlas_w, atlas_h, generate_uvs=True, missing_face_mode="SKIP"):
    """Caixa centrada na origem. `missing_face_mode="SKIP"` = comportamento
    fiel ao Blockbench (face sem entrada no textureLayout nunca teve
    textura). Faces sempre apontando pra fora (orient_faces_outward), com
    ou sem stretch negativo."""
    hx, hy, hz = size_scaled.x / 2.0, size_scaled.y / 2.0, size_scaled.z / 2.0
    half_extents = (hx, hy, hz)

    verts_co = [
        (-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
        (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz),
    ]

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm = bmesh.new()
    bm_verts = [bm.verts.new(co) for co in verts_co]

    uv_layer = bm.loops.layers.uv.new() if generate_uvs else None
    tex_layout = shape.get("textureLayout", {})

    for face_key, idxs in BOX_FACES_LOOP_ORDER:
        lookup_key = face_key
        if face_key not in tex_layout:
            if missing_face_mode == "OPPOSITE_FALLBACK":
                lookup_key = OPPOSITE_FACE.get(face_key)
                if lookup_key not in tex_layout:
                    continue
            else:
                continue

        face = bm.faces.new([bm_verts[i] for i in idxs])
        if uv_layer is not None:
            info = tex_layout[lookup_key]
            fixed_axis = BOX_FACE_FIXED_AXIS[face_key]
            axis_u, axis_v = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
            fw, fh = face_size_raw(size_raw, fixed_axis)
            tex_offset = info.get("offset", {})
            mirror = info.get("mirror", {})
            angle = info.get("angle", 0)
            for loop in face.loops:
                local_co = loop.vert.co
                u, v = compute_face_uv(
                    local_co, half_extents, axis_u, axis_v, face_key, tex_offset, fw, fh, mirror, angle, atlas_w, atlas_h
                )
                loop[uv_layer].uv = (u, v)

    orient_faces_outward(bm)
    bm.to_mesh(mesh)
    bm.free()
    return mesh


def make_quad_mesh(name, shape, size_scaled_2d, size_raw_2d, atlas_w, atlas_h, generate_uvs=True):
    """Malha plana (1 ou 2 faces, se doubleSided)."""
    normal = shape.get("settings", {}).get("normal", "+Z")
    axis_letter = normal[-1].lower() if normal else "z"
    fixed_axis = axis_letter if axis_letter in ("x", "y", "z") else "z"
    axis_u, axis_v = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
    geom_face_key = NORMAL_TO_HYTALE_FACE_KEY.get(normal, "front")

    hu, hv = size_scaled_2d.x / 2.0, size_scaled_2d.y / 2.0
    half_extents = [0.0, 0.0, 0.0]
    half_extents[axis_u] = hu or 1.0
    half_extents[axis_v] = hv or 1.0

    def assemble(val_u, val_v):
        co = [0.0, 0.0, 0.0]
        co[axis_u] = val_u
        co[axis_v] = val_v
        return tuple(co)

    verts_co = [assemble(-hu, -hv), assemble(hu, -hv), assemble(hu, hv), assemble(-hu, hv)]

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm = bmesh.new()

    uv_layer = bm.loops.layers.uv.new() if generate_uvs else None
    tex_layout = shape.get("textureLayout", {})
    face_key = next(iter(tex_layout.keys()), None)

    def build_face(vert_order):
        verts = [bm.verts.new(verts_co[i]) for i in vert_order]
        face = bm.faces.new(verts)
        if uv_layer is not None and face_key is not None:
            info = tex_layout[face_key]
            tex_offset = info.get("offset", {})
            mirror = info.get("mirror", {})
            angle = info.get("angle", 0)
            for loop in face.loops:
                local_co = loop.vert.co
                u, v = compute_face_uv(
                    local_co, tuple(half_extents), axis_u, axis_v, geom_face_key, tex_offset,
                    size_raw_2d.x, size_raw_2d.y, mirror, angle, atlas_w, atlas_h,
                )
                loop[uv_layer].uv = (u, v)

    build_face((0, 1, 2, 3))
    if shape.get("doubleSided"):
        build_face((3, 2, 1, 0))

    # Face principal aponta pro lado declarado em settings.normal ("+Y" =
    # pra cima), invertido se o stretch desse eixo for negativo (quad
    # espelhado). Antes a ordem fixa dava +Z certo mas +X/+Y invertidos.
    # A 2a face (doubleSided) fica no sentido oposto.
    stretch = shape.get("stretch", {}) or {}
    sign = -1.0 if (normal and normal.startswith("-")) else 1.0
    try:
        if float(stretch.get(fixed_axis, 1.0)) < 0.0:
            sign = -sign
    except (TypeError, ValueError):
        pass
    axis_index = {"x": 0, "y": 1, "z": 2}[fixed_axis]
    bm.normal_update()
    faces = list(bm.faces)
    for i, face in enumerate(faces):
        want = sign if i == 0 else -sign
        if face.normal[axis_index] * want < 0.0:
            bmesh.ops.reverse_faces(bm, faces=[face])
    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    return mesh


def build_shape_mesh(name, shape, unit_scale, atlas_w, atlas_h, generate_uvs=True):
    """Recebe o dict "shape" cru de um no do .blockymodel e devolve uma
    bpy.types.Mesh centrada na origem local do proprio no -- quem chama
    posiciona o Object resultante."""
    settings = shape.get("settings", {})
    size_dict = settings.get("size", {})
    size_raw = Vector((size_dict.get("x", 1.0), size_dict.get("y", 1.0), size_dict.get("z", 1.0)))

    stretch_dict = shape.get("stretch", {"x": 1.0, "y": 1.0, "z": 1.0})
    stretch = Vector((stretch_dict.get("x", 1.0), stretch_dict.get("y", 1.0), stretch_dict.get("z", 1.0)))

    # tamanho final = size_raw * unit_scale * stretch (stretch e adimensional)
    size_scaled = Vector((
        size_raw.x * unit_scale * stretch.x,
        size_raw.y * unit_scale * stretch.y,
        size_raw.z * unit_scale * stretch.z,
    ))

    # Stretch negativo (geometria espelhada) nao precisa de caso especial:
    # make_box_mesh orienta as faces pra fora pela geometria final.
    shape_type = shape.get("type")
    if shape_type == "box":
        return make_box_mesh(name, size_scaled, size_raw, shape, atlas_w, atlas_h, generate_uvs)
    if shape_type == "quad":
        return make_quad_mesh(name, shape, size_scaled, size_raw, atlas_w, atlas_h, generate_uvs)

    raise ValueError(
        f"Peca {name!r} tem shape.type={shape_type!r}, sem gerador conhecido (so 'box'/'quad' sao "
        "suportados)."
    )
