"""Ponte entre os widgets (Python puro) e o Blender (RNA + operadores).

Tudo que a UI por GPU mostra ou muda passa por aqui, com as MESMAS
properties e operadores do painel clássico -- nenhuma lógica nova de
import/export/rig mora nesta pasta (mesma regra de interface/__init__.py).

`UI` é criado uma vez por reconstrução da árvore (ver app.build) e
carrega o que toda página precisa: frame, contexto, idioma, tr().
"""

import traceback

import bpy

from ...translations import get_language, tr
from .framework.core import Button, Column, Row, Style, Toggle
from .framework.core import Segmented
from .widgets import (CONTROL_H, CheckBox, DropdownHeader, NumberField, OptionRow, SectionHeader,
                      TextInput, icon_button, labeled, option_list)


# --------------------------------------------------------------------------
# RNA
# --------------------------------------------------------------------------

def rna_prop(owner, prop):
    try:
        return owner.bl_rna.properties[prop]
    except (KeyError, AttributeError, ReferenceError):
        return None


def enum_items(owner, prop, context):
    """[(id, nome, descrição)] de um EnumProperty -- inclusive os de
    items= dinâmico (callback), que o bl_rna devolve vazio."""
    p = rna_prop(owner, prop)
    if p is None:
        return []
    static = [(i.identifier, i.name, i.description) for i in p.enum_items]
    if static:
        return static
    # PropertyGroup do addon: o callback está na anotação da classe
    deferred = getattr(type(owner), "__annotations__", {}).get(prop)
    items_fn = getattr(deferred, "keywords", {}).get("items") if deferred is not None else None
    if callable(items_fn):
        try:
            return [(i[0], i[1], i[2] if len(i) > 2 else "") for i in items_fn(owner, context) if i]
        except Exception:
            traceback.print_exc()
    # Resto (ex.: WindowManager.x = EnumProperty(items=fn)): o erro de
    # atribuição lista os ids válidos; o nome vem do próprio UILayout.
    try:
        setattr(owner, prop, "\x00hyblend_probe")
    except TypeError as error:
        text = str(error)
        start, end = text.rfind("("), text.rfind(")")
        if start >= 0 and end > start:
            import ast
            try:
                ids = ast.literal_eval(text[start:end + 1])
            except (ValueError, SyntaxError):
                ids = ()
            if isinstance(ids, str):
                ids = (ids,)
            return [(i, bpy.types.UILayout.enum_item_name(owner, prop, i) or i, "") for i in ids]
    except Exception:
        pass
    return []


def prop_description(owner, prop):
    p = rna_prop(owner, prop)
    return p.description if p is not None else ""


def owner_key(owner, prop, index=None):
    try:
        base = "%x" % owner.as_pointer()
    except (AttributeError, ReferenceError):
        base = str(id(owner))
    return "p.%s.%s%s" % (base, prop, "" if index is None else "[%d]" % index)


def _idname_call(idname):
    if "." in idname:
        mod, name = idname.split(".", 1)
    else:   # "ABC_OT_nome" -> abc.nome
        mod, _, name = idname.partition("_OT_")
        mod = mod.lower()
    return getattr(getattr(bpy.ops, mod), name)


def _py_operator(idname):
    """Classe Python de um operador do addon pelo idname ("hyblend.welcome"),
    ou None (operador nativo). Sem isso, botão criado por idname mostrava o
    bl_description (= docstring da classe, em pt-br) em vez do tooltip()
    traduzido."""
    if "." in idname:
        mod, name = idname.split(".", 1)
        idname = "%s_OT_%s" % (mod.upper(), name)
    try:
        return bpy.types.Operator.bl_rna_get_subclass_py(idname)
    except Exception:
        return None


def _undo_push(message):
    try:
        bpy.ops.ed.undo_push(message=message)
    except Exception:
        pass


# --------------------------------------------------------------------------
# UI: o "layout" das páginas
# --------------------------------------------------------------------------

class UI:
    def __init__(self, f):
        self.f = f
        self.context = f.context
        self.lang = get_language(f.context)
        self.wm = f.context.window_manager
        self.state = f.state
        self.theme = f.theme

    # ---- texto ----
    def t(self, key, **fmt):
        text = tr(key, self.lang)
        return text.format(**fmt) if fmt else text

    # ---- contexto para rodar operadores ----
    def override(self):
        """Operadores rodam como se o botão estivesse na sidebar (igual ao
        painel clássico): janela + área da View3D + região UI."""
        host = getattr(self.f, "host", None)
        found = host.lookup() if host is not None else None
        if not found:
            return {}
        window, area, sidebar, _viewport = found
        return {"window": window, "area": area, "region": sidebar}

    def run_op(self, f, idname, props=None, label="", toast=False, invoke=True):
        try:
            call = _idname_call(idname)
            with bpy.context.temp_override(**self.override()):
                result = call("INVOKE_DEFAULT" if invoke else "EXEC_DEFAULT", True, **(props or {}))
        except RuntimeError as error:
            # report ERROR do operador vira RuntimeError no bpy.ops
            message = str(error).split("\n")[0].replace("Error: ", "").strip()
            f.toast(message or label, error=True)
            return None
        except Exception as error:
            traceback.print_exc()
            f.toast("%s %s" % (self.t("gpu_ui.error_prefix"), error), error=True)
            return None
        if toast and "FINISHED" in result:
            f.toast(label)
        return result

    # ---- operadores ----
    def op_poll(self, cls_or_idname):
        cls = cls_or_idname if not isinstance(cls_or_idname, str) else None
        try:
            if cls is not None:
                poll = getattr(cls, "poll", None)
                return True if poll is None else bool(poll(self.context))
            return bool(_idname_call(cls_or_idname).poll())
        except Exception:
            return False

    def op_description(self, cls_or_idname, props=None):
        """Tooltip igual ao do botão clássico (tooltip() dinâmico ou bl_description)."""
        def text():
            cls = cls_or_idname if not isinstance(cls_or_idname, str) else _py_operator(cls_or_idname)
            desc = getattr(cls, "description", None) if cls is not None else None
            if callable(desc):
                try:
                    return desc(bpy.context, None)
                except Exception:
                    pass
            idname = cls.bl_idname if cls is not None else cls_or_idname
            try:
                return _idname_call(idname).get_rna_type().description
            except Exception:
                return ""
        return text

    def op(self, key, op, text="", icon=None, props=None, variant="secondary", enabled=True,
           height=None, style=None, tooltip=None, toast=False, selected=False, flex=None):
        idname = op if isinstance(op, str) else op.bl_idname
        ok = enabled and self.op_poll(op)
        st = style or Style(height=height or CONTROL_H, flex=flex or 0.0,
                            width=CONTROL_H if (not text and icon) else None)

        def click(f):
            self.run_op(f, idname, props, label=text or idname, toast=toast)

        return Button(key, text, click, icon=icon, variant=variant, enabled=ok, selected=selected,
                      style=st, tooltip=tooltip or self.op_description(op, props))

    def url_button(self, key, url, text="", icon=None, image=None, variant="secondary", flex=None):
        from .pages.common import ImageButton
        enabled = bool(url)

        def click(f):
            self.run_op(f, "wm.url_open", {"url": url})
        return ImageButton(key, text, click, icon=icon, image=image, enabled=enabled, variant=variant,
                           tooltip=url or None, style=Style(height=CONTROL_H, flex=flex or 0.0,
                                                            width=None if text else CONTROL_H + 2))

    def menu(self, key, text, icon, items, variant="secondary", height=None, tooltip=None, flex=None,
             width=None):
        """Botão que abre um menu INLINE logo abaixo (um item por linha).
        items = [(rótulo, ícone, callback(f) ou None, habilitado)]."""
        is_open = self.state.get("_open_menu") == key

        def toggle(f):
            f.state["_open_menu"] = None if is_open else key

        button = Button(key, text, toggle, icon=icon, variant=variant, selected=is_open,
                        tooltip=tooltip,
                        style=Style(height=height or CONTROL_H, flex=flex or 0.0,
                                    width=width if width else (CONTROL_H if not text else None)))
        if not is_open:
            return button, None

        def wrap(callback):
            def run(f):
                f.state["_open_menu"] = None
                if callback:
                    callback(f)
            return run
        rows = [OptionRow("%s.item%d" % (key, i), label, wrap(cb), icon=ic, enabled=en)
                for i, (label, ic, cb, en) in enumerate(items)]
        return button, option_list(rows, key=key + ".list")

    def op_item(self, label, icon, op, props=None, toast=False):
        """Item de menu inline que roda um operador."""
        idname = op if isinstance(op, str) else op.bl_idname
        return (label, icon, lambda f: self.run_op(f, idname, props, label=label, toast=toast),
                self.op_poll(op))

    # ---- escrita em property ----
    def set(self, f, owner, prop, value, index=None, final=True):
        try:
            if index is None:
                setattr(owner, prop, value)
            else:
                getattr(owner, prop)[index] = value
        except (ReferenceError, AttributeError):
            return False
        except (TypeError, ValueError) as error:
            f.toast(str(error), error=True)
            return False
        if final:
            p = rna_prop(owner, prop)
            _undo_push(p.name if p is not None and p.name else prop)
        return True

    # ---- keyframe (tecla I com o mouse em cima) ----
    def keyer(self, owner, prop, index=None):
        """on_insert_key de um widget ligado a property: keyframe no frame
        atual, igual a apertar I em cima do campo no painel clássico."""
        def insert(f):
            p = rna_prop(owner, prop)
            name = p.name if p is not None and p.name else prop
            try:
                owner.keyframe_insert(prop, index=-1 if index is None else index)
            except (TypeError, RuntimeError, ReferenceError) as error:
                f.toast(str(error).split("\n")[0], error=True)   # ex.: property não animável
                return
            f.toast(self.t("gpu_ui.toast_keyframe").format(name=name))
        return insert

    def _keyable(self, widget, owner, prop, index=None):
        widget.on_insert_key = self.keyer(owner, prop, index)
        return widget

    # ---- controles ligados a property ----
    def toggle(self, owner, prop, label=None, key=None, enabled=True):
        value = bool(getattr(owner, prop))
        key = key or owner_key(owner, prop)
        return self._keyable(Toggle(key, label if label is not None else prop, value,
                                    lambda f, v: self.set(f, owner, prop, v) if enabled else None,
                                    tooltip=lambda: prop_description(owner, prop)), owner, prop)

    def check(self, owner, prop, key=None, tooltip=None, enabled=True):
        value = bool(getattr(owner, prop))
        return self._keyable(CheckBox(key or owner_key(owner, prop), value,
                                      lambda f, v: self.set(f, owner, prop, v),
                                      tooltip=tooltip or (lambda: prop_description(owner, prop)),
                                      enabled=enabled), owner, prop)

    def toggle_button(self, owner, prop, text="", icon=None, key=None, tooltip=None, flex=None):
        """prop(..., toggle=True): botão que fica "apertado" quando True."""
        value = bool(getattr(owner, prop))
        return Button(key or owner_key(owner, prop), text,
                      lambda f: self.set(f, owner, prop, not value), icon=icon, selected=value,
                      tooltip=tooltip or (lambda: prop_description(owner, prop)),
                      style=Style(height=CONTROL_H, flex=flex or 0.0,
                                  width=CONTROL_H if not text else None))

    def number(self, owner, prop, label="", index=None, key=None, enabled=True):
        p = rna_prop(owner, prop)
        raw = getattr(owner, prop)
        value = raw[index] if index is not None else raw
        integer = p is not None and p.type == "INT"
        degrees = p is not None and (getattr(p, "unit", "") == "ROTATION" or p.subtype in {"ANGLE", "EULER"})
        precision = 0 if integer else min(4, max(1, getattr(p, "precision", 2) or 2))
        if degrees:
            import math
            value = math.degrees(value)
            precision = 1
        lo = hi = None
        if p is not None:
            lo, hi = p.hard_min, p.hard_max
            if degrees:
                lo = hi = None
            elif abs(lo) > 1e30:
                lo = None
            if hi is not None and abs(hi) > 1e30:
                hi = None
        step = 1.0
        if not integer and p is not None:
            step = max(10 ** -precision, (p.step or 3) / 100.0)
            if degrees:
                step = 1.0

        def change(f, v, final):
            if degrees:
                import math
                v = math.radians(v)
            self.set(f, owner, prop, int(v) if integer else float(v), index=index, final=final)

        return self._keyable(NumberField(
            key or owner_key(owner, prop, index), value, change, label, integer=integer,
            step=step, precision=precision, lo=lo, hi=hi, suffix="°" if degrees else "",
            enabled=enabled, tooltip=lambda: prop_description(owner, prop)), owner, prop, index)

    def vector(self, owner, prop, labels=("X", "Y", "Z")):
        return Row([self.number(owner, prop, labels[i], index=i) for i in range(len(labels))],
                   style=Style(gap=4))

    def text(self, owner, prop, placeholder="", key=None, icon=None, on_edit=None, enabled=True):
        return TextInput(key or owner_key(owner, prop), getattr(owner, prop),
                         lambda f, v: self.set(f, owner, prop, v), placeholder=placeholder, icon=icon,
                         on_edit=on_edit, enabled=enabled,
                         tooltip=lambda: prop_description(owner, prop))

    def enum(self, owner, prop, key=None, expand=None, placeholder=None, icons=None):
        """Dropdown inline (ou segmentado se `expand`). Devolve UM widget;
        com o dropdown aberto é uma Column (campo + opções)."""
        key = key or owner_key(owner, prop)
        items = enum_items(owner, prop, self.context)
        current = getattr(owner, prop)
        if expand is None:
            expand = 0 < len(items) <= 3 and all(len(name) <= 10 for _, name, _ in items)
        if expand and items:
            options = [(i, name, (icons or {}).get(i)) for i, name, _ in items]
            return Segmented(key, options, current,
                             lambda f, v: self.set(f, owner, prop, v),
                             style=Style(height=CONTROL_H),
                             tooltip=lambda: prop_description(owner, prop))
        names = {i: name for i, name, _ in items}
        is_open = self.state.get("_open_menu") == key

        def toggle(f):
            f.state["_open_menu"] = None if is_open else key

        header = DropdownHeader(key, names.get(current, current or placeholder or "—"), toggle,
                                is_open=is_open, icon=(icons or {}).get(current),
                                placeholder=not current, tooltip=lambda: prop_description(owner, prop))
        if not is_open:
            return header

        def pick(value):
            def run(f):
                f.state["_open_menu"] = None
                self.set(f, owner, prop, value)
            return run
        rows = [OptionRow("%s.opt.%s" % (key, i), name, pick(i), icon=(icons or {}).get(i),
                          selected=(i == current), tooltip=desc or None)
                for i, name, desc in items]
        return Column(header, option_list(rows, key=key + ".list"), style=Style(gap=4))

    def section(self, wm_prop, title, icon, build_content, right=None, key=None):
        """Seção recolhível ligada ao MESMO Bool do WindowManager que o
        painel clássico usa (hytale_show_*): aberta aqui = aberta lá."""
        is_open = bool(getattr(self.wm, wm_prop))
        header = SectionHeader(key or "sec." + wm_prop, title, is_open,
                               lambda f, v: setattr(self.wm, wm_prop, v), icon=icon, right=right)
        if not is_open:
            return header
        content = build_content()
        if isinstance(content, (list, tuple)):
            content = Column([c for c in content if c is not None], style=Style(gap=6))
        return Column(header, Column(content, style=Style(padding=(4, 2, 0, 2), gap=6)), style=Style(gap=4))

    def labeled(self, label, *controls, split=0.38, tooltip=None):
        return labeled(label, *controls, split=split, tooltip=tooltip)

    def icon_button(self, key, icon, on_click, tooltip=None, enabled=True, selected=False):
        return icon_button(key, icon, on_click, tooltip=tooltip, enabled=enabled, selected=selected)
