"""cube_mesh.py -- gera a malha de um bloco "cru" (cubo padrao do motor,
sem .blockymodel proprio -- ver block_def.py). Cada grupo de face usa sua
propria imagem dedicada, sem atlas -- UV e so o retangulo (0,0)-(1,1). So a
topologia (ordem de vertices/faces) e reaproveitada de box_mesh.py."""

from __future__ import annotations

import bmesh
import bpy

from .box_mesh import BOX_FACE_FIXED_AXIS, BOX_FACES_LOOP_ORDER, orient_faces_outward

# Up/Down sao grupos separados (materiais proprios); as outras 4 faces
# compartilham "sides". Ver DEVELOPER_NOTES.md ("Texturas de cube").
_FACE_GROUP = {
    "top": "up",
    "bottom": "down",
    "front": "sides",
    "back": "sides",
    "left": "sides",
    "right": "sides",
}


def build_cube_mesh(name: str, size: float):
    """Cubo centrado na origem, lado `size` (ja em unidades Blender).
    material_index 0 = sides, 1 = up, 2 = down. As 6 faces SEMPRE sao
    criadas (nunca vira so vertices soltos) -- se um grupo nao tem textura,
    o material dele e que recebe o placeholder cinza (ver _build_mesh_entry /
    materials.get_or_create_flat_material)."""
    h = size / 2.0
    verts_co = [
        (-h, -h, -h), (h, -h, -h), (h, h, -h), (-h, h, -h),
        (-h, -h, h), (h, -h, h), (h, h, h), (-h, h, h),
    ]

    mesh = bpy.data.meshes.new(name + "_mesh")
    mesh.materials.append(None)  # slot 0: sides
    mesh.materials.append(None)  # slot 1: up
    mesh.materials.append(None)  # slot 2: down

    _GROUP_MATERIAL_INDEX = {"sides": 0, "up": 1, "down": 2}

    bm = bmesh.new()
    bm_verts = [bm.verts.new(co) for co in verts_co]
    uv_layer = bm.loops.layers.uv.new()

    for face_key, idxs in BOX_FACES_LOOP_ORDER:
        group = _FACE_GROUP[face_key]
        face = bm.faces.new([bm_verts[i] for i in idxs])
        face.material_index = _GROUP_MATERIAL_INDEX[group]

        # UV cheio (0..1), sem atlas -- so precisa de ordem consistente pra
        # textura nao sair espelhada entre faces.
        fixed_axis = BOX_FACE_FIXED_AXIS[face_key]
        axis_u, axis_v = {"z": (0, 1), "y": (0, 2), "x": (2, 1)}[fixed_axis]
        for loop in face.loops:
            co = loop.vert.co
            u = (co[axis_u] + h) / size
            v = (co[axis_v] + h) / size
            loop[uv_layer].uv = (u, v)

    # Faces pra FORA (a ordem de BOX_FACES_LOOP_ORDER deixava as 6 pra
    # dentro -- ver box_mesh.orient_faces_outward).
    orient_faces_outward(bm)
    bm.to_mesh(mesh)
    bm.free()
    return mesh
