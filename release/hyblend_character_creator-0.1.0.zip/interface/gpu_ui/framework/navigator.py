"""Navegador próprio (orbe de eixos + botões) para quando o painel é alargado.

O gizmo nativo de navegação fica no canto direito do viewport e acabaria
coberto pelo painel. O host esconde o nativo e este módulo desenha um
navegador equivalente, À ESQUERDA da borda do painel, com o mesmo visual da
nossa UI. Ele não reimplementa matemática de câmera: só desenha e chama os
operadores do próprio Blender (view3d.rotate, view3d.view_axis, view3d.zoom...).

Custo: ~20 primitivas desenhadas direto no viewport, e só enquanto o painel
está alargado. O orbe depende da rotação da vista, então não vai para o cache.
"""

import bpy
from mathutils import Vector

from .core import Rect
from .motion import mix

# eixo → (vetor, operador view_axis, oposto)
_AXES = (
    ("X", (1, 0, 0), "RIGHT", "LEFT"), ("-X", (-1, 0, 0), "LEFT", "RIGHT"),
    ("Y", (0, 1, 0), "BACK", "FRONT"), ("-Y", (0, -1, 0), "FRONT", "BACK"),
    ("Z", (0, 0, 1), "TOP", "BOTTOM"), ("-Z", (0, 0, -1), "BOTTOM", "TOP"),
)
_FALLBACK_COLORS = {"X": (1.0, 0.2, 0.32), "Y": (0.54, 0.86, 0.0), "Z": (0.16, 0.56, 1.0)}


def _axis_colors(context):
    ui = context.preferences.themes[0].user_interface
    return {name: tuple(getattr(ui, "axis_" + name.lower(), fallback))[:3]
            for name, fallback in _FALLBACK_COLORS.items()}


class Navigator:
    BUTTON_R = 14.0

    def __init__(self, host):
        self.host = host
        self.hover = None          # "orb", ("axis", nome) ou ("button", id)
        self._shape = None         # geometria do último desenho (para hit-test)

    # ------------------------------------------------------------- geometria
    def _active(self, context):
        space = context.space_data
        return (self.host.extended and self.host._nav_hidden
                and space is not None and space.show_gizmo)

    def _layout(self, context):
        view = context.preferences.view
        radius = view.gizmo_size_navigate_v3d / 2
        p = self.host.panel
        cx, cy = p.x - 14 - radius, p.top - 6 - radius
        show_orb = view.mini_axis_type == "GIZMO"
        orb = None
        bubbles = []
        if show_orb:
            rotation = context.region_data.view_matrix.to_3x3()
            reach = radius - 11
            for name, vec, view_type, opposite in _AXES:
                v = rotation @ Vector(vec)                 # espaço da vista: z > 0 = para o observador
                positive = not name.startswith("-")
                bubbles.append((v.z, name, cx + v.x * reach, cy + v.y * reach,
                                9.0 if positive else 7.0, view_type, opposite))
            bubbles.sort()                                 # desenha do fundo para a frente
            orb = (cx, cy, radius)
        buttons = []
        if getattr(view, "show_navigate_ui", True):
            rd = context.region_data
            camera = rd.view_perspective == "CAMERA"
            items = [("zoom", "search"), ("pan", "move"),
                     ("camera", "camera"),
                     ("lock", "lock" if context.space_data.lock_camera else "unlock") if camera
                     else ("persp", "persp" if rd.is_perspective else "ortho")]
            y = (cy - radius - 12 - self.BUTTON_R) if show_orb else p.top - 6 - self.BUTTON_R
            for ident, icon in items:
                buttons.append((ident, icon, cx, y))
                y -= self.BUTTON_R * 2 + 6
        self._shape = (orb, bubbles, buttons)

    def contains(self, x, y):
        return self._shape is not None and self._hit(x, y) is not None

    def _hit(self, x, y):
        orb, bubbles, buttons = self._shape
        for ident, _, bx, by in buttons:
            if (x - bx) ** 2 + (y - by) ** 2 <= self.BUTTON_R ** 2:
                return ("button", ident)
        if orb:
            for depth, name, bx, by, r, *_ in reversed(bubbles):   # o da frente ganha
                if (x - bx) ** 2 + (y - by) ** 2 <= (r + 2) ** 2:
                    return ("axis", name)
            cx, cy, radius = orb
            if (x - cx) ** 2 + (y - cy) ** 2 <= radius ** 2:
                return "orb"
        return None

    # ----------------------------------------------------------------- desenho
    def draw(self, context, region, sidebar):
        if not self._active(context):
            self._shape = None
            self.hover = None
            return
        self._layout(context)
        host = self.host
        s = host.geo.scale
        r = host.renderer
        th = host.theme
        r.begin(s, linear=True)                    # direto no viewport: cor linear
        r.offset_x = (sidebar.x - region.x) / s
        r.offset_y = (sidebar.y - region.y) / s
        try:
            orb, bubbles, buttons = self._shape
            if orb:
                cx, cy, radius = orb
                if self.hover == "orb" or (isinstance(self.hover, tuple) and self.hover[0] == "axis"):
                    r.rect(Rect(cx - radius, cy - radius, radius * 2, radius * 2),
                           (1.0, 1.0, 1.0, 0.10), radius=radius)
                colors = _axis_colors(context)
                for depth, name, bx, by, br, *_ in bubbles:
                    base = colors[name[-1]]
                    positive = not name.startswith("-")
                    if positive:                   # haste do centro até o eixo
                        steps = 10
                        for i in range(1, steps):
                            t = i / steps
                            r.rect(Rect(cx + (bx - cx) * t - 1, cy + (by - cy) * t - 1, 2, 2),
                                   base + (0.9,), radius=1)
                    hovered = self.hover == ("axis", name)
                    if hovered:
                        r.rect(Rect(bx - br - 2, by - br - 2, (br + 2) * 2, (br + 2) * 2),
                               (1.0, 1.0, 1.0, 0.9), radius=br + 2)
                    fill = base + (1.0,) if positive else mix(base + (1.0,), (0.1, 0.1, 0.12, 1.0), 0.55)
                    r.rect(Rect(bx - br, by - br, br * 2, br * 2), fill, radius=br,
                           border=None if positive else base + (0.9,), border_width=1.5)
                    if positive:
                        r.text(Rect(bx - br, by - br, br * 2, br * 2), name, (0.05, 0.05, 0.07, 1.0),
                               size=10, weight="SemiBold", align="CENTER", truncate=False)
            for ident, icon, bx, by in buttons:
                hovered = self.hover == ("button", ident)
                rad = self.BUTTON_R
                r.rect(Rect(bx - rad, by - rad, rad * 2, rad * 2),
                       th.surface_hover if hovered else th.canvas[:3] + (0.72,),
                       radius=rad, border=th.border)
                r.icon(Rect(bx - 7, by - 7, 14, 14), icon, th.text if hovered else th.text_muted)
        finally:
            r.end()

    # ----------------------------------------------------------------- eventos
    def on_event(self, context, event, x, y, found):
        """None = não é comigo; senão, o resultado do modal."""
        if self._shape is None:
            return None
        hit = self._hit(x, y)
        viewport = found[3]
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            if hit != self.hover:
                self.hover = hit
                if viewport:
                    viewport.tag_redraw()          # o navegador não está no cache: só recompõe
            if hit is not None:
                if self.host.state.pop("_hover", None) is not None:
                    self.host.request()
                return {"PASS_THROUGH"}
            return None
        if hit is None:
            return None
        if event.type == "LEFTMOUSE" and event.value in {"PRESS", "DOUBLE_CLICK"}:
            self._run(hit, found)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE":
            return {"RUNNING_MODAL"}
        return None

    def _run(self, hit, found):
        window, area, _, viewport = found
        override = {"window": window, "area": area, "region": viewport}
        with bpy.context.temp_override(**override):
            if hit == "orb":
                bpy.ops.view3d.rotate("INVOKE_DEFAULT")          # arrastar = orbitar
            elif hit[0] == "axis":
                entry = next(b for b in self._shape[1] if b[1] == hit[1])
                depth, _, _, _, _, view_type, opposite = entry
                # clicar no eixo que já está de frente vira para o lado oposto
                bpy.ops.view3d.view_axis(type=opposite if depth > 0.98 else view_type)
            elif hit[1] == "zoom":
                bpy.ops.view3d.zoom("INVOKE_DEFAULT")            # arrastar = zoom
            elif hit[1] == "pan":
                bpy.ops.view3d.move("INVOKE_DEFAULT")            # arrastar = pan
            elif hit[1] == "camera":
                bpy.ops.view3d.view_camera()
            elif hit[1] == "persp":
                bpy.ops.view3d.view_persportho()
            elif hit[1] == "lock":
                space = area.spaces.active
                space.lock_camera = not space.lock_camera
        if viewport:
            viewport.tag_redraw()
