"""Auto-Rigger -- Shape Edit Mode / Vertex Edit Mode / Mirror Shape / Use Selected as Widget."""

import bmesh
import bpy
import blf
import gpu
from gpu_extras.batch import batch_for_shader
from bpy.types import Operator

from ..translations import tooltip

from .constants import (
    PROP_WIDGET_SOURCE_ROLE,
)

from .helpers import _redraw_all_areas
from .constraints import armature_has_generated_bones
from .widgets import _bone_widget_name, _compute_bone_widget_world_matrix, _mute_shape_scale_drivers, _restore_shape_scale_drivers, _set_collection_excluded, _unmute_shape_scale_drivers, get_or_create_widgets_collection


SHAPE_EDIT_BORDER_COLOR = (1.0, 0.85, 0.1, 0.9)
SHAPE_EDIT_BORDER_THICKNESS = 2
SHAPE_EDIT_BORDER_TEXT = "Shape Edit Mode"
SHAPE_VERTEX_EDIT_BORDER_TEXT = "Shape Vertex Edit Mode"
SHAPE_EDIT_BORDER_TEXT_SIZE = 16
SHAPE_EDIT_BORDER_TEXT_PADDING = 34
SHAPE_EDIT_BORDER_TEXT_SHADOW_COLOR = (0.0, 0.0, 0.0, 0.6)

_shape_edit_border_shader = None
_shape_edit_border_handler = None


def register_shape_edit_border():
    """Registra o draw_handler_add global, uma vez por sessão do
    Blender (não por Armature). Chamado por rigger/__init__.py."""
    global _shape_edit_border_handler
    if _shape_edit_border_handler is None:
        _shape_edit_border_handler = bpy.types.SpaceView3D.draw_handler_add(
            _draw_shape_edit_border, (), "WINDOW", "POST_PIXEL"
        )


def unregister_shape_edit_border():
    global _shape_edit_border_handler, _shape_edit_border_shader
    if _shape_edit_border_handler is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_shape_edit_border_handler, "WINDOW")
        _shape_edit_border_handler = None
    _shape_edit_border_shader = None


def _draw_shape_edit_border():
    context = bpy.context
    obj = context.active_object
    if obj is None:
        return

    # Dois estados mostram a borda: Shape Edit Mode "de fora" (Armature
    # ativo) ou Vertex Edit Mode (objeto ativo é a MESH do widget) --
    # nunca coincidem.
    if obj.type == "MESH" and obj.get("hytale_vertex_edit_armature"):
        border_text = SHAPE_VERTEX_EDIT_BORDER_TEXT
    elif obj.type == "ARMATURE" and getattr(obj.data, "hytale_shape_edit_mode", False):
        border_text = SHAPE_EDIT_BORDER_TEXT
    else:
        return

    region = context.region
    if region is None or region.width <= 0 or region.height <= 0:
        return

    global _shape_edit_border_shader
    if _shape_edit_border_shader is None:
        _shape_edit_border_shader = gpu.shader.from_builtin("UNIFORM_COLOR")

    w, h = region.width, region.height
    t = SHAPE_EDIT_BORDER_THICKNESS
    # Quatro faixas formando uma moldura -- quads em vez de GL_LINE com
    # largura (não confiável em core profile).
    coords = [
        (0, 0), (w, 0), (w, t), (0, t),                  # baixo
        (0, h - t), (w, h - t), (w, h), (0, h),           # cima
        (0, 0), (t, 0), (t, h), (0, h),                   # esquerda
        (w - t, 0), (w, 0), (w, h), (w - t, h),           # direita
    ]
    indices = [
        (0, 1, 2), (0, 2, 3),
        (4, 5, 6), (4, 6, 7),
        (8, 9, 10), (8, 10, 11),
        (12, 13, 14), (12, 14, 15),
    ]
    batch = batch_for_shader(_shape_edit_border_shader, "TRIS", {"pos": coords}, indices=indices)

    gpu.state.blend_set("ALPHA")
    _shape_edit_border_shader.bind()
    _shape_edit_border_shader.uniform_float("color", SHAPE_EDIT_BORDER_COLOR)
    batch.draw(_shape_edit_border_shader)
    gpu.state.blend_set("NONE")

    _draw_shape_edit_border_text(w, h, t, border_text)


def _draw_shape_edit_border_text(w, h, border_thickness, text):
    """Desenha `text` centralizado, logo abaixo da faixa de cima."""
    font_id = 0
    blf.size(font_id, SHAPE_EDIT_BORDER_TEXT_SIZE)
    text_width, text_height = blf.dimensions(font_id, text)
    text_x = round((w - text_width) / 2.0)
    text_y = h - border_thickness - SHAPE_EDIT_BORDER_TEXT_PADDING - text_height

    blf.color(font_id, *SHAPE_EDIT_BORDER_TEXT_SHADOW_COLOR)
    blf.position(font_id, text_x - 1, text_y - 1, 0)
    blf.draw(font_id, text)

    blf.color(font_id, *SHAPE_EDIT_BORDER_COLOR)
    blf.position(font_id, text_x, text_y, 0)
    blf.draw(font_id, text)


class RIG_OT_hytale_shape_edit_mode_enter(Operator):
    """Muta todo driver de shape scale do armature ativo, resolvido pro
    tamanho cheio -- libera redimensionar qualquer custom shape sem o
    driver de FK/IK sobrescrevendo. Troca pra Pose Mode se preciso."""

    bl_idname = "armature.hytale_shape_edit_mode_enter"
    bl_label = "Shape Edit Mode"
    description = tooltip("rigger.tooltip.shape_edit_mode_enter")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != "ARMATURE":
            return False
        armature = obj.data
        if not armature_has_generated_bones(armature):
            cls.poll_message_set("Run 'Create Rig' first -- there's no generated rig on this armature yet.")
            return False
        if getattr(armature, "hytale_shape_edit_mode", False):
            cls.poll_message_set("Already in Shape Edit Mode.")
            return False
        return True

    def execute(self, context):
        obj = context.active_object
        armature = obj.data

        if obj.mode != "POSE":
            bpy.ops.object.mode_set(mode="POSE")

        muted = _mute_shape_scale_drivers(obj)

        armature.hytale_shape_edit_mode = True
        _redraw_all_areas(context)
        if muted:
            self.report(
                {"INFO"},
                f"Shape Edit Mode on -- {muted} shape-scale driver channel(s) muted at full size. Resize custom "
                f"shapes freely, then use 'Finish Shape Edit Mode' to save.",
            )
        else:
            self.report(
                {"INFO"},
                "Shape Edit Mode on -- this armature has no FK/IK shape-scale drivers, so every custom shape was "
                "already freely editable. Use 'Finish Shape Edit Mode' when done.",
            )
        return {"FINISHED"}


class RIG_OT_hytale_shape_edit_mode_finish(Operator):
    """Contrário de Enter: pra cada driver mutado, grava o valor atual
    do pose bone como novo tamanho cheio na expressão, depois desmuta.
    Não força volta de modo."""

    bl_idname = "armature.hytale_shape_edit_mode_finish"
    bl_label = "Finish Shape Edit Mode"
    description = tooltip("rigger.tooltip.shape_edit_mode_finish")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != "ARMATURE":
            return False
        if not getattr(obj.data, "hytale_shape_edit_mode", False):
            cls.poll_message_set("Not currently in Shape Edit Mode.")
            return False
        if getattr(obj.data, "hytale_shape_vertex_edit_mode", False):
            cls.poll_message_set("Finish Vertex Edit Mode first.")
            return False
        return True

    def execute(self, context):
        obj = context.active_object
        armature = obj.data

        restored = _restore_shape_scale_drivers(obj)

        armature.hytale_shape_edit_mode = False
        _redraw_all_areas(context)
        self.report(
            {"INFO"},
            f"Shape Edit Mode off -- {restored} shape-scale driver channel(s) restored, new size(s) saved as "
            f"the max value.",
        )
        return {"FINISHED"}


# --- Vertex Edit Mode: edita a malha do widget por vértice, por-bone (nunca compartilhada) ---
#
# O Blender guarda .mode por OBJETO, não globalmente -- trocar o objeto
# ativo pra malha do widget e chamar mode_set(EDIT) não tira o Armature
# do Pose Mode "por baixo". interface.py trata isso com um branch
# especial (obj.type == 'MESH' + 'hytale_vertex_edit_armature').


class RIG_OT_hytale_shape_vertex_edit_mode_enter(Operator):
    """Entra em Edit Mode direto na malha do custom shape do bone
    ativo. Esconde todo outro widget deste Armature, move o objeto pra
    cima do bone (senão apareceria longe, na posição de quando foi
    apendado) e desmuta os drivers de FK/IK -- Shape Edit Mode "de
    fora" deixa tudo em tamanho cheio, o que sobreporia FK e IK; aqui
    o resto volta a respeitar o switch normalmente enquanto dura a
    edição, sem perder nenhuma calibração em andamento em outro bone.
    Só disponível dentro do Shape Edit Mode externo."""

    bl_idname = "armature.hytale_shape_vertex_edit_mode_enter"
    bl_label = "Edit Shape Vertices"
    description = tooltip("rigger.tooltip.shape_vertex_edit_mode_enter")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != "ARMATURE":
            return False
        if not getattr(obj.data, "hytale_shape_edit_mode", False):
            cls.poll_message_set("Only available during Shape Edit Mode.")
            return False
        if getattr(obj.data, "hytale_shape_vertex_edit_mode", False):
            cls.poll_message_set("Already editing a shape's vertices -- use 'Finish Vertex Edit' first.")
            return False
        active_pb = context.active_pose_bone
        if active_pb is None or active_pb.custom_shape is None:
            cls.poll_message_set("Active bone must have a custom shape assigned.")
            return False
        return True

    def execute(self, context):
        armature_obj = context.active_object
        active_pb = context.active_pose_bone
        target_obj = active_pb.custom_shape

        widgets_collection = get_or_create_widgets_collection(armature_obj)
        _set_collection_excluded(widgets_collection, False)

        for wgt_obj in widgets_collection.objects:
            wgt_obj.hide_select = False
            wgt_obj.hide_set(wgt_obj is not target_obj)

        # Rede de segurança: se o custom shape não vier da collection
        # WGT (override manual apontando pra fora), garante visível
        # mesmo assim -- senão o mode_set(EDIT) abaixo falha em silêncio.
        target_obj.hide_select = False
        target_obj.hide_set(False)

        target_obj.matrix_world = _compute_bone_widget_world_matrix(armature_obj, active_pb)

        # Desmuta DEPOIS de posicionar -- a posição usou o valor "cheio"
        # de antes de desmutar, fica estável mesmo que o driver reavalie.
        restored = _unmute_shape_scale_drivers(armature_obj)

        # API direta em vez de bpy.ops.object.select_all -- esse
        # operator pode falhar com "context is incorrect" dependendo
        # de como o botão foi clicado (relatado por usuário real).
        for other_obj in context.view_layer.objects:
            other_obj.select_set(False)
        target_obj.select_set(True)
        context.view_layer.objects.active = target_obj

        bpy.ops.object.mode_set(mode="EDIT")

        target_obj["hytale_vertex_edit_armature"] = armature_obj.name
        target_obj["hytale_vertex_edit_bone"] = active_pb.name
        armature_obj.data.hytale_shape_vertex_edit_mode = True

        self.report(
            {"INFO"},
            f"Editing vertices of '{target_obj.name}' (bone '{active_pb.name}') -- other widgets of this "
            f"character are hidden, and {restored} FK/IK shape-scale driver(s) unmuted (no calibrated size was "
            f"changed). Use 'Finish Vertex Edit' when done.",
        )
        return {"FINISHED"}


class RIG_OT_hytale_shape_vertex_edit_mode_finish(Operator):
    """Contrário de Enter: sai do Edit Mode, re-esconde a collection
    WGT inteira, muta de novo os drivers de FK/IK e devolve o Armature
    como ativo -- ele nunca saiu do Pose Mode "por baixo", então a
    viewport volta sozinha."""

    bl_idname = "armature.hytale_shape_vertex_edit_mode_finish"
    bl_label = "Finish Vertex Edit"
    description = tooltip("rigger.tooltip.shape_vertex_edit_mode_finish")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != "MESH" or not obj.get("hytale_vertex_edit_armature"):
            cls.poll_message_set("Only available while editing a custom shape's vertices.")
            return False
        return True

    def execute(self, context):
        target_obj = context.active_object
        armature_name = target_obj.get("hytale_vertex_edit_armature")
        bone_name = target_obj.get("hytale_vertex_edit_bone", "")
        armature_obj = bpy.data.objects.get(armature_name)

        if target_obj.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")

        if "hytale_vertex_edit_armature" in target_obj:
            del target_obj["hytale_vertex_edit_armature"]
        if "hytale_vertex_edit_bone" in target_obj:
            del target_obj["hytale_vertex_edit_bone"]

        if armature_obj is not None:
            get_or_create_widgets_collection(armature_obj)  # já reexcluída
            armature_obj.data.hytale_shape_vertex_edit_mode = False
            _mute_shape_scale_drivers(armature_obj)

            for other_obj in context.view_layer.objects:
                other_obj.select_set(False)
            armature_obj.select_set(True)
            context.view_layer.objects.active = armature_obj
        else:
            self.report(
                {"WARNING"},
                "Could not find the armature this shape belongs to (renamed/deleted mid-edit?) -- the widgets "
                "collection wasn't re-hidden automatically, hide it manually in the Outliner if needed.",
            )

        self.report(
            {"INFO"},
            f"Finished editing '{target_obj.name}'" + (f" (bone '{bone_name}')." if bone_name else "."),
        )
        return {"FINISHED"}


# --- Mirror Shape: copia translation/rotation/scale (e a malha) pro bone do lado oposto ---


def _mirrored_bone_name(name):
    """Troca "L-" por "R-" (ou vice-versa) no início do nome. None se
    não começar com nenhum dos dois."""
    if name.startswith("L-"):
        return "R-" + name[len("L-"):]
    if name.startswith("R-"):
        return "L-" + name[len("R-"):]
    return None


def _mirror_mesh_data_x(mesh):
    """Espelha os vértices no eixo X local e inverte a ordem de cada
    face -- mirror num único eixo sempre inverte o winding/handedness,
    senão as normais ficam de dentro pra fora. Opera direto no
    datablock, que precisa já ser uma cópia exclusiva."""
    bm = bmesh.new()
    bm.from_mesh(mesh)
    for v in bm.verts:
        v.co.x = -v.co.x
    bmesh.ops.reverse_faces(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()


class RIG_OT_hytale_mirror_shape(Operator):
    """Espelha a malha do custom shape do bone ativo pro bone oposto
    (L-/R-), junto com Translation/Rotation/Scale. Remove primeiro
    qualquer shape próprio já atribuído ao alvo (nunca deixa órfão),
    duplica a malha de origem, espelha em X e atribui ao bone oposto.
    Translation espelha em X; Rotation/Scale são copiados direto (não
    têm handedness)."""

    bl_idname = "armature.hytale_mirror_shape"
    bl_label = "Mirror Shape"
    description = tooltip("rigger.tooltip.mirror_shape")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != "ARMATURE":
            return False
        if not getattr(obj.data, "hytale_shape_edit_mode", False):
            cls.poll_message_set("Only available during Shape Edit Mode.")
            return False
        active_pb = context.active_pose_bone
        if active_pb is None or _mirrored_bone_name(active_pb.name) is None:
            cls.poll_message_set("Active bone must start with 'L-' or 'R-' to have a mirror target.")
            return False
        if active_pb is not None and active_pb.custom_shape is None:
            cls.poll_message_set("Active bone must have a custom shape assigned to mirror.")
            return False
        return True

    def execute(self, context):
        obj = context.active_object
        source = context.active_pose_bone
        source_obj = source.custom_shape
        target_name = _mirrored_bone_name(source.name)
        target = obj.pose.bones.get(target_name)
        if target is None:
            self.report({"WARNING"}, f"Mirror target '{target_name}' not found on this armature.")
            return {"CANCELLED"}

        widgets_collection = get_or_create_widgets_collection(obj)

        old_target_obj = target.custom_shape
        if old_target_obj is not None and old_target_obj != source_obj:
            old_mesh = old_target_obj.data
            bpy.data.objects.remove(old_target_obj, do_unlink=True)
            if old_mesh is not None and old_mesh.users == 0:
                bpy.data.meshes.remove(old_mesh, do_unlink=True)

        target_widget_name = _bone_widget_name(obj.name, target.name)

        # Rede de segurança: libera o nome canônico antes de renomear a
        # cópia -- um objeto órfão com esse nome faria o Blender sufixar
        # ".001" sozinho, e chamadas futuras de _ensure_bone_widget_copy
        # (que procuram pelo nome exato) perderiam o mirror.
        stale_obj = bpy.data.objects.get(target_widget_name)
        if stale_obj is not None and stale_obj != source_obj:
            stale_mesh = stale_obj.data
            bpy.data.objects.remove(stale_obj, do_unlink=True)
            if stale_mesh is not None and stale_mesh.users == 0:
                bpy.data.meshes.remove(stale_mesh, do_unlink=True)

        new_obj = source_obj.copy()
        new_obj.data = source_obj.data.copy()
        new_obj.name = target_widget_name
        new_obj.data.name = target_widget_name
        new_obj.hide_render = True
        # Object.copy() também copia custom properties -- não deve
        # herdar marcadores de uma sessão de Vertex Edit interrompida.
        if "hytale_vertex_edit_armature" in new_obj:
            del new_obj["hytale_vertex_edit_armature"]
        if "hytale_vertex_edit_bone" in new_obj:
            del new_obj["hytale_vertex_edit_bone"]
        widgets_collection.objects.link(new_obj)

        _mirror_mesh_data_x(new_obj.data)

        target.custom_shape = new_obj
        target.use_custom_shape_bone_size = source.use_custom_shape_bone_size
        target.custom_shape_wire_width = source.custom_shape_wire_width

        src_translation = source.custom_shape_translation
        target.custom_shape_translation = (
            -src_translation[0], src_translation[1], src_translation[2],
        )
        target.custom_shape_rotation_euler = tuple(source.custom_shape_rotation_euler)
        target.custom_shape_scale_xyz = tuple(source.custom_shape_scale_xyz)

        self.report({"INFO"}, f"Mirrored '{source.name}' shape mesh onto '{target_name}'.")
        return {"FINISHED"}


class RIG_OT_hytale_use_selected_as_widget(Operator):
    """Copia a geometria de um objeto de malha selecionado (junto com o
    Armature) pro CONTEÚDO da cópia por-bone já existente do bone pose
    ativo -- não troca o Object atribuído, só a Mesh, pra continuar
    reconhecido como "gerenciado" pelo resto do sistema. Fluxo:
    selecionar a fonte -> Shift+clique no Armature -> clicar aqui, com
    Shape Edit Mode ligado.

    Copia só a geometria em espaço local, nunca a matrix_world do
    objeto-fonte -- senão a escala/rotação dele vazaria pro "shape
    space" do bone; avisa se houver transform não aplicado, mas segue
    em frente mesmo assim. Não mexe no objeto-fonte."""

    bl_idname = "armature.hytale_use_selected_as_widget"
    bl_label = "Use Selected Object as Widget"
    description = tooltip("rigger.tooltip.use_selected_as_widget")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != "ARMATURE":
            return False
        if not getattr(obj.data, "hytale_shape_edit_mode", False):
            cls.poll_message_set("Only available during Shape Edit Mode.")
            return False
        active_pb = context.active_pose_bone
        if active_pb is None or active_pb.custom_shape is None:
            cls.poll_message_set("Active bone must have a custom shape assigned.")
            return False
        source_candidates = [
            o for o in context.selected_objects if o.type == "MESH" and o is not active_pb.custom_shape
        ]
        if len(source_candidates) != 1:
            cls.poll_message_set(
                "Select exactly one other mesh object (besides the armature) to use as the widget.",
            )
            return False
        return True

    def execute(self, context):
        active_pb = context.active_pose_bone
        target_obj = active_pb.custom_shape
        source_obj = next(
            o for o in context.selected_objects if o.type == "MESH" and o is not target_obj
        )

        bm = bmesh.new()
        bm.from_mesh(source_obj.data)
        bm.to_mesh(target_obj.data)
        bm.free()
        target_obj.data.update()

        # Sem proveniência conhecida a partir de agora, ver
        # _widget_mesh_differs_from_template.
        if PROP_WIDGET_SOURCE_ROLE in target_obj:
            del target_obj[PROP_WIDGET_SOURCE_ROLE]

        has_transform = (
            tuple(source_obj.scale) != (1.0, 1.0, 1.0)
            or tuple(source_obj.rotation_euler) != (0.0, 0.0, 0.0)
        )
        message = (
            f"Copied geometry from '{source_obj.name}' into the widget of bone '{active_pb.name}' "
            f"('{target_obj.name}')."
        )
        if has_transform:
            message += (
                " Note: the source object had a non-applied scale/rotation -- only its raw local-space "
                "geometry was copied (Object > Apply > All Transforms on the source first if the shape "
                "looks off)."
            )
        self.report({"INFO"}, message)
        return {"FINISHED"}
