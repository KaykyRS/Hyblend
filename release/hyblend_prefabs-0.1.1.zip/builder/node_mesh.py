"""node_mesh.py -- o .blockymodel inteiro numa UNICA malha Blender (sem Armature/bones -- um bloco de prefab e
estatico), pelo núcleo (api.model.geometry.merged_mesh: mesma UV/normais/stretch do import do Hyblend). O resultado
e cacheado e reaproveitado por todas as instancias daquele item no prefab (ver prefab_importer.py)."""

from __future__ import annotations

import bpy
from mathutils import Matrix

from ..toolkit import api


def build_item_mesh(
    name: str,
    root_nodes: list,
    unit_scale: float,
    atlas_w: float,
    atlas_h: float,
    item_scale: float = 1.0,
    root_correction: Matrix | None = None,
) -> bpy.types.Mesh:
    """`root_nodes` = data["nodes"] cru do .blockymodel. Malha com toda a geometria visivel do item, relativa a
    origem do proprio item. `item_scale` = campo "Scale" do item, em torno da origem. `root_correction` = rotacao
    extra em torno da origem (NAO CONFIRMADO visualmente, ver prefab_importer.py/_build_mesh_entry)."""
    root = Matrix.Diagonal((item_scale, item_scale, item_scale, 1.0))
    if root_correction is not None:
        root = root @ root_correction
    return api.model.geometry.merged_mesh(name, root_nodes, unit_scale, atlas_w, atlas_h, root=root)
