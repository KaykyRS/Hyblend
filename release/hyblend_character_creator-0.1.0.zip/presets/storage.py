"""storage.py -- salvar/carregar presets de personagem (a combinacao
completa de categoria -> item/cor/variante equipados) como JSON em disco.

Mesma convencao de pasta que thumbnails/cache.py -- Documentos/Hyblend/
CharacterCreator/, so numa subpasta propria (presets/) -- mantem tudo
deste addon organizado sob o mesmo guarda-chuva do Hyblend, decisao ja
tomada la no comeco da conversa de design.

Puro Python, sem bpy -- so decide ONDE e COMO o preset e guardado, nao
sabe nada sobre Armature/Object. Quem le/escreve o estado de verdade do
personagem (character_assembly.get_equipped_item / bpy.ops.hyblendcc.
apply_slot) mora no __init__.py, que ja tem acesso a bpy."""

from __future__ import annotations

import json
from pathlib import Path

from ..paths import data_root


def presets_root() -> Path:
    root = data_root() / "presets"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _sanitize(name: str) -> str:
    """Nome de preset vira nome de arquivo -- troca qualquer coisa que
    nao seja seguro em path por '_', mas preserva espaco (nomes de
    preset sao pra ser lidos por humano, diferente dos Ids tecnicos de
    item)."""
    cleaned = "".join(c if (c.isalnum() or c in "-_ ") else "_" for c in name).strip()
    return cleaned or "preset"


def preset_path(name: str) -> Path:
    return presets_root() / f"{_sanitize(name)}.json"


def list_presets() -> list:
    """Nomes de preset (sem a extensao .json), ordenados alfabeticamente."""
    return sorted(p.stem for p in presets_root().glob("*.json"))


def save_preset(name: str, slots: dict) -> Path:
    """`slots` e {categoria: {"item_id": ..., "color": ..., "variant": ...}}
    -- o MESMO formato que character_assembly.get_equipped_item ja
    devolve por categoria, so agregado pra todas de uma vez."""
    path = preset_path(name)
    payload = {"slots": slots}
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def load_preset(name: str) -> dict:
    """Devolve o dict de slots gravado (ver save_preset). Levanta
    FileNotFoundError/json.JSONDecodeError se o preset nao existir ou
    estiver corrompido -- quem chama (Operator) decide como reportar."""
    path = preset_path(name)
    data = json.loads(path.read_text(encoding="utf-8"))
    return data.get("slots", {})


def delete_preset(name: str) -> bool:
    path = preset_path(name)
    if path.is_file():
        path.unlink()
        return True
    return False
