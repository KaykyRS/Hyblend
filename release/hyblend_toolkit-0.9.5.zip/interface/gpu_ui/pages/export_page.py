"""Aba Export -- mesmos campos/botões de HYTALE_PT_main._draw_export."""

from ..framework.core import Column, Label, Row, Style
from ..widgets import Hint, ListRow, card, labeled, list_box, list_with_buttons
from ....common import HYTALE_OT_pick_bone_into_field
from ....exporter import (
    EXPORT_OT_hytale_blockyanim,
    EXPORT_OT_hytale_blockymodel,
    EXPORT_OT_hytale_fbx_anim,
    EXPORT_OT_hytale_fbx_model,
    EXPORT_OT_texture_picker_export_add,
    EXPORT_OT_texture_picker_export_remove,
)
from .common import active_armature, bone_field, text_field


def _texture_picker(ui, obj):
    t = ui.t
    armature = obj.data
    exports = armature.hytale_texture_picker_exports
    index = armature.hytale_texture_picker_exports_index

    def select(i):
        return lambda f: ui.set(f, armature, "hytale_texture_picker_exports_index", i)

    rows = [ListRow("tpx.%d" % i, item.uv_offset_target_bone or "(no target bone)", select(i),
                    icon="image", selected=(i == index))
            for i, item in enumerate(exports)]
    content = Column(rows, style=Style(gap=2)) if rows else Label("—", color=ui.theme.text_muted,
                                                                   align="CENTER", style=Style(height=26))
    parts = [list_with_buttons(list_box(content, 4, "tpx.scroll"), [
        ui.op("tpx.add", EXPORT_OT_texture_picker_export_add, "", icon="plus"),
        ui.op("tpx.remove", EXPORT_OT_texture_picker_export_remove, "", icon="minus"),
    ])]
    if exports and 0 <= index < len(exports):
        item = exports[index]
        picker_path = "data.hytale_texture_picker_exports[%d]" % index

        def picker(field):
            return (HYTALE_OT_pick_bone_into_field, {"data_path": picker_path, "field": field})
        source_label = item.bl_rna.properties["uv_offset_source_bone"].name
        parts += [
            bone_field(ui, item, "uv_offset_source_bone", source_label, picker=picker("uv_offset_source_bone")),
            bone_field(ui, item, "uv_offset_target_bone", t("panel.texture_picker_target_bone"),
                       picker=picker("uv_offset_target_bone")),
            labeled(t("panel.texture_picker_extra_target_bones"), ui.text(item, "uv_offset_target_bones_extra")),
            Row(ui.number(item, "uv_offset_step_x", item.bl_rna.properties["uv_offset_step_x"].name),
                ui.number(item, "uv_offset_px_x", item.bl_rna.properties["uv_offset_px_x"].name),
                style=Style(gap=4)),
            Row(ui.number(item, "uv_offset_step_y", item.bl_rna.properties["uv_offset_step_y"].name),
                ui.number(item, "uv_offset_px_y", item.bl_rna.properties["uv_offset_px_y"].name),
                style=Style(gap=4)),
        ]
    return parts


def build(ui):
    t = ui.t
    obj = active_armature(ui.context)
    widgets = []
    if obj is not None:
        widgets.append(card(Hint("%s %s" % (t("panel.hint_export_target"), obj.name), icon="rig", tone="info")))
        settings = obj.data.hytale_export_settings
        collections = [c.name for c in obj.data.collections_all]
        wip = Label(t("panel.warn_texture_picker_wip_short"), size=10.5, color=ui.theme.warning,
                    align="RIGHT")
        widgets.append(card(
            text_field(ui, settings, "export_collection_name", t("panel.export_collection"), collections,
                       icon="collection"),
            ui.section("hytale_show_export_texture_picker", t("panel.export_texture_picker"), "image",
                       lambda: _texture_picker(ui, obj), right=wip),
            title=t("panel.export_settings_box"), icon="gear",
        ))
    else:
        widgets.append(card(Hint(t("panel.hint_export_none"), icon="error", tone="danger")))

    widgets.append(Column(
        ui.op("export.anim", EXPORT_OT_hytale_blockyanim, t("panel.btn_export"), icon="export",
              variant="primary", enabled=obj is not None, height=38),
        ui.op("export.model", EXPORT_OT_hytale_blockymodel, t("panel.btn_export_model"), icon="rig",
              enabled=obj is not None, height=32),
        style=Style(gap=6),
    ))

    def more():
        return [
            Hint(t("panel.hint_more_exports"), icon="info"),
            Label("FBX", size=11, weight="SemiBold", color=ui.theme.text_muted, style=Style(height=18)),
            ui.op("export.fbx_model", EXPORT_OT_hytale_fbx_model, t("panel.btn_export_fbx_model"), icon="mesh",
                  enabled=obj is not None),
            ui.op("export.fbx_anim", EXPORT_OT_hytale_fbx_anim, t("panel.btn_export_fbx_anim"), icon="anim",
                  enabled=obj is not None),
        ]
    widgets.append(card(ui.section("hytale_show_more_exports", t("panel.more_exports"), "more", more), gap=0))
    return widgets
