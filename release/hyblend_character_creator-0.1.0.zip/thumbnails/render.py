"""render.py -- renderiza uma miniatura (PNG) de um item de customizacao,
isolado (sem Armature nenhum), pra alimentar um picker visual. Roda numa
cena temporaria separada da cena do usuario, e desfaz tudo que criou no
final (so o PNG final fica).

Reaproveita build_shape_mesh (builder/box_mesh.py) pra geometria, e as
mesmas funcoes de composicao de matriz que character_assembly.py usa
(_node_local_matrix/_shape_offset_of) -- aqui compostas desde a RAIZ do
proprio arquivo (Matrix.Identity), sem nenhum bone/Armature envolvido, ja
que a miniatura so precisa mostrar a FORMA da peca isolada, nao onde ela
fica no corpo do Player.

AVISO: nao testavel no sandbox de desenvolvimento (sem Blender) -- ao
contrario de model_tree.py/manifest_parser.py (puro Python) e de
character_assembly.py (que pelo menos foi validado indiretamente pelos
testes reais dentro do Blender ao longo da conversa), este e o primeiro
codigo do addon que mexe em Scene/Camera/Light/render -- area nova,
tratar o primeiro teste real como teste de verdade, nao como "deveria
funcionar".
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import bpy
from mathutils import Matrix, Vector

from ..builder.box_mesh import build_shape_mesh
from ..builder.character_assembly import _node_local_matrix, _shape_offset_of
from ..builder.model_tree import UNIT_SCALE_DEFAULT
from ..compat import set_eevee_engine, set_png_output

# Correcao de eixo Y-up (jogo) -> Z-up (Blender). Quando uma peca e
# anexada a um Armature de verdade (ver character_assembly.py), essa
# correcao "vem de graca" atraves da orientacao do bone reaproveitado
# (o Player, importado pelo Hyblend, ja nasce com essa correcao aplicada
# na raiz do esqueleto). A miniatura NAO tem Armature nenhum -- por isso
# compoe a arvore a partir de Matrix.Identity() teria a peca deitada (foi
# exatamente o sintoma relatado no primeiro teste real). Aplicamos a
# MESMA correcao aqui manualmente, como matriz-raiz da composicao.
#
# +90 graus em X e o sentido mais comum pra esse tipo de conversao
# (Y-pra-frente/cima vira Z-pra-cima) -- se a miniatura ainda vier girada
# errado (de cabeca pra baixo, ou deitada pro lado oposto), o unico
# ajuste necessario e trocar o sinal aqui (-90) ou tentar 'Y'/'Z' como
# eixo -- nao devia precisar mexer em mais nada.
_UP_AXIS_CORRECTION_DEGREES = 90.0
_UP_AXIS_CORRECTION_AXIS = "X"


def _collect_shape_world_matrices(root_nodes: list, unit_scale: float, root_correction: Matrix) -> list:
    """Anda a arvore desde a raiz do PROPRIO ARQUIVO (sem casar com bone
    nenhum de Armature -- essa e a diferenca chave vs
    character_assembly.py). Devolve [(node, matriz_de_mundo_da_MESH), ...]
    pra cada no com geometria visivel (shape.type in box/quad).

    BUG REAL CORRIGIDO (confirmado contra MorningLong.blockymodel --
    varias pecas de cabelo com shape.offset proprio nao-zero: "Top",
    "Side", "LongSide"): a posicao final de uma peca tem DOIS
    deslocamentos, nao um. O primeiro (position do no + offset do PAI) da
    a posicao do "pivo" do no -- isso ja estava certo aqui. O SEGUNDO
    (offset PROPRIO do no) desloca a malha visual em relacao a esse pivo
    -- isso faltava. character_assembly.py sempre fez os dois (ver
    node_own_offsets/local_offset la), mas esse modulo (escrito depois,
    pra miniatura) só replicou o primeiro. Toda peca com offset proprio
    zero (a maioria dos itens de roupa que testamos, por coincidencia)
    nunca expôs isso -- cabelo, com varias pecas aninhadas com offset
    proprio real, expôs."""
    result = []

    def walk(node, parent_world, parent_offset):
        local = _node_local_matrix(node, parent_offset, unit_scale)
        world = parent_world @ local
        own_offset = _shape_offset_of(node, unit_scale)
        if node.get("shape", {}).get("type") in ("box", "quad"):
            mesh_world = world @ Matrix.Translation(own_offset)
            result.append((node, mesh_world))
        for child in node.get("children", []):
            walk(child, world, own_offset)

    for root_node in root_nodes:
        walk(root_node, root_correction, Vector((0.0, 0.0, 0.0)))
    return result


def _world_bbox_corners(obj) -> list:
    return [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]


def _point_at(obj, target: Vector) -> None:
    direction = target - obj.location
    obj.rotation_mode = "QUATERNION"
    obj.rotation_quaternion = direction.to_track_quat("-Z", "Y")


def render_item_thumbnail(
    blockymodel_path: Path,
    material,
    atlas_w: float,
    atlas_h: float,
    output_path: Path,
    size: int = 128,
    unit_scale: float = UNIT_SCALE_DEFAULT,
) -> bool:
    """Renderiza a peca (todas as geometrias do arquivo, sem Armature)
    isolada num fundo transparente, salva em `output_path`. Devolve False
    (sem escrever nada) se o arquivo nao tiver nenhuma peca de geometria
    visivel -- nao deveria acontecer na pratica, mas nao assumimos.

    `atlas_w`/`atlas_h`: mesmo significado que em character_assembly.py
    -- tamanho real da textura, pro UV bater certo (usamos UV de
    verdade aqui, nao um atalho sem UV, porque a textura E o que faz a
    miniatura ser reconhecivel)."""
    with blockymodel_path.open(encoding="utf-8") as f:
        data = json.load(f)
    root_nodes = data.get("nodes", [])

    root_correction = Matrix.Rotation(math.radians(_UP_AXIS_CORRECTION_DEGREES), 4, _UP_AXIS_CORRECTION_AXIS)
    shape_matrices = _collect_shape_world_matrices(root_nodes, unit_scale, root_correction)
    if not shape_matrices:
        return False

    temp_scene = bpy.data.scenes.new("HyCharCreator_ThumbnailScene")
    temp_collection = temp_scene.collection

    created_objs = []
    created_meshes = []
    camera_obj = None
    camera_data = None
    bbox_min = Vector((float("inf"),) * 3)
    bbox_max = Vector((float("-inf"),) * 3)

    try:
        for node, mesh_world in shape_matrices:
            mesh = build_shape_mesh(node["name"], node["shape"], unit_scale, atlas_w, atlas_h, generate_uvs=True)
            created_meshes.append(mesh)
            obj = bpy.data.objects.new(node["name"], mesh)
            temp_collection.objects.link(obj)
            obj.matrix_world = mesh_world
            if material is not None:
                obj.data.materials.append(material)
            created_objs.append(obj)

            for corner in _world_bbox_corners(obj):
                bbox_min.x = min(bbox_min.x, corner.x)
                bbox_min.y = min(bbox_min.y, corner.y)
                bbox_min.z = min(bbox_min.z, corner.z)
                bbox_max.x = max(bbox_max.x, corner.x)
                bbox_max.y = max(bbox_max.y, corner.y)
                bbox_max.z = max(bbox_max.z, corner.z)

        center = (bbox_min + bbox_max) / 2.0
        radius = max((bbox_max - bbox_min).length / 2.0, 0.01)

        camera_data = bpy.data.cameras.new("HyCharCreator_ThumbnailCamera")
        camera_data.type = "ORTHO"
        camera_data.ortho_scale = radius * 2.4
        camera_obj = bpy.data.objects.new("HyCharCreator_ThumbnailCamera", camera_data)
        camera_obj.location = center + Vector((1.6, -1.6, 1.2)) * radius * 3.0
        temp_collection.objects.link(camera_obj)
        _point_at(camera_obj, center)
        temp_scene.camera = camera_obj

        # SEM luz de proposito -- o material de preview (ver
        # material_setup.build_*_preview_material) usa Emission, que nao
        # depende de luz nenhuma da cena. Pedido explicito: a miniatura
        # nao pode ter sombra/specular/luz interferindo, so a cor base.
        set_eevee_engine(temp_scene)  # compat: BLENDER_EEVEE_NEXT (4.5) / BLENDER_EEVEE (5.x)
        temp_scene.render.resolution_x = size
        temp_scene.render.resolution_y = size
        temp_scene.render.film_transparent = True
        temp_scene.render.filepath = str(output_path)
        # 5.x exige media_type antes de file_format -- ver compat.set_png_output.
        set_png_output(temp_scene.render.image_settings, color_mode="RGBA")

        output_path.parent.mkdir(parents=True, exist_ok=True)

        window = bpy.context.window
        prev_window_scene = window.scene if window is not None else None
        if window is not None:
            window.scene = temp_scene

        try:
            bpy.ops.render.render(write_still=True, scene=temp_scene.name)
        finally:
            if window is not None and prev_window_scene is not None:
                window.scene = prev_window_scene

    finally:
        for obj in created_objs:
            bpy.data.objects.remove(obj, do_unlink=True)
        for mesh in created_meshes:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        if camera_obj is not None:
            bpy.data.objects.remove(camera_obj, do_unlink=True)
        if camera_data is not None:
            bpy.data.cameras.remove(camera_data)
        bpy.data.scenes.remove(temp_scene)

    return True
