"""
anim_tools.py -- Auxiliares de Animação (aba "Animation" do N-Panel).
======================================================================

Este submódulo NÃO desenha nada -- só registra os operadores (e três
funções de leitura pura) que a aba "Animation" do interface.py usa.
Mesmo espírito de rigger.py: interface.py é quem desenha os botões, este
arquivo só fornece o que os botões chamam.

Cobre, até agora:
  1. FK/IK -- dois jeitos de trocar, propositalmente separados:
     - ANIM_OT_hytale_set_fk_ik (botões FK/IK da lista, por índice de
       cadeia): troca CRUA, só a influência -- não mexe na pose. Pode
       dar um "pulo" visual se FK e IK estiverem posados diferente.
     - ANIM_OT_hytale_snap_selected (botão único "Snap FK/IK", olha o
       bone ATIVO selecionado): iguala a pose do lado oposto ao
       selecionado E troca pra esse lado oposto, tudo de uma vez --
       ver identify_chain_from_bone/snap_chain_pose logo abaixo.
  2. v0.13.5 -- "Head Free/Lock" (ANIM_OT_hytale_set_head_follow +
     get_head_follow_state): mesmo espírito "cru" do botão FK/IK da
     lista (só troca a influência, não iguala pose) -- não tem
     equivalente ao "Snap FK/IK" (não pedido, e não haveria "lado
     oposto" pra igualar do mesmo jeito -- Head_CTRL não tem duas
     poses paralelas guardadas em bones diferentes, só uma rotação
     própria vs. a do predecessor). Switch ÚNICO, sem índice de cadeia
     -- só existe UM Head_CTRL no rig inteiro.
  3. v0.7.5 -- ANIM_OT_hytale_keyframe_switch: insere keyframe (frame
     atual) na custom property crua por trás do FK/IK e do Head Free/
     Lock. Motivo de existir: os botões acima (1 e 2) são operadores
     (`layout.operator`), e um operador NUNCA é "keyframeable" pelo
     Blender (colocar o mouse em cima e apertar "I", ou botão direito
     -> Insert Keyframe, só funciona sobre um `layout.prop()` de
     verdade) -- por isso não era possível animar FK/IK nem Head Free/
     Lock antes, mesmo os dois já sendo baseados numa custom property
     (que POR SI SÓ é animável). Este operador cobre os dois casos
     (`switch` = "FK_IK"/"HEAD_FOLLOW") reaproveitando a mesma
     resolução de property que os botões de troca já usam
     (_resolve_switch_prop) -- ver interface.py pra onde o botão de
     keyframe (ícone) fica desenhado, ao lado de cada FK/IK e do Free/
     Lock.

     v0.7.5 -- a visibilidade das Bone Collections (abaixo) deixou de
     usar operador (ANIM_OT_hytale_toggle_collection_visibility,
     removido) e passou a ser um `layout.prop(coll, "is_visible", ...)`
     direto em interface.py -- MESMO motivo do keyframe acima
     (`is_visible` já é uma property nativa de bpy.types.BoneCollection,
     não precisava de operador nenhum pra trocar) e também resolve o
     outro problema relatado (arrastar o mouse sobre vários botões de
     visibilidade ao mesmo tempo só funciona quando são `prop()` de
     verdade lado a lado -- é um comportamento nativo do Blender pra
     botões toggle numa mesma row(align=True), operadores não têm
     isso). Este arquivo não precisou de nenhuma função nova pra essa
     parte -- só perdeu a classe do operador antigo.

CAVEAT -- Pole Local/Global: o pole target já tem dois Child Of no rig
(um mirando na ponta da cadeia -- "Local", ativo por padrão -- outro no
Origin_CTRL -- "Global", influência 0 por padrão -- ver
CONSTRAINT_CHILD_OF_LOCAL/GLOBAL em rigger/rig.py), mas hoje NENHUM dos
dois tem custom property + driver pra trocar entre eles (fica fixo no
que foi gerado). snap_chain_pose() calcula a matrix corrigida pra
QUALQUER Child Of ativa nesses bones (ver _snap_matrix_through_
constraints, que compensa até o inverse_matrix do "Set Inverse" já
aplicado -- ver rigger/rig.py) -- então funciona corretamente não
importa qual das duas esteja ativa no momento. Se um dia isso ganhar um
switch de verdade (teria que nascer em rigger/rig.py, não aqui),
nenhuma mudança deveria ser necessária neste arquivo.

DEPENDÊNCIA -- este arquivo importa de `.rigger`:
    BONE_PROPERTIES, CONSTRAINT_CHILD_OF_GLOBAL, CONSTRAINT_CHILD_OF_LOCAL,
    PROP_HEAD_FOLLOW_SWITCH, SUFFIX_CTRL, SUFFIX_IK, SUFFIX_MCH_IK_TRANSFER,
    SUFFIX_MCH, SUFFIX_POLE, find_org_path, switch_property_name
(v0.13: SUFFIX_IK_MCH renomeado pra SUFFIX_MCH_IK_TRANSFER em
rigger/constants.py -- mesmo bone-ponte de sempre, só nome novo.
v0.13.5: PROP_HEAD_FOLLOW_SWITCH entrou pro switch "Head Free/Lock" --
ver get_head_follow_state/ANIM_OT_hytale_set_head_follow abaixo.)
Todos precisam estar na lista de reexport de rigger/__init__.py (alguns
-- BONE_PROPERTIES, find_org_path, switch_property_name -- não estavam
lá originalmente; foram adicionados especificamente pra este arquivo
poder existir sem duplicar lógica que já mora em rigger/rig.py e
rigger/constants.py).

Visibilidade das Bone Collections é lida/escrita via
`armature.collections_all` (API nativa do Blender 4.0+, plana --
inclusive as aninhadas dentro de "Main"), então este arquivo NÃO precisa
importar os nomes de collection de rigger/constants.py: recebe o nome
(string) já pronto de quem desenha (interface.py), que é quem decide
QUAIS collections mostrar na lista.

v0.14 -- primeiro arquivo migrado pro sistema de tooltip dinâmico (ver
"Tooltips dinâmicos" em translations/__init__.py): os 4 bl_description
viraram `description = tooltip("anim_tools.tooltip.<nome>")`, e os 2
IntProperty com description= viraram @localized_props (chain_index em
ANIM_OT_hytale_set_fk_ik e em ANIM_OT_hytale_keyframe_switch) --
register()/unregister() usam register_localized_class/
unregister_localized_class no lugar de bpy.utils.*_class direto. Keys
novas em translations/en.py: anim_tools.tooltip.set_fk_ik,
anim_tools.tooltip.set_head_follow, anim_tools.tooltip.snap_selected,
anim_tools.tooltip.keyframe_switch, anim_tools.prop.set_fk_ik_chain_index,
anim_tools.prop.keyframe_switch_chain_index.
"""

import bpy
from bpy.props import EnumProperty, IntProperty
from bpy.types import Operator
from mathutils import Vector

from .translations import localized_props, register_localized_class, tooltip, tr, unregister_localized_class
from .rigger import (
    BONE_PROPERTIES,
    CONSTRAINT_CHILD_OF_GLOBAL,
    CONSTRAINT_CHILD_OF_LOCAL,
    PROP_HEAD_FOLLOW_SWITCH,
    SUFFIX_CTRL,
    SUFFIX_IK,
    SUFFIX_MCH,
    SUFFIX_MCH_IK_TRANSFER,
    SUFFIX_POLE,
    find_org_path,
    switch_property_name,
)


def _redraw_all_areas(context):
    """Força o redraw de TODA área de TODA janela aberta. Mesmo problema
    (e mesmo fix) documentado em rigger/rig.py para outros botões que
    mudam um valor lido por um driver: escrever a custom property (ver
    ANIM_OT_hytale_set_fk_ik.execute) já recalcula o driver de
    influência/escala na hora (context.view_layer.update() cuida disso),
    mas o Blender não redesenha a viewport sozinho por causa disso --
    só quando QUALQUER outro evento (clicar num bone, por exemplo) força
    um redraw geral por outro motivo. Cópia local (não importada de
    rig.py) porque lá é uma função privada (prefixo "_"), fora do que
    rigger/__init__.py reexporta."""
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()


# ---------------------------------------------------------------------------
# FK/IK Switch + Snap -- por cadeia (armature.hytale_ik_chains)
# ---------------------------------------------------------------------------


def get_fk_ik_state(obj, item):
    """Leitura pura, sem efeito colateral: retorna 0 (FK), 1 (IK), ou
    None se esse switch ainda não existe (chain_type == CHAIN -- não tem
    IK --, rig nunca gerado, ou entrada nova na lista que ainda não
    passou por "Create Rig"). Usada pelo interface.py só pra saber qual
    dos dois botões (FK/IK) desenhar destacado -- nunca escreve nada."""
    if item.chain_type == "CHAIN":
        return None
    pose = obj.pose
    if pose is None:
        return None
    props_bone = pose.bones.get(BONE_PROPERTIES)
    if props_bone is None:
        return None
    prop_name = switch_property_name(item.tip_bone, item.side)
    value = props_bone.get(prop_name)
    if value is None:
        return None
    return 1 if value else 0


def get_head_follow_state(obj):
    """Leitura pura, sem efeito colateral -- mesmo espírito de
    get_fk_ik_state acima, só que pro switch ÚNICO "Head Free/Lock"
    (PROP_HEAD_FOLLOW_SWITCH -- não é "por cadeia/lado", só existe UM
    Head_CTRL no rig todo, ver HytaleIKChainItem.head_follow_enabled/
    _build_head_follow em rigger/rig.py). Retorna 1 (Lock -- segue o
    predecessor) ou 0 (Free), ou None se o switch ainda não existe
    ("Head Free/Lock" nunca foi ligado em nenhuma entrada HEAD, ou o
    rig nunca foi gerado). Usada pelo interface.py só pra saber qual
    dos dois botões (Free/Lock) desenhar destacado -- nunca escreve
    nada."""
    pose = obj.pose
    if pose is None:
        return None
    props_bone = pose.bones.get(BONE_PROPERTIES)
    if props_bone is None:
        return None
    value = props_bone.get(PROP_HEAD_FOLLOW_SWITCH)
    if value is None:
        return None
    return 1 if value else 0


def _snap_matrix_through_constraints(context, pose_bone, target_matrix, constraint_names):
    """Escreve `target_matrix` em `pose_bone.matrix` de um jeito que
    dá o resultado final CORRETO mesmo com uma Child Of ativa
    (`constraint_names`, por nome -- a primeira com influência > 0 e
    subtarget válido é a usada; as outras são ignoradas).

    `pose_bone.matrix = valor` sozinho NÃO é "ciente" de constraints:
    ele calcula o canal local (matrix_basis) assumindo que mais nada
    vai mexer no bone depois -- mas a Child Of roda de novo assim que
    o depsgraph reavalia a pose. Uma primeira tentativa foi desativar a
    constraint, escrever, e reativar -- funciona SE con.inverse_matrix
    (gravado pelo "Set Inverse" que _apply_pole_childof_inverses já
    aplica na geração do rig) ainda corresponder à pose ATUAL do alvo
    -- mas ele foi calculado uma vez, no rest, e o alvo (ik_tip) acabou
    de ser movido por este mesmo Snap -- sobra um resíduo (era esse o
    "quase, mas não perfeito" -- só o "Set Inverse" manual, que
    recalcula esse valor, corrigia).

    A fórmula da Child Of (com Set Inverse já aplicado) é:
        final = target.matrix @ con.inverse_matrix @ rest_matrix @ matrix_basis
    Queremos final == target_matrix (o valor desejado). `.matrix = X`
    (sem constraint interferindo) grava matrix_basis = rest_matrix
    .inverted() @ X, ou seja rest_matrix @ matrix_basis == X -- então
    isolando X pra que, DEPOIS da Child Of rodar de novo em cima dele,
    o resultado bata com target_matrix:
        X = (target.matrix @ con.inverse_matrix).inverted() @ target_matrix
    Sem precisar desativar/reativar nada -- escreve direto, já
    compensado."""
    active_con = None
    for name in constraint_names:
        con = pose_bone.constraints.get(name)
        if con is not None and con.type == "CHILD_OF" and not con.mute and con.influence > 0.0 and con.subtarget:
            active_con = con
            break  # as duas (Local/Global) nunca deveriam estar ativas ao mesmo tempo -- para na primeira

    if active_con is None:
        pose_bone.matrix = target_matrix
        return

    target_pb = pose_bone.id_data.pose.bones.get(active_con.subtarget)
    if target_pb is None:
        pose_bone.matrix = target_matrix
        return

    pose_bone.matrix = (target_pb.matrix @ active_con.inverse_matrix).inverted() @ target_matrix
    context.view_layer.update()


def snap_chain_pose(context, obj, item, target_mode):
    """FK/IK Snap: iguala a pose dos controles do modo DE DESTINO
    (target_mode) à pose atualmente VISÍVEL da cadeia, pra trocar o
    switch sem "pulo". Não mexe no switch em si -- ver
    ANIM_OT_hytale_set_fk_ik, que chama isto ANTES de escrever a
    property.

    A leitura é sempre a mesma, não importa o modo atual: o bone `_MCH`
    de cada segmento ORG é a única fonte de verdade da pose visível (é
    ele quem os bones ORG realmente seguem -- ver CONSTRAINT_ORG_TO_MCH
    em rigger/rig.py) -- FK ou IK, o MCH já reflete o resultado, porque
    é ele quem recebe o blend das duas camadas via driver. Por isso este
    código não precisa saber em qual modo a cadeia está agora: só lê
    `_MCH` e escreve no lado (`_CTRL` ou `_IK`/pole) que ainda não é a
    fonte da verdade.

    -- target_mode == "FK": copia o matrix (armature space, já com
       constraints aplicados) de CADA `<org>_MCH` pro `<org>_CTRL`
       correspondente, segmento por segmento, raiz->ponta (nessa ordem
       -- um view_layer.update() entre cada um garante que o próximo
       bone da cadeia, cujo parent É o _CTRL anterior, calcula a
       própria pose local relativa ao valor NOVO do pai, não ao antigo).
       Funciona pra cadeia de qualquer tamanho (Thigh/Calf/Heel/Foot
       etc.), sem precisar saber quantos segmentos existem.

    -- target_mode == "IK": só 2 bones são realmente controláveis em IK
       (o resto é resolvido pelo solver) --
         1. `<tip>_IK` (o alvo solto, ex. Hand_IK) recebe o matrix de
            `<tip>_MCH`, compensado por um offset fixo de rest (a
            ponta foi reorientada na criação do rig -- ver comentário
            detalhado dentro do bloco IK, abaixo) -- sem essa
            compensação, a rotação da ponta (mão/pé) sai torta.
         2. O pole target (`<root>_Pole_CTRL`) é reposicionado usando a
            MESMA fórmula que `_pole_position` (rigger/rig.py) usa na
            hora de CRIAR o rig -- só que com o eixo Z do bone de
            referência (pole_bone, ou o bone do meio do caminho se
            vazio) tirado da pose ATUAL (via `<pole_ref>_MCH.matrix`)
            em vez do rest. Mesma regra de sinal (`item.pole_invert`)
            e mesma distância (`item.pole_distance`) que o usuário já
            configurou pra essa cadeia -- reaproveitadas, não
            reinventadas.

       O alvo IK e o pole já têm Child Of ATIVAS por padrão (ver
       _build_pose_constraints) -- `pose_bone.matrix = valor` sozinho
       NÃO dá o resultado certo nesse caso (o Blender não "desfaz" a
       constraint ao calcular o canal local -- ela roda de novo em
       cima depois e desloca o resultado). As duas escritas abaixo
       passam por `_snap_matrix_through_constraints`, que resolve a
       matemática da Child Of (incluindo o inverse_matrix do "Set
       Inverse" já aplicado -- ver rigger/rig.py) e escreve o valor já
       compensado.

    Retorna (True, None) em sucesso, (False, "motivo") se algum bone
    necessário não existir (rig não gerado, cadeia nova sem "Create Rig"
    ainda, etc.) -- quem chama decide se aborta o switch ou segue sem
    snap."""
    pose_bones = obj.pose.bones
    bones = obj.data.bones

    root_bone = bones.get(item.root_bone)
    if root_bone is None:
        return False, f"root bone '{item.root_bone}' not found"
    path = find_org_path(root_bone, item.tip_bone)
    if not path:
        return False, f"no bone path from '{item.root_bone}' to '{item.tip_bone}'"

    if target_mode == "FK":
        for org_bone in path:
            mch_pb = pose_bones.get(org_bone.name + SUFFIX_MCH)
            ctrl_pb = pose_bones.get(org_bone.name + SUFFIX_CTRL)
            if mch_pb is None or ctrl_pb is None:
                continue  # bone sem MCH/CTRL (ex. attachment) -- pula, não é erro
            ctrl_pb.matrix = mch_pb.matrix.copy()
            # Necessário ANTES do próximo segmento: o próximo _CTRL da
            # cadeia é filho DESTE _CTRL -- sem recalcular agora, ele
            # decompõe a própria pose relativa ao valor ANTIGO do pai.
            context.view_layer.update()
        return True, None

    if target_mode == "IK":
        tip_org = path[-1]
        tip_mch_pb = pose_bones.get(tip_org.name + SUFFIX_MCH)
        ik_tip_pb = pose_bones.get(tip_org.name + SUFFIX_IK)
        ik_tip_bone = bones.get(tip_org.name + SUFFIX_IK)
        bridge_bone = bones.get(tip_org.name + SUFFIX_MCH_IK_TRANSFER)
        if tip_mch_pb is None or ik_tip_pb is None or ik_tip_bone is None or bridge_bone is None:
            return False, f"'{tip_org.name}{SUFFIX_MCH}'/'{tip_org.name}{SUFFIX_IK}' bones not found"

        # O bone `_IK` da PONTA (ex. Hand_IK) foi REORIENTADO na criação
        # do rig (aponta pro attachment ou "pra baixo" no mundo -- ver
        # _build_ik_layer) -- rest orientation DIFERENTE da do bridge
        # `_MCH_IK_Transfer` (que mantém a rest do ORG original, intocada -- por
        # isso IK_CopyRotation/Scale, em _build_pose_constraints, miram
        # nele em vez de no `_IK` direto: precisam de uma rest "limpa").
        # Copiar tip_mch.matrix direto pro `_IK` (como fazíamos antes)
        # ignora essa diferença -- ao entrar em IK, o Blender aplica o
        # MESMO offset de novo (via bridge) EM CIMA de um valor que já
        # não tinha o offset compensado, e a mão sai torta.
        #
        # offset = a rest do `_IK` PRA a rest do bridge, em armature
        # space (calculável a qualquer momento via Bone.matrix_local --
        # não precisa de Edit Mode). Relação real em Pose Mode, com o
        # bridge sempre sem pose própria (matrix_basis identidade):
        #     bridge.matrix (mundo) = ik_tip.matrix (mundo) @ offset
        # Queremos bridge.matrix == tip_mch.matrix (é o que
        # IK_CopyRotation/Scale vão copiar pro MCH assim que o switch
        # virar 1) -- resolvendo pra ik_tip.matrix:
        #     ik_tip.matrix = tip_mch.matrix @ offset.inverted()
        # (offset.translation é sempre zero -- os três bones comparados
        # aqui compartilham a mesma cabeça, ver comentário em
        # rigger/__init__.py -- então isto não desloca a posição do
        # alvo, só corrige a rotação/escala.)
        offset = ik_tip_bone.matrix_local.inverted() @ bridge_bone.matrix_local
        # ik_tip tem uma Child Of ATIVA por padrão, mirando no
        # CHILD_OF_GLOBAL_TARGET (Origin_CTRL) -- ver
        # CONSTRAINT_CHILD_OF_GLOBAL em rigger/rig.py. `.matrix = X`
        # sozinho não compensa isso (ver _snap_matrix_through_
        # constraints, acima) -- por isso passa pelo helper em vez de
        # escrever direto.
        _snap_matrix_through_constraints(
            context, ik_tip_pb, tip_mch_pb.matrix @ offset.inverted(), [CONSTRAINT_CHILD_OF_GLOBAL]
        )

        # Necessário ANTES de mexer no pole: ele tem uma Child Of
        # ATIVA mirando neste MESMO ik_tip (ver CONSTRAINT_CHILD_OF_LOCAL
        # em rigger/rig.py) -- sem atualizar agora, o Blender resolveria
        # a matrix do pole daqui a pouco usando o valor ANTIGO (pré-snap)
        # do tip, e o pole (e a rotação dele, que a Child Of também
        # copia) saía errado.
        context.view_layer.update()

        pole_ref_name = item.pole_bone or path[len(path) // 2].name
        pole_ref_mch_pb = pose_bones.get(pole_ref_name + SUFFIX_MCH)
        pole_pb = pose_bones.get(path[0].name + SUFFIX_POLE)
        if pole_ref_mch_pb is not None and pole_pb is not None:
            ref_matrix = pole_ref_mch_pb.matrix
            z_axis = ref_matrix.to_3x3() @ Vector((0.0, 0.0, 1.0))
            z_axis = z_axis.normalized() if z_axis.length > 1e-9 else Vector((0.0, 0.0, 1.0))
            sign = 1.0 if item.pole_invert else -1.0
            target_head = ref_matrix.translation + z_axis * (item.pole_distance * sign)

            new_matrix = pole_pb.matrix.copy()
            new_matrix.translation = target_head
            # Pole tem DUAS Child Of (Local -> ik_tip, ativa por
            # padrão; Global -> Origin_CTRL, influência 0 por padrão --
            # ver CONSTRAINT_CHILD_OF_LOCAL/GLOBAL em rigger/rig.py).
            # O helper acha sozinho qual das duas está ativa (a que
            # tiver influência > 0) e compensa a matrix pra ela --
            # incluindo o inverse_matrix do "Set Inverse" já aplicado,
            # que senão deixa um resíduo (mesmo se o Local, que mira
            # num ik_tip que a gente ACABOU de mover, "reproduzisse" a
            # si mesma -- o inverse foi calculado no rest, não agora).
            _snap_matrix_through_constraints(
                context, pole_pb, new_matrix, [CONSTRAINT_CHILD_OF_LOCAL, CONSTRAINT_CHILD_OF_GLOBAL]
            )
        # Sem pole_ref/pole bone -- não é fatal (o alvo IK já foi
        # posicionado acima); só o ângulo do cotovelo/joelho pode não
        # bater perfeitamente com a pose FK anterior.

        context.view_layer.update()
        return True, None

    return False, f"unknown target_mode '{target_mode}'"


def _resolve_switch_prop(obj, item):
    """Acha (props_bone, prop_name) da custom property de FK/IK switch
    desta cadeia, ou (None, "motivo") se não existir ainda (rig não
    gerado, cadeia nova sem regenerar). Compartilhado por
    ANIM_OT_hytale_set_fk_ik e ANIM_OT_hytale_snap_selected -- os dois
    escrevem exatamente a mesma property, só decidem de jeitos
    diferentes SE/QUANDO escrever."""
    props_bone = obj.pose.bones.get(BONE_PROPERTIES)
    if props_bone is None:
        return None, None, "rig not generated yet -- there's no FK/IK switch to set"
    prop_name = switch_property_name(item.tip_bone, item.side)
    if prop_name not in props_bone.keys():
        return None, None, (
            f"'{prop_name}' not found on the {BONE_PROPERTIES} bone -- generate/regenerate the rig first "
            "(this chain may have been added to the list after the last 'Create Rig')"
        )
    return props_bone, prop_name, None


def _write_fk_ik_switch(context, obj, props_bone, prop_name, mode):
    """Escreve 0/1 na custom property já resolvida (ver
    _resolve_switch_prop) e força o recálculo/redraw -- ver comentário
    detalhado dentro de ANIM_OT_hytale_set_fk_ik.execute (versão
    anterior) sobre por que update_tag()+view_layer.update()+redraw são
    TODOS necessários, não só um deles."""
    props_bone[prop_name] = 1 if mode == "IK" else 0
    obj.update_tag()
    context.view_layer.update()
    _redraw_all_areas(context)


# v0.14 -- todas as properties de ANIM_OT_hytale_set_fk_ik (mesmo a que
# não tem tooltip nenhum, "mode") vêm desta função em vez de anotação
# solta no corpo da classe -- @localized_props precisa do dict COMPLETO
# pra reconstruir a classe quando o idioma muda (ver translations/
# __init__.py, seção "Tooltip de campo").
def _set_fk_ik_props(lang):
    return {
        "chain_index": IntProperty(description=tr("anim_tools.prop.set_fk_ik_chain_index", lang)),
        "mode": EnumProperty(items=[("FK", "FK", ""), ("IK", "IK", "")]),
    }


@localized_props(_set_fk_ik_props)
class ANIM_OT_hytale_set_fk_ik(Operator):
    """Troca a cadeia (item de armature.hytale_ik_chains, por índice)
    pra FK (mode='FK') ou IK (mode='IK') -- SÓ a influência (custom
    property no bone PROPERTIES, criada por rigger.py -- ver
    ensure_switch_property/add_switch_driver em rigger/rig.py).
    NÃO iguala a pose (isso é ANIM_OT_hytale_snap_selected, separado de
    propósito -- pedido explícito: os botões de troca ficam "crus", o
    Snap é uma ação à parte que o usuário decide quando rodar)."""

    bl_idname = "pose.hytale_set_fk_ik"
    bl_label = "Set FK/IK"
    # v0.14 -- description() dinâmico (ver tooltip() em translations/
    # __init__.py) no lugar de bl_description fixo -- texto mora só em
    # translations/en.py (key "anim_tools.tooltip.set_fk_ik").
    description = tooltip("anim_tools.tooltip.set_fk_ik")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "ARMATURE" and obj.pose is not None

    def execute(self, context):
        obj = context.active_object
        armature = obj.data
        chains = armature.hytale_ik_chains
        if not (0 <= self.chain_index < len(chains)):
            self.report({"WARNING"}, "Invalid chain index.")
            return {"CANCELLED"}

        item = chains[self.chain_index]
        if item.chain_type == "CHAIN":
            self.report({"WARNING"}, "Chain entries don't have an FK/IK switch.")
            return {"CANCELLED"}

        props_bone, prop_name, reason = _resolve_switch_prop(obj, item)
        if props_bone is None:
            self.report({"WARNING"}, reason)
            return {"CANCELLED"}

        _write_fk_ik_switch(context, obj, props_bone, prop_name, self.mode)
        return {"FINISHED"}


class ANIM_OT_hytale_set_head_follow(Operator):
    """Troca o switch ÚNICO "Head Free/Lock" (PROP_HEAD_FOLLOW_SWITCH,
    custom property no bone PROPERTIES -- ver ensure_switch_property/
    _build_head_follow em rigger/rig.py) -- SÓ a custom property, mesmo
    espírito "cru" de ANIM_OT_hytale_set_fk_ik acima (não iguala a
    pose -- se a rotação atual de Head_CTRL divergir muito de onde o
    predecessor está agora, trocar pode dar um "pulo" visual, mesmo
    caveat já documentado pro FK/IK). Diferente do FK/IK, não precisa
    de índice de cadeia nenhum -- só existe UM Head_CTRL no rig
    inteiro."""

    bl_idname = "pose.hytale_set_head_follow"
    bl_label = "Set Head Free/Lock"
    # v0.14 -- description() dinâmico, ver ANIM_OT_hytale_set_fk_ik acima.
    # "mode" (abaixo) não tem @localized_props: EnumProperty sem
    # description= própria, nada aqui pra traduzir -- fica como
    # anotação normal mesmo, sem overhead de re-registro à toa.
    description = tooltip("anim_tools.tooltip.set_head_follow")
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(items=[("FREE", "Free", ""), ("LOCK", "Lock", "")])

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "ARMATURE" and obj.pose is not None

    def execute(self, context):
        obj = context.active_object
        props_bone = obj.pose.bones.get(BONE_PROPERTIES)
        if props_bone is None or PROP_HEAD_FOLLOW_SWITCH not in props_bone.keys():
            self.report(
                {"WARNING"},
                f"'{PROP_HEAD_FOLLOW_SWITCH}' not found on the {BONE_PROPERTIES} bone -- enable 'Head "
                "Free/Lock' on the HEAD entry (Bone Settings) and run 'Create Rig' first.",
            )
            return {"CANCELLED"}

        # Mesmo padrão de _write_fk_ik_switch (update_tag + view_layer.
        # update + redraw geral) -- ver docstring lá pro motivo dos 3
        # serem necessários. Não reaproveitado direto (aquela função é
        # específica de FK/IK, recebe prop_name -- aqui é sempre o
        # mesmo PROP_HEAD_FOLLOW_SWITCH) mas é a MESMA sequência.
        props_bone[PROP_HEAD_FOLLOW_SWITCH] = 1 if self.mode == "LOCK" else 0
        obj.update_tag()
        context.view_layer.update()
        _redraw_all_areas(context)
        return {"FINISHED"}


def _keyframe_switch_props(lang):
    return {
        "switch": EnumProperty(items=[("FK_IK", "FK/IK", ""), ("HEAD_FOLLOW", "Head Follow", "")]),
        "chain_index": IntProperty(
            default=-1, description=tr("anim_tools.prop.keyframe_switch_chain_index", lang)
        ),
    }


@localized_props(_keyframe_switch_props)
class ANIM_OT_hytale_keyframe_switch(Operator):
    """Insere um keyframe, no frame atual, no valor CRU (0/1) por trás
    de um switch FK/IK (por índice de cadeia) ou do Head Free/Lock
    (switch único) -- ver docstring do módulo pra por que isso não
    "acontecia sozinho" antes (os botões de troca são operadores, não
    properties, e só properties são keyframeable). Reaproveita
    _resolve_switch_prop pra achar a mesma custom property que
    ANIM_OT_hytale_set_fk_ik já escreve -- então o keyframe inserido
    aqui é sempre da MESMA property que os botões FK/IK/Free/Lock leem
    (get_fk_ik_state/get_head_follow_state), nunca uma cópia
    paralela."""

    bl_idname = "pose.hytale_keyframe_switch"
    bl_label = "Insert Switch Keyframe"
    description = tooltip("anim_tools.tooltip.keyframe_switch")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "ARMATURE" and obj.pose is not None

    def execute(self, context):
        obj = context.active_object

        if self.switch == "FK_IK":
            chains = obj.data.hytale_ik_chains
            if not (0 <= self.chain_index < len(chains)):
                self.report({"WARNING"}, "Invalid chain index.")
                return {"CANCELLED"}
            props_bone, prop_name, reason = _resolve_switch_prop(obj, chains[self.chain_index])
            if props_bone is None:
                self.report({"WARNING"}, reason)
                return {"CANCELLED"}
        else:
            props_bone = obj.pose.bones.get(BONE_PROPERTIES)
            prop_name = PROP_HEAD_FOLLOW_SWITCH
            if props_bone is None or prop_name not in props_bone.keys():
                self.report(
                    {"WARNING"},
                    f"'{prop_name}' not found on the {BONE_PROPERTIES} bone -- enable 'Head Free/Lock' "
                    "on the HEAD entry (Bone Settings) and run 'Create Rig' first.",
                )
                return {"CANCELLED"}

        # data_path entre colchetes/aspas -- sintaxe padrão do Blender
        # pra apontar uma custom (ID) property, não uma bpy.props
        # registrada de verdade (mesma sintaxe que aparece se você
        # clicar com o botão direito numa custom property no painel
        # "Item" da N-Panel e escolher "Copy Data Path").
        try:
            props_bone.keyframe_insert(data_path=f'["{prop_name}"]', frame=context.scene.frame_current)
        except TypeError as exc:
            self.report({"ERROR"}, f"Couldn't insert keyframe for '{prop_name}': {exc}")
            return {"CANCELLED"}

        _redraw_all_areas(context)
        self.report({"INFO"}, f"Keyframed '{prop_name}' at frame {context.scene.frame_current}.")
        return {"FINISHED"}


def identify_chain_from_bone(obj, bone_name):
    """Dado o nome de um bone (tipicamente context.active_pose_bone.name),
    acha em qual cadeia ARM/LEG de armature.hytale_ik_chains ele
    participa, e de qual LADO (FK ou IK) -- olhando os bones reais da
    cadeia (via find_org_path, mesmo caminho que o Snap usa), não o
    nome cru: cobre CTRL de qualquer segmento (raiz/meio/ponta), o
    `_IK` da ponta e o Pole Target. Retorna (index, item, side) ou
    (None, None, None) se o bone não pertencer a nenhuma cadeia (ex.:
    bone de attachment, ou nenhum rig gerado ainda).

    `side` é o lado ONDE o bone selecionado está agora -- ANIM_OT_hytale_
    snap_selected usa o lado OPOSTO como target_mode (seleciona um
    _CTRL -> assume que o objetivo é preparar a troca PRA IK; seleciona
    o alvo IK ou o pole -> prepara a troca PRA FK)."""
    armature = obj.data
    bones = armature.bones
    for index, item in enumerate(armature.hytale_ik_chains):
        if item.chain_type == "CHAIN" or not item.root_bone or not item.tip_bone:
            continue
        root_bone = bones.get(item.root_bone)
        if root_bone is None:
            continue
        path = find_org_path(root_bone, item.tip_bone)
        if not path:
            continue

        if bone_name == path[0].name + SUFFIX_POLE:
            return index, item, "IK"
        if bone_name == path[-1].name + SUFFIX_IK:
            return index, item, "IK"
        for org_bone in path:
            if bone_name == org_bone.name + SUFFIX_CTRL:
                return index, item, "FK"
    return None, None, None


class ANIM_OT_hytale_snap_selected(Operator):
    """Snap + Switch, baseado no bone selecionado -- olha o bone
    ATIVO/selecionado em Pose Mode, descobre a cadeia e de que LADO ele
    está (ver identify_chain_from_bone), iguala a pose do lado OPOSTO
    e JÁ TROCA o switch pra esse lado oposto. Ex.: seleciona um _CTRL
    (FK) -> iguala o IK à pose atual e troca a cadeia pra IK; seleciona
    o alvo IK ou o Pole Target -> iguala o FK e troca a cadeia pra FK.

    Diferente de ANIM_OT_hytale_set_fk_ik (botões FK/IK da lista, que
    só trocam a influência, sem mexer na pose) -- este é o botão único
    "Snap FK/IK": faz o trabalho dos dois (igualar + trocar) de uma vez
    só, só que pra UMA cadeia (a do bone selecionado), não por índice
    escolhido na UI."""

    bl_idname = "pose.hytale_snap_fk_ik_selected"
    bl_label = "Snap FK/IK"
    description = tooltip("anim_tools.tooltip.snap_selected")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            obj is not None
            and obj.type == "ARMATURE"
            and obj.pose is not None
            and context.active_pose_bone is not None
        )

    def execute(self, context):
        obj = context.active_object
        active_bone = context.active_pose_bone
        index, item, side = identify_chain_from_bone(obj, active_bone.name)
        if item is None:
            self.report(
                {"WARNING"},
                f"'{active_bone.name}' doesn't belong to any Arm/Leg chain -- select a chain's FK "
                "control, IK target, or Pole Target first.",
            )
            return {"CANCELLED"}

        props_bone, prop_name, reason = _resolve_switch_prop(obj, item)
        if props_bone is None:
            self.report({"WARNING"}, reason)
            return {"CANCELLED"}

        target_mode = "FK" if side == "IK" else "IK"
        ok, reason = snap_chain_pose(context, obj, item, target_mode)
        if not ok:
            self.report({"WARNING"}, f"Snap failed ({reason}) -- switching without matching the pose.")

        _write_fk_ik_switch(context, obj, props_bone, prop_name, target_mode)
        self.report({"INFO"}, f"Snapped and switched '{item.label or item.root_bone}' to {target_mode}.")
        return {"FINISHED"}


_CLASSES = (
    ANIM_OT_hytale_set_fk_ik,
    ANIM_OT_hytale_set_head_follow,
    ANIM_OT_hytale_snap_selected,
    ANIM_OT_hytale_keyframe_switch,
)


def register():
    # register_localized_class() cuida das classes com @localized_props
    # (ANIM_OT_hytale_set_fk_ik, ANIM_OT_hytale_keyframe_switch) e
    # funciona igual a bpy.utils.register_class() pras outras duas --
    # ver translations/__init__.py, seção "Tooltip de campo".
    for cls in _CLASSES:
        register_localized_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        unregister_localized_class(cls)
