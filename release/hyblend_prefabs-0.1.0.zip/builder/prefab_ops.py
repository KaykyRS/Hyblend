"""prefab_ops.py -- operadores de GERENCIAMENTO dos prefabs ja importados
na cena (selecionar raiz, enquadrar, remover, copiar relatorio, selecionar
instancias do mesmo item). Nenhum deles mexe na logica de import -- so
leem/removem o que prefab_importer.py criou. Usados pelo painel
(interface/__init__.py).

Os helpers `iter_prefab_collections`/`find_prefab_root`/`load_report`/
`prefab_collection_of` tambem sao usados pelo painel pra desenhar a lista
de prefabs -- ficam aqui (e nao em interface/) pra UI continuar "so
desenha", sem logica propria."""

from __future__ import annotations

import json
from pathlib import Path

import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from ..common import (
    PREFAB_COLLECTION_PREFIX,
    PROP_BLOCK_NAME,
    PROP_ENTITY_KIND,
    PROP_PREFAB_BLOCKS_PLACED,
    PROP_PREFAB_BLOCKS_TOTAL,
    PROP_PREFAB_ENTITIES_PLACED,
    PROP_PREFAB_ENTITIES_TOTAL,
    PROP_PREFAB_FILE,
    PROP_PREFAB_HIDDEN_BLOCKS,
    PROP_PREFAB_HIDDEN_FACES,
    PROP_PREFAB_OUTPUT_MODE,
    PROP_PREFAB_REGION_SKIPPED,
    PROP_PREFAB_REPORT_JSON,
    PROP_PREFAB_ROOT,
    PROP_PREFAB_UNIQUE_MESHES,
)


# ---------------------------------------------------------------------------
# Helpers (sem bpy.ops -- seguros pra chamar dentro de Panel.draw)
# ---------------------------------------------------------------------------


def iter_prefab_collections():
    """Collections criadas pelo import, na ordem do bpy.data (alfabetica)."""
    return [c for c in bpy.data.collections if c.name.startswith(PREFAB_COLLECTION_PREFIX)]


def prefab_display_name(collection) -> str:
    return collection.name[len(PREFAB_COLLECTION_PREFIX):] or collection.name


def find_prefab_root(collection):
    """Empty raiz do prefab: o marcado com PROP_PREFAB_ROOT (>= dev-0.2.0), ou,
    pra prefab importado por versao antiga, o primeiro Empty sem parent."""
    fallback = None
    for obj in collection.objects:
        if obj.get(PROP_PREFAB_ROOT):
            return obj
        if fallback is None and obj.type == "EMPTY" and obj.parent is None:
            fallback = obj
    return fallback


def prefab_collection_of(obj):
    """Collection de prefab que contem `obj`, ou None."""
    if obj is None:
        return None
    for coll in obj.users_collection:
        if coll.name.startswith(PREFAB_COLLECTION_PREFIX):
            return coll
    return None


def is_hytale_object(obj) -> bool:
    return obj is not None and (PROP_BLOCK_NAME in obj or PROP_ENTITY_KIND in obj)


# Problemas ja decodificados, por Collection: os DOIS paineis chamam
# load_report() a cada redesenho, e o JSON de um prefab grande pode ter
# milhares de itens. Chave = ponteiro da Collection; o texto cru e
# comparado antes de reaproveitar (ponteiro reusado por outra Collection ou
# reimport = texto diferente = decodifica de novo).
_ISSUES_CACHE = {}
_ISSUES_CACHE_MAX = 64


def _decoded_issues(collection) -> dict:
    raw = collection.get(PROP_PREFAB_REPORT_JSON, "{}") or "{}"
    key = collection.as_pointer()
    hit = _ISSUES_CACHE.get(key)
    if hit is not None and hit[0] == raw:
        return hit[1]
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        data = {}
    issues = {
        "missing": list(data.get("missing", [])),
        "unresolved": list(data.get("unresolved", [])),
        "errored": dict(data.get("errored", {})),
        "textures": list(data.get("textures", [])),
    }
    issues["texture_items"] = sorted({w.split(":", 1)[0] for w in issues["textures"]})
    if len(_ISSUES_CACHE) >= _ISSUES_CACHE_MAX:
        _ISSUES_CACHE.clear()
    _ISSUES_CACHE[key] = (raw, issues)
    return issues


def load_report(collection) -> dict | None:
    """Relatorio gravado pelo import (ver prefab_importer.py/
    _store_report_on_collection), ou None pra prefab de versao antiga.
    As listas de problema vem do cache (_decoded_issues) -- quem chama NAO
    pode altera-las."""
    if PROP_PREFAB_BLOCKS_PLACED not in collection:
        return None
    issues = _decoded_issues(collection)
    return {
        "file": collection.get(PROP_PREFAB_FILE, ""),
        "blocks_placed": int(collection.get(PROP_PREFAB_BLOCKS_PLACED, 0)),
        "blocks_total": int(collection.get(PROP_PREFAB_BLOCKS_TOTAL, 0)),
        "entities_placed": int(collection.get(PROP_PREFAB_ENTITIES_PLACED, 0)),
        "entities_total": int(collection.get(PROP_PREFAB_ENTITIES_TOTAL, -1)),
        "unique_meshes": int(collection.get(PROP_PREFAB_UNIQUE_MESHES, 0)),
        "output": str(collection.get(PROP_PREFAB_OUTPUT_MODE, "OBJECTS")),
        "hidden_blocks": int(collection.get(PROP_PREFAB_HIDDEN_BLOCKS, 0)),
        "hidden_faces": int(collection.get(PROP_PREFAB_HIDDEN_FACES, 0)),
        "region_skipped": int(collection.get(PROP_PREFAB_REGION_SKIPPED, 0)),
        "missing": issues["missing"],
        "unresolved": issues["unresolved"],
        "errored": issues["errored"],
        "textures": issues["textures"],
        "texture_items": issues["texture_items"],
    }


OUTPUT_LABELS = {"OBJECTS": "Objects", "INSTANCES": "Instances", "SINGLE_MESH": "Single Mesh"}


def texture_problem_items(report: dict) -> list:
    """Itens distintos com problema de textura (cada aviso e "<id>: ...")."""
    if "texture_items" in report:
        return report["texture_items"]          # ja calculado no cache do load_report
    return sorted({w.split(":", 1)[0] for w in report.get("textures", [])})


def issue_count(report: dict) -> int:
    return (
        len(report["missing"])
        + len(report["unresolved"])
        + len(report["errored"])
        + len(texture_problem_items(report))
    )


def report_as_text(collection) -> str:
    """Relatorio completo em texto puro (pra colar num issue/mensagem)."""
    report = load_report(collection)
    lines = [f"Hyblend Prefabs -- {prefab_display_name(collection)}"]
    if report is None:
        lines.append("(imported with an older version -- no report stored)")
        return "\n".join(lines)
    lines.append(f"File: {report['file']}")
    lines.append(f"Blocks: {report['blocks_placed']}/{report['blocks_total']}")
    if report["entities_total"] >= 0:
        lines.append(f"Entities: {report['entities_placed']}/{report['entities_total']}")
    else:
        lines.append("Entities: not imported")
    lines.append(f"Unique meshes: {report['unique_meshes']}")
    lines.append(f"Output: {OUTPUT_LABELS.get(report['output'], report['output'])}")
    if report["hidden_blocks"]:
        lines.append(f"Hidden blocks removed: {report['hidden_blocks']}")
    if report["hidden_faces"]:
        lines.append(f"Hidden faces removed: {report['hidden_faces']}")
    if report["region_skipped"]:
        lines.append(f"Outside the region (skipped): {report['region_skipped']}")
    if report["missing"]:
        lines.append("")
        lines.append(f"Unknown item ids ({len(report['missing'])}):")
        lines.extend(f"  {i}" for i in report["missing"])
    if report["unresolved"]:
        lines.append("")
        lines.append(f"No known model/shape ({len(report['unresolved'])}):")
        lines.extend(f"  {i}" for i in report["unresolved"])
    if report["errored"]:
        lines.append("")
        lines.append(f"Errors while building mesh ({len(report['errored'])}):")
        lines.extend(f"  {k}: {v}" for k, v in report["errored"].items())
    if report["textures"]:
        lines.append("")
        lines.append(f"Texture problems ({len(texture_problem_items(report))} item(s)):")
        lines.extend(f"  {w}" for w in report["textures"])
    return "\n".join(lines)


def _prefab_collection_or_report(op, name):
    coll = bpy.data.collections.get(name)
    if coll is None or not coll.name.startswith(PREFAB_COLLECTION_PREFIX):
        op.report({"ERROR"}, f"Prefab collection '{name}' not found.")
        return None
    return coll


def _view_layer_objects(context):
    return context.view_layer.objects


# ---------------------------------------------------------------------------
# Operadores
# ---------------------------------------------------------------------------


def _view3d_override(context):
    """(area, region) da Viewport 3D pra rodar view3d.* a partir de um
    botao da Sidebar. Clicando no painel, context.region e a regiao "UI"
    (Sidebar), e view3d.view_selected exige a regiao "WINDOW" -- bug real
    reportado: "poll() Expected a view3d region"."""
    area = context.area if (context.area is not None and context.area.type == "VIEW_3D") else None
    if area is None and context.screen is not None:
        area = next((a for a in context.screen.areas if a.type == "VIEW_3D"), None)
    if area is None:
        return None, None
    region = next((r for r in area.regions if r.type == "WINDOW"), None)
    return area, region


def _select_only(context, objects, active):
    for obj in context.selected_objects:
        obj.select_set(False)
    for obj in objects:
        obj.select_set(True)
    context.view_layer.objects.active = active


class HYBLENDPREFABS_OT_select_prefab(Operator):
    """Seleciona so o Empty raiz do prefab (mover a raiz move tudo)."""

    bl_idname = "hyblendprefabs.select_prefab"
    bl_label = "Select Prefab Root"
    bl_description = "Select this prefab's root Empty -- moving, rotating or scaling it transforms the whole prefab"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    collection_name: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        coll = _prefab_collection_or_report(self, self.collection_name)
        if coll is None:
            return {"CANCELLED"}
        root = find_prefab_root(coll)
        if root is None or root not in set(_view_layer_objects(context)):
            self.report({"WARNING"}, "Prefab root not found (hidden or excluded from the view layer?).")
            return {"CANCELLED"}
        _select_only(context, [root], root)
        return {"FINISHED"}


class HYBLENDPREFABS_OT_frame_prefab(Operator):
    """Enquadra a Viewport no prefab inteiro e deixa a raiz selecionada.
    Enquadrar so a raiz enquadraria um Empty pontual -- por isso seleciona
    todos os Objects pro view_selected e depois volta pra so a raiz."""

    bl_idname = "hyblendprefabs.frame_prefab"
    bl_label = "Frame Prefab"
    bl_description = "Zoom the viewport to fit this prefab"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    collection_name: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        coll = _prefab_collection_or_report(self, self.collection_name)
        if coll is None:
            return {"CANCELLED"}

        visible = set(_view_layer_objects(context))
        targets = [o for o in coll.objects if o in visible and o.visible_get()]
        if not targets:
            self.report({"WARNING"}, "Nothing to frame (prefab hidden or excluded from the view layer?).")
            return {"CANCELLED"}
        root = find_prefab_root(coll)
        root = root if root in visible else None

        _select_only(context, targets, root or targets[0])
        area, region = _view3d_override(context)
        if area is not None and region is not None:
            with context.temp_override(area=area, region=region):
                bpy.ops.view3d.view_selected()
        else:
            self.report({"WARNING"}, "No 3D Viewport found to frame the prefab in.")

        if root is not None:
            _select_only(context, [root], root)
        return {"FINISHED"}


class HYBLENDPREFABS_OT_remove_prefab(Operator):
    """Remove um prefab importado: todos os Objects da Collection, a
    Collection, e as malhas/materiais que ficaram sem uso nenhum depois
    disso (malha e compartilhada entre instancias, entao so apaga quando
    realmente nenhum outro Object usa)."""

    bl_idname = "hyblendprefabs.remove_prefab"
    bl_label = "Remove Prefab"
    bl_description = "Delete this prefab from the scene (objects, collection and meshes no longer used)"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    collection_name: StringProperty(options={"HIDDEN"})

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(
            self, event, title="Remove Prefab", message=f"Delete '{self.collection_name}' from the scene?",
            confirm_text="Delete", icon="WARNING",
        )

    def execute(self, context):
        coll = _prefab_collection_or_report(self, self.collection_name)
        if coll is None:
            return {"CANCELLED"}

        # all_objects inclui a Collection filha "(sources)" do modo Instances.
        objects = list(coll.all_objects)
        meshes = {obj.data for obj in objects if obj.type == "MESH" and obj.data is not None}
        node_groups = {
            mod.node_group for obj in objects for mod in obj.modifiers if mod.type == "NODES" and mod.node_group
        }
        collections = list(coll.children_recursive) + [coll]

        # batch_remove: uma passada so pra remapear usuarios. Remover um
        # Object por vez fica mais caro quanto mais Objects existem (num
        # prefab de 90k blocos, minutos em vez de segundos).
        bpy.data.batch_remove(objects)
        bpy.data.batch_remove(collections)

        dead_meshes = [m for m in meshes if m.users == 0]
        materials = {mat for m in dead_meshes for mat in m.materials if mat is not None}
        if dead_meshes:
            bpy.data.batch_remove(dead_meshes)
        dead = [m for m in materials if m.users == 0] + [g for g in node_groups if g.users == 0]
        if dead:
            bpy.data.batch_remove(dead)

        self.report({"INFO"}, f"Removed prefab ({len(objects)} object(s)).")
        return {"FINISHED"}


class HYBLENDPREFABS_OT_copy_report(Operator):
    """Copia o relatorio completo do import (contagens + todos os itens com
    problema) pra area de transferencia."""

    bl_idname = "hyblendprefabs.copy_report"
    bl_label = "Copy Report"
    bl_description = "Copy the full import report (counts and every item with a problem) to the clipboard"
    bl_options = {"INTERNAL"}

    collection_name: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        coll = _prefab_collection_or_report(self, self.collection_name)
        if coll is None:
            return {"CANCELLED"}
        context.window_manager.clipboard = report_as_text(coll)
        self.report({"INFO"}, "Import report copied to the clipboard.")
        return {"FINISHED"}


class HYBLENDPREFABS_OT_copy_text(Operator):
    """Copia um texto qualquer (ex. item id) pra area de transferencia."""

    bl_idname = "hyblendprefabs.copy_text"
    bl_label = "Copy"
    bl_description = "Copy to the clipboard"
    bl_options = {"INTERNAL"}

    text: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        context.window_manager.clipboard = self.text
        self.report({"INFO"}, f"Copied: {self.text}")
        return {"FINISHED"}


class HYBLENDPREFABS_OT_select_instances(Operator):
    """Seleciona todo Object visivel que usa a MESMA malha do Object ativo
    -- como a malha e compartilhada por item_id (ver DEVELOPER_NOTES.md,
    "Cache de malhas"), isso e "todas as instancias deste item"."""

    bl_idname = "hyblendprefabs.select_instances"
    bl_label = "Select All Instances"
    bl_description = "Select every object in the scene that uses the same item (same shared mesh)"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and obj.data is not None

    def execute(self, context):
        active = context.active_object
        mesh = active.data
        count = 0
        for obj in context.selected_objects:
            obj.select_set(False)
        for obj in _view_layer_objects(context):
            same = obj.type == "MESH" and obj.data == mesh
            if same and obj.visible_get():
                obj.select_set(True)
                count += 1
        self.report({"INFO"}, f"{count} instance(s) selected.")
        return {"FINISHED"}


class HYBLENDPREFABS_OT_open_prefab_folder(Operator):
    """Abre no explorador de arquivos a pasta do .prefab.json de origem."""

    bl_idname = "hyblendprefabs.open_prefab_folder"
    bl_label = "Open Source Folder"
    bl_description = "Open the folder of the source .prefab.json in the file browser"
    bl_options = {"INTERNAL"}

    filepath: StringProperty(options={"HIDDEN"}, subtype="FILE_PATH")

    def execute(self, context):
        folder = Path(self.filepath).parent
        if not folder.is_dir():
            self.report({"WARNING"}, f"Folder not found: {folder}")
            return {"CANCELLED"}
        bpy.ops.wm.path_open(filepath=str(folder))
        return {"FINISHED"}


_CLASSES = (
    HYBLENDPREFABS_OT_select_prefab,
    HYBLENDPREFABS_OT_frame_prefab,
    HYBLENDPREFABS_OT_remove_prefab,
    HYBLENDPREFABS_OT_copy_report,
    HYBLENDPREFABS_OT_copy_text,
    HYBLENDPREFABS_OT_select_instances,
    HYBLENDPREFABS_OT_open_prefab_folder,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
