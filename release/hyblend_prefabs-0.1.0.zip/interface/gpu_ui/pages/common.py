"""Peças compartilhadas pelas páginas da UI por GPU (ImageButton copiado do
Hyblend Toolkit, pages/common.py)."""

from ..framework.core import Button, Rect, fit_text
from ..framework.motion import mix


class ImageButton(Button):
    """Botão cujo ícone pode ser um PNG do disco (logos do About, de
    assets/icons/); sem o PNG, cai no ícone procedural."""

    def __init__(self, key, text, on_click, icon=None, image=None, **kw):
        super().__init__(key, text, on_click, icon=icon, **kw)
        self.image = image

    def measure(self, f, max_w):
        w, h = super().measure(f, max_w)
        if self.image and not self.icon:
            w += 16 + (6 if self.text else 0)
        return (w, h)

    def draw(self, f):
        th, r = f.theme, f.renderer
        hovered = f.hover == self.key and self.enabled
        pressed = hovered and f.pressed == self.key
        h = f.animate(self.key + ".hover", 1.0 if hovered else 0.0, 0.12)
        p = f.animate(self.key + ".press", 1.0 if pressed else 0.0, 0.06)
        rect = self.rect.expand(-0.75 * p)
        if not self._draw_skin(f, self.rect, h, p, 0.0):
            color = mix(mix(th.surface_raised, th.surface_hover, h), th.surface_pressed, p)
            r.rect(rect, color, radius=self.style.radius * th.radius_scale, border=th.border)
        label, weight, tracking, size = self._label(th)
        gap = 6.0 if self.text else 0.0
        if self.text:
            size, tracking = fit_text(r, label, rect.w - 18 - 16 - gap, size, weight, tracking)
        text_w = r.text_width(label, size, weight, tracking) if self.text else 0.0
        total = 16 + gap + text_w
        x = rect.x + (max(6.0, (rect.w - total) / 2) if self.text else (rect.w - total) / 2)
        box = Rect(x, rect.y + (rect.h - 16) / 2, 16, 16)
        old = r.opacity
        if not self.enabled:
            r.opacity = old * 0.45
        if not (self.image and r.image(box, self.image)):
            r.icon(box, self.icon or "globe", th.text if self.enabled else th.text_muted)
        r.opacity = old
        if self.text:
            r.text(Rect(box.right + gap, rect.y, rect.right - box.right - gap - 6, rect.h), label,
                   th.text if self.enabled else th.text_muted, size=size, weight=weight, tracking=tracking)
