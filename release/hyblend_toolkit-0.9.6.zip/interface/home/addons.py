"""Aba Add-ons da Home: instala, atualiza, liga/desliga e desinstala os addons Hyblend direto dos releases do GitHub.

Fonte = releases.py (a MESMA chamada do Changelog): tag "<prefixo>-v<versão>" + o zip anexado ("<id>-<versão>.zip",
com o sha256 que o GitHub calcula). Pre-release e draft não são oferecidos.
Instalar/atualizar/desinstalar = operadores de extensão do Blender, no repositório onde o addon já está (senão
user_default); a atualização de um addon ligado é desligar -> trocar -> religar, feita pelo próprio Blender.

IMPORTANTE: rede só na thread; disco (manifests), bpy.ops e addon_utils só em timer. O desenho lê só o que está em
memória (state(), installed(), latest()) e o `preferences.addons` (ligado ou não).
IMPORTANTE: o Toolkit se atualiza com a Home FECHADA (o operador da Home é dele e sai no unregister).
"""

import hashlib
import os
import shutil
import tempfile
import threading
import traceback
import zipfile

import bpy

from ...common import ADDON_PACKAGE
from . import releases

CORE_ID = "hyblend_toolkit"

# (prefixo da tag em releases.TAG_PREFIXES, id do manifest, nome, ícone da UI por GPU, key da descrição).
# Ordem = ordem da lista. Addon novo = uma linha aqui (e em releases.TAG_PREFIXES).
CATALOG = (
    ("toolkit", CORE_ID, "Hyblend Toolkit", "gear", "home.addons.desc.toolkit"),
    ("anim", "hyblend_anim", "Hyblend Anim", "anim", "home.addons.desc.anim"),
    ("cc", "hyblend_character_creator", "Hyblend Character Creator", "user", "home.addons.desc.cc"),
    ("prefabs", "hyblend_prefabs", "Hyblend Prefabs", "collection", "home.addons.desc.prefabs"),
)

POLL = 0.2               # timer da thread de download
CHUNK = 64 * 1024
TIMEOUT = 20.0

_installed = {}          # id -> {"version", "repo", "directory", "module"} (scan())
_job = {}                # o trabalho em andamento (um por vez): id, phase, progress, ...
_ticks = []              # timers de _start (saem no cancel)
_lock = threading.Lock()


def _t(key):
    from . import t
    return t(key)


def _notify(text, error=False):
    from ..gpu_ui import home_host
    home_host.toast(text, error=error)


def _redraw():
    from ..gpu_ui import home_host
    home_host.refresh_all()


# --- Versões ---

def parse_version(text):
    """"v0.1.10" -> (0, 1, 10); pedaço não numérico vira 0."""
    parts = []
    for piece in str(text or "").strip().lstrip("vV").split("-")[0].split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    while len(parts) > 1 and parts[-1] == 0:
        parts.pop()
    return tuple(parts) or (0,)


def entry(ident):
    return next((row for row in CATALOG if row[1] == ident), None)


# --- O que está instalado (disco: só fora do desenho) ---

def _user_repos():
    """Repositórios de extensão do usuário ligados (o "system" não aceita instalar/desinstalar)."""
    repos = []
    for repo in bpy.context.preferences.extensions.repos:
        if repo.enabled and getattr(repo, "source", "USER") == "USER" and repo.directory:
            repos.append(repo)
    return repos


def _read_manifest_text(text):
    import tomllib
    return tomllib.loads(text)


def scan():
    """Relê os manifests instalados (um stat + um TOML por addon conhecido). Abrir a página / depois de cada ação."""
    found = {}
    for repo in _user_repos():
        for _prefix, ident, *_ in CATALOG:
            if ident in found:
                continue
            path = os.path.join(repo.directory, ident, "blender_manifest.toml")
            if not os.path.isfile(path):
                continue
            try:
                with open(path, "rb") as handle:
                    manifest = _read_manifest_text(handle.read().decode("utf-8"))
            except Exception:
                manifest = {}
            found[ident] = {"version": str(manifest.get("version", "?")), "repo": repo.module,
                            "directory": repo.directory, "module": "bl_ext.%s.%s" % (repo.module, ident)}
    # O Toolkit rodando é a verdade (até instalado fora de um repositório de usuário).
    if CORE_ID not in found:
        from ..welcome import addon_version
        repo = ADDON_PACKAGE.split(".")[1] if ADDON_PACKAGE.count(".") == 2 else ""
        found[CORE_ID] = {"version": addon_version(), "repo": repo, "directory": "", "module": ADDON_PACKAGE}
    _installed.clear()
    _installed.update(found)


def installed(ident):
    return _installed.get(ident)


def is_enabled(ident, context=None):
    """Ligado agora? (preferences.addons: pode ir no desenho)."""
    info = _installed.get(ident)
    if info is None:
        return False
    return (context or bpy.context).preferences.addons.get(info["module"]) is not None


# --- O que está no GitHub (memória) ---

def latest(ident):
    """Release mais novo (não pre-release) com zip do addon: {"version", "tag", "url", "size", "digest", "name"}
    ou None. Mais novo = maior versão (não a ordem do GitHub)."""
    row = entry(ident)
    if row is None:
        return None
    best = None
    for release in releases.releases():
        if release.get("prerelease"):
            continue
        prefix, _name, version = releases.split_tag(release.get("tag_name"))
        if prefix != row[0]:
            continue
        assets = release.get("assets") or []
        asset = next((a for a in assets if str(a.get("name", "")).startswith(ident + "-")), None)
        if asset is None and len(assets) == 1:
            asset = assets[0]                    # nome fora do padrão: aceita se for o único zip
        if asset is None or not asset.get("url"):
            continue
        candidate = {"version": version.lstrip("vV"), "tag": release.get("tag_name"), "url": asset["url"],
                     "size": asset.get("size"), "digest": asset.get("digest"), "name": asset.get("name")}
        if best is None or parse_version(candidate["version"]) > parse_version(best["version"]):
            best = candidate
    return best


def has_update(ident):
    info, new = _installed.get(ident), latest(ident)
    return bool(info and new and parse_version(new["version"]) > parse_version(info["version"]))


def state():
    """Trabalho em andamento: {"id", "phase" ("download"|"install"|"remove"|"toggle"), "progress"} ou {}."""
    with _lock:
        return dict(_job)


def busy():
    return bool(state())


# --- Ações (clique na página: só agendam; o trabalho é em thread/timer) ---

def install(ident):
    """Instalar ou atualizar pela última versão do GitHub."""
    new = latest(ident)
    if busy() or new is None:
        return False
    if not releases.online_allowed():
        _notify(_t("home.addons.tooltip.offline"), error=True)
        return False
    folder = tempfile.mkdtemp(prefix="hyblend_download_")
    target = os.path.join(folder, os.path.basename(new["name"] or ident + ".zip"))
    token = object()                               # a thread só escreve no _job enquanto ele for deste download
    with _lock:
        _job.clear()
        _job.update(id=ident, phase="download", progress=0.0, release=new, path=target, folder=folder,
                    result=None, token=token)
    threading.Thread(target=_download, args=(new, target, token), name="hyblend_addon_download",
                     daemon=True).start()
    if not bpy.app.timers.is_registered(_poll):
        bpy.app.timers.register(_poll, first_interval=POLL)
    _redraw()
    return True


def uninstall(ident):
    if busy() or ident == CORE_ID or ident not in _installed:
        return False
    _start("remove", ident, _do_uninstall)
    return True


def set_enabled(ident, value):
    if busy() or ident == CORE_ID or ident not in _installed:
        return False
    _start("toggle", ident, lambda i: _do_toggle(i, value))
    return True


def _start(phase, ident, work):
    with _lock:
        _job.clear()
        _job.update(id=ident, phase=phase, progress=0.0)
    _redraw()

    def tick():
        if tick in _ticks:
            _ticks.remove(tick)
        try:
            work(ident)
        except Exception:
            traceback.print_exc()
        finally:
            _finish()
        return None
    _ticks.append(tick)
    bpy.app.timers.register(tick, first_interval=0.05)


def _finish():
    with _lock:
        folder = _job.get("folder")
        _job.clear()
    if folder:
        shutil.rmtree(folder, ignore_errors=True)
    try:
        scan()
    except Exception:
        traceback.print_exc()
    _redraw()


# --- Download (THREAD: só rede, arquivo e hash) ---

def _report(token, **values):
    """THREAD -> _job, só se o trabalho ainda for o deste download (cancel() ou outro download = descarta)."""
    with _lock:
        if _job.get("token") is token:
            _job.update(values)


def _download(release, target, token):
    import ssl
    import urllib.request
    try:
        try:
            import certifi
            context = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            context = ssl.create_default_context()
        request = urllib.request.Request(release["url"], headers={"User-Agent": "Hyblend-Toolkit",
                                                                  "Accept": "application/octet-stream"})
        digest = hashlib.sha256()
        done = 0
        with urllib.request.urlopen(request, timeout=TIMEOUT, context=context) as response, \
                open(target, "wb") as out:
            total = int(release.get("size") or response.headers.get("Content-Length") or 0)
            while True:
                chunk = response.read(CHUNK)
                if not chunk:
                    break
                out.write(chunk)
                digest.update(chunk)
                done += len(chunk)
                if total:
                    _report(token, progress=min(1.0, done / total))
        expected = str(release.get("digest") or "")
        if release.get("size") and done != int(release["size"]):
            result = ("error", "home.addons.err.size")
        elif expected.startswith("sha256:") and expected[7:].lower() != digest.hexdigest():
            result = ("error", "home.addons.err.hash")
        else:
            result = ("ok", None)
    except Exception as error:                     # sem internet, 404, disco cheio (ou a pasta já apagada)...
        result = ("error", str(error)[:200])
    _report(token, result=result)


def _poll():
    """Timer (thread principal): espera o download, confere o zip e instala."""
    with _lock:
        job = dict(_job)
    if not job or job.get("phase") != "download":
        return None
    if job.get("result") is None:
        _redraw()                                  # barra de progresso
        return POLL
    ident, release = job["id"], job["release"]
    name = entry(ident)[2]
    kind, detail = job["result"]
    if kind != "ok":                               # key nossa (tamanho/hash) ou o erro cru da rede
        _fail(name, _t(detail) if detail.startswith("home.addons.") else
              _t("home.addons.err.download").format(error=detail))
        return None
    problem = check_archive(job["path"], ident, release["version"])
    if problem:
        _fail(name, _t(problem) if problem.startswith("home.addons.") else problem)
        return None
    with _lock:
        _job.update(phase="install", progress=1.0)
    _redraw()
    if ident == CORE_ID:
        _install_core(job)
    else:
        try:
            _do_install(ident, job["path"], release["version"])
        except Exception:
            traceback.print_exc()
        finally:
            _finish()
    return None


def _fail(name, text):
    print("[Hyblend] Add-ons:", name, "-", text)
    _notify(_t("home.addons.msg.failed").format(name=name, error=text), error=True)
    _finish()


def check_archive(path, ident, version):
    """Confere o zip ANTES de instalar: manifest na raiz, id, versão do release e a faixa do Blender.
    Devolve "" (ok), uma key de erro (home.addons.err.*) ou o texto do erro."""
    try:
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            inner = "blender_manifest.toml" if "blender_manifest.toml" in names else next(
                (n for n in names if n.count("/") == 1 and n.endswith("/blender_manifest.toml")), None)
            if inner is None:
                return "home.addons.err.manifest"
            manifest = _read_manifest_text(archive.read(inner).decode("utf-8"))
    except Exception:
        return "home.addons.err.manifest"
    if manifest.get("id") != ident or parse_version(manifest.get("version")) != parse_version(version):
        return "home.addons.err.manifest"
    low = parse_version(manifest.get("blender_version_min", "0"))
    high = manifest.get("blender_version_max")
    current = parse_version(".".join(map(str, bpy.app.version)))
    if current < low or (high and current >= parse_version(high)):
        return _t("home.addons.err.blender").format(min=manifest.get("blender_version_min", "?"),
                                                     max=high or "-")
    return ""


# --- bpy.ops (timer) ---

def _target_repo(ident):
    info = _installed.get(ident)
    if info and info["repo"]:
        return info["repo"]
    repos = _user_repos()
    local = [r for r in repos if not r.use_remote_url]
    pick = next((r for r in local if r.module == "user_default"), None) or (local or repos or [None])[0]
    return pick.module if pick is not None else ""


def _do_install(ident, path, version):
    """Instala/atualiza (o Blender desliga, troca e religa o que estava ligado). Addon novo nasce ligado."""
    name = entry(ident)[2]
    was = _installed.get(ident)
    repo = _target_repo(ident)
    if not repo:
        _notify(_t("home.addons.msg.failed").format(name=name, error=_t("home.addons.err.repo")), error=True)
        return
    try:
        bpy.ops.extensions.package_install_files(filepath=path, repo=repo, enable_on_install=was is None)
    except Exception as error:                     # operador que reporta ERROR levanta RuntimeError
        _notify(_t("home.addons.msg.failed").format(name=name, error=str(error).strip()[:160]), error=True)
        return
    key = "home.addons.msg.updated" if was else "home.addons.msg.installed"
    _notify(_t(key).format(name=name, version=version))


def _install_core(job):
    """Toolkit: fecha a Home e instala por cima de si mesmo. Daqui em diante este módulo pode ser descarregado
    (o Blender desliga o Toolkit, troca os arquivos e religa; os dependentes caem e voltam pelo hyblend_link)."""
    from ..gpu_ui import home_host
    path, folder, version = job["path"], job["folder"], job["release"]["version"]
    with _lock:
        _job["folder"] = None                       # a pasta sai no `then`, depois da instalação
    repo = _target_repo(CORE_ID)

    def then(_window):
        try:
            bpy.ops.extensions.package_install_files(filepath=path, repo=repo, enable_on_install=False)
            print("[Hyblend] Toolkit updated to", version)
        except Exception as error:
            print("[Hyblend] Toolkit update failed:", error)
        finally:
            shutil.rmtree(folder, ignore_errors=True)
            with _lock:
                _job.clear()
    home_host.close_home(then)


def _do_uninstall(ident):
    info, name = _installed.get(ident), entry(ident)[2]
    if info is None:
        return
    try:
        bpy.ops.extensions.package_uninstall(repo_directory=info["directory"], pkg_id=ident)
    except Exception as error:
        _notify(_t("home.addons.msg.failed").format(name=name, error=str(error).strip()[:160]), error=True)
        return
    _notify(_t("home.addons.msg.removed").format(name=name))


def _do_toggle(ident, value):
    info, name = _installed.get(ident), entry(ident)[2]
    if info is None:
        return
    try:
        if value:
            bpy.ops.preferences.addon_enable(module=info["module"])
        else:
            bpy.ops.preferences.addon_disable(module=info["module"])
    except Exception as error:
        _notify(_t("home.addons.msg.failed").format(name=name, error=str(error).strip()[:160]), error=True)
        return
    if value and not is_enabled(ident):           # register() do addon falhou (o Blender só imprime)
        _notify(_t("home.addons.msg.failed").format(name=name, error=_t("home.addons.err.enable")), error=True)
        return
    _notify(_t("home.addons.msg.enabled" if value else "home.addons.msg.disabled").format(name=name))


def cancel():
    """unregister: nenhum timer sobra e o trabalho pela metade sai (o módulo sobrevive ao desligar; religado na
    mesma sessão, um _job velho deixaria a aba "ocupada" pra sempre). A thread é daemon e só escreve em _job.
    IMPORTANTE: na atualização do Toolkit este cancel roda NO MEIO da instalação (o Blender desliga o Toolkit antes
    de ler o zip): por isso _install_core tira a pasta do _job antes (senão ela seria apagada aqui)."""
    for fn in [_poll] + _ticks:
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    _ticks.clear()
    with _lock:
        folder = _job.get("folder")
        _job.clear()
    if folder:
        shutil.rmtree(folder, ignore_errors=True)
