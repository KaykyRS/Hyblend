"""block_def.py -- traduz o "name" cru de um bloco/entity do .prefab.json +
o JSON de item correspondente (Server/Item/Items/.../<id>.json) numa
estrutura simples que o resto do importer sabe desenhar. Ver
DEVELOPER_NOTES.md ("Resolucao de blocks") pro schema do item JSON
(CustomModel vs Textures vs State vs Parent)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

# Dois marcadores de estado coexistem no "name"/Item.Item.Id cru -- tentados
# nesta ordem (o mais especifico primeiro). Ver DEVELOPER_NOTES.md.
_STATE_MARKERS = ("_State_Definitions_", "_State_")
_MAX_PARENT_DEPTH = 8

ItemLoader = Callable[[str], Optional[dict]]


@dataclass
class TextureVariant:
    path: str  # relativo a Common/
    weight: float = 1.0


@dataclass
class BlockDef:
    item_id: str
    draw_type: str  # "MODEL" | "CUBE" | "UNKNOWN"
    custom_model: Optional[str] = None  # relativo a Common/
    custom_model_textures: list = field(default_factory=list)  # list[TextureVariant]
    cube_sides: Optional[str] = None  # relativo a Common/
    cube_up: Optional[str] = None  # relativo a Common/
    cube_down: Optional[str] = None  # relativo a Common/
    custom_model_scale: float = 1.0  # BlockType.CustomModelScale -- ver build_block_def
    # (r,g,b) 0..1 ou None. `tint` e pra MODEL (1 material so); `tint_sides`/
    # `tint_up`/`tint_down` sao pra CUBE (3 materiais separados).
    tint: Optional[tuple] = None
    tint_sides: Optional[tuple] = None
    tint_up: Optional[tuple] = None
    tint_down: Optional[tuple] = None
    # BlockType.Opacity cru ("Solid", "Semitransparent", "Transparent"...) ou
    # None se ausente. So o Optimizer le isso (bloco "cubo" opaco esconde a
    # face/bloco vizinho) -- nao afeta o desenho normal.
    opacity: Optional[str] = None


def parse_resolved_name(raw_name: str) -> tuple[str, Optional[str]]:
    """Separa o "name"/"Item.Item.Id" cru (bloco OU entity) em (item_id, state_name).

    "Furniture_Tavern_Barrel" -> ("Furniture_Tavern_Barrel", None)
    "*Furniture_Crude_Trapdoor_State_Definitions_OpenDoorOut"
        -> ("Furniture_Crude_Trapdoor", "OpenDoorOut")
    "*Deco_Mug_State_Filled_Water" -> ("Deco_Mug", "Filled_Water")
    """
    name = raw_name[1:] if raw_name.startswith("*") else raw_name
    for marker in _STATE_MARKERS:
        if marker in name:
            item_id, _, state_name = name.partition(marker)
            return item_id, state_name
    return name, None


def _deep_merge(base: dict, override: dict) -> dict:
    """Mescla `override` por cima de `base`, recursivo em sub-dicionarios
    (permite herdar chaves de State.Definitions que so existem no pai,
    mesmo o filho tendo seu proprio State.Definitions parcial)."""
    result = dict(base)
    for key, value in override.items():
        base_value = result.get(key)
        if isinstance(value, dict) and isinstance(base_value, dict):
            result[key] = _deep_merge(base_value, value)
        else:
            result[key] = value
    return result


def _effective_block_type(item_id: str, loader: ItemLoader, _depth: int = 0, _seen: Optional[set] = None) -> dict:
    """BlockType do item, com campo ausente preenchido subindo a cadeia
    "Parent" (pai, avo, ...). `_seen` evita loop infinito numa cadeia
    circular."""
    if _seen is None:
        _seen = set()
    if item_id in _seen or _depth > _MAX_PARENT_DEPTH:
        return {}
    _seen.add(item_id)

    data = loader(item_id)
    if data is None:
        return {}

    own_block_type = data.get("BlockType", {}) or {}
    parent_id = data.get("Parent")
    if not parent_id:
        return own_block_type

    parent_block_type = _effective_block_type(parent_id, loader, _depth + 1, _seen)
    return _deep_merge(parent_block_type, own_block_type)


def _effective_root_fields(
    item_id: str, loader: ItemLoader, keys: tuple, _depth: int = 0, _seen: Optional[set] = None
) -> dict:
    """Mesma ideia de _effective_block_type, mas pra campos do NIVEL RAIZ
    do JSON (irmaos de "BlockType"/"Parent", ex. "Model"/"Texture") --
    usado pra resolver item entities (ver resolve_item_model_ref)."""
    if _seen is None:
        _seen = set()
    if item_id in _seen or _depth > _MAX_PARENT_DEPTH:
        return {}
    _seen.add(item_id)

    data = loader(item_id)
    if data is None:
        return {}

    own = {k: data[k] for k in keys if data.get(k) is not None}
    parent_id = data.get("Parent")
    if not parent_id:
        return own

    parent_fields = _effective_root_fields(parent_id, loader, keys, _depth + 1, _seen)
    merged = dict(parent_fields)
    merged.update(own)
    return merged


def resolve_item_model_ref(item_id: str, loader: ItemLoader) -> Optional[dict]:
    """{"Model": ..., "Texture": ...} (relativos a Common/) pro modelo de
    uma item entity, ou None se nem o item nem nenhum ancestral tiver "Model"."""
    fields = _effective_root_fields(item_id, loader, ("Model", "Texture"))
    if not fields.get("Model"):
        return None
    return fields


def _texture_variants(block_type: dict) -> list:
    return [
        TextureVariant(path=v["Texture"], weight=float(v.get("Weight", 1)))
        for v in block_type.get("CustomModelTexture", [])
        if v.get("Texture")
    ]


# Cor de aproximacao pra BiomeTint (Prefab nao carrega info de bioma do
# mundo). Verde tipo grama "padrao", mesma logica de fallback que
# ferramentas de Minecraft usam. Ver DEVELOPER_NOTES.md ("Tint").
_DEFAULT_BIOME_TINT_RGB = (0.4745, 0.7529, 0.3529)


def _hex_to_rgb(value) -> Optional[tuple]:
    """"#RRGGBB" ou "RRGGBB" -> (r,g,b) em 0..1."""
    try:
        text = str(value).lstrip("#")
        n = int(text, 16)
    except (TypeError, ValueError):
        return None
    r = ((n >> 16) & 0xFF) / 255.0
    g = ((n >> 8) & 0xFF) / 255.0
    b = (n & 0xFF) / 255.0
    return (r, g, b)


def _resolve_tint(block_type: dict, direction_suffixes: tuple) -> Optional[tuple]:
    """Tint pra um GRUPO de faces (qualquer uma das direcoes bastando).
    Prioridade: Tint<Direcao> literal > Tint generico literal >
    BiomeTint<Direcao> (aproximado) > BiomeTint generico (aproximado)."""
    for suffix in direction_suffixes:
        arr = block_type.get(f"Tint{suffix}")
        if arr:
            rgb = _hex_to_rgb(arr[0])
            if rgb is not None:
                return rgb
    generic = block_type.get("Tint")
    if generic:
        rgb = _hex_to_rgb(generic[0])
        if rgb is not None:
            return rgb

    for suffix in direction_suffixes:
        val = block_type.get(f"BiomeTint{suffix}")
        if val not in (None, 0):  # 0 == "sem tint" (mesma convencao do jogo)
            return _DEFAULT_BIOME_TINT_RGB
    generic_biome = block_type.get("BiomeTint")
    if generic_biome not in (None, 0):
        return _DEFAULT_BIOME_TINT_RGB

    return None


def _best_biome_tint_approx(block_type: dict, face_suffix: str) -> tuple:
    """Aproximacao pra BiomeTint de uma face: usa o Tint literal generico
    do item se existir, senao cai pra _DEFAULT_BIOME_TINT_RGB."""
    arr = block_type.get(f"Tint{face_suffix}") or block_type.get("Tint")
    if arr:
        rgb = _hex_to_rgb(arr[0])
        if rgb is not None:
            return rgb
    return _DEFAULT_BIOME_TINT_RGB


def _resolve_face_tint(block_type: dict, face_suffix: str) -> Optional[tuple]:
    """Tint de UMA face especifica (ex. "Up"), prioridade: tint literal da
    face > tint literal generico > tint de bioma da face > tint de bioma
    generico > nenhum. Diferente de _resolve_tint: verifica se a chave
    "Tint<Face>"/"BiomeTint<Face>" esta PRESENTE (mesmo vazia), nao so se
    tem valor -- um array vazio ("TintDown": []) e o jogo dizendo
    EXPLICITAMENTE "sem tint nessa face", e nao deve cair pro Tint
    generico (ver DEVELOPER_NOTES.md, "Tint" -- bug real: grama tingia a
    terra embaixo dela de verde)."""
    literal_key = f"Tint{face_suffix}"
    if literal_key in block_type:
        arr = block_type.get(literal_key)
        if arr:
            rgb = _hex_to_rgb(arr[0])
            if rgb is not None:
                return rgb
        # chave presente mas vazia/invalida -> sem tint literal, de proposito.
    else:
        generic = block_type.get("Tint")
        if generic:
            rgb = _hex_to_rgb(generic[0])
            if rgb is not None:
                return rgb

    biome_key = f"BiomeTint{face_suffix}"
    if biome_key in block_type:
        biome_val = block_type.get(biome_key)
        if biome_val not in (None, 0):
            return _best_biome_tint_approx(block_type, face_suffix)
        return None  # BiomeTint<Face> == 0 explicito -> sem tint de bioma nessa face
    generic_biome = block_type.get("BiomeTint")
    if generic_biome not in (None, 0):
        return _best_biome_tint_approx(block_type, face_suffix)
    return None


def build_block_def(item_id: str, loader: ItemLoader) -> BlockDef:
    """Resolve o BlockDef de um item, subindo a cadeia `Parent` quando o
    proprio item nao tem CustomModel/Textures suficiente pra desenhar nada."""
    block_type = _effective_block_type(item_id, loader)
    state_defs = (block_type.get("State", {}) or {}).get("Definitions", {}) or {}
    # BlockType.CustomModelScale -- escala uniforme com pivo no "bottom
    # center" do bloco (espaco 16-unidades), ver node_mesh.py/build_item_mesh.
    custom_model_scale = float(block_type.get("CustomModelScale", 1.0) or 1.0)
    # MODEL usa 1 material pro item inteiro -- checa as 6 direcoes, qualquer
    # uma com tint serve (nao ha tint por-face num material unico).
    model_tint = _resolve_tint(
        block_type, ("Up", "Down", "Top", "Bottom", "UpDown", "North", "South", "East", "West")
    )

    custom_model = block_type.get("CustomModel")
    if custom_model:
        return BlockDef(
            item_id=item_id,
            draw_type="MODEL",
            custom_model=custom_model,
            custom_model_textures=_texture_variants(block_type),
            custom_model_scale=custom_model_scale,
            tint=model_tint,
        )

    textures = block_type.get("Textures", [])
    if textures:
        # "primeira entrada vence" -- Weight e pra variacao aleatoria do
        # PROPRIO JOGO, o prefab nao guarda qual variante foi sorteada.
        first = textures[0]
        # Camadas na ordem confirmada (a de baixo vence): All -> Sides ->
        # UpDown -> North/South/East/West -> Up -> Down. Ver DEVELOPER_NOTES.md
        # ("Texturas de cube").
        all_tex = first.get("All")
        cube_sides = first.get("Sides") or first.get("Side") or all_tex
        updown_shared = first.get("UpDown") or first.get("Top") or first.get("Bottom")
        cube_up = first.get("Up") or updown_shared or all_tex
        cube_down = first.get("Down") or updown_shared or all_tex
        # Fallback pra bloco "cru" com textura uniforme cujo JSON nao usa
        # nenhuma chave conhecida: pega o primeiro valor string != "Weight".
        if not cube_sides and not cube_up and not cube_down:
            for key, value in first.items():
                if key == "Weight" or not isinstance(value, str) or not value:
                    continue
                cube_sides = value
                cube_up = value
                cube_down = value
                break
        return BlockDef(
            item_id=item_id,
            draw_type="CUBE",
            cube_sides=cube_sides,
            cube_up=cube_up,
            cube_down=cube_down,
            tint_sides=_resolve_tint(block_type, ("North", "South", "East", "West")),
            tint_up=_resolve_face_tint(block_type, "Up"),
            tint_down=_resolve_face_tint(block_type, "Down"),
            opacity=block_type.get("Opacity"),
        )

    # Ultimo recurso: nem CustomModel nem Textures em nenhum nivel da cadeia
    # Parent, mas existe um State.Definitions com modelo proprio. Prefere
    # "default"; senao a primeira variante com CustomModel.
    if state_defs:
        chosen = state_defs.get("default")
        if not chosen or not chosen.get("CustomModel"):
            chosen = next((v for v in state_defs.values() if v.get("CustomModel")), None)
        if chosen:
            return BlockDef(
                item_id=item_id,
                draw_type="MODEL",
                custom_model=chosen["CustomModel"],
                custom_model_textures=_texture_variants(block_type),
                custom_model_scale=custom_model_scale,
                tint=model_tint,
            )

    return BlockDef(item_id=item_id, draw_type="UNKNOWN")
