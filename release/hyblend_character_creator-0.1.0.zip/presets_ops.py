"""presets_ops.py -- salvar/carregar/apagar presets de personagem
(combinacao completa de categoria -> item/cor/variante/gradient_set).

Reaproveita bpy.ops.hyblendcc.apply_slot (definido em picker.py) via
STRING (bl_idname), nao import direto -- por isso este modulo nao
importa nada de picker.py: o desacoplamento e proposital, so precisa que
o operador esteja REGISTRADO (o que __init__.py garante), nao de uma
referencia direta a classe."""

from __future__ import annotations

import bpy
from bpy.types import Operator

from .builder.character_assembly import get_equipped_item, remove_equipped_slot
from .common import _MANDATORY_CATEGORIES, _SLOT_NONE_VALUE, game_found
from .picker import _sync_slots_from_armature
from .presets.storage import delete_preset, list_presets, load_preset, save_preset
from .scanner.catalog import get_cache

# BUG DE PERFORMANCE REAL corrigido: list_presets() faz I/O DE DISCO de
# verdade (presets_root() chama Path.mkdir(exist_ok=True) -- uma
# chamada de sistema mesmo quando a pasta ja existe -- e list_presets()
# em cima disso ainda faz .glob("*.json") pra listar arquivos). Sem
# cache, isso rodava a CADA REDRAW do painel (sempre que a secao
# "Presets" estava expandida), nao so quando salvar/apagar de verdade
# muda algo -- diferente de CPU, I/O de disco NAO e barato (Windows +
# antivirus em tempo real deixa isso ainda pior), e foi a causa raiz
# confirmada de um problema real de performance durante scroll continuo
# do painel (cada redraw pagando o preco de bater no disco de novo).
_preset_list_cache: "list | None" = None


def _invalidate_preset_list_cache() -> None:
    global _preset_list_cache
    _preset_list_cache = None


def _preset_enum_items(self, context):
    global _preset_list_cache
    if _preset_list_cache is None:
        _preset_list_cache = list_presets()
    names = _preset_list_cache
    if not names:
        return [("", "(no saved presets)", "")]
    return [(n, n, "") for n in names]


class HYBLENDCC_OT_save_preset(Operator):
    """Salva a combinacao INTEIRA de categorias equipadas no Armature
    ativo como um preset nomeado (Documentos/Hyblend/CharacterCreator/
    presets/<nome>.json). Categorias sem nada equipado simplesmente nao
    entram no preset -- carregar de volta nao "limpa" categorias que o
    preset nao menciona (ver HYBLENDCC_OT_load_preset)."""

    bl_idname = "hyblendcc.save_preset"
    bl_label = "Save Preset"
    bl_description = "Save everything currently equipped on the active Armature as a named preset"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "ARMATURE" and bool(context.window_manager.hyblendcc_preset_name.strip())

    def execute(self, context):
        wm = context.window_manager
        armature_obj = context.active_object
        cache = get_cache()

        slots = {}
        for category in cache.catalogs.keys():
            equipped = get_equipped_item(armature_obj, category)
            if equipped is None:
                continue
            item_id, color, variant, gradient_set, background_color, background_linked, skin_linked = equipped
            slots[category] = {
                "item_id": item_id, "color": color, "variant": variant, "gradient_set": gradient_set,
                "background_color": background_color, "background_linked": background_linked,
                "skin_linked": skin_linked,
            }

        if not slots:
            self.report({"WARNING"}, "Nothing equipped on the active Armature -- nothing to save.")
            return {"CANCELLED"}

        path = save_preset(wm.hyblendcc_preset_name.strip(), slots)
        _invalidate_preset_list_cache()
        self.report({"INFO"}, f"Preset saved: {path.name} ({len(slots)} categorie(s)).")
        return {"FINISHED"}


class HYBLENDCC_OT_load_preset(Operator):
    """Carrega um preset salvo, reaplicando cada categoria que ele
    menciona via o MESMO operador hyblendcc.apply_slot que o picker usa
    -- nao reimplementa a logica de assembly aqui. Um preset e um
    RETRATO COMPLETO do personagem: qualquer categoria que o Armature
    ativo tenha equipada mas o preset NAO mencione e LIMPADA (exceto
    categorias obrigatorias tipo BodyCharacteristics, que nunca ficam
    vazias) -- pedido explicito, corrigindo um comportamento anterior
    (aditivo) que deixava sobras de antes do preset ser carregado."""

    bl_idname = "hyblendcc.load_preset"
    bl_label = "Load Preset"
    bl_description = "Load a saved preset, replacing the current outfit with the full portrait it saved"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return game_found() and obj is not None and obj.type == "ARMATURE" and bool(context.window_manager.hyblendcc_preset_selected)   # sem o jogo: travado (common.game_found)

    def execute(self, context):
        wm = context.window_manager
        name = wm.hyblendcc_preset_selected
        try:
            slots = load_preset(name)
        except (OSError, ValueError) as exc:
            self.report({"ERROR"}, f"Could not read preset '{name}': {exc}")
            return {"CANCELLED"}

        if not slots:
            self.report({"WARNING"}, f"Preset '{name}' is empty.")
            return {"CANCELLED"}

        armature_obj = context.active_object
        cache = get_cache()

        applied = 0
        for category, data in slots.items():
            item_id = data.get("item_id", "")
            color = data.get("color", "")
            variant = data.get("variant", "") or _SLOT_NONE_VALUE
            gradient_set = data.get("gradient_set", "") or _SLOT_NONE_VALUE
            background_color = data.get("background_color", "") or color
            background_linked = bool(data.get("background_linked", False))
            skin_linked = bool(data.get("skin_linked", True))
            if not item_id:
                continue
            result = bpy.ops.hyblendcc.apply_slot(
                category=category, item_id=item_id, color=color, variant=variant, gradient_set=gradient_set,
                background_color=background_color, background_linked=background_linked, skin_linked=skin_linked,
            )
            if "FINISHED" in result:
                applied += 1

        # Limpa qualquer categoria que o Armature JA tinha equipada mas
        # que este preset nao menciona -- um preset e um retrato
        # completo, nao um "aplicar por cima" do que ja estava.
        cleared = 0
        for category in cache.catalogs.keys():
            if category in slots or category in _MANDATORY_CATEGORIES:
                continue
            if get_equipped_item(armature_obj, category) is not None:
                remove_equipped_slot(context, armature_obj, category)
                cleared += 1

        # Forca a UI a reler o que ficou equipado de verdade -- sem isso
        # os dropdowns ficariam mostrando o estado de ANTES de carregar
        # o preset ate a proxima troca manual.
        if "hyblendcc_synced_for" in wm:
            del wm["hyblendcc_synced_for"]
        _sync_slots_from_armature(context, armature_obj)

        self.report({"INFO"}, f"Preset '{name}' loaded ({applied}/{len(slots)} categorie(s) applied, {cleared} cleared).")
        return {"FINISHED"}


class HYBLENDCC_OT_delete_preset(Operator):
    """Apaga o preset selecionado do disco -- nao mexe no personagem
    atual, so remove o arquivo salvo."""

    bl_idname = "hyblendcc.delete_preset"
    bl_label = "Delete Preset"
    bl_description = "Delete the selected preset from disk (does not change the current character)"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return bool(context.window_manager.hyblendcc_preset_selected)

    def execute(self, context):
        wm = context.window_manager
        name = wm.hyblendcc_preset_selected
        ok = delete_preset(name)
        if ok:
            _invalidate_preset_list_cache()
            self.report({"INFO"}, f"Preset '{name}' deleted.")
        else:
            self.report({"WARNING"}, f"Preset '{name}' not found (already deleted?).")
        return {"FINISHED"}
