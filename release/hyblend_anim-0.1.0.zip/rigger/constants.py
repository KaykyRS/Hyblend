"""Constantes de nomenclatura/convenção do rigger: collections, sufixos de camada, constraints, custom properties,
overrides pontuais e os widgets WGT_hytale_*. Só literais; os usados fora são reexportados por rigger/__init__.py.
"""

# --- Contrato interno do rigger (o compartilhado com o exporter fica em common.py) ---

COLL_HYTALE_EXPORT = "Hytale Export"
COLL_INTERNAL = "Internal"
COLL_ORG = "ORG"
COLL_MCH = "MCH"
# Collection interna dos bones de mecanismo (pontes `_MCH_Transfer`/`_MCH_IK_Transfer`, pais do Tweak).
# PROP_RIG_LAYER continua "MCH-IK" (IK) / "MCH-TRANSFER" (genérico), independente do nome exibido.
COLL_MCH_IK = "Specials"
COLL_CTRL = "CTRL"
COLL_CTRL_IK = "CTRL-IK"

# Filha de Internal: bones ORG de attachments (nome com ATTACHMENT_NAME_HINT); refeita a cada Create Rig.
COLL_ATTACHMENTS_IMPORTED = "Attachments Imported"

# Collections visíveis depois de gerar (Face, Main e sub-collections, Attachments); o resto (Internal) fica oculto.
COLL_FACE = "Face"
COLL_MAIN = "Main"
COLL_ATTACHMENTS = "Attachments"
COLL_MAIN_HEAD = "Head"
COLL_MAIN_SPINE = "Spine"
COLL_MAIN_BODY = "Body"
COLL_MAIN_ARM_L = "Arm L"
COLL_MAIN_ARM_R = "Arm R"
COLL_MAIN_LEG_L = "Leg L"
COLL_MAIN_LEG_R = "Leg R"
COLL_MAIN_ROOT = "Root"
COLL_MAIN_CHAIN = "Chain"  # cadeia genérica (era "Tail")
COLL_MAIN_TEXTURE_PICKER = "Texture Picker"

# Collections que o Create Rig já gerencia sozinho: ficam fora do Collection Template.
RESERVED_MAIN_COLLECTION_NAMES = {
    COLL_HYTALE_EXPORT, COLL_INTERNAL, COLL_ORG, COLL_MCH, COLL_MCH_IK, COLL_CTRL, COLL_CTRL_IK,
    COLL_ATTACHMENTS_IMPORTED, COLL_FACE, COLL_MAIN, COLL_ATTACHMENTS, COLL_MAIN_HEAD, COLL_MAIN_SPINE,
    COLL_MAIN_BODY, COLL_MAIN_ARM_L, COLL_MAIN_ARM_R, COLL_MAIN_LEG_L, COLL_MAIN_LEG_R, COLL_MAIN_ROOT,
    COLL_MAIN_CHAIN, COLL_MAIN_TEXTURE_PICKER,
}

# SUFFIX_MCH/SUFFIX_CTRL/SUFFIX_IK vêm de common.py (fonte única, o exporter usa também).
from ..common import SUFFIX_CTRL, SUFFIX_IK, SUFFIX_MCH  # noqa: F401 (SUFFIX_MCH: reexport pro rigger/__init__.py)

# Ponte por segmento do IK: filha real do Tweak (peças do solver) ou do `_IK`, com a rest do ORG.
# IMPORTANTE: reexportado por rigger/__init__.py (anim_tools usa); renomear nos dois.
SUFFIX_MCH_IK_TRANSFER = "_MCH_IK_Transfer"
SUFFIX_POLE = "_Pole_CTRL"
# Tweak: ajuste por peça (IK e FK), só nas peças do solver.
SUFFIX_TWEAK = "_Tweak"
SUFFIX_MCH_TWEAK_PARENT = "_MCH_Tweak_Parent"  # pai do Tweak: segue o `_IK` ou o `_CTRL` conforme o switch
SUFFIX_MCH_TWEAK_FK = "_MCH_Tweak_FK"  # filho do `_CTRL` no pivô do Tweak, pai do `_MCH_Transfer`: o Tweak no FK
TWEAK_COLLECTION_SUFFIX = " (Tweak)"
TWEAK_FALLBACK_COLLECTION = "Tweak"
TWEAK_SHAPE_SCALE = (0.8, 0.8, 0.8)
# Stretch no IK: True = o filho acompanha a escala do pai (igual ao FK); False = cada peça sozinha. Trocar + Create Rig.
IK_STRETCH_FOLLOWS_PARENT = False
# Tweak só ganha valor no snap/import se a diferença apareceria no jogo (tolerância do export).
TWEAK_MIN_PX = 0.02
TWEAK_MIN_DEG = 0.05

# Ponte genérica de todo `_CTRL`: filha real dele (ou do `_MCH_Tweak_FK`) com a rest do ORG, que o MCH copia no mundo.
# Existe porque a cópia em World Space ignora a rest do alvo: com a ponte, o `_CTRL` pode ter a rest que quiser
# (Continuous Chain, roll de Arm/Leg) sem a pose sair torta.
SUFFIX_MCH_TRANSFER = "_MCH_Transfer"

# Pole Line: só visual (hide_select), filho do ORG do meio, esticado até o pole (Stretch To).
SUFFIX_POLE_LINE = "_Pole_Line"


# Marca todo bone gerado (é isso, não o nome, que separa ORG de gerado; base da idempotência).
PROP_RIG_LAYER = "hytale_rig_layer"

# Custom property no bone _IK da ponta (mão/pé) de cada cadeia. Inteira,
# 0..1 -- 0 = FK, 1 = IK.
PROP_FK_IK_SWITCH = "fk_ik_switch"

# Head Free/Lock: switch único no PROPERTIES; 1 (padrão, Lock) = segue o tronco, 0 (Free) = rotação livre, posição presa no pescoço.
PROP_HEAD_FOLLOW_SWITCH = "head_follow_switch"

# No objeto widget: o template de origem (pro Shape Template saber se embute a malha editada); ausente = sempre embute.
PROP_WIDGET_SOURCE_ROLE = "hytale_widget_source_role"

# Apelido do Rename "Only CTRL" no ORG: os controles (_CTRL, _IK, _Pole_CTRL, _Pole_Line, _Tweak) usam este nome-base;
# ORG, _MCH e pontes ficam com o nome do ORG. Ver control_name().
PROP_CONTROL_NAME = "hytale_control_name"
# Em todo bone gerado: de qual ORG ele nasceu (sem a marca, source_org_of tira o sufixo).
PROP_SOURCE_ORG = "hytale_source_org"

# Nomes de constraint iguais aos dos scripts de referência (facilita
# comparar/depurar um rig gerado por este script com um feito à mão).
CONSTRAINT_FK_ROT = "FK_CopyRotation"
CONSTRAINT_FK_SCALE = "FK_CopyScale"
CONSTRAINT_FK_LOC = "FK_CopyLocation"
CONSTRAINT_IK_ROT = "IK_CopyRotation"
CONSTRAINT_IK_SCALE = "IK_CopyScale"
CONSTRAINT_IK_LOC = "IK_CopyLocation"
CONSTRAINT_TWEAK_FK = "Tweak_FK"  # no `_MCH_Tweak_FK`: o Tweak também vale no FK
CONSTRAINT_TWEAK_PARENT = "Tweak_Parent"  # Armature no pai do Tweak: alvos `_IK` (IK) e `_CTRL` (FK)
CONSTRAINT_IK = "IK"
CONSTRAINT_ORG_TO_MCH = "Hytale_ORG_to_MCH"  # trio Location/Rotation/Scale -- convenção própria deste addon
CONSTRAINT_SPINE_FOLLOW = "Hytale_SpineFollow"
CONSTRAINT_CHILD_OF_LOCAL = "Child Of_local"
CONSTRAINT_CHILD_OF_GLOBAL = "Child Of_global"
# Head Follow: três constraints no Head_CTRL, nesta ordem (_build_head_follow reordena):
#   _ROT  Child Of -> o bone de cima do Head, influência = switch (Lock)
#   _ROOT Child Of -> Origin, influência = 1 - switch (Free)
#   _LOC  Copy Location (mundo, head_tail 1.0) no Tail do bone de cima, influência = 1 - switch (Free)
CONSTRAINT_HEAD_FOLLOW_ROT = "Hytale_HeadFollow_Rot"
CONSTRAINT_HEAD_FOLLOW_ROOT = "Hytale_HeadFollow_Root"
CONSTRAINT_HEAD_FOLLOW_LOC = "Hytale_HeadFollow_Loc"
# v0.8: Stretch To do bone "_Pole_Line" (ver SUFFIX_POLE_LINE), mirando
# sempre no "_Pole_CTRL" do mesmo lado/cadeia -- ver ensure_stretch_to_constraint.
CONSTRAINT_POLE_LINE_STRETCH = "PoleLine_StretchTo"
# Chain (Tail) reaproveita os FK_Copy* do MCH, só trocando o alvo pra ponte (_build_tail_pose_constraints).

_COPY_CONSTRAINT_TYPES = {
    "LOCATION": "COPY_LOCATION",
    "ROTATION": "COPY_ROTATION",
    "SCALE": "COPY_SCALE",
}

# --- Overrides pontuais (bones fora das cadeias): reparent de `_CTRL` e organização de Main ---

# LEGADO: só vale sem Bone Settings correspondente (sem SPINE: Pelvis/Belly; sem LEG: Thigh).
# `_CTRL` -> pai forçado, aplicado a toda execução. Hoje os pais saem do Bone Settings (_resolve_ctrl_parent_overrides).
CTRL_PARENT_OVERRIDES = {
    "Pelvis_CTRL": "root.pelvis_CTRL",
    "Belly_CTRL": "root.master_CTRL",
    "L-Thigh" + SUFFIX_CTRL: "root.pelvis_CTRL",
    "R-Thigh" + SUFFIX_CTRL: "root.pelvis_CTRL",
    # Head_CTRL -> Origin_CTRL saiu daqui: depende do Head Free/Lock (_apply_head_follow_parent).
}

# Bones utilitários de controle geral (nome próprio, posicionados por bones de referência).
BONE_ROOT_MASTER = "root.master_CTRL"
BONE_ROOT_SPINE = "root.spine_CTRL"
BONE_ROOT_PELVIS = "root.pelvis_CTRL"
ROOT_MASTER_SOURCE = "Belly"        # bone ORG usado como referência de posição do master/spine
ORIGIN_ORG_NAME = "Origin"          # bone ORG esperado no modelo importado -- ver _ensure_origin_bone (v0.8)
ROOT_MASTER_PARENT = ORIGIN_ORG_NAME + SUFFIX_CTRL  # "Origin_CTRL" -- parent do master, gerado do ORG acima
ROOT_SPINE_LENGTH = 0.5             # comprimento (head->tail) do root.spine_CTRL
ORIGIN_FALLBACK_LENGTH = 0.3        # comprimento do ORG "Origin" quando precisa ser criado -- ver _ensure_origin_bone

# Texture Picker: o nome do root.ui e do cursor é montado por instância (_texture_picker_ui_root_name /
# _texture_picker_cursor_name) com o nome do bone alvo; aqui só ficam prefixo/sufixo.
BONE_UI_ROOT_PREFIX = "root.ui."
# Cursor do Texture Picker: a Location dele dirige o Mapping do material e vira shapeUvOffset no export.
BONE_TEXTURE_PICKER_CURSOR_PREFIX = "ui."
BONE_TEXTURE_PICKER_CURSOR_SUFFIX = ".picker"
# Deslocamento do root.ui no X local do texture_picker_ctrl, pra não nascer em cima do alvo.
TEXTURE_PICKER_UI_OFFSET_X = 0.5
# E no Y local (testado no Blender).
TEXTURE_PICKER_UI_OFFSET_Y = 0.2
# Sufixos do plane de referência e do material do Texture Picker (prefixados pelo nome do bone).
TEXTURE_PICKER_PLANE_SUFFIX = "_Atlas_Plane"
TEXTURE_PICKER_MATERIAL_SUFFIX = "_Atlas_Reference_MAT"
# Na cópia do material compartilhado: nome do material original (pra voltar no Remove Texture Picker).
PROP_TEXTURE_PICKER_MATERIAL_ORIGINAL = "hytale_texture_picker_original_material"
# Nodes injetados no material do alvo, achados pelo nome (idempotência).
TEXTURE_PICKER_MAPPING_NODE_NAME = "Hytale_Texture_Picker_Mapping"
TEXTURE_PICKER_UVMAP_NODE_NAME = "Hytale_Texture_Picker_UV_Map"
# Limit Location do cursor: trava dentro do grid (0..colunas-1, 0..linhas-1).
CONSTRAINT_TEXTURE_PICKER_LIMIT = "Hytale_Texture_Picker_Limit"

# Câmera de primeira pessoa (HEAD): sufixo do objeto, prefixado pelo nome do Armature (uma por personagem).
FIRST_PERSON_CAMERA_SUFFIX = "_FirstPerson_CAM"

# Bone que guarda as custom properties de switch (FK/IK de cada cadeia, Head Follow), acima da cabeça.
BONE_PROPERTIES = "PROPERTIES"
PROPERTIES_BONE_OFFSET_Y = 0.7  # metros acima do Head_CTRL (mesmo espaço/eixo Y do armature)

# Spine Follow: Spine 1..N seguem o root.spine_CTRL (Copy Transforms local) com 0.5, 0.63... (+0.13); Pelvis nunca.
SPINE_FOLLOW_TARGET = BONE_ROOT_SPINE
SPINE_FOLLOW_INFLUENCES = (0.5, 0.63, 0.76, 0.89)
# Legado -- só usado quando o Armature NÃO tem entrada SPINE no Bone
# Settings (nomes do Player).
SPINE_FOLLOW_BONES = {
    "Belly_CTRL": 0.5,
    "Chest_CTRL": 0.63,
}

# Head Follow: o bone de cima do Head é achado pelo pai real do ORG "Head" (Neck, ou Chest sem Neck);
# tudo (reparent + constraints) só com o toggle Head Free/Lock ligado.

# head_tail 1.0: mira o Tail do bone de cima (onde o Head começa).
HEAD_FOLLOW_LOC_HEAD_TAIL = 1.0


# Root Parent: nome de ORG -> bone gerado (ex.: "Pelvis" -> root.pelvis_CTRL), que ainda não existe ao configurar.
PARENT_OVERRIDE_ALIASES = {
    "Pelvis": BONE_ROOT_PELVIS,
    # Nome ORG literal ("L-Shoulder") resolve pro `_CTRL` dele, senão o braço sai da collection Arm.
    "L-Shoulder": "L-Shoulder" + SUFFIX_CTRL,
    "R-Shoulder": "R-Shoulder" + SUFFIX_CTRL,
}

# --- Custom shapes: biblioteca hytale_widgets.blend (append, reaproveitada; nunca gerada via bmesh) ---
# Papel sem shape próprio na biblioteca usa WGT_DEFAULT_FALLBACK. Os widgets são cópias por personagem na collection
# 'WGT - <nome>' (excluída da View Layer; volta só no Vertex Edit Mode).

WIDGETS_LIBRARY_SUBDIR = "assets"
WIDGETS_LIBRARY_FILENAME = "hytale_widgets.blend"

WGT_DEFAULT_FALLBACK = "WGT_hytale_default"  # usado quando o shape "preferido" abaixo não existe ainda
WIDGET_WIRE_WIDTH = 2.0  # custom_shape_wire_width -- espessura de linha, igual pra TODOS os bones com shape
ATTACHMENT_SHAPE_SCALE = 0.3  # scale genérico pra QUALQUER attachment sem override de "scale" específico

# Máximo de campos attachment_bone_N (gerados num loop; StringProperty não aceita lista ilimitada).
ATTACHMENTS_MAX_COUNT = 25

# Máximo de Companion Bones do Texture Picker (mesmo mecanismo).
TEXTURE_PICKER_EXTRA_BONES_MAX_COUNT = 8

# Slots de root da entrada ROOT (Root 1 = Origin; Root 2 é pai do Root 1...).
ROOT_MAX_COUNT = 4
# Root criado ("New Bone"): comprimento cresce por slot, pra os widgets ficarem concêntricos.
ROOT_CREATED_LENGTH_STEP = 0.5
# Widget do Root N = este fator × o do Root N-1.
ROOT_WIDGET_SIZE_STEP = 1.15

WGT_FK_RING = "WGT_hytale_fk_ring"          # bones _CTRL genéricos (FK)
WGT_IK_BOX = "WGT_hytale_ik_box"            # ponta de cadeia IK (mão/pé -- o _IK que tem o switch)
WGT_POLE = "WGT_hytale_pole"                # *_Pole_CTRL
WGT_POLE_LINE = "WGT_hytale_pole_line"      # *_Pole_Line (v0.8 -- bone visual, ver SUFFIX_POLE_LINE)
WGT_ROOT_MASTER = "WGT_hytale_root_master"  # root.master_CTRL
WGT_ROOT_SPINE = "WGT_hytale_root_spine"    # root.spine_CTRL
WGT_ROOT_PELVIS = "WGT_hytale_root_pelvis"  # root.pelvis_CTRL
WGT_HEAD = "WGT_hytale_head"                # Head_CTRL
WGT_ORIGIN = "WGT_hytale_origin"            # Origin_CTRL (gerado do ORG "Origin" pelo loop padrão -- ver override abaixo)
WGT_PROPERTIES = "WGT_hytale_properties"    # bone PROPERTIES (ver BONE_PROPERTIES) -- override abaixo
WGT_ATTACHMENT = "WGT_hytale_attachment"    # qualquer _CTRL de attachment (is_attachment_bone) -- antes caía no WGT_FK_RING genérico
WGT_TEXTURE_PICKER_CURSOR = "WGT_hytale_texture_picker_cursor"  # cursor do Texture Picker
WGT_UI_ROOT = "WGT_hytale_ui_root"  # root.ui do Texture Picker

# WIDGET_NAME_OVERRIDES fica abaixo (depende de HEAD_COLLECTION_ROOT).

# Rig Templates vêm de templates/rig/*.json (builtin + Documentos/Hyblend); personagem novo = só um .json.

# Dica de nome (sem maiúsculas, substring) dos bones de attachment, em qualquer camada.
ATTACHMENT_NAME_HINT = "attachment"

# Bones específicos das collections Main/* (ver _build_main_collections).
HEAD_COLLECTION_ROOT = "Head" + SUFFIX_CTRL

# Bone -> widget dedicado (fora da regra por camada). Origin_CTRL e PROPERTIES são `_CTRL` normais com shape próprio.
WIDGET_NAME_OVERRIDES = {
    BONE_ROOT_MASTER: WGT_ROOT_MASTER,
    BONE_ROOT_SPINE: WGT_ROOT_SPINE,
    BONE_ROOT_PELVIS: WGT_ROOT_PELVIS,
    HEAD_COLLECTION_ROOT: WGT_HEAD,
    ROOT_MASTER_PARENT: WGT_ORIGIN,
    BONE_PROPERTIES: WGT_PROPERTIES,
    # Os bones do Texture Picker recebem o widget direto em _build_texture_picker.
}

# Ajustes de translation/rotation_deg/scale do widget vêm do Shape Template ativo (hytale_active_shape_template).
# Em bones com driver FK/IK, "scale" é o tamanho cheio (o driver multiplica por 0 ou 1).
SPINE_COLLECTION_BONES = ["Pelvis" + SUFFIX_CTRL, "Belly" + SUFFIX_CTRL, "Chest" + SUFFIX_CTRL]

# --- Bone Color: cada palette = (normal, select, active) em RGB 0..1 (bone.color.custom) ---
BONE_COLOR_LEFT = ((0.9412, 0.0, 0.0), (1.0, 0.3216, 0.3216), (1.0, 0.3961, 0.3961))
BONE_COLOR_RIGHT = ((0.0, 0.349, 1.0), (0.298, 0.5412, 1.0), (0.4471, 0.6784, 1.0))
BONE_COLOR_ROOT_HEAD = ((1.0, 0.8706, 0.0), (1.0, 0.8824, 0.2157), (1.0, 0.8863, 0.4353))
BONE_COLOR_SPINE = ((0.0, 0.7961, 0.0), (0.0, 0.8471, 0.0), (0.5765, 1.0, 0.498))
BONE_COLOR_ATTACHMENT = ((0.8471, 0.8471, 0.8471), (0.898, 0.898, 0.898), (1.0, 1.0, 1.0))
BONE_COLOR_PROPERTIES = ((0.1451, 0.5137, 1.0), (0.1608, 0.4667, 1.0), (0.3373, 0.502, 1.0))  # #2583FF / #2977FF / #5680FF
# root.ui amarelo e cursor vermelho (o cursor se destaca do quadro).
BONE_COLOR_UI_ROOT = ((1.0, 0.8706, 0.0), (1.0, 0.8824, 0.2157), (1.0, 0.8824, 0.2157))  # #FFDE00 / #FFE137 / #FFE137
BONE_COLOR_UI_CURSOR = ((0.8392, 0.0, 0.0), (1.0, 0.2784, 0.2784), (1.0, 0.0, 0.0))  # #D60000 / #FF4747 / #FF0000

# Cor em 3 níveis (_build_bone_colors): 1) bones fixos do rigger; 2) o que está marcado no Bone Settings;
# 3) fallback por nome/attachment/token de lado.
BONE_COLOR_FIXED = {
    BONE_ROOT_MASTER: BONE_COLOR_ROOT_HEAD,
    BONE_ROOT_SPINE: BONE_COLOR_ROOT_HEAD,
    BONE_ROOT_PELVIS: BONE_COLOR_ROOT_HEAD,
    ROOT_MASTER_PARENT: BONE_COLOR_ROOT_HEAD,  # Origin_CTRL
    BONE_PROPERTIES: BONE_COLOR_PROPERTIES,
}
# Nomes do padrão Player: só fallback (nível 3).
BONE_COLOR_NAME_FALLBACK = {
    HEAD_COLLECTION_ROOT: BONE_COLOR_ROOT_HEAD,
    **{name: BONE_COLOR_SPINE for name in SPINE_COLLECTION_BONES},
    "Neck" + SUFFIX_CTRL: BONE_COLOR_SPINE,
}
BODY_COLLECTION_BONES = [BONE_ROOT_SPINE, BONE_ROOT_MASTER, BONE_ROOT_PELVIS]
ROOT_COLLECTION_BONES = [ROOT_MASTER_PARENT]
ARM_COLLECTION_ROOTS = {
    COLL_MAIN_ARM_L: ["L-Shoulder" + SUFFIX_CTRL],
    COLL_MAIN_ARM_R: ["R-Shoulder" + SUFFIX_CTRL],
}
# Personagem sem ombro: CTRL e IK entram como raízes próprias do walk (o `_IK` raiz fica sem pai).
ARM_COLLECTION_ROOTS_NO_SHOULDER = {
    COLL_MAIN_ARM_L: ["L-Arm" + SUFFIX_CTRL, "L-Arm" + SUFFIX_IK],
    COLL_MAIN_ARM_R: ["R-Arm" + SUFFIX_CTRL, "R-Arm" + SUFFIX_IK],
}
# Pernas: FK e IK não têm ancestral comum na perna (os dois saem do root.pelvis_CTRL).
LEG_COLLECTION_ROOTS = {
    COLL_MAIN_LEG_L: ["L-Thigh" + SUFFIX_CTRL, "L-Thigh" + SUFFIX_IK],
    COLL_MAIN_LEG_R: ["R-Thigh" + SUFFIX_CTRL, "R-Thigh" + SUFFIX_IK],
}


# --- Sentinel de UI ---

# "(none)": primeira opção dos dropdowns de template pra desmarcar; nunca é um template de verdade.
_TEMPLATE_NONE = "NONE"

# Continuous Chain: só os `_CTRL` destes tipos (menos o Head) apontam o Tail pro próximo bone.
CTRL_TAIL_TO_CHILD_TYPES = ("HEAD", "SPINE", "ARM", "LEG")
# Marca nos `_CTRL` que saíram da rest do ORG (no bone, sobrevive ao Rename); a próxima geração devolve quem saiu.
PROP_CTRL_TAIL_TO_CHILD = "hytale_ctrl_tail_to_child"
# Arm/Leg: `_CTRL` e `_IK` com o X local no Z do ORG (lado R no -Z, rest espelhada), com ou sem Continuous Chain.
LIMB_X_FROM_Z_TYPES = ("ARM", "LEG")
# Modo de rotação dos controles destas camadas a cada Create Rig; ORG/MCH ficam em Quaternion.
CONTROL_ROTATION_MODE = "XYZ"
ROTATION_EULER_LAYERS = ("CTRL", "CTRL-IK", "CTRL-TWEAK", "ROOT-CTRL")
# Trava de dobradiça: alinhamento mínimo (|cos|, ~8°) com um eixo local do `_IK`, senão fica livre.
IK_HINGE_MIN_ALIGNMENT = 0.99
