"""Registro do Prefabs com o Hyblend Toolkit (núcleo) pronto -- chamado por __init__._activate.
Ordem importa: interface/ importa classes de todos os outros modulos, e precisa ser registrada por ultimo (e
desregistrada primeiro). register() que falha no meio desfaz os que entraram (inclusive o que falhou)."""

import traceback

from . import builder, common, interface, preferences, translations  # noqa: F401
from .builder import debug_export, prefab_importer, prefab_ops

_MODULES = (translations, preferences, prefab_importer, prefab_ops, debug_export, interface)   # translations primeiro
_registered = []


def register():
    for module in _MODULES:
        _registered.append(module)     # antes: se falhar no meio, o unregister dele desfaz o que já registrou
        module.register()


def unregister():
    while _registered:
        module = _registered.pop()
        try:
            module.unregister()
        except Exception:         # segue desregistrando o resto (senão sobra classe registrada)
            traceback.print_exc()
