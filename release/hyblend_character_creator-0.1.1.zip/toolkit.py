"""Acesso ao núcleo (Hyblend Toolkit) pelo resto do CC. Só é importado com o núcleo ativo (ver __init__.py);
tudo do núcleo passa por aqui (api.py dele), nunca pelos módulos internos dele."""

from . import hyblend_link

_core = hyblend_link.core()
if _core is None:
    raise ImportError("Hyblend Toolkit (núcleo) não está ativo")

api = _core.api
hub = api.hub                          # hyblend_hub do núcleo (seletor, documents_dir, restore_cached_images...)
hytale_install = api.hytale_install    # mapa da instalação do Hytale (Python puro)
ZipAssetsSource = api.ZipAssetsSource  # leitura do Assets.zip
game_found = api.game_found
hytale_dir = api.hytale_dir            # pasta do Hytale das Preferences do núcleo (cacheada)
documents_dir = api.documents_dir
core_preferences = api.preferences     # Preferences do núcleo (pasta, use_gpu_ui, gpu_ui_scale...)
LOCATE_GAME_OP = api.LOCATE_GAME_OP    # "Localizar jogo" do núcleo (passar reopen=False)
