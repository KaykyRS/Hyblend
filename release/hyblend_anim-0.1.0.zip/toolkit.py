"""Acesso ao núcleo (Hyblend Toolkit) pelo resto do Anim. Só é importado com o núcleo ativo (ver __init__.py);
tudo do núcleo passa por aqui (api.py dele), nunca pelos módulos internos dele."""

from . import hyblend_link

_core = hyblend_link.core()
if _core is None:
    raise ImportError("Hyblend Toolkit (núcleo) não está ativo")

api = _core.api
hub = api.hub                  # hyblend_hub do núcleo
HUB_ID = api.HUB_ID            # botão do núcleo no seletor (o Anim aparece nele)
game_found = api.game_found
documents_dir = api.documents_dir
