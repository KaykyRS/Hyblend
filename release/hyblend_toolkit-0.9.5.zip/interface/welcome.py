"""interface/welcome.py -- janela de boas-vindas (0.9.4).

Aparece sozinha ao habilitar/instalar o addon e, ao abrir o Blender,
uma vez a cada versão nova do addon. "Não mostrar novamente" desliga as
aberturas automáticas pra sempre (inclusive em versões novas); o botão
"Welcome" da aba Info abre a janela a qualquer hora.

Duas versões, MESMO conteúdo:
  * GPU (interface/gpu_ui/pages/welcome_page.py): Blender >= 5.0 E pasta
    do Hytale localizada (a arte e as fontes vêm da pasta do jogo);
  * nativa (este arquivo, popover do Blender): Blender 4.5, ou jogo não
    localizado. Fecha ao clicar em qualquer botão. "Localizar jogo" nela,
    dando certo, troca pela versão GPU.

Ordem na abertura automática: primeiro a detecção da pasta do jogo
(game.autodetect_on_startup), depois a decisão GPU x nativa, depois a
janela. Abre na hora -- só no STARTUP com o splash do Blender na tela
(_blender_splash_likely) espera o clique/tecla que fecha o splash
(HYBLEND_OT_welcome_wait), pra não ficar sobreposta a ele.

Estado persistente (arquivo welcome.json na pasta de dados do addon, não
nas Preferences -- vale mesmo sem salvar as Preferences, e entre versões):
  dont_show        "Não mostrar novamente"
  always           "Mostrar ao abrir: Sempre"
  last_version     última versão em que a janela abriu sozinha
  home_startup     Home: "Mostrar ao abrir" (interface/home)
  splash_original  splash do Blender ANTES da Home desligá-lo (restaurado ao desabilitar)

Startup x habilitar: register() olha QUEM o chamou (_registered_by_session_load:
carga dos addons na abertura/Reload Scripts x usuário instalando/habilitando).
Startup: só abre com versão nova. Habilitar/instalar: abre.

Home (0.9.5, interface/home/): na ABERTURA do Blender, com a Home
disponível (5.0+, jogo achado) e "Mostrar ao abrir" ligado, quem abre é a
Home e o Welcome NUNCA abre sozinho. Instalar/habilitar/atualizar abre o
Welcome (nunca a Home). Sem a Home, tudo como antes -- só que no 5.0+ o
splash do Blender (desligado pela Home) é aberto na mão antes.

A detecção da pasta do jogo usa gpu_ui/game.py (+ hytale_install.py),
que só lê as Preferences -- funciona mesmo no 4.5 (nada de GPU ali).
"""

import json
import os
import textwrap
import time

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty
from bpy.types import WindowManager

from .. import hyblend_hub
from ..common import ADDON_PACKAGE, HUB_ID
from ..translations import get_language, tooltip, tr

# Textos do banner (desenhados por cima da arte; troque aqui).
BANNER_TITLE = "HYBLEND"
BANNER_SUBTITLE = "BLENDER + HYTALE"
BANNER_FILE = "welcome_banner.jpg"            # assets/

_STATE_FILE = "welcome.json"
_ADDON_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# --------------------------------------------------------------------------
# Versão, links, banner
# --------------------------------------------------------------------------

_version = None


def addon_version():
    """Versão do blender_manifest.toml (a única que conta, ver notas)."""
    global _version
    if _version is None:
        _version = ""
        try:
            with open(os.path.join(_ADDON_ROOT, "blender_manifest.toml"), encoding="utf-8") as handle:
                for line in handle:
                    key, _, value = line.partition("=")
                    if key.strip() == "version":
                        _version = value.strip().strip('"')
                        break
        except OSError:
            pass
    return _version


def changelog_url():
    from . import HYBLEND_CHANGELOG_URL
    return HYBLEND_CHANGELOG_URL


def support_url():
    from . import HYBLEND_SUPPORT_URL
    return HYBLEND_SUPPORT_URL


def banner_path():
    path = os.path.join(_ADDON_ROOT, "assets", BANNER_FILE)
    return path if os.path.isfile(path) else ""


# --------------------------------------------------------------------------
# Estado persistente
# --------------------------------------------------------------------------

_state = {"loaded": False, "dont_show": False, "always": False, "last_version": "",
          "home_startup": True, "splash_original": None}
_SAVED_KEYS = ("dont_show", "always", "last_version", "home_startup", "splash_original")


def _state_dir():
    try:        # extensão: pasta de dados do usuário (sobrevive a updates)
        return bpy.utils.extension_path_user(ADDON_PACKAGE, create=True)
    except Exception:   # addon "legado" (fora do sistema de extensões)
        return bpy.utils.user_resource("CONFIG", path="hyblend_toolkit", create=True)


def _state_path():
    return os.path.join(_state_dir(), _STATE_FILE)


def _load_state():
    if _state["loaded"]:
        return _state
    _state["loaded"] = True
    try:
        with open(_state_path(), encoding="utf-8") as handle:
            data = json.load(handle)
        _state["dont_show"] = bool(data.get("dont_show", False))
        _state["always"] = bool(data.get("always", False))
        _state["last_version"] = str(data.get("last_version", ""))
        _state["home_startup"] = bool(data.get("home_startup", True))
        splash = data.get("splash_original")
        _state["splash_original"] = None if splash is None else bool(splash)
    except (OSError, ValueError, TypeError):
        pass
    return _state


def _save_state():
    try:
        with open(_state_path(), "w", encoding="utf-8") as handle:
            json.dump({key: _state[key] for key in _SAVED_KEYS}, handle)
    except OSError as error:
        print("[Hyblend] could not save welcome state:", error)


def state_value(key):
    """Campo do welcome.json (a Home guarda o dela aqui: home_startup, splash_original)."""
    return _load_state()[key]


def set_state_value(key, value):
    _load_state()
    _state[key] = value
    _save_state()


def dont_show():
    return _load_state()["dont_show"]


def set_dont_show(value):
    _load_state()
    _state["dont_show"] = bool(value)
    _save_state()


# "Mostrar ao abrir" das Preferences = o MESMO estado do arquivo (NEVER é o
# "Não mostrar novamente" da janela): um só dono, vale sem salvar Preferences.
STARTUP_MODES = ("ALWAYS", "NEW_VERSION", "NEVER")      # ordem = índice do enum


def startup_mode():
    state = _load_state()
    if state["dont_show"]:
        return "NEVER"
    return "ALWAYS" if state["always"] else "NEW_VERSION"


def set_startup_mode(mode):
    _load_state()
    _state["dont_show"] = mode == "NEVER"
    if mode != "NEVER":
        _state["always"] = mode == "ALWAYS"
    _save_state()


def _wm_dont_show_get(self):
    return dont_show()


def _wm_dont_show_set(self, value):
    set_dont_show(value)


# --------------------------------------------------------------------------
# Jogo e versão GPU x nativa
# --------------------------------------------------------------------------

def game_dir():
    """Pasta do Hytale (Path) configurada/detectada, ou None."""
    try:
        from .gpu_ui import game
        return game.hytale_dir()
    except Exception:
        return None


def _autodetect_game():
    try:
        from .gpu_ui import game
        return game.autodetect()
    except Exception:
        return None


def gpu_available():
    """Framework da UI por GPU registrado (Blender >= gpu_ui.MIN_BLENDER)."""
    try:
        from . import gpu_ui
        return gpu_ui.is_registered()
    except Exception:
        return False


def use_gpu():
    return gpu_available() and game_dir() is not None


def _largest_view3d(window):
    areas = [a for a in window.screen.areas if a.type == "VIEW_3D"]
    return max(areas, key=lambda a: a.width * a.height) if areas else None


def _pick_window(for_gpu, preferred_ptr=None):
    wm = bpy.context.window_manager
    windows = list(wm.windows) if wm else []
    if not windows:
        return None
    if not for_gpu and preferred_ptr:
        for window in windows:
            if window.as_pointer() == preferred_ptr:
                return window
    with_view = [w for w in windows if _largest_view3d(w) is not None]
    if for_gpu and with_view:
        return max(with_view, key=lambda w: _largest_view3d(w).width * _largest_view3d(w).height)
    return windows[0]


def show(window=None):
    """Abre a janela AGORA (versão GPU se der, senão a nativa)."""
    if use_gpu():
        target = window if (window is not None and _largest_view3d(window) is not None) else _pick_window(True)
        if target is not None:
            from . import gpu_ui
            if gpu_ui.open_welcome(target, _largest_view3d(target)):
                return True
    target = window or _pick_window(False)
    if target is None:
        return False
    return _open_native(target)


def _open_native(window):
    area = max(window.screen.areas, key=lambda a: a.width * a.height, default=None)
    region = next((r for r in area.regions if r.type == "WINDOW"), None) if area else None
    override = {"window": window, "screen": window.screen}
    if area is not None and region is not None:
        override.update(area=area, region=region)
    try:
        with bpy.context.temp_override(**override):
            bpy.ops.hyblend.welcome_native("INVOKE_DEFAULT")
        return True
    except Exception as error:
        print("[Hyblend] could not open the welcome window:", error)
        return False


_pending = []               # timers de _show_later ainda não disparados (unregister limpa)


def _show_later(window_ptr=None, delay=0.05):
    """Abre no próximo tick (depois do popup/file browser atual fechar)."""
    def run():
        if run in _pending:
            _pending.remove(run)
        wm = bpy.context.window_manager
        window = next((w for w in (wm.windows if wm else ()) if w.as_pointer() == window_ptr), None)
        show(window)
        return None
    _pending.append(run)
    bpy.app.timers.register(run, first_interval=delay)


# --------------------------------------------------------------------------
# Operadores
# --------------------------------------------------------------------------

class HYBLEND_OT_welcome(bpy.types.Operator):
    """Botão "Welcome" da aba Info: abre a janela (mesmo com "Não mostrar
    novamente" marcado)."""
    bl_idname = "hyblend.welcome"
    bl_label = "Welcome"
    description = tooltip("welcome.tooltip.open")

    def execute(self, context):
        window = context.window
        if use_gpu() and (window is None or _largest_view3d(window) is None):
            # Chamado de uma janela SEM 3D Viewport (botão das Preferences):
            # a versão GPU abre na janela principal, criada FORA deste
            # operador (timer) -- o mesmo caminho da abertura automática.
            # Direto daqui ela não abria e caía na nativa (achado pelo autor).
            _show_later(None, delay=0.0)
        else:
            show(window)
        return {"FINISHED"}


WRAP_CHARS = 60             # UILayout não quebra linha: ~caracteres por linha


def _draw_native(panel, context):
    """Conteúdo da versão nativa (HYBLEND_PT_welcome_native)."""
    lang = get_language(context)
    layout = panel.layout
    layout.operator_context = "INVOKE_DEFAULT"     # "Localizar jogo": detecção + seletor de pasta
    head = layout.row()
    head.label(text="Hyblend Toolkit", icon="ARMATURE_DATA")
    version = head.row()
    version.alignment = "RIGHT"
    version.label(text="v%s" % addon_version())

    box = layout.box()
    col = box.column(align=True)
    for paragraph in tr("welcome.description", lang).split("\n"):
        if not paragraph.strip():
            col.separator()
            continue
        for line in textwrap.wrap(paragraph, WRAP_CHARS):
            col.label(text=line)
    col.separator()
    col.label(text=tr("welcome.experimental", lang), icon="EXPERIMENTAL")

    if game_dir() is None:
        # 0.9.5: sem o jogo o addon fica travado (common.game_found) -- aqui é
        # o único lugar (com as Preferences) que mostra isso e como resolver.
        warn = layout.column(align=True)
        warn.alert = True
        for i, line in enumerate(textwrap.wrap(tr("welcome.game_required", lang), WRAP_CHARS)):
            warn.label(text=line, icon="ERROR" if i == 0 else "BLANK1")

    buttons = layout.column(align=False)
    buttons.scale_y = 1.4
    if game_dir() is not None:
        buttons.operator(HYBLEND_OT_welcome_open_game_folder.bl_idname, text=tr("welcome.game_found", lang),
                         icon="CHECKMARK")
    else:
        buttons.operator(HYBLEND_OT_welcome_locate_game.bl_idname, text=tr("welcome.locate_game", lang),
                         icon="VIEWZOOM")
    buttons.operator(HYBLEND_OT_welcome_changelog.bl_idname, text=tr("welcome.changelog", lang), icon="TEXT")
    op = buttons.operator("wm.url_open", text=tr("welcome.support", lang), icon="FUND")
    op.url = support_url()

    layout.separator()
    # Só a caixinha clica (o texto ao lado é um label), igual à versão GPU.
    row = layout.row(align=True)
    row.prop(context.window_manager, "hytale_welcome_dont_show", text="")
    row.label(text=tr("welcome.dont_show", lang))


class HYBLEND_PT_welcome_native(bpy.types.Panel):
    """Versão nativa da janela, aberta como POPOVER (wm.call_panel com
    keep_open=False): visual de painel (caixa, botões de verdade, largura
    fixa) e fecha sozinho depois de um clique. Nunca aparece sozinho em
    lugar nenhum (região HEADER só desenha painel via popover).
    Histórico: invoke_popup ficava aberto depois de "Localizar jogo"
    (UI_BLOCK_KEEP_OPEN) e ficava atrás da versão GPU até dois cliques
    fora; popup_menu fechava, mas com cara de menu. Marcar "Não mostrar
    novamente" aqui também fecha a janela (a marcação vale)."""
    bl_idname = "HYBLEND_PT_welcome_native"
    bl_label = "Hyblend Toolkit"
    bl_space_type = "VIEW_3D"
    bl_region_type = "HEADER"
    bl_ui_units_x = 19          # ~380 px na escala 1x (WRAP_CHARS acompanha)

    def draw(self, context):
        _draw_native(self, context)


class HYBLEND_OT_welcome_native(bpy.types.Operator):
    """Abre a versão nativa (popover que fecha depois de um clique)."""
    bl_idname = "hyblend.welcome_native"
    bl_label = "Hyblend Toolkit"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        bpy.ops.wm.call_panel(name=HYBLEND_PT_welcome_native.bl_idname, keep_open=False)
        return {"FINISHED"}

    def execute(self, context):
        return self.invoke(context, None)


def size_factor(context=None):
    """Tamanho da versão GPU (Preferences, em %) -> fator."""
    try:
        prefs = (context or bpy.context).preferences.addons[ADDON_PACKAGE].preferences
        return max(0.25, prefs.welcome_size / 100.0)
    except (KeyError, AttributeError):
        return 1.0


def on_size_changed(context):
    """update= do "Tamanho": janela aberta acompanha na hora."""
    if gpu_available():
        from .gpu_ui.framework import overlay
        overlay.refresh_all()


def draw_preferences(prefs, layout, context, lang):
    """Conteúdo da aba "Janela de boas-vindas" (dentro de Experimental) --
    a aba colapsável é montada por importer/preferences.py."""
    col = layout.column()
    col.prop(prefs, "welcome_startup", text=tr("importer.prefs_welcome_startup", lang))
    size = col.row()
    size.active = gpu_available()          # a versão nativa segue a escala do Blender
    size.prop(prefs, "welcome_size", text=tr("importer.prefs_welcome_size", lang))
    col.operator(HYBLEND_OT_welcome.bl_idname, text=tr("importer.prefs_welcome_open", lang), icon="WINDOW")


def _redraw_all():
    """Jogo achado/perdido: o addon aparece/some (N-Panel, menus -- polls de
    common.game_found), então redesenha todas as áreas de todas as janelas."""
    wm = bpy.context.window_manager
    for window in (wm.windows if wm else ()):
        for area in window.screen.areas:
            area.tag_redraw()


class HYBLEND_OT_welcome_locate_game(bpy.types.Operator):
    """Localizar jogo: tenta o local padrão; sem achar, abre o seletor de
    pasta. Achou -> reabre a janela (versão GPU quando der). Usado também
    pelas Preferences (reopen=False: só localiza) -- funciona em qualquer
    versão e mesmo com o addon travado sem o jogo (common.game_found)."""
    bl_idname = "hyblend.welcome_locate_game"
    bl_label = "Locate Game"
    bl_options = {"INTERNAL"}
    description = tooltip("welcome.tooltip.locate_game")

    directory: StringProperty(subtype="DIR_PATH", options={"SKIP_SAVE"})
    reopen: BoolProperty(default=True, options={"SKIP_SAVE", "HIDDEN"})   # reabrir o Welcome no fim

    def invoke(self, context, event):
        self._window_ptr = context.window.as_pointer() if context.window else None
        found = _autodetect_game()
        if found is not None:
            self.report({"INFO"}, str(found))
            _redraw_all()
            if self.reopen:
                _show_later(self._window_ptr)
            return {"FINISHED"}
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        window_ptr = getattr(self, "_window_ptr", None) or (context.window.as_pointer() if context.window else None)
        from .gpu_ui import hytale_install
        found = hytale_install.find_hytale_dir(bpy.path.abspath(self.directory)) if self.directory else None
        if found is None:
            self.report({"WARNING"}, tr("welcome.locate_invalid", get_language(context)))
            if self.reopen:
                _show_later(window_ptr, delay=0.3)
            return {"CANCELLED"}
        # Campos daqui + os outros addons Hyblend, compartilhando UMA vez.
        hyblend_hub.set_hytale(HUB_ID, ADDON_PACKAGE, "MANUAL", str(found))
        self.report({"INFO"}, str(found))
        _redraw_all()
        if self.reopen:
            _show_later(window_ptr)
        return {"FINISHED"}


class HYBLEND_OT_welcome_changelog(bpy.types.Operator):
    """Botão "Changelog" do Welcome: abre a Home já na aba Changelog (as
    releases do GitHub dentro do Blender). Sem a Home (Blender < 5.0 ou
    jogo não achado): a página de releases no navegador, como antes."""
    bl_idname = "hyblend.welcome_changelog"
    bl_label = "Changelog"
    bl_options = {"INTERNAL"}

    @classmethod
    def description(cls, context, properties):
        lang = get_language(context)
        if _home_available():
            return tr("welcome.tooltip.changelog_home", lang)
        return "%s\n%s" % (tr("welcome.tooltip.changelog_web", lang), changelog_url())

    @classmethod
    def poll(cls, context):
        return _home_available() or bool(changelog_url())

    def execute(self, context):
        if not _home_available():
            bpy.ops.wm.url_open(url=changelog_url())
            return {"FINISHED"}
        from . import home
        # O Welcome sai NA HORA (a Home troca o layout pra tela cheia) e a
        # Home abre num timer, fora deste operador, já no Changelog.
        if gpu_available():
            from .gpu_ui.framework import overlay
            overlay.close("welcome")
        window = context.window
        home.show_later(window.as_pointer() if window else None, delay=0.05, page="CHANGELOG")
        return {"FINISHED"}


def _home_available():
    try:
        from . import home
        return home.available()
    except Exception:
        return False


class HYBLEND_OT_welcome_open_game_folder(bpy.types.Operator):
    """Jogo localizado: abre a pasta no explorador de arquivos."""
    bl_idname = "hyblend.welcome_open_game_folder"
    bl_label = "Open Game Folder"
    bl_options = {"INTERNAL"}

    @classmethod
    def description(cls, context, properties):
        found = game_dir()
        text = tr("welcome.tooltip.game_found", get_language(context))
        return "%s\n%s" % (text, found) if found else text

    def execute(self, context):
        found = game_dir()
        if found is None:
            return {"CANCELLED"}
        bpy.ops.wm.path_open(filepath=str(found))
        return {"FINISHED"}


# Eventos que NÃO fecham o splash do Blender (não servem de sinal).
_NOT_DISMISS = {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE", "WHEELUPMOUSE", "WHEELDOWNMOUSE", "WHEELINMOUSE",
                "WHEELOUTMOUSE", "LEFT_CTRL", "RIGHT_CTRL", "LEFT_ALT", "RIGHT_ALT", "LEFT_SHIFT",
                "RIGHT_SHIFT", "OSKEY", "NONE"}


class HYBLEND_OT_welcome_wait(bpy.types.Operator):
    """Abertura do Blender com o splash dele na tela: espera o gesto que
    FECHA o splash (clique ou tecla -- Esc, clicar fora, escolher algo) e
    abre a nossa janela no tique seguinte, já sem o splash.

    Por que não "o primeiro evento": operadores modais ficam NA FRENTE dos
    popups na fila de eventos do Blender (wm_event_system.cc), então o
    movimento do mouse chegava aqui com o splash aberto e as duas janelas
    ficavam sobrepostas (achado pelo autor). O clique/tecla é repassado
    (PASS_THROUGH): o splash recebe e fecha normalmente. Se o gesto abre
    um arquivo pelo splash, a espera morre no load -- _on_load_post abre
    depois do arquivo carregar."""
    bl_idname = "hyblend.welcome_wait"
    bl_label = "Hyblend Welcome (waiting)"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        self._window_ptr = context.window.as_pointer()
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if not _auto["pending"]:
            # Já resolvida por outro caminho (ex.: _on_load_post abriu depois
            # de um arquivo escolhido no splash): sai sem abrir de novo.
            return {"FINISHED", "PASS_THROUGH"}
        if (event.value not in {"PRESS", "DOUBLE_CLICK"} or event.type in _NOT_DISMISS
                or event.type.startswith(("TIMER", "WINDOW", "TRACKPAD", "NDOF", "EVT_"))):
            return {"PASS_THROUGH"}
        _auto["shown_at"] = time.monotonic()
        _show_later(self._window_ptr, delay=0.0)
        return {"FINISHED", "PASS_THROUGH"}


# --------------------------------------------------------------------------
# Abertura automática
# --------------------------------------------------------------------------

_boot = {"window_ptr": None, "startup": False, "tries": 0}
# Abertura automática em andamento (esperando o splash / aberta há pouco):
# se um .blend carregar nesse meio tempo (escolhido no splash), a espera e
# a janela morrem no load -- _on_load_post abre de novo depois.
_auto = {"pending": False, "shown_at": 0.0}
AUTO_RELOAD_WINDOW = 2.0     # s depois de abrir: um load aqui (arquivo escolhido no splash) ainda reabre
BOOT_DELAY = 0.1            # só pra sair do register(); a detecção do jogo roda dentro do _boot_tick


def should_auto_show(dont_show_flag, last_version, version, startup, always=False):
    """Regra da abertura automática: "Não mostrar novamente" (Nunca) vence
    tudo; ao habilitar/instalar abre sempre; no startup, só com versão nova
    -- ou sempre, com "Mostrar ao abrir: Sempre" nas Preferences."""
    if dont_show_flag:
        return False
    return not startup or always or last_version != version


# Quem chama o register(): nomes/arquivos do Blender (conferidos no 4.5 e no 5.2).
_SESSION_LOAD_FUNCS = {"_initialize_once", "reset_all", "load_scripts", "load_scripts_extensions"}
_SESSION_LOAD_FILES = ("/addon_utils.py", "/bpy/utils/__init__.py")
# Usuário habilitando/instalando: operador das Preferences e o instalador de extensões.
_USER_ENABLE_FILES = ("/bl_operators/userpref.py",)
_USER_ENABLE_DIRS = ("/bl_pkg/",)


def _registered_by_session_load():
    """True se o register() está sendo chamado pela CARGA dos addons do
    Blender (abertura: addon_utils._initialize_once, via
    bpy.utils.load_scripts; Reload Scripts: addon_utils.reset_all), False
    se foi o usuário (Preferences: bl_operators/userpref.py; instalar /
    habilitar extensão: bl_pkg). Olha a PILHA de chamadas.

    NA DÚVIDA (nenhum dos dois reconhecido, ex.: uma versão futura do
    Blender renomeou essas funções): True = abertura -- o lado seguro, a
    janela só abre sozinha em versão nova. O contrário faria ela abrir em
    TODA abertura do Blender.

    Histórico: "sem janela no contexto" ou load_post = startup falhava ao
    instalar (a janela só aparecia depois de mexer o mouse, achado pelo
    autor)."""
    import inspect
    try:
        paths = [(f.function, f.filename.replace("\\", "/")) for f in inspect.stack(0)]
    except Exception:
        return True
    if any(func in _SESSION_LOAD_FUNCS and path.endswith(_SESSION_LOAD_FILES) for func, path in paths):
        return True
    if any(path.endswith(_USER_ENABLE_FILES) or any(d in path for d in _USER_ENABLE_DIRS) for _, path in paths):
        return False
    return True


@persistent
def _on_load_post(*_):
    if not _auto["pending"]:
        return
    if _auto["shown_at"] and time.monotonic() - _auto["shown_at"] > AUTO_RELOAD_WINDOW:
        _auto["pending"] = False
        return
    _auto["pending"] = False
    _show_later(None, delay=0.3)        # arquivo novo carregado: sem splash


def _blender_splash_likely(context):
    """O splash do Blender pode estar na tela? (o usuário quer o splash e o
    Blender não abriu direto um .blend -- nesse caso não há splash).

    No 5.0+ a Home DESLIGA view.show_splash e abre o splash na mão quando
    ela não abre (home.show_native_splash, chamado antes desta consulta):
    por isso a pergunta é pro home.splash_wanted() (o valor ORIGINAL do
    usuário), não pra view.show_splash."""
    try:
        from . import home
        return bool(home.splash_wanted()) and not bpy.data.filepath
    except Exception:
        return True


def _boot_tick():
    if bpy.app.background:
        return None
    wm = bpy.context.window_manager
    if wm is None or not wm.windows:
        _boot["tries"] += 1
        return 0.5 if _boot["tries"] < 40 else None
    # 1) pasta do jogo primeiro
    try:
        from .gpu_ui import game
        game.autodetect_on_startup()
    except Exception:
        pass
    state = _load_state()
    version = addon_version()
    startup = _boot["startup"]
    from . import home
    # 2) abertura do Blender com a Home ligada (5.0+, jogo achado, "Mostrar
    #    ao abrir"): a Home é a tela inicial e o Welcome NÃO abre sozinho
    #    (pedido do autor). A versão conta como vista.
    if startup and home.wants_startup():
        if state["last_version"] != version:
            state["last_version"] = version
            _save_state()
        opened = not bpy.data.filepath and home.show(_boot["window_ptr"])
        home.cover_decided()
        if not opened and not bpy.data.filepath:
            home.show_native_splash()           # Home falhou: o splash do Blender, como sem ela
        return None
    home.cover_decided()
    # 2b) sem a Home: o splash do Blender (que a Home desligou no 5.0+) volta
    #     na mão, ANTES do Welcome decidir -- ele espera o splash fechar.
    if startup and home.is_registered() and not bpy.data.filepath:
        home.show_native_splash()
    # 3) Welcome: abrir ou não (instalar/habilitar = sempre; startup = versão nova)
    if not should_auto_show(state["dont_show"], state["last_version"], version, startup, state["always"]):
        return None
    state["last_version"] = version
    _save_state()
    # 4) abre JÁ -- exceto na abertura do Blender com o splash dele na
    #    tela: aí espera o clique/tecla que fecha o splash (welcome_wait).
    window = _pick_window(use_gpu(), _boot["window_ptr"])
    if window is None:
        return None
    if not (startup and _blender_splash_likely(bpy.context)):
        show(window)
        return None
    _auto.update(pending=True, shown_at=0.0)
    try:
        with bpy.context.temp_override(window=window, screen=window.screen):
            bpy.ops.hyblend.welcome_wait("INVOKE_DEFAULT")
    except Exception as error:
        print("[Hyblend] welcome:", error)
    return None


_CLASSES = (HYBLEND_OT_welcome, HYBLEND_PT_welcome_native, HYBLEND_OT_welcome_native, HYBLEND_OT_welcome_locate_game,
            HYBLEND_OT_welcome_changelog, HYBLEND_OT_welcome_open_game_folder, HYBLEND_OT_welcome_wait)


registered_by_session_load = _registered_by_session_load      # usado por interface/__init__.py


def register(startup=None):
    """startup: abertura do Blender (True) x usuário instalando/habilitando
    (False); None = decide aqui pela pilha."""
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    WindowManager.hytale_welcome_dont_show = BoolProperty(
        name="Don't Show Again", description="Don't open the welcome window by itself anymore",
        get=_wm_dont_show_get, set=_wm_dont_show_set)
    window = getattr(bpy.context, "window", None)
    if startup is None:
        startup = _registered_by_session_load()
    _boot.update(window_ptr=window.as_pointer() if window else None, startup=startup, tries=0)
    _state["loaded"] = False
    _auto.update(pending=False, shown_at=0.0)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not bpy.app.background and not bpy.app.timers.is_registered(_boot_tick):
        bpy.app.timers.register(_boot_tick, first_interval=BOOT_DELAY)


def unregister():
    for fn in _pending:
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    _pending.clear()
    if bpy.app.timers.is_registered(_boot_tick):
        bpy.app.timers.unregister(_boot_tick)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    del WindowManager.hytale_welcome_dont_show
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
