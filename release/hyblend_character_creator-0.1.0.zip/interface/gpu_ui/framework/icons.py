"""Ícones procedurais da UI por GPU.

Cada ícone é uma função `f(x, y) -> bool` com x, y em [-1, 1] (Y para
cima): True = o ponto é pintado. O renderer amostra 4x4 vezes por pixel
(borda suave), gera uma máscara alpha e tinge no shader -- então os ícones
seguem a cor do tema e ficam nítidos em qualquer escala de interface.

O módulo `gpu` não desenha os ícones embutidos do Blender (esses só
existem via UILayout), por isso o conjunto é próprio. Ícone novo = uma
função com @icon("nome"). Nome desconhecido cai no "dot".
"""

import math

_ICONS = {}
STROKE = 0.13          # meia-espessura padrão de traço


def icon(*names):
    """@icon("nome", "apelido"...): registra (ou SUBSTITUI) o desenho. Um
    app pode trocar o desenho de um nome registrando de novo depois de
    importar este módulo (ex.: o CC mantém os ícones de reserva dele)."""
    def register(fn):
        for name in names:
            _ICONS[name] = fn
        return fn
    return register


def inside(name, x, y):
    fn = _ICONS.get(name) or _ICONS["dot"]
    return fn(x, y)


def names():
    return sorted(_ICONS)


# --------------------------------------------------------------------------
# Primitivas
# --------------------------------------------------------------------------

def seg(px, py, ax, ay, bx, by):
    """Distância do ponto ao segmento AB."""
    dx, dy = bx - ax, by - ay
    length = dx * dx + dy * dy
    t = 0.0 if length == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / length))
    return math.hypot(px - (ax + dx * t), py - (ay + dy * t))


def poly(px, py, points, w=STROKE, closed=False):
    """Traço por uma polilinha."""
    pts = list(points) + ([points[0]] if closed else [])
    return any(seg(px, py, *pts[i], *pts[i + 1]) < w for i in range(len(pts) - 1))


def fill(px, py, points):
    """Ponto dentro do polígono (regra par-ímpar)."""
    inside_ = False
    j = len(points) - 1
    for i, (xi, yi) in enumerate(points):
        xj, yj = points[j]
        if (yi > py) != (yj > py) and px < (xj - xi) * (py - yi) / (yj - yi) + xi:
            inside_ = not inside_
        j = i
    return inside_


def ring(px, py, cx, cy, r, w=STROKE):
    return abs(math.hypot(px - cx, py - cy) - r) < w


def disc(px, py, cx, cy, r):
    return math.hypot(px - cx, py - cy) <= r


def rbox(px, py, cx, cy, hw, hh, r=0.0):
    """Distância assinada de caixa arredondada (<0 dentro)."""
    qx, qy = abs(px - cx) - hw + r, abs(py - cy) - hh + r
    return min(max(qx, qy), 0.0) + math.hypot(max(qx, 0.0), max(qy, 0.0)) - r


def box_line(px, py, cx, cy, hw, hh, r=0.12, w=STROKE):
    return abs(rbox(px, py, cx, cy, hw, hh, r)) < w


def arc(px, py, cx, cy, r, start, end, w=STROKE):
    """Arco de `start` a `end` graus (anti-horário)."""
    if abs(math.hypot(px - cx, py - cy) - r) >= w:
        return False
    a = math.degrees(math.atan2(py - cy, px - cx)) % 360
    start %= 360
    end %= 360
    return start <= a <= end if start <= end else (a >= start or a <= end)


# --------------------------------------------------------------------------
# Ícones
# --------------------------------------------------------------------------

@icon("dot")
def _dot(x, y):
    return disc(x, y, 0, 0, 0.3)


@icon("circle")
def _circle(x, y):
    return disc(x, y, 0, 0, 0.66)


@icon("sparkle")
def _sparkle(x, y):     # estrela de 4 pontas = astroide
    big = abs(x + 0.14) ** 0.66 + abs(y + 0.14) ** 0.66 <= 0.84 ** 0.66
    return big or abs(x - 0.6) ** 0.66 + abs(y - 0.6) ** 0.66 <= 0.36 ** 0.66


@icon("box")
def _box(x, y):
    m = max(abs(x), abs(y))
    return 0.56 <= m <= 0.78 or (abs(y - 0.12) < 0.08 and abs(x) < 0.6)


@icon("cube")
def _cube(x, y):
    top = [(0, 0.8), (0.72, 0.42), (0, 0.04), (-0.72, 0.42)]
    return (poly(x, y, top, closed=True)
            or poly(x, y, [(-0.72, 0.42), (-0.72, -0.4), (0, -0.8), (0.72, -0.4), (0.72, 0.42)])
            or seg(x, y, 0, 0.04, 0, -0.8) < STROKE)


@icon("search")
def _search(x, y):
    return ring(x, y, -0.14, 0.14, 0.46, 0.1) or seg(x, y, 0.22, -0.22, 0.74, -0.74) < 0.11


@icon("sun")
def _sun(x, y):
    r = math.hypot(x, y)
    a = math.atan2(y, x) % (math.pi / 4)
    return r <= 0.38 or (0.58 < r < 0.86 and min(a, math.pi / 4 - a) * r < 0.07)


@icon("camera")
def _camera(x, y):
    return ((-0.78 <= x <= 0.3 and abs(y) <= 0.42)
            or (0.3 < x <= 0.82 and abs(y) <= 0.12 + (x - 0.3) * 0.6))


@icon("check")
def _check(x, y):
    return seg(x, y, -0.62, 0.0, -0.18, -0.46) < 0.13 or seg(x, y, -0.18, -0.46, 0.66, 0.5) < 0.13


@icon("move")
def _move(x, y):
    arm = (abs(x) < 0.08 and abs(y) < 0.72) or (abs(y) < 0.08 and abs(x) < 0.72)
    tip = min(abs(x) + abs(y - 0.62), abs(x) + abs(y + 0.62),
              abs(y) + abs(x - 0.62), abs(y) + abs(x + 0.62)) < 0.26
    return arm or tip


@icon("persp")
def _persp(x, y):
    half = 0.35 + 0.35 * (y + 0.55) / 1.1
    return (abs(y) <= 0.55 and abs(abs(x) - half) < 0.11) or (abs(abs(y) - 0.55) < 0.1 and abs(x) <= half)


@icon("ortho")
def _ortho(x, y):
    return abs(max(abs(x), abs(y)) - 0.58) < 0.1


def _lock_shape(x, y, open_):
    body = abs(x) <= 0.55 and -0.75 <= y <= 0.05
    shift = 0.38 if open_ else 0.0
    shackle = (y > 0.05 and abs(math.hypot(x - shift, y - 0.12) - 0.36) < 0.09
               and (y > 0.12 or not open_ or x > 0))
    return body or shackle


@icon("lock")
def _lock(x, y):
    return _lock_shape(x, y, False)


@icon("unlock")
def _unlock(x, y):
    return _lock_shape(x, y, True)


@icon("import")
def _import(x, y):
    return (seg(x, y, 0, 0.8, 0, -0.2) < STROKE
            or poly(x, y, [(-0.36, 0.14), (0, -0.24), (0.36, 0.14)])
            or poly(x, y, [(-0.76, -0.26), (-0.76, -0.76), (0.76, -0.76), (0.76, -0.26)]))


@icon("export")
def _export(x, y):
    return (seg(x, y, 0, -0.3, 0, 0.72) < STROKE
            or poly(x, y, [(-0.36, 0.4), (0, 0.78), (0.36, 0.4)])
            or poly(x, y, [(-0.76, -0.26), (-0.76, -0.76), (0.76, -0.76), (0.76, -0.26)]))


@icon("bone")
def _bone(x, y):
    return (seg(x, y, -0.42, -0.42, 0.42, 0.42) < 0.14
            or disc(x, y, -0.62, -0.36, 0.2) or disc(x, y, -0.36, -0.62, 0.2)
            or disc(x, y, 0.62, 0.36, 0.2) or disc(x, y, 0.36, 0.62, 0.2))


@icon("rig")
def _rig(x, y):     # boneco de palitos com juntas
    return (disc(x, y, 0, 0.62, 0.2)
            or seg(x, y, 0, 0.38, 0, -0.2) < 0.1
            or poly(x, y, [(-0.62, 0.02), (-0.3, 0.22), (0, 0.22), (0.3, 0.22), (0.62, 0.02)], 0.09)
            or poly(x, y, [(-0.42, -0.84), (0, -0.2), (0.42, -0.84)], 0.1)
            or disc(x, y, -0.62, 0.02, 0.13) or disc(x, y, 0.62, 0.02, 0.13))


@icon("anim")
def _anim(x, y):     # losango de keyframe + trilha
    return (abs(x - 0.18) + abs(y) <= 0.5
            or seg(x, y, -0.86, 0, -0.5, 0) < 0.09 or seg(x, y, -0.86, 0.42, -0.2, 0.42) < 0.09
            or seg(x, y, -0.86, -0.42, -0.2, -0.42) < 0.09)


@icon("key")
def _keyframe(x, y):
    return abs(x) + abs(y) <= 0.7


@icon("info")
def _info(x, y):
    return ring(x, y, 0, 0, 0.72, 0.11) or disc(x, y, 0, 0.3, 0.1) or (abs(x) < 0.085 and -0.4 < y < 0.12)


@icon("warning")
def _warning(x, y):
    tri = [(0, 0.8), (0.82, -0.66), (-0.82, -0.66)]
    return (poly(x, y, tri, 0.11, closed=True) or (abs(x) < 0.08 and -0.18 < y < 0.36)
            or disc(x, y, 0, -0.38, 0.09))


@icon("error")
def _error(x, y):
    return ring(x, y, 0, 0, 0.72, 0.11) or seg(x, y, -0.3, -0.3, 0.3, 0.3) < 0.11 or seg(x, y, -0.3, 0.3, 0.3, -0.3) < 0.11


@icon("plus")
def _plus(x, y):
    return (abs(x) < 0.1 and abs(y) < 0.66) or (abs(y) < 0.1 and abs(x) < 0.66)


@icon("minus")
def _minus(x, y):
    return abs(y) < 0.1 and abs(x) < 0.66


@icon("close")
def _close(x, y):
    return seg(x, y, -0.5, -0.5, 0.5, 0.5) < 0.12 or seg(x, y, -0.5, 0.5, 0.5, -0.5) < 0.12


@icon("chevron_down")
def _chev_down(x, y):
    return poly(x, y, [(-0.5, 0.25), (0, -0.25), (0.5, 0.25)], 0.12)


@icon("chevron_left")
def _chev_left(x, y):
    return poly(x, y, [(0.25, 0.5), (-0.25, 0), (0.25, -0.5)], 0.12)


@icon("chevron_up")
def _chev_up(x, y):
    return poly(x, y, [(-0.5, -0.25), (0, 0.25), (0.5, -0.25)], 0.12)


@icon("chevron_right")
def _chev_right(x, y):
    return poly(x, y, [(-0.25, 0.5), (0.25, 0), (-0.25, -0.5)], 0.12)


@icon("arrow_up")
def _arrow_up(x, y):
    return seg(x, y, 0, -0.66, 0, 0.6) < 0.11 or poly(x, y, [(-0.44, 0.2), (0, 0.64), (0.44, 0.2)], 0.11)


@icon("arrow_down")
def _arrow_down(x, y):
    return seg(x, y, 0, 0.66, 0, -0.6) < 0.11 or poly(x, y, [(-0.44, -0.2), (0, -0.64), (0.44, -0.2)], 0.11)


@icon("trash")
def _trash(x, y):
    can = [(-0.56, 0.42), (-0.46, -0.8), (0.46, -0.8), (0.56, 0.42)]
    return (poly(x, y, can, 0.1) or seg(x, y, -0.78, 0.46, 0.78, 0.46) < 0.1
            or poly(x, y, [(-0.26, 0.5), (-0.2, 0.74), (0.2, 0.74), (0.26, 0.5)], 0.09)
            or seg(x, y, -0.16, 0.2, -0.13, -0.56) < 0.07 or seg(x, y, 0.16, 0.2, 0.13, -0.56) < 0.07)


@icon("eyedropper")
def _eyedropper(x, y):
    return (seg(x, y, -0.7, -0.7, 0.1, 0.1) < 0.11
            or disc(x, y, 0.42, 0.42, 0.3)
            or seg(x, y, -0.02, 0.44, 0.44, -0.02) < 0.12)


def _eye_shape(x, y):
    if abs(x) > 0.9:
        return False
    edge = 0.52 * (1 - (x / 0.9) ** 2)
    return abs(abs(y) - edge) < 0.1 or disc(x, y, 0, 0, 0.24)


@icon("eye")
def _eye(x, y):
    return _eye_shape(x, y)


@icon("eye_off")
def _eye_off(x, y):
    slash = seg(x, y, -0.72, -0.72, 0.72, 0.72)
    return slash < 0.1 or (_eye_shape(x, y) and slash > 0.22)


@icon("folder")
def _folder(x, y):
    pts = [(-0.82, 0.6), (-0.3, 0.6), (-0.14, 0.4), (0.82, 0.4), (0.82, -0.66), (-0.82, -0.66)]
    return poly(x, y, pts, 0.1, closed=True) or seg(x, y, -0.82, 0.22, 0.82, 0.22) < 0.08


@icon("refresh")
def _refresh(x, y):
    return (arc(x, y, 0, 0, 0.6, 40, 330, 0.11)
            or fill(x, y, [(0.32, 0.72), (0.86, 0.66), (0.62, 0.16)]))


@icon("undo")
def _undo(x, y):
    return (arc(x, y, 0.08, -0.05, 0.56, 270, 110, 0.11) or seg(x, y, -0.28, -0.61, 0.1, -0.61) < 0.11
            or fill(x, y, [(-0.6, 0.62), (-0.14, 0.96), (-0.06, 0.3)]))


@icon("image")
def _image(x, y):
    return (box_line(x, y, 0, 0, 0.8, 0.66, 0.12, 0.1)
            or fill(x, y, [(-0.62, -0.5), (-0.14, 0.14), (0.22, -0.26), (0.36, -0.1), (0.62, -0.5)])
            or disc(x, y, 0.36, 0.3, 0.14))


@icon("mirror")
def _mirror(x, y):
    dashed = abs(x) < 0.06 and (int((y + 1) * 5) % 2 == 0)
    return (dashed or fill(x, y, [(-0.2, 0.55), (-0.2, -0.55), (-0.82, -0.55)])
            or poly(x, y, [(0.2, 0.55), (0.2, -0.55), (0.82, -0.55)], 0.08, closed=True))


@icon("pencil")
def _pencil(x, y):
    u, v = _rot(x, y)
    body = -0.3 < u < 0.8 and abs(v) < 0.2 and not (0.46 < u < 0.54)
    tip = -0.95 < u <= -0.3 and abs(v) < 0.2 * (u + 0.95) / 0.65
    return body or tip


@icon("mesh")
def _mesh(x, y):
    pts = [(-0.7, -0.6), (0.7, -0.6), (0, 0.72)]
    return (poly(x, y, pts, 0.08, closed=True) or seg(x, y, 0, 0.72, 0, -0.6) < 0.08
            or any(disc(x, y, px, py, 0.17) for px, py in pts + [(0, -0.6)]))


@icon("sort")
def _sort(x, y):
    return (seg(x, y, -0.8, 0.6, 0.1, 0.6) < 0.09 or seg(x, y, -0.8, 0.1, -0.1, 0.1) < 0.09
            or seg(x, y, -0.8, -0.4, -0.3, -0.4) < 0.09
            or seg(x, y, 0.55, 0.7, 0.55, -0.7) < 0.09
            or poly(x, y, [(0.28, -0.4), (0.55, -0.72), (0.82, -0.4)], 0.09))


@icon("layers")
def _layers(x, y):
    top = [(0, 0.78), (0.8, 0.36), (0, -0.06), (-0.8, 0.36)]
    return (poly(x, y, top, 0.09, closed=True)
            or poly(x, y, [(-0.8, -0.04), (0, -0.46), (0.8, -0.04)], 0.09)
            or poly(x, y, [(-0.8, -0.42), (0, -0.84), (0.8, -0.42)], 0.09))


@icon("gear")
def _gear(x, y):
    r = math.hypot(x, y)
    a = math.atan2(y, x)
    teeth = (math.cos(a * 8) > 0.2) and 0.55 <= r <= 0.84
    return (0.34 <= r <= 0.62) or teeth


@icon("magnet")
def _magnet(x, y):
    u = arc(x, y, 0, 0, 0.5, 180, 360, 0.18)
    legs = (abs(abs(x) - 0.5) < 0.18 and 0 <= y <= 0.72)
    return u or legs


@icon("link")
def _link(x, y):
    return (abs(rbox(*_rot(x + 0.28, y + 0.28), 0, 0, 0.5, 0.24, 0.24)) < 0.1
            or abs(rbox(*_rot(x - 0.28, y - 0.28), 0, 0, 0.5, 0.24, 0.24)) < 0.1)


def _rot(x, y, deg=45):
    c, s = math.cos(math.radians(-deg)), math.sin(math.radians(-deg))
    return x * c - y * s, x * s + y * c


@icon("globe")
def _globe(x, y):
    r = math.hypot(x, y)
    return (ring(x, y, 0, 0, 0.74, 0.1) or (r < 0.74 and abs(y) < 0.07)
            or (r < 0.74 and abs(math.hypot(x / 0.42, y / 0.74) - 1.0) < 0.14))


@icon("user")
def _user(x, y):
    return disc(x, y, 0, 0.36, 0.3) or (y < -0.12 and math.hypot(x / 0.72, (y + 0.86) / 0.66) <= 1.0)


@icon("heart")
def _heart(x, y):
    y2 = y + 0.1
    return (x * x + (y2 - abs(x) ** 0.7 * 0.6) ** 2) <= 0.46


@icon("play")
def _play(x, y):
    return fill(x, y, [(-0.44, 0.66), (0.66, 0), (-0.44, -0.66)])


@icon("grid")
def _grid(x, y):
    return any(rbox(x, y, cx, cy, 0.3, 0.3, 0.08) <= 0 for cx in (-0.42, 0.42) for cy in (-0.42, 0.42))


@icon("origin")
def _origin(x, y):
    return ring(x, y, 0, 0, 0.6, 0.1) or disc(x, y, 0, 0, 0.2)


@icon("chain")
def _chain(x, y):
    return (any(ring(x, y, cx, cy, 0.24, 0.09) for cx, cy in ((-0.5, -0.5), (0, 0), (0.5, 0.5))))


@icon("arm")
def _arm(x, y):     # membro com IK: dois segmentos, junta e alvo
    return (poly(x, y, [(-0.74, 0.6), (-0.1, -0.36), (0.66, 0.1)], 0.1)
            or disc(x, y, -0.1, -0.36, 0.17) or ring(x, y, 0.66, 0.1, 0.22, 0.08))


@icon("spine")
def _spine(x, y):
    return any(rbox(x, y, 0, cy, 0.3, 0.12, 0.1) <= 0 for cy in (0.66, 0.22, -0.22, -0.66))


@icon("head")
def _head(x, y):
    return ring(x, y, 0, 0.1, 0.56, 0.1) or disc(x, y, -0.2, 0.18, 0.09) or disc(x, y, 0.2, 0.18, 0.09) \
        or seg(x, y, 0, -0.46, 0, -0.84) < 0.1


@icon("attach")
def _attach(x, y):   # clipe
    return (arc(x, y, 0.12, 0.38, 0.3, 0, 180, 0.09) or arc(x, y, -0.02, -0.34, 0.3, 180, 360, 0.09)
            or seg(x, y, 0.42, 0.38, 0.42, -0.1) < 0.09 or seg(x, y, -0.18, 0.38, -0.18, -0.34) < 0.09
            or seg(x, y, 0.28, -0.34, 0.28, 0.1) < 0.09 or seg(x, y, -0.32, -0.34, -0.32, 0.5) < 0.09)


@icon("collection")
def _collection(x, y):
    return (box_line(x, y, 0.1, -0.1, 0.62, 0.52, 0.12, 0.09)
            or poly(x, y, [(-0.74, 0.3), (-0.74, 0.62), (0.52, 0.62)], 0.08))


@icon("more")
def _more(x, y):
    return any(disc(x, y, cx, 0, 0.14) for cx in (-0.5, 0, 0.5))


@icon("edit")
def _edit(x, y):     # modo edição: quadrado com vértices
    return box_line(x, y, 0, 0, 0.56, 0.56, 0.0, 0.07) or any(
        rbox(x, y, cx, cy, 0.16, 0.16) <= 0 for cx in (-0.56, 0.56) for cy in (-0.56, 0.56))


@icon("shape")
def _shape(x, y):    # custom shape: círculo tracejado em volta de um bone
    a = math.degrees(math.atan2(y, x)) % 45
    return (ring(x, y, 0, 0, 0.72, 0.09) and a < 30) or seg(x, y, -0.3, -0.3, 0.3, 0.3) < 0.13


@icon("hide")
def _hide(x, y):
    return _eye_off(x, y)


@icon("history")
def _history(x, y):     # relógio com seta: "último arquivo" (Home)
    return (arc(x, y, 0.04, 0, 0.66, 200, 160, 0.1)
            or fill(x, y, [(-0.94, 0.02), (-0.36, 0.02), (-0.66, -0.4)])
            or seg(x, y, 0.04, 0, 0.04, 0.4) < 0.09 or seg(x, y, 0.04, 0, 0.32, -0.18) < 0.09)


@icon("external")
def _external(x, y):    # caixa aberta + seta saindo: link pra fora (Home)
    frame = poly(x, y, [(-0.06, 0.62), (-0.7, 0.62), (-0.7, -0.7), (0.62, -0.7), (0.62, 0.06)], 0.1)
    return (frame or seg(x, y, -0.12, -0.12, 0.62, 0.62) < 0.1
            or fill(x, y, [(0.82, 0.82), (0.22, 0.82), (0.82, 0.22)]))


@icon("copy")
def _copy(x, y):        # duas folhas sobrepostas (Home: copiar caminho)
    back = box_line(x, y, -0.18, 0.18, 0.46, 0.52, 0.1, 0.09) and not (x > -0.04 and y < 0.42)
    return back or box_line(x, y, 0.2, -0.2, 0.46, 0.52, 0.1, 0.09)


# --------------------------------------------------------------------------
# Máscaras prontas (gpu_ui/icons/<nome>.png)
# --------------------------------------------------------------------------
# Calcular um ícone aqui custa ~7 ms (16 px) a ~27 ms (32 px, tela 2x) --
# era feito DENTRO do desenho, na primeira vez de cada ícone (até ~0,5 s
# travado na 1ª abertura do N-Panel sem a pasta do jogo). Por isso os
# ícones vão no addon como PNG (máscara branca + alfa, MASK_PX) e o
# renderer só carrega e tinge. Ícone NOVO: criar a função @icon e rodar
#     python interface/gpu_ui/framework/icons.py
# (Python puro, sem Blender). Sem o PNG ele continua funcionando, pelo
# cálculo antigo (mais lento só na primeira vez).

ALIASES = {}               # nome do app -> desenho de outro nome (gpu_ui.register preenche)
MASK_PX = 64               # 64 px cobre ícones de 16 lógicos até a escala 4x
_MASK_SS = 4               # 4x4 amostras por pixel (borda suave)


def mask_alpha_rows(name, px=MASK_PX, ss=_MASK_SS):
    """Linhas de alfa (0-255) de cima pra baixo, como no PNG."""
    rows = []
    for row in range(px):
        line = bytearray()
        top = px - 1 - row                       # Y para cima
        for col in range(px):
            hits = sum(inside(name, ((col + (sx + 0.5) / ss) / px) * 2 - 1,
                              ((top + (sy + 0.5) / ss) / px) * 2 - 1)
                       for sy in range(ss) for sx in range(ss))
            line.append(round(255 * hits / (ss * ss)))
        rows.append(bytes(line))
    return rows


def write_mask_png(path, rows):
    """PNG RGBA (branco + alfa) com zlib puro -- sem dependências."""
    import struct
    import zlib
    px = len(rows)

    def chunk(kind, data):
        return (struct.pack(">I", len(data)) + kind + data
                + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF))
    raw = b"".join(b"\x00" + b"".join(b"\xff\xff\xff" + bytes((a,)) for a in row) for row in rows)
    with open(path, "wb") as handle:
        handle.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", px, px, 8, 6, 0, 0, 0))
                     + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def write_masks(directory=None):
    """Gera gpu_ui/icons/<nome>.png de todos os ícones registrados."""
    import os
    directory = directory or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "icons")
    os.makedirs(directory, exist_ok=True)
    for name in names():
        write_mask_png(os.path.join(directory, name + ".png"), mask_alpha_rows(name))
    return directory


if __name__ == "__main__":
    print("masks ->", write_masks())
