"""A Home do Hyblend em tela cheia (0.9.5; veio do protótipo "Hyblend Home").

  ┌────────────────────────────────────────────────────────────────────┐
  │ fundo do jogo (Zone*Blurred) + GradientOverlay da esquerda          │
  │  HYBLEND             ┌──────────── ornamento ─────────────┐   [X]   │
  │  BLENDER + HYTALE    │ TÍTULO DOURADO / subtítulo          │         │
  │  [ NOVO ] [ ABRIR ]  │ ─────────────────────────────────── │         │
  │                      │ conteúdo da seção (rola)           ▐│         │
  │  ─ RECENTES          │                                     │         │
  │    PERSONAGENS       └──────────── ornamento ─────────────┘         │
  │    APRENDER                                                         │
  │    CHANGELOG          ESC · IR PARA O BLENDER                [WIP]  │
  │  PREFERÊNCIAS / IR PARA O BLENDER / [x] Mostrar ao abrir            │
  │ TRUPE FORGE                                                         │
  └────────────────────────────────────────────────────────────────────┘

Visual tirado dos .ui do menu principal do jogo:
  * itens do menu: HomePage.ui (Lexend Bold caixa alta 30, hover 37 com
    Runes.png atrás e degradê dourado; secundários 25);
  * cards de arquivo: Adventure/WorldTile.ui (311x297, nome 18 bold caixa
    alta #c2d3de, data 11, selo 69x60 no canto);
  * cards em pé: Adventure/GameModeTile (normal / hover azul / selecionado
    dourado);
  * painel: a MESMA moldura do Toolkit (ornamentos + ContainerPatch).

Regra: build/layout/draw rodam no draw handler -- nada de bpy.data aqui.
Ações (abrir arquivo, URL...) moram em interface/home/actions.py; dados
(recentes, releases) em interface/home/. Host: gpu_ui/home_host.py.
"""

import random

from ... import home as home_pkg
from ...home import actions, data, releases
from ...welcome import addon_version
from .. import game, home_host as host, markdown
from ..framework import renderer
from ..framework.core import (Button, Column, Fade, Label, Rect, Row, ScrollView, Spacer, Style, Widget,
                             fit_text, heading, skin, wrap_text)
from ..framework.motion import forget, mix
from ..app import GOLD_TITLE, HARDCORE_RED, MENU_GOLD_LEFT, MENU_GOLD_RIGHT, MENU_TEXT, TILE_TEXT
from ..richtext import RichText
from ..widgets import CheckBox, CheckLabel, Ornament, Paragraph, card

PAGES = ("RECENT", "CHARACTERS", "LEARNING", "CHANGELOG")      # ordem do menu
# Páginas que ainda não abrem: aparecem no menu ESCURAS e sem clique (com a
# dica "Em breve"), pra mostrar que vêm aí. Pra liberar, tirar daqui -- o
# código das duas já está pronto; faltam as miniaturas dos modelos
# (data.CHARACTERS) e os links reais dos vídeos (data.VIDEOS).
COMING_SOON = {"CHARACTERS", "LEARNING"}
_session = {"page": "RECENT", "background": None}      # sobrevive entre aberturas (mesma sessão)


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# --------------------------------------------------------------------------
# Abertura (fora do desenho): escolhe o fundo, relê os recentes
# --------------------------------------------------------------------------

def on_open(page=None):
    p = home_pkg.prefs()
    zone = getattr(p, "home_background", "ZONE3") if p else "ZONE3"
    if p is not None and p.home_background_mode == "RANDOM":
        zone = random.choice(game.BACKGROUNDS)
    blur = bool(getattr(p, "home_background_blur", True)) if p else True
    _session["background"] = "bg_%s%s" % (zone.lower(), "_blur" if blur else "")
    if page in PAGES and page not in COMING_SOON:
        _session["page"] = page
    game.sync()
    path = game.art(_session["background"])[0]
    if path:
        renderer.allow_full_res(path)
    # Arte só da Home: fora da pré-carga do sync() (N-Panel); carrega agora.
    # Fundo primeiro (o maior); dos fundos, só o escolhido.
    others = [game.art(name)[0] for name in sorted(game.HOME_ART) if not name.startswith("bg_")]
    renderer.preload([p_ for p_ in [path] + others if p_])
    data.refresh()
    releases.refresh()                 # Changelog: busca em segundo plano se o cache estiver velho


def release():
    """Home fechou: tira o fundo (1920x1080, ~16 MB) da GPU."""
    path = background_path()
    if path:
        renderer.drop_image(path)


def background_path():
    name = _session["background"] or "bg_zone3_blur"
    return game.art(name)[0]


# --------------------------------------------------------------------------
# Medidas da tela (iguais no build e no layout)
# --------------------------------------------------------------------------

class Metrics:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.margin = clamp(h * 0.045, 18.0, 52.0)
        self.left_w = clamp(w * 0.29, 300.0, 560.0)
        self.left_pad = clamp(self.left_w * 0.16, 30.0, 84.0)
        self.panel = Rect(self.left_w, self.margin, max(200.0, w - self.left_w - self.margin),
                          max(200.0, h - 2 * self.margin))
        self.body_pad = (34.0, 26.0, 30.0, 26.0)
        # largura útil do conteúdo (descontando moldura, padding e barra de rolagem)
        self.inner_w = max(160.0, self.panel.w - self.body_pad[0] - self.body_pad[2] - ScrollView.BAR)


# --------------------------------------------------------------------------
# Widgets da Home
# --------------------------------------------------------------------------

class HomeScreen(Widget):
    """Raiz: posiciona os blocos por medidas absolutas (não é flex)."""

    def __init__(self, metrics, background, left, panel, overlays):
        super().__init__(key="home", children=[background, left, panel] + [o for o in overlays if o])
        self.m, self.background, self.left, self.panel_widget = metrics, background, left, panel
        self.overlays = [o for o in overlays if o]

    def _extent(self, f, width):
        return (self.m.h, self.m.h, self.m.h)

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        m = self.m
        self.background.layout(f, rect)
        self.left.layout(f, Rect(m.left_pad, m.margin, m.left_w - m.left_pad - 28, m.h - 2 * m.margin))
        self.panel_widget.layout(f, m.panel)
        for widget in self.overlays:
            widget.layout(f, widget.place(m))


class Background(Widget):
    """Fundo do jogo (cover) escurecido + GradientOverlay do menu principal
    (750x1080 no jogo) atrás da coluna da esquerda + vinheta embaixo."""

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        if not r.image(rect, background_path(), fit="cover", smooth=True):
            r.rect(rect, th.canvas)
        r.rect(rect, th.canvas[:3] + (0.30,))                          # tom azul-marinho por cima
        width = min(rect.w * 0.62, 750.0 * rect.h / 1080.0 * 1.15)
        if not r.image(Rect(rect.x, rect.y, width, rect.h), game.art("menu_gradient")[0], fit="stretch",
                       smooth=True):
            r.gradient(Rect(rect.x, rect.y, width, rect.h), th.canvas[:3] + (0.85,),   # reserva procedural
                       th.canvas[:3] + (0.0,), power=1.5, horizontal=True)
        # vinheta de baixo: degradê contínuo no shader (antes eram 10 faixas
        # sobrepostas em 0,5 px -- degraus e linhas finas nas emendas)
        r.gradient(Rect(rect.x, rect.y, rect.w, rect.h * 0.22),
                   (0.02, 0.03, 0.05, 0.45), (0.02, 0.03, 0.05, 0.0), power=2.0)


class Logo(Widget):
    """HYBLEND (Lexend) com o BLENDER + HYTALE (dourado, espaçado) centralizado
    embaixo dele e a versão na MESMA linha, encostada à esquerda. Coluna
    estreita demais pros dois lado a lado: a versão desce uma linha."""

    VERSION_SIZE = 11.0
    VERSION_INDENT = 10.0       # a versão começa um pouco pra dentro do "H" (pedido do autor)

    def __init__(self, width, subtitle, version):
        super().__init__(style=Style())
        self.size = clamp(width * 0.215, 42.0, 86.0)
        self.subtitle, self.version = subtitle, version
        self._inline = True

    def _parts(self):
        size = self.size
        sub = max(11.0, size * 0.2)
        return size, sub, size * renderer.CAP_RATIO, sub * renderer.CAP_RATIO

    def fit(self, f, width):
        """Tela pequena: o título encolhe até caber na coluna. Devolve a
        largura do "HYBLEND" (NOVO/ABRIR e o subtítulo centralizam por ela)."""
        natural = f.renderer.text_width("HYBLEND", self.size, "Title")
        if natural > width > 0:
            self.size = max(28.0, self.size * width / natural)
        return f.renderer.text_width("HYBLEND", self.size, "Title")

    def _widths(self, f):
        """(largura do HYBLEND, do subtítulo, da versão)."""
        r = f.renderer
        size, sub, _, _ = self._parts()
        return (r.text_width("HYBLEND", size, "Title"), r.text_width(self.subtitle, sub, "Title", sub * 0.22),
                r.text_width(self.version, self.VERSION_SIZE, "Bold"))

    def _extent(self, f, width):
        self.fit(f, width)
        size, sub, cap, sub_cap = self._parts()
        logo_w, sub_w, ver_w = self._widths(f)
        # cabe a versão à esquerda do subtítulo centralizado (com folga)?
        self._inline = (logo_w - sub_w) / 2 >= self.VERSION_INDENT + ver_w + 10
        h = cap + size * 0.28 + sub_cap + (0 if self._inline else 20) + 6
        return (h, h, h)

    def measure(self, f, max_w):
        return (max_w, self.extent(f, max_w)[1])

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        size, sub, cap, sub_cap = self._parts()
        logo_w, sub_w, _ = self._widths(f)
        top = rect.top
        r.text(Rect(rect.x - 2, top - cap, rect.w + 40, cap), "HYBLEND", (1, 1, 1, 1), size=size,
               weight="Title", truncate=False, shadow=((0.0, 0.0, 0.0, 0.55), 2.0, -3.0))
        base = top - cap - size * 0.28 - sub_cap               # linha de base do subtítulo
        r.text(Rect(rect.x + max(0.0, (logo_w - sub_w) / 2), base, sub_w + 40, sub_cap), self.subtitle,
               GOLD_TITLE, size=sub, weight="Title", tracking=sub * 0.22, truncate=False,
               shadow=((0.0, 0.0, 0.0, 0.6), 1.0, -1.0))
        ver_cap = self.VERSION_SIZE * renderer.CAP_RATIO
        ver_base = base if self._inline else base - 20         # mesma linha de base do subtítulo
        r.text(Rect(rect.x + self.VERSION_INDENT, ver_base, rect.w, ver_cap), self.version, th.text_muted[:3] + (0.8,),
               size=self.VERSION_SIZE, weight="Bold", truncate=False)


class ActionButton(Button):
    """NOVO / ABRIR: botões do jogo (Primary azul / Secondary) maiores."""

    def _label(self, th):
        text, weight, tracking = heading(th, self.text)
        return text, weight, 1.0, 13.5


class MenuItem(Widget):
    """Item do menu principal, como o @PrimaryButton do HomePage.ui:
      * o botão vai da BORDA DA TELA até o fim do texto (Padding Left 80);
        no hover o fundo dele é o Runes.png -- a faixa dourada que nasce na
        borda e some perto do texto;
      * texto Lexend caixa alta com máscara em degradê: normal = azul-claro
        (HomeButtonLabelGradient #b7cce9); hover/ativo = amarelo claro ->
        laranja da esquerda pra direita (HomeButtonLabelHoveredGradient);
      * hover cresce 30 -> 37; pressionado #bbb9b9."""
    interactive = True
    GROW = 37.0 / 30.0 - 1.0

    DISABLED = 0.32           # opacidade do item "em breve" (escuro, sem hover)

    def __init__(self, key, text, on_click, active=False, size=28.0, height=50.0, tooltip=None, enabled=True):
        super().__init__(key, Style(height=height), tooltip)
        self.text, self.callback, self.active, self.size = text.upper(), on_click, active, size
        self.enabled = enabled
        self._base = size
        self._hit_w = None

    def measure(self, f, max_w):
        return (max_w, self.style.height)

    def _text_w(self, f, size):
        return f.renderer.text_width(self.text, size, "Title", size * 0.04)

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        # coluna estreita: o texto (já crescido pelo hover) nunca passa da coluna
        self.size = self._base
        widest = self._text_w(f, self.size * (1 + self.GROW))
        if widest > rect.w > 0:
            self.size *= rect.w / widest
        self._hit_w = self._text_w(f, self.size * (1 + self.GROW)) + 24

    def hit(self, x, y):
        # só a faixa do texto (+ folga): o resto da linha não é botão
        if not self.visible_at(x, y):
            return None
        return self if x <= self.rect.x + (self._hit_w or self.rect.w) else None

    def draw(self, f):
        r, rect = f.renderer, self.rect
        live = self.enabled
        h = f.animate(self.key + ".hover", 1.0 if (live and f.hover == self.key) else 0.0, 0.14)
        p = f.animate(self.key + ".press", 1.0 if (live and f.pressed == self.key) else 0.0, 0.06)
        a = f.animate(self.key + ".active", 1.0 if self.active else 0.0, 0.25)
        lit = max(h, a)                                                  # dourado (hover ou página atual)
        size = self.size * (1.0 + self.GROW * h)
        tracking = size * 0.04
        text_w = self._text_w(f, size)
        cap = size * renderer.CAP_RATIO
        cy = rect.y + rect.h / 2
        if lit > 0.01:
            # Runes.png = fundo do botão: da borda da tela (x=0) até o fim do texto,
            # altura do botão (60 no jogo pra fonte 30 = 2x o tamanho).
            band_h = self.size * 2.0 * (1.0 + self.GROW * h)
            old, r.opacity = r.opacity, r.opacity * lit
            if not r.image(Rect(0.0, cy - band_h / 2, rect.x + text_w, band_h), game.art("menu_runes")[0],
                           fit="stretch"):
                r.rect(Rect(0.0, cy - 1.0, rect.x - 12, 2.0), MENU_GOLD_RIGHT[:3] + (0.6,))
            r.opacity = old
        if lit < 0.01:
            # parado: cor única (azul-claro) -> UMA chamada de desenho pro item todo
            color = mix(MENU_TEXT, (0.73, 0.72, 0.72, 1.0), p)
            shade = 0.5
            if not live:
                color, shade = color[:3] + (color[3] * self.DISABLED,), 0.5 * self.DISABLED
            r.text(Rect(rect.x, cy - cap / 2, text_w + 20, cap), self.text, color, size=size, weight="Title",
                   tracking=tracking, truncate=False, shadow=((0.0, 0.0, 0.0, shade), 1.5, -2.0))
            return
        # dourado: letra por letra -- a cor de cada letra = o degradê na posição dela
        step = max(1, round(tracking * r.scale)) / r.scale if tracking else 0.0
        x = rect.x
        for i, ch in enumerate(self.text):
            t = (x - rect.x) / max(text_w, 1.0)
            color = mix(MENU_TEXT, mix(MENU_GOLD_LEFT, MENU_GOLD_RIGHT, t), lit)
            color = mix(color, (0.73, 0.72, 0.72, 1.0), p)                # Pressed #bbb9b9
            if ch != " ":
                r.text(Rect(x, cy - cap / 2, size * 2, cap), ch, color, size=size, weight="Title",
                       truncate=False, shadow=((0.0, 0.0, 0.0, 0.5), 1.5, -2.0))
            x = rect.x + r.text_width(self.text[:i + 1], size, "Title") + step * (i + 1)

    def on_click(self, f, x, y):
        if self.callback and self.enabled:
            self.callback(f)


class Placed(Widget):
    """Widget com posição absoluta calculada a partir das Metrics."""

    def __init__(self, child, place):
        super().__init__(children=[child])
        self.place = place

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        self.children[0].layout(f, rect, clip)


class FreeText(Widget):
    def __init__(self, text, size, color, weight="Title", tracking=0.0, align="LEFT"):
        super().__init__()
        self.text, self.size, self.color, self.weight, self.tracking, self.align = (text, size, color, weight,
                                                                                    tracking, align)

    def draw(self, f):
        f.renderer.text(self.rect, self.text, self.color, size=self.size, weight=self.weight,
                        tracking=self.tracking, align=self.align, truncate=False)


class WipBadge(Widget):
    """Selo WIP do jogo (Common/WIPLogo) no canto do painel."""

    def __init__(self, tooltip):
        super().__init__(key="home.wip", tooltip=tooltip)

    def draw(self, f):
        r = f.renderer
        h = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.14)
        rect = self.rect.expand(2 * h)
        r.shadow(rect.expand(-10), 20, f.theme.shadow[:3] + (0.5,), blur=14, dy=-3)
        if not r.image(rect, game.art("wip_logo")[0], fit="contain"):
            r.icon(rect, "experimental", f.theme.warning)


# ---- painel --------------------------------------------------------------

class PanelFrame(Column):
    """[ornamento, corpo (ContainerPatch opaco), ornamento]; o de cima é
    desenhado POR ÚLTIMO (a metade vazia do PNG cai por cima do corpo)."""

    def draw(self, f):
        for child in self.children[1:] + self.children[:1]:
            child.draw(f)


class PanelBody(Column):
    """Corpo do painel com a moldura do jogo (ContainerPatch). O PNG só tem o
    chanfro (escuro-claro-escuro) EMBAIXO: no jogo o topo fica sempre sob a
    faixa do título. Sem a faixa, o topo parecia cortado -- então a faixa de
    cima é a MESMA moldura espelhada na vertical, recortada à borda."""

    def draw_box(self, f):
        s, r, rect = self.style, f.renderer, self.rect
        if not s.frame:
            return super().draw_box(f)
        path, slices, scale = s.frame
        if s.shadow:
            r.shadow(rect, s.radius, f.theme.shadow)
        edge = slices[1] * scale                          # altura lógica da borda (46 px @2x -> 23)
        top = Rect(rect.x, rect.top - edge, rect.w, edge)
        rest = Rect(rect.x, rect.y, rect.w, rect.h - edge)
        drew = False
        for clip, flip in ((rest, False), (top, True)):
            r.push_clip(clip if self.clip is None else self.clip.intersect(clip))
            try:
                if s.frame_base:
                    r.nine_slice(rect, path, slices, scale=scale, tint=s.frame_base, silhouette=True, flip_y=flip)
                drew = r.nine_slice(rect, path, slices, scale=scale, flip_y=flip) or drew
            finally:
                r.pop_clip()
        if not drew:
            r.rect(rect, s.background or (0, 0, 0, 0), radius=s.radius, border=s.border)


class PageTitle(Widget):
    """Título dourado + subtítulo cinza em caixa alta ("SELECIONE UM MUNDO")."""

    def __init__(self, title, subtitle):
        super().__init__(style=Style(height=62.0, flex=1))
        self.title, self.subtitle = title.upper(), subtitle.upper()

    def measure(self, f, max_w):
        return (max_w, 62.0)

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        size, tracking = fit_text(r, self.title, rect.w, 30.0, "Title", 1.2, min_size=18.0)
        cap = size * renderer.CAP_RATIO
        top = rect.top - 6
        r.text(Rect(rect.x, top - cap, rect.w, cap), self.title, GOLD_TITLE, size=size, weight="Title",
               tracking=tracking, shadow=((0.0, 0.0, 0.0, 0.5), 1.0, -1.5))
        r.text(Rect(rect.x, top - cap - 12 - 13 * renderer.CAP_RATIO, rect.w, 13 * renderer.CAP_RATIO),
               self.subtitle, th.text_muted, size=13.0, weight="Medium", tracking=0.6)


class Divider(Widget):
    def __init__(self):
        super().__init__(style=Style(height=9.0))

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        r.rect(Rect(rect.x, rect.y + rect.h / 2 - 0.5, rect.w, 1.0), th.border[:3] + (0.55,))


class SectionLabel(Widget):
    def __init__(self, text, detail=""):
        super().__init__(style=Style(height=22.0))
        self.text, self.detail = text.upper(), detail

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        r.text(rect, self.text, th.text_muted, size=12.0, weight="Title", tracking=0.9)
        if self.detail:
            w = r.text_width(self.text, 12.0, "Title", 0.9)
            r.text(Rect(rect.x + w + 10, rect.y, rect.w - w - 10, rect.h), self.detail,
                   th.text_muted[:3] + (0.6,), size=11.5, weight="Bold")


# ---- cards ---------------------------------------------------------------

def _pressable(widget, f):
    """(hover, press) animados de um widget interativo."""
    h = f.animate(widget.key + ".hover", 1.0 if f.hover == widget.key else 0.0, 0.12)
    p = f.animate(widget.key + ".press", 1.0 if (f.hover == widget.key and f.pressed == widget.key) else 0.0,
                  0.06)
    return h, p


def _image_or_placeholder(r, rect, path, radius=0.0):
    """Miniatura (ampliação suave: é foto da cena, não pixel art) ou o
    NoPreview do jogo; sem nada, um cinza."""
    if path and r.image(rect, path, fit="cover", radius=radius, smooth=True):
        return True
    if r.image(rect, game.art("no_preview")[0], fit="cover", radius=radius):
        return False
    r.rect(rect, (0.16, 0.2, 0.27, 1.0), radius=radius)
    return False


class FileTile(Widget):
    """Card de arquivo recente = card de mundo do jogo (WorldTile.ui)."""
    interactive = True

    def __init__(self, key, item, t, on_click, style):
        super().__init__(key, style, tooltip=lambda: t("home.recent.tooltip_open").format(
            name=item["name"], path=item["path"]))
        self.item, self.t, self.callback = item, t, on_click

    def draw(self, f):
        th, r = f.theme, f.renderer
        h, p = _pressable(self, f)
        rect = self.rect.expand(-1.2 * p)
        k = rect.w / 311.0
        item = self.item
        old = r.opacity
        if not item["exists"]:
            r.opacity = old * 0.55
        _image_or_placeholder(r, rect, item["thumb"], radius=3 * k)
        part = "world_tile_hover" if h > 0.5 else "world_tile"
        if not r.image(rect, game.art(part)[0], fit="stretch"):
            r.rect(Rect(rect.x, rect.y, rect.w, 62 * k), th.canvas[:3] + (0.85,))
            r.rect(rect, (0, 0, 0, 0), radius=3, border=mix(th.border, th.primary, h))
        name_size = clamp(18 * k, 11.0, 20.0)
        date_size = clamp(11 * k, 8.5, 12.0)
        badge_w = 69 * k
        r.text(Rect(rect.x + 11 * k, rect.y + 47 * k, rect.w - 22 * k - badge_w * 0.6, 24 * k),
               item["name"].upper(), TILE_TEXT, size=name_size, weight="Bold")
        r.opacity = old
        if item["exists"]:
            when = data.relative_time(item["mtime"], self.t).upper()
            r.text(Rect(rect.x + 11 * k, rect.y + 13 * k, rect.w * 0.6, 16 * k), when, TILE_TEXT,
                   size=date_size, weight="Bold")
            badge = Rect(rect.right - 7 * k - badge_w, rect.y + 9 * k, badge_w, 60 * k)
            r.image(badge, game.art("mode_icon_creative")[0], fit="contain")
        else:
            r.text(Rect(rect.x + 11 * k, rect.y + 13 * k, rect.w - 22 * k, 16 * k),
                   self.t("home.recent.missing").upper(), HARDCORE_RED, size=date_size, weight="Bold")

    def on_click(self, f, x, y):
        self.callback(f)

    def on_context(self, f, x, y):
        recent_menu(f, x, y, self.item, self.t)


class EmptyTile(Widget):
    """Espaço livre da grade (EmptyWorldTilePatch do jogo)."""

    def draw(self, f):
        if not skin(f, self.rect, "world_tile_empty", opacity=0.9):
            f.renderer.rect(self.rect, (1, 1, 1, 0.025), radius=3)


class ThumbBox(Widget):
    """Miniatura grande do card "Último arquivo" (clique abre; direito = menu)."""
    interactive = True

    def __init__(self, item, t, style):
        super().__init__("home.hero.thumb", style, tooltip=lambda: t("home.recent.tooltip_open").format(
            name=item["name"], path=item["path"]))
        self.item, self.t = item, t

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        h, _ = _pressable(self, f)
        r.shadow(rect, 3, th.shadow[:3] + (0.5,), blur=10, dy=-3)
        _image_or_placeholder(r, rect, self.item["thumb"], radius=3)
        r.rect(rect, (0, 0, 0, 0), radius=3, border=mix(th.border, th.primary, h))
        chip = Rect(rect.x + 10, rect.top - 34, 24, 24)
        r.rect(chip, th.canvas[:3] + (0.82,), radius=3)
        r.icon(chip.inset(4, 4, 4, 4), "history", GOLD_TITLE)

    def on_click(self, f, x, y):
        if self.item["exists"]:
            actions.open_file(f, self.item["path"])

    def on_context(self, f, x, y):
        recent_menu(f, x, y, self.item, self.t)


# ---- menu de contexto ------------------------------------------------------

def recent_menu(f, x, y, item, t):
    """Clique direito num recente: abrir pasta / copiar caminho / remover da lista."""
    path, folder = item["path"], item["folder"]
    f.state["_popup"] = {"x": x, "y": y, "entries": (
        ("folder", t("home.menu.open_folder"), lambda f: actions.open_folder(f, folder), item["exists"]),
        ("copy", t("home.menu.copy_path"), lambda f: actions.copy_path(f, path), True),
        ("trash", t("home.menu.remove"), lambda f: actions.remove_recent(f, path), True),
    )}


class ContextMenu(Widget):
    """Menu flutuante no mouse. Por baixo, um "fundo" invisível do tamanho da
    tela: clique fora fecha o menu sem clicar no que está atrás."""
    ROW, PAD, ICON = 32.0, 6.0, 14.0

    def __init__(self, popup):
        self.popup = popup
        entries = [_MenuEntry("home.menu.%d" % i, icon, label, run, enabled)
                   for i, (icon, label, run, enabled) in enumerate(popup["entries"])]
        super().__init__(key="home.menu", children=[_MenuBackdrop()] + entries)
        self.box = Rect(0, 0, 0, 0)

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        r = f.renderer
        entries = self.children[1:]
        text_w = max((r.text_width(e.label, 12.5, "Bold") for e in entries), default=0.0)
        w = max(200.0, text_w + self.ICON + 3 * 12)
        h = len(entries) * self.ROW + 2 * self.PAD
        # abre pra baixo/direita do mouse; perto da borda, vira pro outro lado
        x, y = self.popup["x"], self.popup["y"]
        bx = x + 2 if x + 2 + w <= rect.right - 8 else x - 2 - w
        top = min(y - 2 if y - 2 - h >= rect.y + 8 else y + 2 + h, rect.top - 8)
        self.box = Rect(clamp(bx, rect.x + 8, rect.right - w - 8), top - h, w, h)
        self.children[0].layout(f, rect)
        for i, entry in enumerate(entries):
            entry.layout(f, Rect(self.box.x + self.PAD, self.box.top - self.PAD - (i + 1) * self.ROW,
                                 w - 2 * self.PAD, self.ROW))

    def draw(self, f):
        th, r, box = f.theme, f.renderer, self.box
        r.shadow(box, 4, th.shadow, blur=16, dy=-4)
        r.rect(box, th.canvas[:3] + (0.98,), radius=4, border=th.border)
        r.rect(Rect(box.x + 1, box.top - 2, box.w - 2, 1), GOLD_TITLE[:3] + (0.35,))   # filete do jogo
        for child in self.children[1:]:
            child.draw(f)


class _MenuBackdrop(Widget):
    interactive = True

    def __init__(self):
        super().__init__(key="home.menu.backdrop")

    def on_click(self, f, x, y):
        f.state.pop("_popup", None)


class _MenuEntry(Widget):
    interactive = True

    def __init__(self, key, icon, label, run, enabled):
        super().__init__(key=key)
        self.icon, self.label, self.run, self.enabled = icon, label, run, enabled

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        h = f.animate(self.key + ".hover", 1.0 if (f.hover == self.key and self.enabled) else 0.0, 0.1)
        if h > 0.01:
            r.rect(rect, mix(th.canvas, th.primary, 0.35)[:3] + (h,), radius=3)
        color = mix(th.text, GOLD_TITLE, h) if self.enabled else th.text_muted[:3] + (0.45,)
        size = ContextMenu.ICON
        r.icon(Rect(rect.x + 10, rect.y + (rect.h - size) / 2, size, size), self.icon, color)
        r.text(Rect(rect.x + 10 + size + 10, rect.y, rect.w - size - 26, rect.h), self.label, color,
               size=12.5, weight="Bold")

    def on_click(self, f, x, y):
        f.state.pop("_popup", None)
        if self.enabled:
            self.run(f)


def context_menu(f):
    popup = f.state.get("_popup")
    if not popup:
        return None
    return Placed(ContextMenu(popup), lambda mm: Rect(0, 0, mm.w, mm.h))


class CharacterTile(Widget):
    """Card em pé (GameModeTile do jogo): imagem placeholder [X] + nome."""
    interactive = True
    SLICES = (64, 64, 64, 64)

    def __init__(self, key, name, kind, selected, on_click, style):
        super().__init__(key, style, tooltip=name)
        self.name, self.kind, self.selected, self.callback = name, kind, selected, on_click

    def draw(self, f):
        th, r = f.theme, f.renderer
        h, p = _pressable(self, f)
        sel = f.animate(self.key + ".sel", 1.0 if self.selected else 0.0, 0.18)
        rect = self.rect.expand(-1.2 * p)
        scale = min(0.32, rect.w / 863.0 * 1.1)
        base = game.art("mode_tile")[0]
        drew = r.nine_slice(rect, base, self.SLICES, scale=scale)
        if drew and h > 0.01:
            r.nine_slice(rect, game.art("mode_tile_hover")[0], self.SLICES, scale=scale, opacity=h)
        if drew and sel > 0.01:
            r.nine_slice(rect, game.art("mode_tile_selected")[0], self.SLICES, scale=scale, opacity=sel)
        if not drew:
            r.rect(rect, th.surface, radius=3, border=mix(mix(th.border, th.primary, h), GOLD_TITLE, sel))
        # área da imagem: placeholder [X] até as miniaturas existirem
        art = rect.inset(14, 14, 14, 58)
        r.rect(art, (1, 1, 1, 0.03 + 0.02 * h), radius=2)
        x_size = min(art.w, art.h) * 0.42
        r.icon(Rect(art.x + (art.w - x_size) / 2, art.y + (art.h - x_size) / 2, x_size, x_size), "close",
               mix(th.text_muted, GOLD_TITLE, max(h * 0.5, sel))[:3] + (0.32 + 0.25 * h,))
        name, weight, tracking = heading(th, self.name)
        size, tracking = fit_text(r, name, rect.w - 24, 15.0, weight, 0.6, min_size=10.0)
        r.text(Rect(rect.x + 12, rect.y + 28, rect.w - 24, 18), name, mix(TILE_TEXT, GOLD_TITLE, sel),
               size=size, weight=weight, tracking=tracking, align="CENTER")
        r.text(Rect(rect.x + 12, rect.y + 12, rect.w - 24, 12), self.kind.upper(), th.text_muted, size=9.5,
               weight="Bold", align="CENTER", tracking=0.5)

    def on_click(self, f, x, y):
        self.callback(f)


class VideoCard(Widget):
    """Card de vídeo (estilo dos cards de notícia do launcher)."""
    interactive = True
    TEXT_H = 92.0

    def __init__(self, key, video, lang, on_click, style):
        super().__init__(key, style, tooltip=video["url"])
        self.video, self.lang, self.callback = video, lang, on_click

    def draw(self, f):
        th, r = f.theme, f.renderer
        h, p = _pressable(self, f)
        rect = self.rect.expand(-1.0 * p)
        if not skin(f, rect, "card"):
            r.rect(rect, th.surface, radius=4, border=th.border)
        if h > 0.01:
            r.rect(rect.expand(-1), (0, 0, 0, 0), radius=3, border=GOLD_TITLE[:3] + (0.55 * h,), border_width=1.5)
        thumb = Rect(rect.x + 8, rect.y + self.TEXT_H, rect.w - 16, rect.h - self.TEXT_H - 8)
        _image_or_placeholder(r, thumb, None, radius=2)
        r.rect(thumb, (0.02, 0.04, 0.08, 0.38 - 0.12 * h), radius=2)
        d = clamp(thumb.h * 0.36, 34.0, 64.0) * (1 + 0.06 * h)                # botão de play
        circle = Rect(thumb.x + (thumb.w - d) / 2, thumb.y + (thumb.h - d) / 2, d, d)
        r.shadow(circle, d / 2, th.shadow, blur=10, dy=-2)
        r.rect(circle, mix(th.primary, th.primary_hover, h), radius=d / 2, border=(1, 1, 1, 0.35))
        icon = d * 0.42
        r.icon(Rect(circle.x + (d - icon) / 2 + d * 0.04, circle.y + (d - icon) / 2, icon, icon), "play",
               (1, 1, 1, 1))
        duration = self.video["duration"]
        dw = r.text_width(duration, 10.5, "Bold") + 12
        chip = Rect(thumb.right - dw - 6, thumb.y + 6, dw, 18)
        r.rect(chip, th.canvas[:3] + (0.88,), radius=2)
        r.text(chip, duration, th.text, size=10.5, weight="Bold", align="CENTER")
        title = self.video["title"].get(self.lang) or self.video["title"]["EN"]
        desc = self.video["desc"].get(self.lang) or self.video["desc"]["EN"]
        r.text(Rect(rect.x + 12, rect.y + self.TEXT_H - 32, rect.w - 24, 20), title,
               mix(th.text, GOLD_TITLE, h), size=14.5, weight="Bold")
        lines = wrap_text(r, desc, rect.w - 24, 11.5)[:2]
        top = rect.y + self.TEXT_H - 40
        for line in lines:
            r.text(Rect(rect.x + 12, top - 16, rect.w - 24, 16), line, th.text_muted, size=11.5)
            top -= 16

    def on_click(self, f, x, y):
        self.callback(f)


class Pill(Widget):
    def __init__(self, text, color):
        super().__init__(style=Style(height=20.0))
        self.text, self.color = text.upper(), color

    def measure(self, f, max_w):
        return (min(max_w, f.renderer.text_width(self.text, 9.5, "Title", 0.6) + 16), 20.0)

    def draw(self, f):
        r, rect = f.renderer, self.rect
        w = min(rect.w, r.text_width(self.text, 9.5, "Title", 0.6) + 16)
        box = Rect(rect.x, rect.y + (rect.h - 18) / 2, w, 18)
        r.rect(box, self.color[:3] + (0.16,), radius=2, border=self.color[:3] + (0.6,))
        r.text(box, self.text, self.color, size=9.5, weight="Title", tracking=0.6, align="CENTER")


class VersionLabel(Widget):
    def __init__(self, text):
        super().__init__(style=Style(height=34.0))
        self.text = text

    def draw(self, f):
        f.renderer.text(self.rect, self.text, GOLD_TITLE, size=26.0, weight="Title", tracking=0.6,
                        shadow=((0, 0, 0, 0.5), 1.0, -1.5))


# --------------------------------------------------------------------------
# Páginas
# --------------------------------------------------------------------------

def _grid(widgets, cols, tile_w, tile_h, gap, filler=None, min_rows=0):
    rows = []
    count = max(len(widgets), min_rows * cols)
    count = -(-count // cols) * cols if filler else len(widgets)
    for start in range(0, max(count, 0), cols):
        cells = []
        for i in range(start, start + cols):
            if i < len(widgets):
                cells.append(widgets[i])
            elif filler is not None:
                cells.append(filler(Style(width=tile_w, height=tile_h)))
            else:
                cells.append(Spacer(size=tile_w))
        rows.append(Row(cells, style=Style(height=tile_h, gap=gap)))
    return Column(rows, style=Style(gap=gap))


def _cols(inner_w, min_w, gap, lo, hi):
    cols = int(clamp((inner_w + gap) // (min_w + gap), lo, hi))
    return cols, (inner_w - gap * (cols - 1)) / cols


def page_recent(ui):
    t, m = ui.t, ui.m
    items = data.recent_files()
    if not items:
        return [card(Paragraph(t("home.recent.empty"), size=13, color=ui.theme.text_muted))]
    content = []
    last = items[0]
    hero_h = clamp(m.inner_w * 0.24, 170.0, 250.0)
    thumb_w = hero_h * 16 / 10
    info_w = m.inner_w - 20 - thumb_w - 18 - 8               # card (padding) - miniatura - gap - padding
    button_w = clamp((info_w - 8) / 2, 110.0, 190.0)
    info = [
        Label(t("home.recent.last").upper(), size=11.5, weight="Title", color=GOLD_TITLE, style=Style(height=18)),
        _TitleLine(last["name"].upper()),
        Paragraph(last["path"], size=11, color=ui.theme.text_muted, style=Style()),
        Label(t("home.recent.modified").format(when=data.relative_time(last["mtime"], t))
              + ("  ·  " + data.human_size(last["size"]) if last["exists"] else ""),
              size=12, color=ui.theme.text, style=Style(height=20)),
        Spacer(),
        Row(ActionButton("home.resume", t("home.recent.resume"),
                         lambda f, p=last["path"]: actions.open_file(f, p), icon="play", variant="primary",
                         enabled=last["exists"], style=Style(width=button_w, height=38)),
            ActionButton("home.folder", t("home.recent.open_folder"),
                         lambda f, d=last["folder"]: actions.open_folder(f, d), icon="folder",
                         variant="secondary", enabled=last["exists"], style=Style(width=button_w, height=38)),
            style=Style(gap=8, height=38)),
    ]
    hero = Row(ThumbBox(last, t, Style(width=thumb_w, height=hero_h)),
               Column(info, style=Style(flex=1, gap=6, padding=(4, 4, 4, 2))),
               style=Style(height=hero_h, gap=18))
    content.append(card(hero, key="home.hero"))
    rest = items[1:]
    gap = 16.0
    cols, tile_w = _cols(m.inner_w, 210.0, gap, 2, 5)
    tile_h = tile_w * 297.0 / 311.0
    tiles = [FileTile("home.file.%d" % i, item, t, (lambda f, p=item["path"]: actions.open_file(f, p)),
                      Style(width=tile_w, height=tile_h)) for i, item in enumerate(rest)]
    if rest:
        content.append(SectionLabel(t("home.recent.more"), str(len(rest))))
    content.append(_grid(tiles, cols, tile_w, tile_h, gap, filler=lambda st: EmptyTile(style=st), min_rows=1))
    return content


class _TitleLine(Widget):
    def __init__(self, text):
        super().__init__(style=Style(height=30.0))
        self.text = text

    def draw(self, f):
        r = f.renderer
        size, tracking = fit_text(r, self.text, self.rect.w, 22.0, "Title", 0.6, min_size=13.0)
        r.text(self.rect, self.text, f.theme.text, size=size, weight="Title", tracking=tracking)


def page_characters(ui):
    t, m, st = ui.t, ui.m, ui.f.state
    gap = 18.0
    cols, tile_w = _cols(m.inner_w, 190.0, gap, 3, 6)
    tile_h = tile_w * 1.3
    selected = st.get("home.character")

    def pick(ident, name):
        def run(f):
            f.state["home.character"] = ident
            f.toast(t("home.characters.soon").format(name=name))
        return run
    tiles = [CharacterTile("home.char." + ident, name,
                           t("home.characters.kind_player") if kind == "player" else t("home.characters.kind_creature"),
                           ident == selected, pick(ident, name), Style(width=tile_w, height=tile_h))
             for ident, name, kind in data.CHARACTERS]
    return [_grid(tiles, cols, tile_w, tile_h, gap)]


def page_learning(ui):
    m = ui.m
    gap = 18.0
    cols, tile_w = _cols(m.inner_w, 300.0, gap, 1, 4)
    tile_h = (tile_w - 16) * 9 / 16 + VideoCard.TEXT_H + 8
    cards = [VideoCard("home.video.%d" % i, video, ui.lang, (lambda f, u=video["url"]: actions.open_url(f, u)),
                       Style(width=tile_w, height=tile_h)) for i, video in enumerate(data.VIDEOS)]
    return [_grid(cards, cols, tile_w, tile_h, gap)]


_MONTHS = {"EN": ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"),
           "PT_BR": ("jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez")}
_PARSED = {}            # (tag, corpo) -> blocos do markdown (build roda a cada redesenho)


def _release_date(iso, lang):
    """"2026-09-30T12:00:00Z" -> "Sep 30, 2026" / "30 set 2026"."""
    try:
        year, month, day = int(iso[0:4]), int(iso[5:7]), int(iso[8:10])
    except (TypeError, ValueError):
        return ""
    names = _MONTHS.get(lang, _MONTHS["EN"])
    return ("%d %s %d" % (day, names[month - 1], year)) if lang == "PT_BR" else (
        "%s %d, %d" % (names[month - 1], day, year))


def _blocks(release):
    key = (release.get("tag_name"), release.get("body"))
    if key not in _PARSED:
        if len(_PARSED) > 64:
            _PARSED.clear()
        _PARSED[key] = markdown.parse(release.get("body") or "")
    return _PARSED[key]


def page_changelog(ui):
    t, th = ui.t, ui.theme
    items = releases.releases()
    state, error, fetched_at = releases.status()
    content = []

    # linha de status: o que aconteceu com o GitHub + atualizar + todas as versões
    notes = {"loading": t("home.changelog.loading"), "offline": t("home.changelog.offline"),
             "error": t("home.changelog.error")}
    info = notes.get(state, "")
    if not info and fetched_at:
        info = t("home.changelog.updated").format(when=data.relative_time(fetched_at, t))
    refresh = Button("home.log.refresh", "", lambda f: releases.refresh(force=True), icon="refresh",
                     variant="ghost", enabled=state != "loading" and releases.online_allowed(),
                     tooltip=t("home.changelog.refresh"), style=Style(width=28, height=28))
    all_versions = ActionButton("home.log.all", t("home.changelog.all"),
                                lambda f: actions.open_url(f, releases.PAGE_URL), icon="external",
                                variant="secondary", style=Style(width=200, height=30))
    content.append(Row(Label(info, size=11.5, weight="Medium",
                             color=th.warning if state in ("offline", "error") else th.text_muted,
                             style=Style(flex=1, height=30)),
                       refresh, all_versions, style=Style(gap=8, height=30, align="center")))

    if not items:
        message = t("home.changelog.empty_offline") if state == "offline" else t("home.changelog.empty")
        content.append(card(Paragraph(message, size=13, color=th.text_muted)))
        return content

    latest = next((r for r in items if not r.get("prerelease")), None)
    for i, release in enumerate(items):
        tag = release.get("tag_name") or "?"
        title = (release.get("name") or "").strip()
        left = [VersionLabel(tag if tag.lower().startswith("v") else "v" + tag)]
        if title and title.lower() not in (tag.lower(), "v" + tag.lower(), tag.lower().lstrip("v")):
            left.append(Paragraph(title, size=12, weight="Bold", color=th.text))
        date = _release_date(release.get("published_at"), ui.lang)
        if date:
            left.append(Label(date.upper(), size=11, weight="Bold", color=th.text_muted, style=Style(height=16)))
        if release is latest:
            left.append(Pill(t("home.changelog.latest"), GOLD_TITLE))
        if release.get("prerelease"):
            left.append(Pill(t("home.changelog.prerelease"), th.warning))
        blocks = _blocks(release)
        body = RichText("home.log.text.%d" % i, blocks, on_link=actions.open_url,
                        cache_key=(release.get("tag_name"), release.get("body"))) if blocks else \
            Label(t("home.changelog.no_notes"), size=12, color=th.text_muted, style=Style(height=20))
        right = Column([body, Row(
            Spacer(),
            ActionButton("home.log.%d" % i, t("home.changelog.github"),
                         lambda f, u=release.get("html_url") or releases.PAGE_URL: actions.open_url(f, u),
                         icon="external", variant="secondary", style=Style(width=190, height=34)),
            style=Style(height=34))], style=Style(flex=1, gap=10))
        content.append(card(Row(Column(left, style=Style(width=170, gap=6)), right,
                                style=Style(gap=18, align="start")), key="home.log.card.%d" % i))
    return content


_PAGES = {"RECENT": ("home.nav.recent", "home.recent.title", "home.recent.subtitle", page_recent),
          "CHARACTERS": ("home.nav.characters", "home.characters.title", "home.characters.subtitle",
                         page_characters),
          "LEARNING": ("home.nav.learning", "home.learning.title", "home.learning.subtitle", page_learning),
          "CHANGELOG": ("home.nav.changelog", "home.changelog.title", "home.changelog.subtitle", page_changelog)}


# --------------------------------------------------------------------------
# build
# --------------------------------------------------------------------------

class _UI:
    def __init__(self, f, m):
        self.f, self.m, self.theme = f, m, f.theme
        self.lang = home_pkg.language(f.context)

    def t(self, key):
        return home_pkg.t(key, self.lang)


def toast(f, m):
    data_ = f.state.get("_toast")
    if not data_:
        return None
    text, born, error = data_
    age = f.now - born
    if age > 2.8:
        f.state.pop("_toast", None)
        return None
    if age < 0.2 or age > 2.4:
        f.state["_motion_active"] = True
    else:
        f.wake_at(born + 2.4)
    alpha = max(0.0, min(1.0, age / 0.15, (2.8 - age) / 0.4))
    return Placed(_Toast(text, error, alpha), lambda mm: Rect(mm.panel.x + mm.panel.w / 2 - 220,
                                                              mm.panel.y + 30, 440, 34))


class _Toast(Widget):
    def __init__(self, text, error, alpha):
        super().__init__()
        self.text, self.error, self.alpha = text, error, alpha

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        old, r.opacity = r.opacity, r.opacity * self.alpha
        r.shadow(rect, 4, th.shadow, blur=10, dy=-2)
        if not skin(f, rect, "inset_light"):
            r.rect(rect, th.surface_raised, radius=4, border=th.border)
        r.rect(rect, th.canvas[:3] + (0.6,), radius=3)
        color = th.danger if self.error else GOLD_TITLE
        r.icon(Rect(rect.x + 12, rect.y + (rect.h - 14) / 2, 14, 14), "error" if self.error else "info", color)
        r.text(Rect(rect.x + 34, rect.y, rect.w - 44, rect.h), self.text, color, size=12, weight="Bold")
        r.opacity = old


def _left_column(ui, m, page, go, nav_size):
    """Logo, NOVO/ABRIR, menu, secundários e "Mostrar ao abrir". `nav_size`
    menor = tudo mais compacto (o build reduz até caber na altura da tela)."""
    t = ui.t
    k = nav_size / clamp(m.h * 0.027, 21.0, 30.0)          # 1 = tamanho normal; < 1 = tela baixa
    column_w = m.left_w - m.left_pad - 28
    logo = Logo(m.left_w - m.left_pad, t("home.subtitle"), "v%s" % addon_version())
    logo_w = logo.fit(ui.f, column_w)
    button_w = min(300.0, logo_w * 0.82, column_w)
    offset = max(0.0, (logo_w - button_w) / 2)              # NOVO/ABRIR centralizados embaixo do HYBLEND
    nav_h = nav_size * 2.0
    button_h = clamp(42 * k, 32.0, 42.0)

    def centered(widget):
        return Row(Spacer(size=offset), widget, style=Style(height=button_h, gap=0))
    return Column([
        Spacer(size=m.h * 0.07 * k),
        logo,
        Spacer(size=26 * k),
        centered(ActionButton("home.new", t("home.new"), actions.new_file, icon="plus", variant="primary",
                              tooltip=t("home.tooltip.new"), style=Style(width=button_w, height=button_h))),
        centered(ActionButton("home.open", t("home.open"), actions.open_dialog, icon="folder",
                              variant="secondary", tooltip=t("home.tooltip.open"),
                              style=Style(width=button_w, height=button_h))),
        Spacer(size=m.h * 0.055 * k),
    ] + [MenuItem("home.nav." + ident, t(_PAGES[ident][0]), go(ident), active=(ident == page),
                  size=nav_size, height=nav_h, enabled=ident not in COMING_SOON,
                  tooltip=t("home.tooltip.soon") if ident in COMING_SOON else None) for ident in PAGES] + [
        Spacer(),
        MenuItem("home.nav.prefs", t("home.nav.preferences"), actions.preferences, size=nav_size * 0.72,
                 height=nav_h * 0.72, tooltip=t("home.tooltip.preferences")),
        MenuItem("home.nav.close", t("home.nav.close"), lambda f: host.close_home(), size=nav_size * 0.72,
                 height=nav_h * 0.72, tooltip=t("home.tooltip.close")),
        Spacer(size=14 * k),
        Row(CheckBox("home.startup", home_pkg.show_on_startup(), lambda f, v: home_pkg.set_show_on_startup(v),
                     tooltip=t("home.tooltip.show_on_startup")),
            CheckLabel("home.startup.label", t("home.show_on_startup"), style=Style(height=26)),   # só a caixinha clica
            style=Style(gap=2, align="center", height=28)),
        Spacer(size=30),                                  # espaço da assinatura TRUPE FORGE
    ], style=Style(gap=6 * k))


def build(f):
    game.sync()
    screen = f.host.screen
    m = Metrics(screen.w, screen.h)
    ui = _UI(f, m)
    t, th, st = ui.t, f.theme, f.state

    page = st.get("home.page") or _session["page"]
    if page not in PAGES or page in COMING_SOON:
        page = "RECENT"
    if st.get("home.page.last") != page:
        st["home.page.last"] = page
        forget(st, "home.page.enter")
    enter = f.animate("home.page.enter", 1.0, 0.3, initial=0.0)

    def go(ident):
        def run(f):
            f.state["home.page"] = _session["page"] = ident
        return run

    # ---- coluna da esquerda (encolhe o menu/espaços até caber na altura)
    left_w = m.left_w - m.left_pad - 28
    avail_h = m.h - 2 * m.margin
    nav_size = clamp(m.h * 0.027, 21.0, 30.0)
    for _ in range(8):
        left = _left_column(ui, m, page, go, nav_size)
        if left.extent(f, left_w)[1] <= avail_h or nav_size <= 13.0:
            break
        nav_size *= 0.88

    # ---- painel da direita
    title_key, sub_key, builder = _PAGES[page][1], _PAGES[page][2], _PAGES[page][3]
    try:
        content = builder(ui)
    except Exception as error:                       # página quebrada não derruba a Home
        import traceback
        traceback.print_exc()
        content = [Label("%s %s" % (t("home.error_prefix"), error), color=th.danger, size=12)]
    page_column = Column([c for c in content if c is not None], style=Style(gap=16, padding=(0, 4, 0, 12)))
    body = PanelBody([
        Row(PageTitle(t(title_key), t(sub_key)), style=Style(height=62)),
        Divider(),
        ScrollView("home.scroll." + page, Fade(page_column, alpha=enter, dy=-10.0 * (1.0 - enter)),
                   style=Style(flex=1, min_height=80)),
    ], key="home.body", style=Style(padding=m.body_pad, gap=10, flex=1,
                                    frame=game.frame_style("frame"), frame_base=th.canvas,
                                    background=th.canvas, border=th.border, radius=4, shadow=True))
    panel = PanelFrame([Ornament(game.art("ornament")[0], base=th.canvas), body,
                        Ornament(game.art("ornament_bottom")[0], bottom=True, base=th.canvas)],
                       key="home.panel", style=Style(gap=0))

    # ---- soltos: fechar, selo WIP, dica do Esc, assinatura
    close = Placed(Button("home.close", "", lambda f: host.close_home(), icon="close", variant="ghost",
                          tooltip=t("home.tooltip.close"), style=Style(width=30, height=30)),
                   lambda mm: Rect(mm.w - mm.margin - 30, mm.h - mm.margin / 2 - 15, 30, 30))
    wip = Placed(WipBadge(t("home.tooltip.wip")),
                 lambda mm: Rect(mm.panel.right - 54, mm.panel.y - 20, 72, 72))
    hint = Placed(FreeText(t("home.hint_esc"), 11.0, th.text_muted[:3] + (0.75,), tracking=0.9),
                  lambda mm: Rect(mm.panel.x + 6, (mm.margin - 14) / 2, 400, 14))
    signature = Placed(FreeText("TRUPE FORGE", 17.0, (1, 1, 1, 0.16), tracking=1.4),
                       lambda mm: Rect(16, 12, 300, 18))
    return HomeScreen(m, Background(), left, panel, [close, hint, signature, wip, toast(f, m), context_menu(f)])
