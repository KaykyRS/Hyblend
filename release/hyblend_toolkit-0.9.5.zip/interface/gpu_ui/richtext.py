"""RichText: desenha os blocos de gpu_ui/markdown.py com quebra de linha entre
trechos de estilos diferentes. Python puro + renderer (nada de bpy).

  títulos h1/h2   Lexend dourado em caixa alta (como os títulos do jogo)
  h3              Lexend no branco; h4-h6 negrito cinza
  **negrito**     Nunito ExtraBold      *itálico*  inclinado pelo renderer
  ~~riscado~~     linha no meio         `código`   fundo escuro
  [link](url)     azul claro sublinhado -- CLICÁVEL (abre no navegador)
  listas          • / ◦ por nível, 1. 2. numeradas, [x] tarefas
  > citação       barra dourada à esquerda, itálico
  ```código```    caixa escura          ---  linha    | tabela |
"""

import re

from .framework.core import Rect, Widget
from .framework.motion import mix
from .app import GOLD_TITLE, _rgb as rgb

LINK = rgb("#8fc3ff")
LINK_HOVER = rgb("#c2ddff")
CODE_TEXT = rgb("#f0d9a8")

# bloco -> (tamanho, peso, caixa alta, cor ("text"/"muted"/"gold"), espaço antes, espaço depois)
_HEADINGS = {1: (18.0, "Title", True, "gold", 10, 6), 2: (15.0, "Title", True, "gold", 10, 5),
             3: (13.5, "Title", False, "text", 8, 4), 4: (12.5, "Bold", False, "muted", 6, 3),
             5: (12.0, "Bold", False, "muted", 6, 3), 6: (11.5, "Bold", False, "muted", 6, 3)}
BODY = 12.5
LINE = 1.5                     # altura da linha = tamanho * LINE
INDENT = 18.0                  # por nível de lista
_WORDS = re.compile(r"\n|[ \t]+|[^ \t\n]+")


_LAYOUTS = {}          # (cache_key, largura, escala, tema) -> (ops, links, altura): a árvore é nova a
                       # cada quadro, o layout do texto não precisa ser


class RichText(Widget):
    """`cache_key` identifica o CONTEÚDO (ex.: tag + corpo da release): com ele
    o layout (medir cada palavra) é feito uma vez e reaproveitado em todos os
    quadros seguintes -- rolar/passar o mouse não refaz nada."""
    interactive = True

    def __init__(self, key, blocks, on_link=None, style=None, cache_key=None):
        super().__init__(key, style)
        self.blocks, self.on_link, self.cache_key = blocks, on_link, cache_key
        self._for_width = None
        self._ops, self._links, self._height = [], [], 0.0

    # ---------------------------------------------------------------- layout
    def _extent(self, f, width):
        self._build(f, width)
        return (self._height, self._height, self._height)

    def measure(self, f, max_w):
        return (max_w, self.extent(f, max_w)[1])

    def _build(self, f, width):
        if self._for_width == width:
            return
        self._for_width = width
        key = None
        if self.cache_key is not None:
            key = (self.cache_key, round(width, 1), f.renderer.scale, id(f.theme))
            hit = _LAYOUTS.get(key)
            if hit is not None:
                self._ops, self._links, self._height = hit
                return
        self._layout_blocks(f, width)
        self._merge_runs()
        if key is not None:
            if len(_LAYOUTS) > 256:
                _LAYOUTS.clear()
            _LAYOUTS[key] = (self._ops, self._links, self._height)

    def _merge_runs(self):
        """Palavras vizinhas na MESMA linha e com o MESMO estilo viram um texto
        só: uma chamada de desenho por trecho em vez de uma por palavra."""
        merged = []
        for op in self._ops:
            if op[0] == "text" and merged and merged[-1][0] == "text":
                last = merged[-1]
                same_line = last[2] == op[2] and abs(last[1] + last[3] - op[1]) < 0.5
                if same_line and last[6:11] == op[6:11] and "code" not in op[9]:
                    merged[-1] = (last[0], last[1], last[2], last[3] + op[3], last[4], last[5] + op[5]) + last[6:]
                    continue
            merged.append(op)
        # espaço sobrando no fim de cada trecho não precisa de desenho nem sublinhado
        self._ops = [op[:3] + (op[3] - (op[3] / max(len(op[5]), 1)) * (len(op[5]) - len(op[5].rstrip())),
                               op[4], op[5].rstrip()) + op[6:]
                     if op[0] == "text" and op[5] != op[5].rstrip() and op[5].strip() else op
                     for op in merged]

    def _layout_blocks(self, f, width):
        self._ops, self._links = [], []
        self._f, self._y = f, 0.0
        th = f.theme
        colors = {"text": mix(th.text, th.text_muted, 0.15), "muted": th.text_muted, "gold": GOLD_TITLE}
        first = True
        for block in self.blocks:
            kind = block[0]
            if kind == "h":
                size, weight, upper, color, before, after = _HEADINGS[block[1]]
                if not first:
                    self._y += before
                self._flow(block[2], 0.0, width, size, weight, colors[color], upper=upper)
                if block[1] <= 2:                                   # filete embaixo de h1/h2
                    self._ops.append(("rect", 0.0, self._y + 3, width, 1.0, th.border[:3] + (0.45,)))
                    self._y += 4
                self._y += after
            elif kind == "p":
                self._flow(block[1], 0.0, width, BODY, "Regular", colors["text"])
                self._y += 7
            elif kind == "li":
                _, depth, ordered, checked, spans = block
                x = depth * INDENT
                top = self._y
                line_h = BODY * LINE
                if checked is not None:
                    self._ops.append(("check", x, top, line_h, checked))
                elif ordered is not None:
                    self._ops.append(("text", x, top, 18.0, line_h, ordered + ".", BODY, "Bold", GOLD_TITLE,
                                      frozenset(), None))
                else:
                    self._ops.append(("bullet", x, top, line_h, depth))
                self._flow(spans, x + 18.0, width - x - 18.0, BODY, "Regular", colors["text"])
                self._y += 3
            elif kind == "quote":
                top = self._y
                self._y += 4
                self._flow(block[1], 14.0, width - 14.0, BODY, "Regular", colors["muted"], force=frozenset({"i"}))
                self._y += 4
                self._ops.append(("rect", 2.0, top, 3.0, self._y - top, GOLD_TITLE[:3] + (0.7,)))
                self._ops.insert(0, ("rect", 0.0, top, width, self._y - top, (1, 1, 1, 0.03)))
                self._y += 7
            elif kind == "code":
                top = self._y
                line_h = 11.5 * LINE
                self._y += 8
                for line in block[1] or [""]:
                    self._ops.append(("text", 12.0, self._y, width - 24, line_h, line.replace("\t", "    "), 11.5,
                                      "Medium", CODE_TEXT, frozenset(), None))
                    self._y += line_h
                self._y += 8
                self._ops.insert(0, ("box", 0.0, top, width, self._y - top))
                self._y += 8
            elif kind == "hr":
                self._y += 6
                self._ops.append(("rect", 0.0, self._y, width, 1.0, th.border[:3] + (0.7,)))
                self._y += 9
            elif kind == "table":
                self._table(block[1], width, colors)
                self._y += 8
            first = False
        self._height = max(0.0, self._y - 4)

    def _table(self, rows, width, colors):
        cols = max(len(r) for r in rows)
        cw = width / max(cols, 1)
        th = self._f.theme
        for index, row in enumerate(rows):
            top = self._y
            bottom = top
            for c in range(cols):
                spans = row[c] if c < len(row) else []
                self._y = top + 5
                self._flow(spans, c * cw + 8, cw - 16, BODY - 0.5, "Bold" if index == 0 else "Regular",
                           colors["text"] if index else GOLD_TITLE)
                bottom = max(bottom, self._y + 5)
            if index == 0:
                self._ops.insert(0, ("rect", 0.0, top, width, bottom - top, (1, 1, 1, 0.04)))
            self._ops.append(("rect", 0.0, bottom, width, 1.0, th.border[:3] + (0.5 if index else 0.8,)))
            self._y = bottom + 1

    def _flow(self, spans, x0, width, size, weight, color, upper=False, force=frozenset()):
        """Trechos -> linhas (quebra por palavra, trocando de fonte no meio)."""
        r = self._f.renderer
        line_h = size * LINE
        x, line_start = x0, True
        run = None          # trecho corrente (mesma linha + mesmo estilo): [chave, y, x inicial, texto]
        for text, styles, url in spans:
            styles = styles | force
            for word in _WORDS.findall(text.upper() if upper else text):
                if word == "\n":
                    x, line_start = x0, True
                    self._y += line_h
                    continue
                w_weight = "Bold" if ("b" in styles and weight not in ("Title", "Bold")) else weight
                w_size = size * 0.92 if "code" in styles else size
                width_w = r.text_width(word, w_size, w_weight)
                while not word.isspace() and width_w > width and len(word) > 1:
                    # palavra/URL maior que a linha inteira: quebra no caractere que couber
                    if not line_start:
                        x, line_start = x0, True
                        self._y += line_h
                    cut = len(word) - 1
                    while cut > 1 and r.text_width(word[:cut], w_size, w_weight) > width:
                        cut -= 1
                    piece_w = r.text_width(word[:cut], w_size, w_weight)
                    self._ops.append(("text", x, self._y, piece_w, line_h, word[:cut], w_size, w_weight, color,
                                      styles, url))
                    if url:
                        self._links.append((x, self._y, piece_w, line_h, url))
                    self._y += line_h
                    word = word[cut:]
                    width_w = r.text_width(word, w_size, w_weight)
                if word.isspace():
                    if line_start:
                        continue
                    if x + width_w > x0 + width:
                        continue
                elif x + width_w > x0 + width and not line_start:
                    x, line_start = x0, True
                    self._y += line_h
                # Posição pela largura do TRECHO acumulado, não pela soma das palavras:
                # o trecho é desenhado de uma vez (_merge_runs) e o kerning entre as
                # letras o deixa um pouco mais curto -- somando palavras sobrava um vão
                # antes da próxima troca de estilo ("2 *3*").
                run_key = (w_size, w_weight, color, styles, url)
                if (run is not None and run[0] == run_key and run[1] == self._y and "code" not in styles
                        and abs(run[2] + r.text_width(run[3], w_size, w_weight) - x) < 0.5):
                    full = run[3] + word
                    width_w = run[2] + r.text_width(full, w_size, w_weight) - x
                    run[3] = full
                else:
                    run = [run_key, self._y, x, word]
                self._ops.append(("text", x, self._y, width_w, line_h, word, w_size, w_weight, color, styles, url))
                if url and not word.isspace():
                    self._links.append((x, self._y, width_w, line_h, url))
                x += width_w
                line_start = False
        self._y += line_h

    # ---------------------------------------------------------------- desenho
    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        self._build(f, rect.w)

    def _link_at(self, x, y):
        top = self.rect.top
        for lx, ly, lw, lh, url in self._links:
            if self.rect.x + lx <= x <= self.rect.x + lx + lw and top - ly - lh <= y <= top - ly:
                return url
        return None

    def hit(self, x, y):
        return self if self.visible_at(x, y) and self._link_at(x, y) else None

    def on_click(self, f, x, y):
        url = self._link_at(x, y)
        if url and self.on_link:
            self.on_link(f, url)

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        left, top = rect.x, rect.top
        if self._links:
            f.track_mouse(rect)            # só texto com link reage à posição do mouse
        mx, my = f.mouse
        hover_url = self._link_at(mx, my) if (self._links and f.hover == self.key) else None
        # faixa visível (rolagem): só desenha o que cruza a área recortada
        vis_top, vis_bottom = (self.clip.top, self.clip.y) if self.clip is not None else (top, rect.y)
        for op in self._ops:
            kind = op[0]
            y, h = op[2], (op[4] if kind in ("rect", "box", "text") else op[3])
            if top - y - h > vis_top or top - y < vis_bottom:
                continue
            if kind == "rect":
                _, x, y, w, h, color = op
                r.rect(Rect(left + x, top - y - h, w, h), color)
            elif kind == "box":
                _, x, y, w, h = op
                r.rect(Rect(left + x, top - y - h, w, h), th.canvas[:3] + (0.75,), radius=3, border=th.border)
            elif kind == "bullet":
                _, x, y, line_h, depth = op
                d = 5.0 if depth == 0 else 4.0
                box = Rect(left + x + 4, top - y - line_h / 2 - d / 2, d, d)
                if depth == 0:
                    r.rect(box, GOLD_TITLE, radius=1)
                else:
                    r.rect(box, (0, 0, 0, 0), radius=1, border=GOLD_TITLE[:3] + (0.8,))
            elif kind == "check":
                _, x, y, line_h, checked = op
                box = Rect(left + x + 1, top - y - line_h / 2 - 6, 12, 12)
                r.rect(box, th.input, radius=2, border=GOLD_TITLE[:3] + (0.8 if checked else 0.4,))
                if checked:
                    r.icon(box.inset(2, 2, 2, 2), "check", GOLD_TITLE)
            elif kind == "text":
                _, x, y, w, h, word, size, weight, color, styles, url = op
                box = Rect(left + x, top - y - h, w + 6, h)
                if "code" in styles:
                    r.rect(Rect(box.x - 1, box.y + h * 0.14, w + 2, h * 0.72), th.input, radius=2)
                    color = CODE_TEXT
                if url:
                    color = LINK_HOVER if url == hover_url else LINK
                if word.isspace():
                    continue
                r.text(box, word, color, size=size, weight=weight, truncate=w + 6 < r.text_width(word, size, weight),
                       italic="i" in styles)
                base = box.y + (h - size * 0.71) / 2
                if url:
                    r.rect(Rect(box.x, base - 2, w, 1.0), color[:3] + (0.8,))
                if "s" in styles:
                    r.rect(Rect(box.x, base + size * 0.3, w, 1.2), color)
