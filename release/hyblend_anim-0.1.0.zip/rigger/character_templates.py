"""Auto-Rigger -- Character Templates: save/apply/delete de Rig/Shape/Collection Template."""

import math

import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from ..common import is_active_armature
from ..templates import (
    delete_collection_template,
    delete_rig_template,
    delete_shape_template,
    get_collection_template,
    get_shape_template,
    list_collection_templates,
    list_rig_templates,
    list_shape_templates,
    save_collection_template,
    save_rig_template,
    save_shape_template,
    template_source,
)
from ..translations import get_language, localized_props, tooltip, tr

from .constants import (
    BONE_ROOT_MASTER,
    BONE_ROOT_PELVIS,
    BONE_ROOT_SPINE,
    HEAD_COLLECTION_ROOT,
    PROP_RIG_LAYER,
    PROP_WIDGET_SOURCE_ROLE,
    RESERVED_MAIN_COLLECTION_NAMES,
    ROOT_MASTER_PARENT,
    WGT_DEFAULT_FALLBACK,
    _TEMPLATE_NONE,
)

from .helpers import _find_bone_collection_anywhere, _iter_all_collections, _redraw_all_areas, ensure_bone_collection
from .widgets import _mesh_object_to_dict, _widget_mesh_differs_from_template, resolve_custom_shape_scale
from .bone_collections import SECTION_ROOT, ensure_default_bone_collections, ensure_default_bone_section_backfill, sync_bone_collection_order
from .bone_settings import _IK_CHAIN_JSON_FIELDS
from .rename import BONE_NAME_FIELDS, map_bone_name, renamed_bone_names


def _shape_template_apply_props(lang):
    return {
        "template": StringProperty(
            name="Shape Template",
            default="",
            description=tr("rigger.prop.shape_template_apply_template", lang),
            options={"HIDDEN", "SKIP_SAVE"},
        ),
    }


@localized_props(_shape_template_apply_props)
class RIG_OT_hytale_shape_template_apply(Operator):
    """Troca só o Shape Template ativo (rode o Create Rig depois); "(none)" volta pro genérico da biblioteca."""

    bl_idname = "armature.hytale_shape_template_apply"
    bl_label = "Set Hytale Shape Template"
    description = tooltip("rigger.tooltip.shape_template_apply")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def execute(self, context):
        template_name = self.template or context.window_manager.hytale_shape_template_selected
        if not template_name:
            self.report({"WARNING"}, "No shape template selected.")
            return {"CANCELLED"}
        if template_name == _TEMPLATE_NONE:
            # Só grava a property; quem aplica é o próximo Create Rig.
            context.active_object.data.hytale_active_shape_template = ""
            self.report(
                {"INFO"},
                "Active shape template cleared -- run 'Create Rig' again to build shapes from scratch, "
                "without any per-character override.",
            )
            return {"FINISHED"}
        if get_shape_template(template_name) is None:
            self.report({"WARNING"}, f"Unknown shape template '{template_name}'.")
            return {"CANCELLED"}
        context.active_object.data.hytale_active_shape_template = template_name
        self.report(
            {"INFO"}, f"Active shape template set to '{template_name}' -- run 'Create Rig' again to apply.",
        )
        return {"FINISHED"}


# Seleção de template (Rig/Shape/Collection) no WindowManager; o item só é apagável se for do usuário.


def _template_source(list_func, name):
    """"builtin"/"user" do template `name` segundo `list_func()`, ou
    None se `name` não corresponder a nenhum template conhecido."""
    for entry in list_func():
        if entry["name"] == name:
            return entry["source"]
    return None


# Base comum dos 3 operadores Delete Template (só muda o Enum lido, as funções e o nome do tipo).
def _poll_user_template(context, wm_attr, list_func):
    name = getattr(context.window_manager, wm_attr)
    return bool(name) and _template_source(list_func, name) == "user"


def _execute_template_delete(operator, context, wm_attr, delete_func, kind_label):
    name = getattr(context.window_manager, wm_attr)
    if not delete_func(name):
        operator.report({"WARNING"}, f"Could not delete {kind_label} template '{name}' (builtin, or already gone).")
        return {"CANCELLED"}
    operator.report({"INFO"}, f"Deleted {kind_label} template '{name}'.")
    return {"FINISHED"}


# Base comum dos 3 operadores Save Template (diálogo com o nome; sugere o template ativo).
def _invoke_template_save_dialog(operator, context, active_template_attr):
    operator.template_name = getattr(context.active_object.data, active_template_attr) or "New Character"
    return context.window_manager.invoke_props_dialog(operator)


def _draw_template_save_dialog(operator, context, kind):
    layout = operator.layout
    layout.prop(operator, "template_name")
    source = template_source(kind, operator.template_name.strip())
    if source is not None:
        key = "panel.template_save_replaces_builtin" if source == "builtin" else "panel.template_save_replaces"
        layout.label(text=tr(key, get_language(context)), icon="ERROR")


def _require_template_name(operator):
    if not operator.template_name.strip():
        operator.report({"WARNING"}, "Template name cannot be empty.")
        return False
    return True


# Bones utilitários (não derivam de nenhuma cadeia IK) que também
# recebem custom shape e fazem sentido salvar num template de shapes.
_UTILITY_SHAPE_BONES = (BONE_ROOT_MASTER, BONE_ROOT_SPINE, BONE_ROOT_PELVIS, HEAD_COLLECTION_ROOT, ROOT_MASTER_PARENT)


class RIG_OT_hytale_rig_template_save(Operator):
    """Salva o Bone Settings (+ Continuous Chain e Rename Bones) em Documentos/Hyblend/templates/rig/<nome>.json.
    Bone renomeado vai com o nome do modelo (o Load traduz numa Armature já renomeada)."""

    bl_idname = "armature.hytale_rig_template_save"
    bl_label = "Save Rig Template"
    description = tooltip("rigger.tooltip.rig_template_save")
    bl_options = {"REGISTER"}

    template_name: StringProperty(name="Template Name", default="")

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return is_active_armature(context) and len(obj.data.hytale_ik_chains) > 0

    def invoke(self, context, event):
        return _invoke_template_save_dialog(self, context, "hytale_active_rig_template")

    def draw(self, context):
        _draw_template_save_dialog(self, context, "rig")

    def execute(self, context):
        if not _require_template_name(self):
            return {"CANCELLED"}

        armature = context.active_object.data
        to_model_names = renamed_bone_names(armature)
        entries = []
        for item in armature.hytale_ik_chains:
            entry = {field: getattr(item, field) for field in _IK_CHAIN_JSON_FIELDS}
            for field in BONE_NAME_FIELDS:
                original = map_bone_name(entry.get(field), to_model_names)
                if original is not None:
                    entry[field] = original
            entries.append(entry)

        data = {
            "description": f"User-saved rig template ({len(entries)} IK chain(s)).",
            "ik_chains": entries,
            "ctrl_tail_to_child": bool(getattr(armature, "hytale_ctrl_tail_to_child", True)),
            "rename_enabled": bool(armature.hytale_rename_enabled),
            "rename_mode": armature.hytale_rename_mode,
        }
        path = save_rig_template(self.template_name, data)
        armature.hytale_active_rig_template = self.template_name
        self.report({"INFO"}, f"Saved rig template '{self.template_name}' to '{path}'.")
        return {"FINISHED"}


class RIG_OT_hytale_rig_template_delete(Operator):
    """Apaga do disco o rig template selecionado -- só templates do
    usuário (source == "user"); um builtin nunca aparece deletável."""

    bl_idname = "armature.hytale_rig_template_delete"
    bl_label = "Delete Rig Template"
    description = tooltip("rigger.tooltip.rig_template_delete")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _poll_user_template(context, "hytale_rig_template_selected", list_rig_templates)

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        return _execute_template_delete(self, context, "hytale_rig_template_selected", delete_rig_template, "rig")


class RIG_OT_hytale_shape_template_save(Operator):
    """Salva translation/rotation/scale/widget de todo controle em Documentos/Hyblend/templates/shapes/<nome>.json.
    Widget editado (_widget_mesh_differs_from_template) vai com a malha ("mesh"); os não editados seguem a biblioteca."""

    bl_idname = "armature.hytale_shape_template_save"
    bl_label = "Save Shape Template"
    description = tooltip("rigger.tooltip.shape_template_save")
    bl_options = {"REGISTER"}

    template_name: StringProperty(name="Template Name", default="")

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return is_active_armature(context) and obj.pose is not None

    def invoke(self, context, event):
        return _invoke_template_save_dialog(self, context, "hytale_active_shape_template")

    def draw(self, context):
        _draw_template_save_dialog(self, context, "shapes")

    def execute(self, context):
        if not _require_template_name(self):
            return {"CANCELLED"}

        obj = context.active_object
        bones = {}
        for pb in obj.pose.bones:
            layer = pb.bone.get(PROP_RIG_LAYER)
            if layer not in ("CTRL", "CTRL-IK", "CTRL-TWEAK") and pb.name not in _UTILITY_SHAPE_BONES:
                continue
            if pb.custom_shape is None:
                continue
            entry = {
                "translation": list(pb.custom_shape_translation),
                "rotation_deg": [math.degrees(v) for v in pb.custom_shape_rotation_euler],
                # resolve_custom_shape_scale: o tamanho cheio (o driver zera o lado inativo).
                "scale": list(resolve_custom_shape_scale(pb)),
            }
            if pb.custom_shape.name not in (WGT_DEFAULT_FALLBACK,):
                entry["widget"] = pb.custom_shape.name

            # Embute a malha só se customizada; sem PROP_WIDGET_SOURCE_ROLE sempre embute.
            if pb.custom_shape.type == "MESH":
                source_role = pb.custom_shape.get(PROP_WIDGET_SOURCE_ROLE)
                if source_role:
                    embed_mesh = _widget_mesh_differs_from_template(pb.custom_shape, source_role, obj.name)
                else:
                    embed_mesh = True
                if embed_mesh:
                    entry["mesh"] = _mesh_object_to_dict(pb.custom_shape.data)

            bones[pb.name] = entry

        if not bones:
            self.report({"WARNING"}, "No CTRL/CTRL-IK bone with a custom shape found -- nothing to save.")
            return {"CANCELLED"}

        data = {
            "description": f"User-saved shape template ({len(bones)} bone(s)).",
            "bones": bones,
        }
        path = save_shape_template(self.template_name, data)
        obj.data.hytale_active_shape_template = self.template_name
        self.report({"INFO"}, f"Saved shape template '{self.template_name}' ({len(bones)} bone(s)) to '{path}'.")
        return {"FINISHED"}


class RIG_OT_hytale_shape_template_delete(Operator):
    """Mesma ideia de RIG_OT_hytale_rig_template_delete, pra shapes/
    <nome>.json -- só templates do usuário, nunca builtin."""

    bl_idname = "armature.hytale_shape_template_delete"
    bl_label = "Delete Shape Template"
    description = tooltip("rigger.tooltip.shape_template_delete")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _poll_user_template(context, "hytale_shape_template_selected", list_shape_templates)

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        return _execute_template_delete(self, context, "hytale_shape_template_selected", delete_shape_template, "shape")


# --- Collection Templates: nome, hierarquia e membros das collections do usuário (fora as do Create Rig) ---


def _apply_collection_template_entries(armature, edit_bones, entries, report):
    """Recria as collections de `entries` ({name, parent, bones}) e reassina os bones; o pai é resolvido em várias passadas
    (a API só cria já com o pai). Pai que nunca resolve vira raiz, com aviso."""
    created = {}
    remaining = list(entries)
    progress = True
    while remaining and progress:
        progress = False
        still = []
        for entry in remaining:
            name = entry.get("name")
            if not name:
                continue
            parent_name = entry.get("parent")
            parent_coll = None
            if parent_name:
                parent_coll = created.get(parent_name) or _find_bone_collection_anywhere(armature, parent_name)
                if parent_coll is None:
                    still.append(entry)
                    continue
            created[name] = ensure_bone_collection(armature, name, parent=parent_coll)
            progress = True
        remaining = still

    for entry in remaining:
        name = entry.get("name")
        if not name:
            continue
        created[name] = ensure_bone_collection(armature, name, parent=None)
        report(
            {"WARNING"},
            f"Collection template: parent '{entry.get('parent')}' not found for '{name}' -- created at top level.",
        )

    assigned = 0
    missing_bones = set()
    for entry in entries:
        coll = created.get(entry.get("name"))
        if coll is None:
            continue
        for bone_name in entry.get("bones", []):
            bone = edit_bones.get(bone_name)
            if bone is None:
                missing_bones.add(bone_name)
                continue
            coll.assign(bone)
            assigned += 1
    return assigned, missing_bones


def _ensure_collection_settings_entry(armature, name, entry_type, report):
    """Entrada do Collection Settings com esse nome e tipo (cria se faltar); conflito de tipo: avisa e devolve None."""
    for item in armature.hytale_bone_collections:
        if item.name == name:
            if item.entry_type != entry_type:
                report(
                    {"WARNING"},
                    f"Collection template: '{name}' already exists as a {item.entry_type.title()} in "
                    f"Collection Settings on this armature -- skipped its {entry_type.title()} settings "
                    f"from the template.",
                )
                return None
            return item
    item = armature.hytale_bone_collections.add()
    item.name = name
    item.entry_type = entry_type
    return item


def _apply_collection_settings_entries(armature, collection_entries, section_entries, report):
    """Parte "Collection Settings" do template (Sections; section/show_in_animation_tab/row/column das entradas).
    Aditivo, nunca remove. Devolve quantas entradas criou/atualizou."""
    ensure_default_bone_collections(armature)
    ensure_default_bone_section_backfill(armature)

    touched = 0
    for entry in section_entries:
        name = entry.get("name")
        if not name:
            continue
        item = _ensure_collection_settings_entry(armature, name, "SECTION", report)
        if item is None:
            continue
        try:
            item.parent = entry.get("parent") or SECTION_ROOT
            item.row = int(entry.get("row", 0))
        except (TypeError, ValueError):
            pass  # campo corrompido num .json editado à mão -- não derruba o Apply
        touched += 1

    settings_fields = ("section", "show_in_animation_tab", "row", "column")
    for entry in collection_entries:
        name = entry.get("name")
        if not name or not any(field in entry for field in settings_fields):
            continue
        item = _ensure_collection_settings_entry(armature, name, "COLLECTION", report)
        if item is None:
            continue
        try:
            if "section" in entry:
                item.parent = entry.get("section") or SECTION_ROOT
            if "show_in_animation_tab" in entry:
                item.show_in_animation_tab = bool(entry.get("show_in_animation_tab", True))
            if "row" in entry:
                item.row = int(entry.get("row", 0))
            if "column" in entry:
                item.column = int(entry.get("column", 0))
        except (TypeError, ValueError):
            pass
        touched += 1

    return touched


class RIG_OT_hytale_collection_template_save(Operator):
    """Salva as collections do usuário (fora RESERVED_MAIN_COLLECTION_NAMES) e o Collection Settings delas. Sem Edit Mode."""

    bl_idname = "armature.hytale_collection_template_save"
    bl_label = "Save Collection Template"
    description = tooltip("rigger.tooltip.collection_template_save")
    bl_options = {"REGISTER"}

    template_name: StringProperty(name="Template Name", default="")

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def invoke(self, context, event):
        return _invoke_template_save_dialog(self, context, "hytale_active_collection_template")

    def draw(self, context):
        _draw_template_save_dialog(self, context, "collections")

    def execute(self, context):
        if not _require_template_name(self):
            return {"CANCELLED"}

        armature = context.active_object.data
        custom_colls = [c for c in _iter_all_collections(armature) if c.name not in RESERVED_MAIN_COLLECTION_NAMES]
        section_settings = [
            item for item in armature.hytale_bone_collections if item.entry_type == "SECTION" and item.name
        ]
        if not custom_colls and not section_settings:
            self.report(
                {"WARNING"},
                "No custom bone collection or section found (only the auto-generated ones exist) -- nothing "
                "to save. Create one first in the Armature Data Properties > Bone Collections panel, or add a "
                "Section in Collection Settings.",
            )
            return {"CANCELLED"}

        custom_names = {c.name for c in custom_colls}
        bones_by_coll = {c.name: [] for c in custom_colls}
        for bone in armature.bones:
            for coll in bone.collections:
                if coll.name in custom_names:
                    bones_by_coll[coll.name].append(bone.name)

        # Índice só entre as entradas do tipo Collection (pode faltar entrada pra alguma collection real).
        settings_by_name = {
            item.name: item for item in armature.hytale_bone_collections if item.entry_type == "COLLECTION"
        }

        entries = []
        for coll in custom_colls:
            entry = {
                "name": coll.name,
                "parent": coll.parent.name if coll.parent is not None else None,
                "bones": bones_by_coll[coll.name],
            }
            settings_item = settings_by_name.get(coll.name)
            if settings_item is not None:
                entry["section"] = settings_item.parent
                entry["show_in_animation_tab"] = settings_item.show_in_animation_tab
                entry["row"] = settings_item.row
                entry["column"] = settings_item.column
            entries.append(entry)

        section_entries = [
            {"name": item.name, "parent": item.parent, "row": item.row} for item in section_settings
        ]

        data = {
            "description": (
                f"User-saved collection template ({len(entries)} collection(s), "
                f"{len(section_entries)} section(s))."
            ),
            "collections": entries,
            "sections": section_entries,
        }
        path = save_collection_template(self.template_name, data)
        armature.hytale_active_collection_template = self.template_name
        self.report(
            {"INFO"},
            f"Saved collection template '{self.template_name}' ({len(entries)} collection(s), "
            f"{len(section_entries)} section(s)) to '{path}'.",
        )
        return {"FINISHED"}


def _collection_template_apply_props(lang):
    return {
        "template_name": StringProperty(
            name="Template",
            default="",
            description=tr("rigger.prop.collection_template_apply_template_name", lang),
            options={"HIDDEN", "SKIP_SAVE"},
        ),
    }


@localized_props(_collection_template_apply_props)
class RIG_OT_hytale_collection_template_apply(Operator):
    """Aplica o Collection Template: cria/reaproveita as collections e reassina os bones (aditivo), depois o Collection
    Settings. "(none)" só limpa o ponteiro (não há desfazer seguro; remova pela lista)."""

    bl_idname = "armature.hytale_collection_template_apply"
    bl_label = "Apply Collection Template"
    description = tooltip("rigger.tooltip.collection_template_apply")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def execute(self, context):
        name = self.template_name or context.window_manager.hytale_collection_template_selected
        if not name:
            self.report({"WARNING"}, "No collection template selected.")
            return {"CANCELLED"}
        if name == _TEMPLATE_NONE:
            context.active_object.data.hytale_active_collection_template = ""
            self.report(
                {"INFO"},
                "Active collection template cleared -- existing bone collections/assignments were not "
                "removed (use the Bone Collections list above to remove them manually).",
            )
            return {"FINISHED"}

        data = get_collection_template(name) or {}
        entries = data.get("collections") or []
        section_entries = data.get("sections") or []
        if not entries and not section_entries:  # o Save aceita só Sections
            self.report({"WARNING"}, f"Unknown or empty collection template '{name}'.")
            return {"CANCELLED"}

        obj = context.active_object
        armature = obj.data
        prev_mode = obj.mode
        bpy.ops.object.mode_set(mode="EDIT")
        try:
            assigned, missing_bones = _apply_collection_template_entries(
                armature, armature.edit_bones, entries, self.report,
            )
        finally:
            bpy.ops.object.mode_set(mode="OBJECT")
            if prev_mode != "OBJECT":
                bpy.ops.object.mode_set(mode=prev_mode)

        settings_touched = _apply_collection_settings_entries(armature, entries, section_entries, self.report)
        sync_bone_collection_order(armature)  # reflete a ordem/seção no painel nativo na hora
        _redraw_all_areas(context)

        armature.hytale_active_collection_template = name
        msg = f"Applied collection template '{name}': {assigned} bone assignment(s) across {len(entries)} collection(s)."
        if settings_touched:
            msg += (
                f" Collection Settings updated for {settings_touched} entr"
                f"{'y' if settings_touched == 1 else 'ies'} ({len(section_entries)} section(s))."
            )
        if missing_bones:
            msg += f" {len(missing_bones)} bone(s) not found on this armature (skipped)."
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class RIG_OT_hytale_collection_template_delete(Operator):
    """Mesma ideia de RIG_OT_hytale_rig_template_delete, pra collections/
    <nome>.json -- só templates do usuário, nunca builtin."""

    bl_idname = "armature.hytale_collection_template_delete"
    bl_label = "Delete Collection Template"
    description = tooltip("rigger.tooltip.collection_template_delete")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _poll_user_template(context, "hytale_collection_template_selected", list_collection_templates)

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        return _execute_template_delete(
            self, context, "hytale_collection_template_selected", delete_collection_template, "collection"
        )
