"""player_ops.py -- criar o Player do zero (sem depender de importar
pelo Hyblend primeiro) e o atalho de um clique pra gerar o rig usando o
template oficial "Player" do proprio Hyblend.

So aciona operadores que JA EXISTEM no Hyblend (armature.hytale_
ik_chain_load_defaults / armature.hytale_shape_template_apply /
armature.hytale_generate_rig) -- nunca reimplementa logica de rig aqui.
Ver DEVELOPER_NOTES.md pra por que a deteccao usa bpy.types em vez de
bpy.ops (bug real corrigido: bpy.ops.<categoria> responde a QUALQUER
nome perguntado, registrado ou nao)."""

from __future__ import annotations

import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from .builder.character_assembly import (
    AssemblyError,
    assemble_item,
    record_equipped_slot,
)
from .builder.model_tree import UNIT_SCALE_DEFAULT, estimate_atlas_size
from .common import game_found
from .toolkit import api
from .picker import _report_warnings, _resolve_item_material
from .preferences import _character_creator_dir, _resolve_assets_path
from .scanner.catalog import get_cache


def _hyblend_generate_rig_available() -> bool:
    """Detecta o Hyblend pela presenca das CLASSES de operador em
    bpy.types (nao pelo nome do modulo da extensao, que pode variar
    dependendo de como foi instalado). IMPORTANTE: checar via
    `hasattr(bpy.ops.armature, "...")` NAO funciona pra isso -- o
    namespace bpy.ops.<categoria> responde (devolve um objeto) pra
    QUALQUER nome perguntado, registrado ou nao, entao hasattr() nele
    sempre da True (bug real encontrado no teste: o botao nao sumia com
    o Hyblend desabilitado). bpy.types so tem a classe de verdade quando
    o operador esta REALMENTE registrado -- essa e a checagem confiavel.
    Convencao de nome: bl_idname "categoria.nome_do_operador" vira classe
    "CATEGORIA_OT_nome_do_operador" em bpy.types."""
    return (
        hasattr(bpy.types, "ARMATURE_OT_hytale_ik_chain_load_defaults")
        and hasattr(bpy.types, "ARMATURE_OT_hytale_shape_template_apply")
        and hasattr(bpy.types, "ARMATURE_OT_hytale_generate_rig")
    )


class HYBLENDCC_OT_create_rig(Operator):
    """So aciona, em sequencia, funcoes que JA EXISTEM no Hyblend -- nao
    reimplementa nada de rig aqui. Pedido explicito: o botao deve fazer
    "quase a mesma coisa que o Create Rig do Hyblend ja faz", so que
    carregando os templates automaticamente primeiro (Bone Settings E
    Custom Shapes, como dois passos EXPLICITOS, cada um chamando o
    operador correspondente do Hyblend -- em vez de confiar no efeito
    colateral de hytale_ik_chain_load_defaults tambem setar o shape
    template sozinho, que é real mas implicito):

      1. armature.hytale_ik_chain_load_defaults(preset="Player")  -- Bone Settings
      2. armature.hytale_shape_template_apply(template="Player")  -- Custom Shapes
      3. armature.hytale_generate_rig()                           -- Create Rig

    "Player" e o nome exato do template builtin (confirmado direto em
    templates/rig/rig_player.json do Hyblend). O Armature que este addon
    produz (Create Player/anexar roupa) ja nasce na estrutura que o
    Hyblend espera -- nao precisa de nenhum passo de "enviar", so rodar
    o que ja existe."""

    bl_idname = "hyblendcc.create_rig"
    bl_label = "Create Rig (Hyblend)"
    bl_description = "Load the Player bone/shape templates and generate the rig, using Hyblend's own operators"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "ARMATURE" and _hyblend_generate_rig_available()

    def execute(self, context):
        result = bpy.ops.armature.hytale_ik_chain_load_defaults(preset="Player")
        if "FINISHED" not in result:
            self.report({"ERROR"}, "Could not load the 'Player' rig template (Bone Settings) from Hyblend.")
            return {"CANCELLED"}

        result = bpy.ops.armature.hytale_shape_template_apply(template="Player")
        if "FINISHED" not in result:
            self.report({"ERROR"}, "Could not apply the 'Player' shape template (Custom Shapes) from Hyblend.")
            return {"CANCELLED"}

        result = bpy.ops.armature.hytale_generate_rig()
        if "FINISHED" not in result:
            self.report({"ERROR"}, "armature.hytale_generate_rig did not finish successfully.")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Rig generated on '{context.active_object.name}' using Hyblend's Player template.")
        return {"FINISHED"}


class HYBLENDCC_OT_create_player(Operator):
    """Cria um Player do zero -- Armature vazio + corpo base (categoria
    BodyCharacteristics, item padrao), sem depender de importar nada
    pelo Hyblend primeiro. Mesma montagem do import do núcleo (Armature
    nova): bone novo pra cada nó, com o que o export do Anim precisa.

    Collections iguais às do import do núcleo:

        <nome>
        ├── Rig - <nome>                    (Armature entra aqui)
        └── Meshes - <nome>
            ├── Main - <nome>                (corpo base)
            └── Mesh Attachments - <nome>    (roupa anexada depois)
    """

    bl_idname = "hyblendcc.create_player"
    bl_label = "Create Player"
    bl_description = "Create a new Player Armature from scratch with a default body"
    bl_options = {"REGISTER", "UNDO"}

    player_name: StringProperty(name="Name", default="Player")

    @classmethod
    def poll(cls, context):
        return game_found()          # sem a pasta do jogo o addon fica travado (common.game_found)

    def execute(self, context):
        cache = get_cache()
        try:
            cache.ensure_loaded(_character_creator_dir(context))
        except AssemblyError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        body_items = cache.catalogs.get("BodyCharacteristics", [])
        if not body_items:
            self.report({"ERROR"}, "Category 'BodyCharacteristics' not found in the catalog -- check the Assets folder.")
            return {"CANCELLED"}
        item = next((it for it in body_items if it.is_default_asset), body_items[0])

        color_name = None
        if item.coloring_mode == "gradient":
            gset = cache.gradient_sets.get(item.gradient_set)
            if gset is not None and gset.colors:
                # Ordenado -- ver conversa de design: strings tipo "01".."53"
                # aparecem em ordem crua/aleatoria dentro do GradientSets.json
                # (a primeira do arquivo era "53"). Mesma convencao de
                # ordenacao usada em todo o resto do picker.
                color_name = sorted(gset.colors, key=lambda c: c.name.lower())[0].name
        elif item.coloring_mode == "discrete" and item.textures:
            color_name = sorted(item.textures, key=lambda t: t.name.lower())[0].name

        try:
            model_rel = item.model_for_variant()
            if not model_rel:
                self.report({"ERROR"}, f"'{item.id}' has no Model at all (neither its own nor any variant's).")
                return {"CANCELLED"}
            model_path = _resolve_assets_path(context, model_rel)
            if not model_path.is_file():
                self.report({"ERROR"}, f"File not found: {model_path}")
                return {"CANCELLED"}

            mat, reference_image = (None, None)
            if color_name is not None:
                mat, reference_image = _resolve_item_material(context, cache, item, color_name)
            if reference_image is not None:
                atlas_w, atlas_h = reference_image.size
            else:
                atlas_w, atlas_h = estimate_atlas_size(model_path)

            # Estrutura de collections identica ao que o Hyblend cria pro
            # modo NEW_ARMATURE (ver docstring da classe) -- garante que
            # o Armature ja nasce do jeito que qualquer ferramenta do
            # Hyblend rodada depois vai esperar encontrar.
            # Armature + collections iguais às do import do Hyblend (núcleo): <nome> > Rig / Meshes > Main /
            # Mesh Attachments, com as propriedades que o Anim procura (malhas, formato).
            name = self.player_name or "Player"
            armature_obj, main_collection = api.model.build.new_armature(context, name)
            name = armature_obj.name

            api.model.build.orient_z_up(armature_obj)     # Y-up do jogo -> Z-up (só no objeto)

            context.view_layer.objects.active = armature_obj
            armature_obj.select_set(True)

            created_objs, created_bone_names, warnings = assemble_item(
                context, armature_obj, model_path, atlas_w, atlas_h,
                unit_scale=UNIT_SCALE_DEFAULT, collection=main_collection, suppress_root_warning=True,
            )
            _report_warnings(self, warnings)

            if mat is not None:
                for obj in created_objs:
                    obj.data.materials.append(mat)

            record_equipped_slot(
                armature_obj, "BodyCharacteristics", created_objs, created_bone_names,
                item_id=item.id, color=color_name or "",
                gradient_set=item.gradient_set if item.coloring_mode == "gradient" else "",
                atlas_size=(atlas_w, atlas_h),
            )

        except AssemblyError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        # Nao precisa forcar nada aqui pra UI mostrar o corpo certo -- o
        # Armature acabou de ser criado com um nome novo, entao
        # _ensure_slots_synced (chamado no proximo draw do painel) vai
        # detectar que o "synced_for" nao bate e ressincronizar sozinho.
        self.report({"INFO"}, f"'{name}' created ({len(created_objs)} body piece(s), {len(created_bone_names)} bone(s)).")
        return {"FINISHED"}
