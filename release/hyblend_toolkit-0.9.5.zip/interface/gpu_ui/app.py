"""A tela da UI por GPU: cabeçalho + abas + página + toast.

`build(f)` roda quando algo muda e devolve uma árvore NOVA de widgets
(estilo React, ver framework/runtime.py). As abas são as MESMAS do painel
clássico e usam a MESMA property (`WindowManager.hytale_active_tab`):
trocar de UI mantém a aba aberta. Cada aba mora num arquivo de pages/ e
devolve uma lista de widgets.
"""

from ...common import ADDON_PACKAGE
from . import game
from .bind import UI
from .framework.core import Button, Column, Fade, Icon, Label, Row, ScrollView, Spacer, Style, Theme, pad
from .framework.motion import forget
from .pages import animation_page, export_page, import_page, info_page, rig_page
from ..welcome import addon_version
from .widgets import DecoratedContainer, Ornament, RuneDivider, SkinRow, TitleBand


def _rgb(hex_color, a=1.0):
    value = hex_color.lstrip("#")
    return tuple(int(value[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (a,)


# Paleta da interface do Hytale (Common.ui do jogo + cores medidas nos PNGs:
# ContainerPatch, Buttons/*, InputBox, DropdownBox...). Vale com ou sem a
# pasta do jogo: sem ela, as formas são procedurais mas as cores são estas.
THEME = Theme(
    canvas=_rgb("#151f2c"),                 # miolo do ContainerPatch
    surface=_rgb("#1f2c44"),                # cartão (OptionBackgroundPatch sobre o canvas)
    surface_raised=_rgb("#21344b"),         # Buttons/Secondary
    surface_hover=_rgb("#2b3a55"),
    surface_pressed=_rgb("#253f60"),        # Secondary_Pressed
    input=_rgb("#263047"),                  # InputBox
    border=_rgb("#42526d", 0.9),            # borda do Secondary/InputBox
    text=_rgb("#dfe7ee"),
    text_muted=_rgb("#96a9be"),             # @ColorDefaultLabel
    accent=_rgb("#e6c279"),                 # dourado (seleção, títulos)
    accent_hover=_rgb("#f1ba50"),
    accent_pressed=_rgb("#c09953"),
    accent_soft=_rgb("#e6c279", 0.14),
    accent_text=_rgb("#151f2c"),
    track_off=_rgb("#0d1217"),
    shadow=(0.0, 0.0, 0.02, 0.6),
    dots=_rgb("#7a9cc6", 0.10),
    danger=_rgb("#e0526f"),                 # Buttons/Destructive (clareado p/ texto)
    danger_soft=_rgb("#c83a5f", 0.16),
    warning=_rgb("#f1ba50"),
    warning_soft=_rgb("#f1ba50", 0.12),
    success=_rgb("#57d9af"),
    primary=_rgb("#4470a4"),                # Buttons/Primary
    primary_hover=_rgb("#3858a2"),
    primary_pressed=_rgb("#2f6db0"),
    primary_text=_rgb("#ffffff"),
    heading_weight="Title",                 # Lexend (fonte "Secondary" do jogo)
    heading_upper=True,
    heading_tracking=0.5,
    radius_scale=0.45,                      # cantos mais retos, como a arte do jogo
)

# Cores extras do menu principal do jogo (Home, pages/home_page.py), medidas
# nos .ui/PNGs de MainMenu e Adventure.
TILE_TEXT = _rgb("#c2d3de")        # WorldTile.ui: nome / data
HARDCORE_RED = _rgb("#eb3e3e")     # WorldTile.ui: "MORTE PERMANENTE" (aqui: arquivo sumido)
GOLD_TITLE = _rgb("#f2c46d")       # títulos dourados das telas ("SELECIONE UM MUNDO")
MENU_TEXT = _rgb("#b7cce9")        # HomeButtonLabelGradient (normal)
MENU_GOLD_LEFT = _rgb("#ffe98c")   # HomeButtonLabelHoveredGradient, começo
MENU_GOLD_RIGHT = _rgb("#f0b142")  # ... fim

# (id do enum hytale_active_tab, rótulo, ícone, key do tooltip, página)
TABS = (
    ("IMPORT", "Import", "import", "panel.tab_import_tooltip", import_page.build),
    ("EXPORT", "Export", "export", "panel.tab_export_tooltip", export_page.build),
    ("RIG", "Rig", "rig", "panel.tab_rig_tooltip", rig_page.build),
    ("ANIMATION", "Animation", "anim", "panel.tab_animation_tooltip", animation_page.build),
    ("INFO", "Info", "info", "panel.tab_info_tooltip", info_page.build),
)
# Mesma grade do painel clássico: duplas + Info fino ocupando a linha toda.
TAB_ROWS = ((("IMPORT", "EXPORT"), 32.0), (("RIG", "ANIMATION"), 32.0), (("INFO",), 22.0))

def signature(context):
    """Resumo BARATO do que a tela mostra; se mudar, o runtime reconstrói.

    Roda a cada redesenho do viewport, então só O(1). Mudança de dado
    "de verdade" (bones, collections...) já chega pelo depsgraph_update_post
    do runtime; o que fica aqui é o que o depsgraph não avisa (troca de
    objeto/bone ativo, modo, abas, idioma)."""
    wm = context.window_manager
    obj = context.view_layer.objects.active
    bone = getattr(context, "active_bone", None)
    try:
        prefs = context.preferences.addons[ADDON_PACKAGE].preferences
        lang, hytale = prefs.language, (prefs.hytale_path_mode, prefs.hytale_path)
    except Exception:
        lang = hytale = None
    return (
        context.scene.as_pointer(),
        obj.name if obj else None,
        obj.type if obj else None,
        bone.name if bone else None,
        context.mode,
        getattr(wm, "hytale_active_tab", None),
        getattr(wm, "hytale_rig_subtab", None),
        lang,
        hytale,
    )


def build(f):
    game.sync()                           # pasta Hytale mudou -> fontes do jogo (O(1) se igual)
    ui = UI(f)
    wm = ui.wm
    th, st = f.theme, f.state
    tab = getattr(wm, "hytale_active_tab", "IMPORT")
    pages = {ident: page for ident, _, _, _, page in TABS}
    if tab not in pages:
        tab = TABS[0][0]

    # Transição de página: aba nova anima de 0 -> 1.
    if st.get("tab.last") != tab:
        st["tab.last"] = tab
        st.pop("_open_menu", None)        # menu/dropdown aberto não atravessa abas
        forget(st, "page.enter")
    enter = f.animate("page.enter", 1.0, 0.3, initial=0.0)

    try:
        content = pages[tab](ui)
    except Exception as error:            # página quebrada não derruba a UI inteira
        import traceback
        traceback.print_exc()
        content = [Label("%s %s" % (ui.t("gpu_ui.error_prefix"), error), color=th.danger, size=11)]
    page = Column([c for c in content if c is not None], style=Style(gap=8))

    tabs = _tab_grid(ui, tab)
    content = [
        tabs,
        RuneDivider(),
        # A página é a parte que cresce: rola quando não cabe na sidebar.
        # Uma posição de rolagem por aba (key diferente).
        ScrollView("page.scroll.%s" % tab, Fade(page, alpha=enter, dy=-8.0 * (1.0 - enter)),
                   style=Style(min_height=120.0)),
        toast(f),
    ]
    return window(f, _header(ui), content, key="root", padding=(14, 10, 14, 14))


def window(f, header, content, *, key, padding, gap=8.0, shadow=False, opaque=False):
    """Moldura do jogo compartilhada (N-Panel e janela de boas-vindas):
    @DecoratedContainer com a arte do jogo; sem a pasta, caixa procedural
    com fundo, borda e sombra do tema. `content` = filhos do corpo.
    opaque=True: base sólida (canvas do tema) por baixo da moldura e dos
    ornamentos, no formato da arte -- a transparência própria dos PNGs do
    jogo (2-20%) some. A faixa do título recebe `base=` de quem a cria."""
    th = f.theme
    frame = game.frame_style("frame")
    base = th.canvas if opaque else None
    if frame:
        body = Column(content, key=key + ".body",
                      style=Style(padding=padding, gap=gap, frame=frame, frame_base=base, shadow=shadow, radius=6))
        return DecoratedContainer(
            Ornament(game.art("ornament")[0], base=base), header, body,
            Ornament(game.art("ornament_bottom")[0], bottom=True, base=base),
            key=key, style=Style(gap=0, clip=not shadow),   # clip cortaria a sombra
        )
    left, top, right, bottom = padding
    body = Column(content, key=key + ".body", style=Style(padding=(left - 2, top, right - 2, bottom - 2), gap=gap))
    return Column(header, body, key=key,
                  style=Style(gap=0, background=th.canvas, border=th.border, radius=12 * th.radius_scale,
                              shadow=True, clip=True))


# --------------------------------------------------------------------------
# Pedaços da tela
# --------------------------------------------------------------------------

def _tab_grid(ui, current):
    """[Import][Export] / [Rig][Animation] / [   Info   ] (fino)."""
    info = {ident: (label, icon, tip) for ident, label, icon, tip, _ in TABS}
    wm = ui.wm
    th = ui.theme

    def pick(ident):
        return lambda f: ui.set(f, wm, "hytale_active_tab", ident, final=False)

    rows = []
    for idents, height in TAB_ROWS:
        buttons = []
        for ident in idents:
            label, icon, tip = info[ident]
            buttons.append(Button("tab." + ident, label, pick(ident), icon=icon,
                                  variant="tab", selected=(ident == current),
                                  tooltip=(lambda key=tip: ui.t(key)),
                                  style=Style(height=height, flex=1.0, radius=7 * th.radius_scale)))
        rows.append(Row(buttons, style=Style(gap=3)))
    return Column(rows, key="tabs", style=Style(gap=3))


def _header(ui):
    """Faixa do título (ContainerHeader do jogo): versão à esquerda, título
    no meio, engrenagem (Preferences do addon) à direita."""
    version = addon_version()
    # Engrenagem = Preferences do addon (mesmo operador do painel
    # clássico). Voltar pro painel clássico = desmarcar a UI por GPU lá.
    prefs = ui.op("header.prefs", "hytale.open_addon_preferences", "", icon="gear", variant="secondary",
                  style=Style(width=26, height=26))
    return TitleBand("Hyblend Toolkit", [Spacer(), prefs], header=game.frame_style("header"),
                     version=("v%s" % version) if version else "", key="header")


def toast(f):
    data = f.state.get("_toast")
    if not data:
        return None
    text, born, error = data
    age = f.now - born
    if age > 2.6:
        f.state.pop("_toast", None)
        return None
    if age < 0.2 or age > 2.2:
        f.state["_motion_active"] = True    # animando entrada/saída: quadro a quadro
    else:
        f.wake_at(born + 2.2)               # parado no meio: só acordar na hora de sumir
    alpha = max(0.0, min(1.0, age / 0.15, (2.6 - age) / 0.4))
    th = f.theme
    body = SkinRow(
        [Icon("check" if not error else "error", size=14, color=th.danger if error else th.success),
         Label(text, size=11, weight="SemiBold", color=th.danger if error else th.accent,
               style=Style(flex=1))],
        "inset_light",
        style=Style(height=30, padding=pad(x=10, y=0), gap=8, align="center",
                    background=th.surface_raised, border=th.border, radius=8 * th.radius_scale),
    )
    return Fade(body, alpha=alpha, dy=-6.0 * (1.0 - min(1.0, age / 0.2)))
