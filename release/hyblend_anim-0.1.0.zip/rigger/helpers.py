"""Auto-Rigger -- helpers genéricos de bone/collection/hierarquia, sem estado próprio."""

import math
import re
from collections import deque

from mathutils import Matrix, Vector

from .constants import (
    ARM_COLLECTION_ROOTS,
    ARM_COLLECTION_ROOTS_NO_SHOULDER,
    ATTACHMENT_NAME_HINT,
    BONE_ROOT_PELVIS,
    COLL_MAIN_ARM_L,
    COLL_MAIN_ARM_R,
    COLL_MAIN_LEG_L,
    COLL_MAIN_LEG_R,
    CONSTRAINT_TWEAK_PARENT,
    HEAD_COLLECTION_ROOT,
    LEG_COLLECTION_ROOTS,
    ORIGIN_ORG_NAME,
    PARENT_OVERRIDE_ALIASES,
    PROP_CONTROL_NAME,
    PROP_RIG_LAYER,
    PROP_SOURCE_ORG,
    ROOT_MASTER_PARENT,
    ROOT_MASTER_SOURCE,
    ROOT_MAX_COUNT,
    SPINE_FOLLOW_BONES,
    SUFFIX_CTRL,
    SUFFIX_IK,
    SUFFIX_MCH,
    SUFFIX_MCH_IK_TRANSFER,
    SUFFIX_MCH_TRANSFER,
    SUFFIX_MCH_TWEAK_FK,
    SUFFIX_MCH_TWEAK_PARENT,
    SUFFIX_POLE,
    SUFFIX_POLE_LINE,
    SUFFIX_TWEAK,
    TWEAK_MIN_DEG,
    TWEAK_MIN_PX,
)


def resolve_head_chain_item(armature):
    """Entrada HEAD principal (a marcada como Main Head; sem marca, a 1ª HEAD com head_bone), usada pelo que é de uma
    cabeça só (PROPERTIES, Head Follow, collection Head, widget/cor do Head_CTRL). None sem HEAD."""
    head_items = [
        item for item in getattr(armature, "hytale_ik_chains", [])
        if item.chain_type == "HEAD" and item.head_bone
    ]
    if not head_items:
        return None
    return next((item for item in head_items if getattr(item, "head_is_main", False)), head_items[0])


def resolve_head_ctrl_name(armature):
    """`_CTRL` da cabeça principal pelo head_bone dela (não o nome fixo "Head_CTRL": um "head" minúsculo quebrava o rig).
    Sem HEAD configurada, o legado HEAD_COLLECTION_ROOT."""
    item = resolve_head_chain_item(armature)
    if item is None:
        return HEAD_COLLECTION_ROOT
    return control_name(armature, item.head_bone, SUFFIX_CTRL)


# --- Root/Origin pela entrada ROOT (Root 1 = Origin principal, Root 2 é pai dele...); sem ela, o legado "Origin" ---


def resolve_root_item(armature):
    """Primeira entrada ROOT de `armature.hytale_ik_chains`, ou None."""
    return next((it for it in getattr(armature, "hytale_ik_chains", []) if it.chain_type == "ROOT"), None)


def default_root_bone_name(slot):
    """Nome usado por um slot "New Bone" com o campo vazio."""
    return ORIGIN_ORG_NAME if slot == 1 else f"Root{slot}"


def resolve_root_slots(armature):
    """[(slot, ORG, criar)] dos slots válidos da entrada ROOT; [] sem ROOT ou sem Root 1 (aí vale o legado)."""
    item = resolve_root_item(armature)
    if item is None:
        return []
    slots = []
    for slot in range(1, min(item.root_count, ROOT_MAX_COUNT) + 1):
        name = (getattr(item, f"root_bone_{slot}", "") or "").strip()
        create = bool(getattr(item, f"root_create_{slot}", False))
        if name.endswith(SUFFIX_CTRL):
            name = name[: -len(SUFFIX_CTRL)]
        if not name and create:
            name = default_root_bone_name(slot)
        if not name:
            if slot == 1:
                return []
            continue
        slots.append((slot, name, create))
    # O mesmo bone em dois slots faria ele virar pai dele mesmo -- mantém
    # só a primeira ocorrência.
    seen = set()
    unique = []
    for entry in slots:
        if entry[1] not in seen:
            seen.add(entry[1])
            unique.append(entry)
    return unique


def resolve_root_org_names(armature):
    """Nomes ORG dos roots, do Origin principal pra cima. Sem entrada
    ROOT válida: [ORIGIN_ORG_NAME] (legado)."""
    slots = resolve_root_slots(armature)
    if not slots:
        return [ORIGIN_ORG_NAME]
    return [name for _slot, name, _create in slots]


def resolve_origin_ctrl_name(armature):
    """`_CTRL` do Origin principal (pai do root.master_CTRL, alvo do Child Of global); sem ROOT, "Origin_CTRL"."""
    slots = resolve_root_slots(armature)
    if not slots:
        return ROOT_MASTER_PARENT
    return control_name(armature, slots[0][1], SUFFIX_CTRL)


# --- Spine/Pelvis pela entrada SPINE (Pelvis + Spine 1..N); sem ela, os nomes legados do Player ---
LEGACY_PELVIS_ORG = "Pelvis"


def resolve_spine_item(armature):
    """Primeira entrada SPINE de `armature.hytale_ik_chains`, ou None --
    mesmo critério que generate.py já usava pro spine_ctrl_enabled."""
    return next((it for it in getattr(armature, "hytale_ik_chains", []) if it.chain_type == "SPINE"), None)


def resolve_pelvis_org_name(armature):
    """Nome do ORG que faz o papel de Pelvis: o campo "Pelvis" da
    entrada SPINE; sem ele, o nome legado "Pelvis"."""
    item = resolve_spine_item(armature)
    if item is not None and (item.pelvis_bone or "").strip():
        return item.pelvis_bone.strip()
    return LEGACY_PELVIS_ORG


def resolve_spine_segment_org_names(armature):
    """Bones da coluna acima do Pelvis (Spine 1..N preenchidos); sem SPINE, "Belly" e "Chest"."""
    item = resolve_spine_item(armature)
    if item is None:
        return [name[: -len(SUFFIX_CTRL)] for name in SPINE_FOLLOW_BONES]
    slots = [getattr(item, f"spine_bone_{i}", "") for i in range(1, 5)]
    names = [(n or "").strip() for n in slots[: max(0, item.spine_count - 1)]]
    return [n for n in names if n]


def resolve_master_source_org_name(armature):
    """ORG de referência do root.master_CTRL/root.spine_CTRL: Spine 1 (ou o Pelvis); sem SPINE, "Belly"."""
    item = resolve_spine_item(armature)
    if item is None:
        return ROOT_MASTER_SOURCE
    segments = resolve_spine_segment_org_names(armature)
    if segments:
        return segments[0]
    return resolve_pelvis_org_name(armature)


def parent_override_candidates(armature, override_name):
    """Candidatos (em ordem) pra um Root Parent: Pelvis -> root.pelvis_CTRL, PARENT_OVERRIDE_ALIASES, o `_CTRL` do bone
    marcado (nunca o ORG cru) e o nome literal. "_CTRL" digitado no campo é ignorado."""
    name = (override_name or "").strip()
    if not name:
        return []
    if name.endswith(SUFFIX_CTRL):
        name = name[: -len(SUFFIX_CTRL)]
    candidates = []
    if armature is not None and name == resolve_pelvis_org_name(armature):
        candidates.append(BONE_ROOT_PELVIS)
    alias = PARENT_OVERRIDE_ALIASES.get(name)
    if alias:
        candidates.append(alias)
    # control_name: um ORG com apelido (Rename "Only CTRL") tem o _CTRL
    # com o nome do apelido.
    candidates.extend((control_name(armature, name, SUFFIX_CTRL), name + SUFFIX_CTRL, name))
    return list(dict.fromkeys(candidates))


def _resolve_parent_override(bones, override_name, armature=None):
    """Bone final de um Root Parent, ou None (`bones`: edit_bones ou armature.bones)."""
    if armature is None:
        armature = getattr(bones, "id_data", None)
    for candidate in parent_override_candidates(armature, override_name):
        bone = bones.get(candidate)
        if bone is not None:
            return bone
    return None


def parent_would_loop(bone, parent):
    """True se `bone.parent = parent` criaria ciclo (compara com ==: o bpy devolve wrappers novos)."""
    ancestor = parent
    while ancestor is not None:
        if ancestor == bone:
            return True
        ancestor = ancestor.parent
    return False


def _classify_chain_limb(item):
    """'ARM'/'LEG'/None a partir de item.chain_type."""
    return item.chain_type if item.chain_type in ("ARM", "LEG") else None


_LIMB_SIDE_TO_COLLECTION = {
    ("ARM", "LEFT"): COLL_MAIN_ARM_L,
    ("ARM", "RIGHT"): COLL_MAIN_ARM_R,
    ("LEG", "LEFT"): COLL_MAIN_LEG_L,
    ("LEG", "RIGHT"): COLL_MAIN_LEG_R,
}


def _resolve_main_limb_roots(armature, edit_bones):
    """Raízes de Arm L/R e Leg L/R: os nomes fixos (variante sem ombro se faltar) + raízes das cadeias ARM/LEG."""
    roots = {name: list(bones) for name, bones in {**ARM_COLLECTION_ROOTS, **LEG_COLLECTION_ROOTS}.items()}

    for coll_name, shoulder_roots in ARM_COLLECTION_ROOTS.items():
        shoulder_name = shoulder_roots[0]
        if edit_bones.get(shoulder_name) is None:
            for candidate in ARM_COLLECTION_ROOTS_NO_SHOULDER[coll_name]:
                if candidate not in roots[coll_name]:
                    roots[coll_name].append(candidate)

    for item in getattr(armature, "hytale_ik_chains", []):
        if not item.root_bone or item.side not in ("LEFT", "RIGHT"):
            continue
        limb = _classify_chain_limb(item)
        if limb is None:
            continue
        coll_name = _LIMB_SIDE_TO_COLLECTION.get((limb, item.side))
        if coll_name is None:
            continue
        for candidate in (
            control_name(armature, item.root_bone, SUFFIX_CTRL),
            control_name(armature, item.root_bone, SUFFIX_IK),
        ):
            if candidate not in roots[coll_name]:
                roots[coll_name].append(candidate)
    return roots


# --- Edit Mode: collections e edit bones ---


def _find_bone_collection_anywhere(armature, name):
    """Procura uma bone collection em qualquer nível de aninhamento --
    armature.collections só enxerga o nível raiz."""
    all_colls = getattr(armature, "collections_all", None)
    if all_colls is not None:
        return all_colls.get(name)

    def search(colls):
        for c in colls:
            if c.name == name:
                return c
            found = search(c.children)
            if found is not None:
                return found
        return None

    return search([c for c in armature.collections if c.parent is None])


def _iter_all_collections(armature):
    all_colls = getattr(armature, "collections_all", None)
    if all_colls is not None:
        return list(all_colls)

    result = []

    def gather(colls):
        for c in colls:
            result.append(c)
            gather(c.children)

    gather([c for c in armature.collections if c.parent is None])
    return result


def set_bone_collection_visibility(armature, visible_names):
    """Deixa visível só as collections cujo nome está em visible_names."""
    for coll in _iter_all_collections(armature):
        coll.is_visible = coll.name in visible_names


def ensure_bone_collection(armature, name, parent=None):
    existing = _find_bone_collection_anywhere(armature, name)
    if existing is not None:
        return existing
    return armature.collections.new(name=name, parent=parent)


def _redraw_all_areas(context):
    """Redesenha tudo (operador chamado de popup não redesenha a UIList)."""
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()


def create_bone_like(edit_bones, source, new_name):
    """Cria (ou reaproveita) um edit bone com a mesma transform de
    source. Retorna (bone, foi_criado_agora)."""
    existing = edit_bones.get(new_name)
    if existing is not None:
        return existing, False
    new_bone = edit_bones.new(new_name)
    new_bone.head = source.head.copy()
    new_bone.tail = source.tail.copy()
    new_bone.roll = source.roll
    new_bone.use_connect = False
    new_bone.use_deform = False  # só ORG deforma a malha
    return new_bone, True


def rotate_edit_bone_local_axis(edit_bone, axis_letter, degrees):
    """Gira um edit bone em volta de um eixo local (ajuste manual da ponta de uma cadeia Chain)."""
    if abs(degrees) < 1e-6:
        return
    axis = {"X": edit_bone.x_axis, "Y": edit_bone.y_axis, "Z": edit_bone.z_axis}.get(axis_letter)
    if axis is None or axis.length < 1e-9:
        return
    axis = axis.normalized()
    old_z = edit_bone.z_axis
    rot = Matrix.Rotation(math.radians(degrees), 4, axis)
    direction = edit_bone.tail - edit_bone.head
    edit_bone.tail = edit_bone.head + (rot @ direction)
    edit_bone.align_roll(rot @ old_z)


def find_layer_bone(edit_bones, org_name, suffix):
    if org_name is None:
        return None
    return edit_bones.get(control_name(getattr(edit_bones, "id_data", None), org_name, suffix))


def is_attachment_bone(bone):
    return ATTACHMENT_NAME_HINT in bone.name.lower()


# Tokens de lado no nome (minúsculo): fonte única do Auto-Detect e do fallback de cor.
SIDE_PREFIX_TOKENS = (
    ("l-", "LEFT"), ("r-", "RIGHT"),
    ("left_", "LEFT"), ("right_", "RIGHT"),
    ("left-", "LEFT"), ("right-", "RIGHT"),
    ("l_", "LEFT"), ("r_", "RIGHT"),
)
SIDE_SUFFIX_TOKENS = (
    ("_left", "LEFT"), ("_right", "RIGHT"),
    (".l", "LEFT"), (".r", "RIGHT"),
    ("_l", "LEFT"), ("_r", "RIGHT"),
)


def split_side_token(bone_name):
    """(lado, base em minúsculo sem o token); o token tem que estar na ponta ("arm_left2" -> (None, ...))."""
    lower = bone_name.lower()
    for token, side in SIDE_PREFIX_TOKENS:
        if lower.startswith(token):
            return side, lower[len(token):]
    for token, side in SIDE_SUFFIX_TOKENS:
        if lower.endswith(token):
            return side, lower[: -len(token)]
    return None, lower


# Sufixos de camada, do mais longo pro mais curto ("_Pole_CTRL" antes de "_CTRL").
_GENERATED_LAYER_SUFFIXES = tuple(
    sorted(
        (
            SUFFIX_MCH_TWEAK_PARENT, SUFFIX_MCH_TWEAK_FK, SUFFIX_MCH_IK_TRANSFER, SUFFIX_MCH_TRANSFER, SUFFIX_POLE_LINE, SUFFIX_POLE, SUFFIX_TWEAK, SUFFIX_CTRL,
            SUFFIX_IK, SUFFIX_MCH,
        ),
        key=len,
        reverse=True,
    )
)


def source_org_name(generated_name):
    """ORG de um bone gerado pelo nome (tira o sufixo de camada), ou None se não termina com nenhum."""
    for suffix in _GENERATED_LAYER_SUFFIXES:
        if generated_name.endswith(suffix) and len(generated_name) > len(suffix):
            return generated_name[: -len(suffix)]
    return None


_TRAILING_NUMBER_RE = re.compile(r"[._-]?\d+$")


# --- Nome dos bones de controle (apelido do Rename "Only CTRL") --------

# Camadas que usam o apelido do ORG. ORG/_MCH/pontes usam sempre o nome
# do ORG.
CONTROL_LAYER_SUFFIXES = (SUFFIX_CTRL, SUFFIX_IK, SUFFIX_POLE, SUFFIX_POLE_LINE, SUFFIX_TWEAK)


def control_base(armature, org_name):
    """Nome-base dos controles de um ORG: o apelido (Rename "Only CTRL") ou o nome dele."""
    if not org_name or armature is None:
        return org_name
    bones = getattr(armature, "bones", None)
    bone = bones.get(org_name) if bones is not None else None
    alias = bone.get(PROP_CONTROL_NAME) if bone is not None else None
    return alias or org_name


def control_name(armature, org_name, suffix):
    """Nome do bone gerado de `org_name` na camada `suffix` (controles usam o apelido; MCH e pontes, o nome do ORG).
    IMPORTANTE: único jeito certo de montar esse nome; não concatene org + sufixo."""
    if suffix in CONTROL_LAYER_SUFFIXES:
        return control_base(armature, org_name) + suffix
    return org_name + suffix


def source_org_of(bone):
    """ORG de onde um bone gerado nasceu: PROP_SOURCE_ORG, ou o nome sem sufixo (Bone, EditBone ou PoseBone)."""
    data = getattr(bone, "bone", bone)  # PoseBone -> Bone
    source = data.get(PROP_SOURCE_ORG) if data is not None else None
    if source:
        return source
    return source_org_name(bone.name)


def _org_by_alias(bones, base):
    """ORG cujo apelido (PROP_CONTROL_NAME) é `base`, se for um só."""
    matches = [b.name for b in bones if b.get(PROP_RIG_LAYER) is None and b.get(PROP_CONTROL_NAME) == base]
    return matches[0] if len(matches) == 1 else None


def normalize_org_name(bones, name):
    """Nome pra um campo do Bone Settings: bone gerado vira o ORG dele; senão `name` sem espaços nas pontas."""
    name = (name or "").strip()
    bone = bones.get(name) if name else None
    if bone is None or bone.get(PROP_RIG_LAYER) is None:
        if bone is None and name:
            # Bone gerado que já não existe (ex. o rig foi apagado): pelo
            # sufixo, e se o resto for um apelido, pelo ORG dono dele.
            source = source_org_name(name)
            source_bone = bones.get(source) if source else None
            if source_bone is not None and source_bone.get(PROP_RIG_LAYER) is None:
                return source
            if source:
                owner = _org_by_alias(bones, source)
                if owner:
                    return owner
            # Nome sem sufixo que é o APELIDO de um ORG ("R-Arm" digitado
            # num campo, com o ORG ainda chamado "leg_front_right").
            owner = _org_by_alias(bones, name)
            if owner:
                return owner
        return name
    source = source_org_of(bone)
    source_bone = bones.get(source) if source else None
    if source_bone is not None and source_bone.get(PROP_RIG_LAYER) is None:
        return source
    return name


def bone_side_prefix(name):
    """Lado ("L"/"R"/None) pelo nome, só pro fallback de cor (aceita prefixo/sufixo; ignora o sufixo de camada)."""
    base = source_org_name(name) or name
    side, _ = split_side_token(base)
    if side is None:
        # Número no fim esconde o token ("arm_left2", "Hand.L.001"); só no fallback de cor.
        trimmed = _TRAILING_NUMBER_RE.sub("", base)
        if trimmed and trimmed != base:
            side, _ = split_side_token(trimmed)
    if side == "LEFT":
        return "L"
    if side == "RIGHT":
        return "R"
    return None


def is_excluded_from_main_collections(bone):
    """Fora das sub-collections de Main: attachments, camadas internas (MCH...) e Tweaks (têm collection própria)."""
    if is_attachment_bone(bone):
        return True
    return bone.get(PROP_RIG_LAYER) in ("MCH", "MCH-IK", "MCH-TRANSFER", "CTRL-TWEAK")


def find_attachment_child(org_bone):
    """Primeiro filho ORG cujo nome contém ATTACHMENT_NAME_HINT, ou None."""
    for child in org_bone.children:
        if is_attachment_bone(child):
            return child
    return None


def find_non_attachment_children(org_bone):
    """Irmã de find_attachment_child: todos os filhos ORG que NÃO são attachment."""
    return [child for child in org_bone.children if not is_attachment_bone(child)]


def find_org_path(root_bone, tip_name):
    """Caminho (root->tip) descendo pela hierarquia ORG, ignorando bones
    já gerados. None se tip_name não for descendente de root_bone."""
    if root_bone.name == tip_name:
        return None
    queue = deque([[root_bone]])
    visited = {root_bone.name}
    while queue:
        path = queue.popleft()
        node = path[-1]
        for child in node.children:
            if PROP_RIG_LAYER in child.keys():
                continue  # só anda por bones ORG
            if child.name in visited:
                continue
            new_path = path + [child]
            if child.name == tip_name:
                return new_path
            visited.add(child.name)
            queue.append(new_path)
    return None


def collect_descendants_inclusive(edit_bones, root_name, exclude_predicate=None):
    """[root] + todos os descendentes, pulando bones pros quais
    exclude_predicate(bone) seja True."""
    root = edit_bones.get(root_name)
    if root is None:
        return []
    result = []
    stack = [root]
    while stack:
        bone = stack.pop()
        stack.extend(bone.children)
        if exclude_predicate is not None and exclude_predicate(bone):
            continue
        result.append(bone)
    return result


def stable_rotation(matrix):
    """Rotação que o Blender tira de uma matriz com escala/cisalhamento (orthogonalize_m3_stable, eixo Y)."""
    m = matrix.to_3x3()
    x, y, z = (m.col[i].copy() for i in range(3))
    if y.length < 1e-12:
        return m.normalized()
    y.normalize()
    x = (x - y * x.dot(y)).normalized()
    z = (z - y * z.dot(y)).normalized()
    if abs(x.dot(z)) > 1e-4:  # X e Z abertos por igual até 90°
        bisector, difference = (x + z).normalized(), (x - z).normalized()
        half = math.sqrt(0.5)
        x = bisector * half + difference * half
        z = bisector * half - difference * half
    return Matrix([[x[i], y[i], z[i]] for i in range(3)])


def ik_parent_world(pbone):
    """Pose do pai; no Tweak, a do lado IK (o pai dele troca entre `_IK` e `_CTRL` pelo switch)."""
    parent = pbone.parent
    con = parent.constraints.get(CONSTRAINT_TWEAK_PARENT)
    ik = parent.id_data.pose.bones.get(con.targets[0].subtarget) if con is not None and con.targets else None
    if ik is None:
        return parent.matrix
    return ik.matrix @ ik.bone.matrix_local.inverted() @ parent.bone.matrix_local


def _basis_frames(pbone):
    """(o que gira, o que posiciona) a basis: o pai @ offset; com inherit_scale NONE o primeiro sem escala."""
    parent = pbone.parent
    if parent is None or pbone.bone.inherit_scale != "NONE":
        prefix = pbone.matrix @ pbone.matrix_basis.inverted()  # pai + constraints, sem a basis
        return prefix, prefix
    offset = parent.bone.matrix_local.inverted() @ pbone.bone.matrix_local
    parent_world = ik_parent_world(pbone)
    unscaled = stable_rotation(parent_world).to_4x4()
    unscaled.translation = parent_world.translation
    return unscaled @ offset, parent_world @ offset


def pose_world_fn(pbone):
    """basis -> mundo do bone, na pose atual do pai."""
    turn, place = _basis_frames(pbone)

    def world(basis):
        result = turn @ basis
        result.translation = place @ basis.translation
        return result

    return world


def basis_for_world(pbone, world):
    """Inverso de pose_world_fn: a basis que leva o bone até `world`."""
    turn, place = _basis_frames(pbone)
    basis = turn.inverted() @ world
    basis.translation = place.inverted() @ world.translation
    return basis


def tweak_basis(tweak_pb, bridge_bone, target, unit_scale):
    """(basis, desprezível?) do Tweak que põe a peça (o bridge) em `target`; desprezível = abaixo da tolerância do export."""
    bridge_rel = tweak_pb.bone.matrix_local.inverted() @ bridge_bone.matrix_local
    untouched = pose_world_fn(tweak_pb)(Matrix.Identity(4)) @ bridge_rel
    moved_px = (target.translation - untouched.translation).length / unit_scale
    turned = target.to_quaternion().rotation_difference(untouched.to_quaternion()).angle
    negligible = moved_px < TWEAK_MIN_PX and math.degrees(turned) < TWEAK_MIN_DEG
    return basis_for_world(tweak_pb, target @ bridge_rel.inverted()), negligible


def pole_position_for_root(ik_root_matrix, chain_end, pole_angle, distance):
    """Pole que faz o solver deixar o `_IK` raiz com `ik_root_matrix` (snap FK->IK e import Control IK).
    `chain_end`: ponto que o solver alcança; `pole_angle`: o da constraint (rad); `distance`: do meio raiz->ponta.
    None se a geometria for degenerada."""
    root = ik_root_matrix.translation
    rot = ik_root_matrix.to_3x3()
    y_axis = (rot @ Vector((0.0, 1.0, 0.0))).normalized()
    x_axis = (rot @ Vector((1.0, 0.0, 0.0))).normalized()
    pole_axis = Matrix.Rotation(-pole_angle, 3, y_axis) @ x_axis
    reach = chain_end - root
    normal = reach.cross(pole_axis)
    if reach.length < 1e-9 or normal.length < 1e-9:
        return None
    if normal.cross(y_axis).dot(pole_axis) < 0:
        normal = -normal
    return root + reach * 0.5 + normal.cross(reach).normalized() * distance


def ik_solver_target_index(path_length):
    """Índice do bone cujo Head o solver alcança: a ponta com 2 segmentos; o 3º bone com 3+ (os seguintes viram jarretes)."""
    return min(2, path_length - 1)
