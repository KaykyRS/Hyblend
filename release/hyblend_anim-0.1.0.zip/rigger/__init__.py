"""Registro do pacote rigger e reexport da API usada de fora (interface, anim).
"""


import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Armature, Object, WindowManager

from ..templates import (
    collection_template_enum_items,
    rig_template_enum_items,
    shape_template_enum_items,
)
from ..translations import (
    get_language,
    register_localized_class,
    register_refresh_hook,
    tr,
    unregister_localized_class,
    unregister_refresh_hook,
)

# --- Reexport: o que interface/ e anim/ importam de `.rigger` (nomes e regras ficam numa fonte só) ---
from .constants import (  # noqa: F401
    BONE_PROPERTIES,
    BONE_ROOT_MASTER,
    BONE_ROOT_PELVIS,
    CONSTRAINT_CHILD_OF_GLOBAL,
    CONSTRAINT_CHILD_OF_LOCAL,
    PROP_FK_IK_SWITCH,
    PROP_HEAD_FOLLOW_SWITCH,
    PROP_RIG_LAYER,
    SUFFIX_CTRL,
    SUFFIX_IK,
    SUFFIX_MCH,
    SUFFIX_MCH_IK_TRANSFER,
    SUFFIX_MCH_TRANSFER,
    SUFFIX_POLE,
    SUFFIX_TWEAK,
)
from .helpers import control_name, find_org_path, ik_solver_target_index, pole_position_for_root, resolve_pelvis_org_name, source_org_of, basis_for_world, pose_world_fn, tweak_basis  # noqa: F401 (reexport pro anim/)
from .constraints import switch_property_name
from .bone_collections import (
    SECTION_ROOT,
    HytaleBoneCollectionItem,
    RIG_OT_hytale_bone_collection_add,
    RIG_OT_hytale_bone_collection_load_defaults,
    RIG_OT_hytale_bone_collection_move,
    RIG_OT_hytale_bone_collection_remove,
    RIG_OT_hytale_bone_collection_reset_grid,
    RIG_UL_hytale_bone_collections,
    _collection_sort_key,
    _iter_sections_in_order,
    _resolve_collection_parent,
    _resolve_collection_section_name,
    _section_sort_key,
    ensure_default_bone_collections,
    register_bone_collection_defaults_handler,
    resolve_collection_override_target,
    unregister_bone_collection_defaults_handler,
)
from .bone_settings import (
    HytaleIKChainItem,
    RIG_MT_hytale_ik_chain_add_menu,
    RIG_OT_hytale_ik_chain_add,
    RIG_OT_hytale_ik_chain_auto_detect,
    RIG_OT_hytale_ik_chain_load_defaults,
    RIG_OT_hytale_ik_chain_move,
    RIG_OT_hytale_ik_chain_pick_bone,
    RIG_OT_hytale_ik_chain_remove,
    RIG_OT_hytale_ik_chain_set_count,
    RIG_UL_hytale_ik_chains,
)
from .validate import RIG_MT_hytale_clear_generated_menu, RIG_OT_hytale_clear_generated, RIG_OT_hytale_validate_rig
from .shape_edit import (
    RIG_OT_hytale_mirror_shape,
    RIG_OT_hytale_shape_edit_mode_enter,
    RIG_OT_hytale_shape_edit_mode_finish,
    RIG_OT_hytale_shape_edit_mode_reselect,
    RIG_OT_hytale_shape_vertex_edit_mode_enter,
    RIG_OT_hytale_shape_vertex_edit_mode_finish,
    RIG_OT_hytale_use_selected_as_widget,
    find_armature_stuck_in_shape_edit_mode,
    register_shape_edit_border,
    register_shape_edit_self_heal,
    unregister_shape_edit_border,
    unregister_shape_edit_self_heal,
)
from .texture_picker import RIG_OT_hytale_texture_picker_create, RIG_OT_hytale_texture_picker_remove
from .camera import RIG_OT_hytale_camera_create, RIG_OT_hytale_camera_remove
from .generate import RIG_OT_hytale_generate_rig
from .rename import RIG_OT_hytale_rename_bones, RIG_OT_hytale_revert_bone_names
from .character_templates import (
    RIG_OT_hytale_collection_template_apply,
    RIG_OT_hytale_collection_template_delete,
    RIG_OT_hytale_collection_template_save,
    RIG_OT_hytale_rig_template_delete,
    RIG_OT_hytale_rig_template_save,
    RIG_OT_hytale_shape_template_apply,
    RIG_OT_hytale_shape_template_delete,
    RIG_OT_hytale_shape_template_save,
)

# --- Ordem de registro (classes que se referenciam: a referenciada antes) ---
_CLASSES = (
    HytaleIKChainItem,
    RIG_UL_hytale_ik_chains,
    RIG_OT_hytale_ik_chain_add,
    RIG_MT_hytale_ik_chain_add_menu,
    RIG_OT_hytale_ik_chain_remove,
    RIG_OT_hytale_ik_chain_set_count,
    RIG_OT_hytale_ik_chain_pick_bone,
    RIG_OT_hytale_ik_chain_load_defaults,
    RIG_OT_hytale_ik_chain_move,
    # Auto-Detect: depois de HytaleIKChainItem.
    RIG_OT_hytale_ik_chain_auto_detect,
    # HytaleBoneCollectionItem antes de quem a usa em CollectionProperty.
    HytaleBoneCollectionItem,
    RIG_UL_hytale_bone_collections,
    RIG_OT_hytale_bone_collection_load_defaults,
    RIG_OT_hytale_bone_collection_reset_grid,
    RIG_OT_hytale_bone_collection_add,
    RIG_OT_hytale_bone_collection_remove,
    RIG_OT_hytale_bone_collection_move,
    RIG_OT_hytale_shape_template_apply,
    RIG_OT_hytale_rig_template_save,
    RIG_OT_hytale_rig_template_delete,
    RIG_OT_hytale_shape_template_save,
    RIG_OT_hytale_shape_template_delete,
    RIG_OT_hytale_collection_template_save,
    RIG_OT_hytale_collection_template_apply,
    RIG_OT_hytale_collection_template_delete,
    RIG_OT_hytale_clear_generated,
    RIG_MT_hytale_clear_generated_menu,
    RIG_OT_hytale_shape_edit_mode_enter,
    RIG_OT_hytale_shape_edit_mode_finish,
    # Recuperação de Armature presa em Shape Edit Mode.
    RIG_OT_hytale_shape_edit_mode_reselect,
    # Vertex Edit Mode (sub-modo do Shape Edit Mode), depois de Enter/Finish.
    RIG_OT_hytale_shape_vertex_edit_mode_enter,
    RIG_OT_hytale_shape_vertex_edit_mode_finish,
    RIG_OT_hytale_generate_rig,
    RIG_OT_hytale_validate_rig,
    RIG_OT_hytale_mirror_shape,
    # Embutir malha no Shape Template (só no Shape Edit Mode).
    RIG_OT_hytale_use_selected_as_widget,
    # Texture Picker.
    RIG_OT_hytale_texture_picker_create,
    RIG_OT_hytale_texture_picker_remove,
    # First Person Camera (HEAD).
    RIG_OT_hytale_camera_create,
    RIG_OT_hytale_camera_remove,
    # Parte 4 -- Rename Bones (padrão de nomes do Hytale). Sem dependência
    # de ordem conhecida com o resto -- acrescentado no fim.
    RIG_OT_hytale_rename_bones,
    RIG_OT_hytale_revert_bone_names,
)


def _assign_dynamic_properties(lang=None):
    """(Re)atribui as properties dinâmicas no Armature: no register e de novo a cada troca de idioma
    (as CollectionProperty apontam pra classes re-registradas; as soltas só traduzem a description reatribuindo)."""
    if lang is None:
        lang = get_language(bpy.context)

    Armature.hytale_ik_chains = CollectionProperty(type=HytaleIKChainItem)
    Armature.hytale_ik_chains_index = IntProperty(default=0)
    # Parte 4 -- modo do Rename Bones. Ordem dos itens FIXA: o .blend
    # guarda o Enum pelo índice (item novo sempre no fim).
    Armature.hytale_rename_mode = EnumProperty(
        name="Rename Mode",
        items=[
            ("ALL_BONES", "All Bones", tr("rigger.prop.armature_rename_mode_item_all", lang)),
            ("ONLY_CTRL", "Only CTRL", tr("rigger.prop.armature_rename_mode_item_only_ctrl", lang)),
        ],
        default="ALL_BONES",
        description=tr("rigger.prop.armature_rename_mode", lang),
    )
    Armature.hytale_rename_enabled = BoolProperty(
        name="Rename Bones",
        description=tr("rigger.prop.armature_rename_enabled", lang),
        default=False,
    )
    # Continuous Chain: o Tail de cada `_CTRL` de HEAD/SPINE/ARM/LEG vai pro Head do próximo (_apply_ctrl_tail_to_child).
    Armature.hytale_ctrl_tail_to_child = BoolProperty(
        name="Continuous Chain",
        description=tr("rigger.prop.armature_ctrl_tail_to_child", lang),
        default=True,
    )
    Armature.hytale_active_rig_template = StringProperty(
        name="Active Rig Template",
        description=tr("rigger.prop.armature_active_rig_template", lang),
        default="",
    )
    Armature.hytale_active_shape_template = StringProperty(
        name="Active Shape Template",
        description=tr("rigger.prop.armature_active_shape_template", lang),
        default="",
    )
    Armature.hytale_active_collection_template = StringProperty(
        name="Active Collection Template",
        description=tr("rigger.prop.armature_active_collection_template", lang),
        default="",
    )
    Armature.hytale_shape_edit_mode = BoolProperty(
        name="Shape Edit Mode",
        description=tr("rigger.prop.armature_shape_edit_mode", lang),
        default=False,
    )
    Armature.hytale_shape_vertex_edit_mode = BoolProperty(
        name="Shape Vertex Edit Mode",
        description=tr("rigger.prop.armature_shape_vertex_edit_mode", lang),
        default=False,
    )

    # Collection Settings: lista de collections e seções (fonte do dropdown "Collection" das entradas).
    # _initialized controla o seed único dos defaults (nunca em draw()).
    Armature.hytale_bone_collections = CollectionProperty(type=HytaleBoneCollectionItem)
    Armature.hytale_bone_collections_index = IntProperty(default=0)
    Armature.hytale_bone_collections_initialized = BoolProperty(default=False)


def register():
    # register_localized_class serve pra classes com e sem @localized_props.
    for cls in _CLASSES:
        register_localized_class(cls)

    _assign_dynamic_properties()
    # Refaz as atribuições acima toda vez que o idioma do addon mudar
    # -- ver docstring de _assign_dynamic_properties.
    register_refresh_hook(_assign_dynamic_properties)

    # Seleção de template no WindowManager (a lista de arquivos é a mesma pra qualquer Armature).
    WindowManager.hytale_rig_template_selected = EnumProperty(name="Rig Template", items=rig_template_enum_items)
    WindowManager.hytale_shape_template_selected = EnumProperty(
        name="Shape Template", items=shape_template_enum_items,
    )
    WindowManager.hytale_collection_template_selected = EnumProperty(
        name="Collection Template", items=collection_template_enum_items,
    )

    # Armature dono do widget no Vertex Edit Mode (PointerProperty sobrevive a rename).
    Object.hytale_vertex_edit_armature_ptr = PointerProperty(type=Object)

    # Borda do Shape Edit Mode (registrada uma vez; o callback decide se desenha).
    register_shape_edit_border()

    # Conserta estado órfão de Shape/Vertex Edit Mode (load/undo/redo e já no register).
    register_shape_edit_self_heal()

    # Seed automático do Collection Settings por handler (draw() não pode escrever).
    register_bone_collection_defaults_handler()


def unregister():
    unregister_bone_collection_defaults_handler()
    unregister_shape_edit_self_heal()
    unregister_shape_edit_border()

    del WindowManager.hytale_collection_template_selected
    del WindowManager.hytale_shape_template_selected
    del WindowManager.hytale_rig_template_selected

    del Object.hytale_vertex_edit_armature_ptr

    unregister_refresh_hook(_assign_dynamic_properties)
    del Armature.hytale_bone_collections_initialized
    del Armature.hytale_bone_collections_index
    del Armature.hytale_bone_collections
    del Armature.hytale_shape_vertex_edit_mode
    del Armature.hytale_shape_edit_mode
    del Armature.hytale_active_collection_template
    del Armature.hytale_active_shape_template
    del Armature.hytale_active_rig_template
    del Armature.hytale_ctrl_tail_to_child
    del Armature.hytale_rename_enabled
    del Armature.hytale_rename_mode
    del Armature.hytale_ik_chains_index
    del Armature.hytale_ik_chains
    for cls in reversed(_CLASSES):
        unregister_localized_class(cls)
