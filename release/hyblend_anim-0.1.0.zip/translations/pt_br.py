"""Português (Brasil). Key de en.py ainda não traduzida aqui cai pro inglês (instruções no topo de en.py).
"""

LANGUAGE_CODE = "PT_BR"
LANGUAGE_NAME = "Português (Brasil)"

TRANSLATIONS = {
    # --- importer: janelas do .bbmodel/Bedrock (o resto das keys de import é do núcleo) ---
    "importer.section_target": "Destino",
    "importer.armature_name": "Nome da Armature",
    "importer.model_format": "Tipo de Modelo",

    # --- anim_tools: tooltips de botão ---
    "anim_tools.tooltip.set_fk_ik": "Troca esta cadeia para FK ou IK -- não iguala a pose (use 'Snap "
    "FK/IK' pra isso)",
    "anim_tools.tooltip.set_head_follow": "Lock (segue a rotação do bone predecessor) ou Free (mantém a "
    "rotação própria do Head_CTRL)",
    "anim_tools.tooltip.snap_selected": "Iguala a pose do lado oposto (FK ou IK) à cadeia do bone "
    "selecionado, depois troca pra ele -- faz o snap e a troca num clique só, pra qualquer cadeia que o bone "
    "ativo pertença",
    "anim_tools.tooltip.keyframe_switch": "Insere um keyframe no valor atual deste switch, no frame atual",

    # --- anim_tools: campos ---
    "anim_tools.prop.set_fk_ik_chain_index": "Índice em armature.hytale_ik_chains",
    "anim_tools.prop.keyframe_switch_chain_index": "Só usado quando switch == 'FK_IK'",

    # --- exporter: tooltips de botão ---
    "exporter.tooltip.texture_picker_export_add": "Adiciona uma entrada manual de export de Texture Picker à lista",
    "exporter.tooltip.texture_picker_export_remove": "Remove a entrada de export de Texture Picker selecionada da lista",

    # --- exporter: HYTALE_export_settings ---
    "exporter.prop.export_settings_collection_name": (
        "Nome da Bone Collection da Armature que contém só os bones "
        "'originais' do jogo pra exportar (Armature Data Properties > "
        "Bone Collections). Se essa collection não existir na armature, "
        "cai pra adivinhar pelo sufixo do nome (_MCH/_CTRL/_IK), o que "
        "não é confiável em rigs complexos"
    ),

    # --- exporter: HYTALE_texture_picker_export_item ---
    "exporter.prop.texture_picker_source_bone": (
        "Nome do bone auxiliar cuja Location controla o picker do atlas "
        "(ex.: 'ui.texture_picker'). Esse bone em si NÃO é exportado -- "
        "só a Location dele é amostrada"
    ),
    "exporter.prop.texture_picker_target_bone": (
        "Nome exato do bone real do jogo pra anexar o canal "
        "'shapeUvOffset' -- precisa ser um dos bones exportáveis (ex.: "
        "'Mouth', ou qualquer outra peça controlada por atlas)"
    ),
    "exporter.prop.texture_picker_target_bones_extra": (
        "Nomes de bone extras, separados por vírgula, que recebem exatamente o mesmo dado "
        "'shapeUvOffset' do Target Bone acima -- pra personagens cuja parte animada é dividida "
        "entre mais de uma malha/bone (ex.: metades esquerda/direita espelhadas) que precisam "
        "mudar de expressão juntas. Normalmente preenchido automaticamente por 'Create Texture "
        "Picker' a partir dos Companion Bones configurados nesta entrada, não digitado aqui direto"
    ),
    "exporter.prop.texture_picker_step_x": (
        "Em unidades do Blender: o quanto o bone de controle precisa se "
        "mover no X pra a textura da boca/rosto avançar um passo. "
        "Precisa bater com o que sua configuração de shader/driver "
        "realmente usa -- isto não inventa o comportamento, só precisa "
        "descrevê-lo corretamente"
    ),
    "exporter.prop.texture_picker_px_x": (
        "Quantos pixels de textura crus um passo de grid em X representa no arquivo (o jogo "
        "espera offsets de pixel crus, não uma fração 0..1)"
    ),
    "exporter.prop.texture_picker_step_y": "Mesma coisa que Grid Step X, pro movimento em Y do bone de controle",
    "exporter.prop.texture_picker_px_y": "Mesma coisa que Pixels per Step X, pro Y",

    # --- exporter: .blockymodel (pose da rest atual; shape/UV capturados no import) ---
    "exporter.prop.blockymodel_unit_scale": (
        "TEM que bater com o valor exato usado quando este personagem "
        "foi importado (Hytale Blockymodel Importer) -- se não "
        "baterem, toda posição no arquivo exportado sai errada por um "
        "fator de escala consistente. Mesmo campo do exportador de "
        ".blockyanim"
        " -- Valor pra modelos Character (64 unidades por bloco). Modelos Prop (32 por bloco) usam o dobro automaticamente, pra os dois ficarem no mesmo tamanho no Blender"
    ),
    "exporter.prop.blockymodel_output_decimal_places": (
        "Quantos dígitos depois da vírgula manter em todo número do "
        "arquivo. Puramente cosmético, não descarta nenhum dado -- só "
        "evita que o arquivo fique cheio de números tipo "
        "0.30000000000000004"
    ),
    "exporter.prop.blockymodel_pretty_print_json": (
        "DESLIGADO (padrão): escreve o arquivo numa linha compacta só "
        "-- menor, e normalmente ninguém precisa ler isso à mão. "
        "LIGADO: escreve bem indentado em várias linhas em vez disso, "
        "só pra um humano conseguir abrir e ler/comparar (mais ou "
        "menos dobra o tamanho do arquivo; o jogo e o Blockbench leem "
        "os dois formatos igualmente)"
    ),

    # --- exporter: FBX (Model + Animation), mesma Export Bone Collection ---
    "exporter.prop.fbx_include_meshes": (
        "Inclui as malhas de referência deste personagem (collections "
        "Main + opcionalmente Mesh Attachments) no .fbx, junto com o "
        "esqueleto. DESLIGADO exporta só o Armature -- sem geometria "
        "nenhuma"
    ),
    "exporter.prop.fbx_include_attachments": (
        "Só importa se 'Include Reference Meshes' estiver LIGADO. "
        "Também inclui malhas da collection Mesh Attachments deste "
        "Armature (qualquer coisa importada via 'Attach to Existing'), "
        "não só a collection Main"
    ),
    "exporter.prop.fbx_match_game_units": (
        "DESLIGADO (padrão): exporta na escala do próprio Blender (1 "
        "unidade do Blender = 1 unidade do Blender) -- o que a maioria "
        "dos outros programas espera ao importar um .fbx. LIGADO: "
        "multiplica por 1 / 'Blender Units per Game Unit', fazendo o "
        "arquivo exportado bater com as unidades cruas do jogo -- só "
        "útil se o que for ler esse .fbx precisar especificamente disso"
    ),
    "exporter.prop.fbx_unit_scale": (
        "Só usado quando 'Scale to Game Units' está LIGADO. TEM que "
        "bater com o valor exato usado quando este personagem foi "
        "importado (Hytale Blockymodel Importer), igual ao campo "
        "equivalente no exportador de .blockyanim"
        " -- Valor pra modelos Character (64 unidades por bloco). Modelos Prop (32 por bloco) usam o dobro automaticamente, pra os dois ficarem no mesmo tamanho no Blender"
    ),
    "exporter.prop.fbx_apply_transform": (
        "DESLIGADO (padrão): a própria rotação/escala do Object "
        "Armature (ex.: a rotação de 90 graus que 'Orient to Z-up' "
        "adiciona em alguns imports) fica guardada como um transform no "
        "node do FBX, do jeito que a maioria dos engines/DCCs espera. "
        "LIGADO: assa esse transform direto nos dados de vértice/bone "
        "exportados, deixando o transform do próprio node em identidade "
        "-- só ligue se o que for ler o arquivo não lidar bem com um "
        "transform de raiz que não seja identidade"
    ),
    "exporter.prop.fbx_add_leaf_bones": (
        "Opção do próprio exportador FBX do Blender: adiciona um bone "
        "de ponta extra no fim de toda cadeia de bones sem filhos, "
        "igual ao 3ds Max/pipelines mais antigos esperam que o "
        "comprimento de um bone seja representado. A maioria dos "
        "engines modernos não precisa disso -- deixe DESLIGADO a não "
        "ser que você saiba que seu pipeline de destino quer isso"
    ),
    "exporter.prop.fbx_embed_textures": (
        "Só importa se 'Include Reference Meshes' estiver LIGADO e "
        "essas malhas tiverem um material com textura de imagem. "
        "DESLIGADO (padrão): o .fbx só referencia o caminho do arquivo "
        "de textura -- LIGADO: copia os dados da imagem direto dentro "
        "do .fbx, então ele deixa de depender desse arquivo externo "
        "(arquivo maior, mas totalmente autocontido)"
    ),

    # --- anim_importer: IMPORT_OT_hytale_blockyanim (campos) ---
    "anim_importer.prop.target_mode": "Em qual camada de bone escrever a animação importada",
    "anim_importer.prop.target_mode_item_org": (
        "Keyframa os bones originais do jogo direto. Funciona em "
        "QUALQUER armature -- riggada ou não -- mas num rig com uma "
        "camada de controle FK/IK por cima, esses keyframes não vão "
        "mover nada (os bones originais estão restritos a seguir a "
        "camada de controle)"
    ),
    "anim_importer.prop.target_mode_item_ctrl": (
        "Escreve nos bones '_CTRL'/'_IK'/pole gerados pela ferramenta "
        "de auto-rig (rigger.py), então a animação importada continua "
        "editável através do rig de controle -- configure Spine/Arms/"
        "Legs abaixo"
    ),
    "anim_importer.prop.action_name": "Deixe vazio pra usar o nome do arquivo",
    "anim_importer.prop.start_frame": "Frame do Blender onde o tempo=0 do arquivo de animação cai",
    "anim_importer.prop.import_fps_preset": (
        "FPS alvo da cena pra este import. Se a cena ainda não estiver "
        "nesse FPS, ele é trocado automaticamente antes de importar -- "
        "arquivos .blockyanim são criados a 60 FPS (FPS_HYTALE), então "
        "manter isto em 60 evita o problema de 'timing parece "
        "comprimido' de importar numa cena com FPS mais baixo. Mesma "
        "lista de Output Properties > Frame Rate do próprio Blender -- "
        "escolha 'Custom' pra definir FPS/Base separadamente, igual lá"
    ),
    "anim_importer.prop.import_fps_preset_item_6": "6 fps",
    "anim_importer.prop.import_fps_preset_item_8": "8 fps",
    "anim_importer.prop.import_fps_preset_item_12": "12 fps",
    "anim_importer.prop.import_fps_preset_item_23_98": "23.976 fps (24000 / 1001, NTSC film)",
    "anim_importer.prop.import_fps_preset_item_24": "24 fps",
    "anim_importer.prop.import_fps_preset_item_25": "25 fps",
    "anim_importer.prop.import_fps_preset_item_29_97": "29.97 fps (30000 / 1001, NTSC)",
    "anim_importer.prop.import_fps_preset_item_30": "30 fps",
    "anim_importer.prop.import_fps_preset_item_50": "50 fps",
    "anim_importer.prop.import_fps_preset_item_59_94": "59.94 fps (60000 / 1001, NTSC)",
    "anim_importer.prop.import_fps_preset_item_60": "60 fps",
    "anim_importer.prop.import_fps_preset_item_120": "120 fps",
    "anim_importer.prop.import_fps_preset_item_240": "240 fps",
    "anim_importer.prop.import_fps_preset_item_custom": "Define FPS e Base separadamente abaixo",
    "anim_importer.prop.import_fps_custom_fps": (
        "Frame Rate customizado -- 'Frame Rate' está definido como "
        "'Custom' -- mesmo campo que Output Properties > Frame Rate > "
        "FPS no próprio Blender. Taxa efetiva é FPS / Base"
    ),
    "anim_importer.prop.import_fps_custom_base": (
        "Frame Rate customizado -- 'Frame Rate' está definido como "
        "'Custom' -- mesmo campo que Output Properties > Frame Rate > "
        "Base no próprio Blender. Taxa efetiva é FPS / Base"
    ),
    "anim_importer.prop.loop_mode": "Se este clip deve fechar num loop sem emenda",
    "anim_importer.prop.loop_mode_item_auto": (
        "Usa a própria flag 'holdLastKeyframe' do arquivo: false = "
        "ciclo (loop), true = início & fim (segura a última pose)"
    ),
    "anim_importer.prop.loop_mode_item_cycle": (
        "Força um loop: o fim emenda de volta no começo como no jogo -- "
        "use pra ciclos de andar/correr/idle"
    ),
    "anim_importer.prop.loop_mode_item_one_shot": (
        "Força este clip a só segurar a última pose no final -- use "
        "pra ações sem loop (ataques, mortes, gestos únicos)"
    ),
    "anim_importer.prop.bake_mode": (
        "Um keyframe por frame em vez de só os keyframes do arquivo. Os dois ficam iguais ao "
        "jogo; desligado deixa menos keys, mais fácil de editar. Afeta 'Original Bones' e o "
        "stretch de shape -- Control Bones sempre ganham um keyframe por frame"
    ),
    "anim_importer.prop.keep_spine_follow": (
        "Só Control FK, Control IK e Default (FK + IK): por padrão, "
        "isto fica ATIVO -- qualquer constraint extra num bone de "
        "controle (ex.: Belly_CTRL/Chest_CTRL seguindo parcialmente "
        "root.spine_CTRL) continua se mesclando durante o import, e em "
        "modos que escrevem IK, os constraints Child Of de cada pole "
        "target também continuam ativos. Desative isto pra mutar esses "
        "constraints em vez disso, fazendo a pose importada bater "
        "exatamente com o arquivo de origem nos bones afetados -- ao "
        "custo de root.spine_CTRL (e o Child Of dos poles) não poder "
        "mais ser usado como ferramenta de ajuste fino em cima da "
        "animação importada"
    ),
    "anim_importer.prop.spine_mode": (
        "Só Controllers: como os bones raiz utilitários do rig "
        "(root.master_CTRL/root.pelvis_CTRL, rigger.py) se comportam. "
        "A animação de origem só move Pelvis/Belly/Chest -- esses "
        "bones raiz nunca se movem sozinhos, então precisam disto pra "
        "viajar junto com a animação (ex.: ciclos de andar/correr) em "
        "vez de ficar congelados perto da origem"
    ),
    "anim_importer.prop.spine_mode_item_default": (
        "root.master_CTRL segue a posição e rotação animadas da "
        "Pelvis a cada frame -- root.pelvis_CTRL e Belly_CTRL (filhos "
        "reais de root.master_CTRL) viajam junto automaticamente. "
        "Recomendado -- bate com o movimento de raiz da animação de "
        "origem"
    ),
    "anim_importer.prop.spine_mode_item_manual": (
        "root.master_CTRL/root.pelvis_CTRL ficam congelados em "
        "repouso -- Pelvis/Belly/Chest continuam keyframados "
        "normalmente, mas o personagem não vai viajar com o movimento "
        "de raiz (ex.: andar vai parecer andar no lugar). Deixa "
        "root.spine_CTRL livre como um controle manual de ajuste fino "
        "em cima da animação importada"
    ),
    "anim_importer.prop.arms_mode": (
        "Só Controllers: como as cadeias tipo 'Arm' "
        "(armature.hytale_ik_chains, rigger.py) são keyframadas"
    ),
    "anim_importer.prop.arms_mode_item_both": (
        "Escreve os dois de uma vez -- todo segmento de braço recebe "
        "seu '_CTRL' de FK E a ponta IK da cadeia (mão) + pole também "
        "são keyframados. fk_ik_switch começa em FK (0); alterne a "
        "qualquer momento depois, por cadeia, pra pré-visualizar ou "
        "usar a versão IK em vez disso -- sem precisar reimportar"
    ),
    "anim_importer.prop.arms_mode_item_ctrl_fk": (
        "Só os bones '_CTRL' por segmento -- fk_ik_switch fica "
        "intocado (a cadeia não recebe nenhum keyframe de '_IK'/pole)"
    ),
    "anim_importer.prop.arms_mode_item_ik": (
        "Só a ponta '_IK' (mão) + pole target -- os bones '_CTRL' por "
        "segmento são pulados, e fk_ik_switch é definido como IK (1)"
    ),
    "anim_importer.prop.legs_mode": (
        "Só Controllers: como as cadeias tipo 'Leg' "
        "(armature.hytale_ik_chains, rigger.py) são keyframadas -- "
        "mesmas 3 opções de Arms, aplicadas independentemente"
    ),
    "anim_importer.prop.legs_mode_item_both": (
        "Escreve os dois de uma vez -- todo segmento de perna recebe "
        "seu '_CTRL' de FK E a ponta IK da cadeia (pé) + pole também "
        "são keyframados. fk_ik_switch começa em FK (0); alterne a "
        "qualquer momento depois, por cadeia, pra pré-visualizar ou "
        "usar a versão IK em vez disso -- sem precisar reimportar"
    ),
    "anim_importer.prop.legs_mode_item_ctrl_fk": (
        "Só os bones '_CTRL' por segmento -- fk_ik_switch fica "
        "intocado (a cadeia não recebe nenhum keyframe de '_IK'/pole)"
    ),
    "anim_importer.prop.legs_mode_item_ik": (
        "Só a ponta '_IK' (pé) + pole target -- os bones '_CTRL' por "
        "segmento são pulados, e fk_ik_switch é definido como IK (1)"
    ),

    # --- interface: aba Import ---
    "panel.new_model_header": "Novo Modelo",
    "panel.btn_new_blockymodel": ".blockymodel",
    "panel.btn_new_bbmodel": ".bbmodel",
    "panel.btn_more_import_options": "Mais Opções",
    "panel.btn_import_bedrock": "Bedrock (.json)",
    "panel.btn_import_attach": "Anexar ao Selecionado",
    "panel.hint_import_attach_none": "Selecione a Armature de destino primeiro",
    "panel.hint_import_attach_target": "Armature:",
    "panel.btn_import_anim": "Importar Animação",
    "panel.hint_import_anim_none": "Selecione a Armature de destino primeiro",
    "panel.hint_import_anim_target": "Armature:",

    # --- interface: aba Export ---
    "panel.btn_export": "Exportar Animações",
    "panel.btn_export_model": "Exportar Modelo (.blockymodel)",
    "panel.hint_export_none": "Selecione/ative uma Armature para exportar",
    "panel.hint_export_target": "Exportando de:",
    "panel.export_settings_box": "Configurações de Export",
    "panel.export_texture_picker": "Texture Picker",
    "panel.export_collection": "Coleção de Export",
    "panel.texture_picker_target_bone": "Bone Alvo",
    "panel.more_exports": "Mais Exports",
    "panel.hint_more_exports": "Outros formatos, separados do fluxo round-trip .blockyanim acima",
    "panel.btn_export_fbx_model": "Exportar Modelo (.fbx)",
    "panel.btn_export_fbx_anim": "Exportar Animações (.fbx)",

    # --- interface: aba Rig ---
    "panel.hint_rig_none": "Selecione uma Armature.",
    "panel.templates_box": "Templates de Personagem",
    "panel.active_rig_template": "Template de Rig:",
    "panel.active_shape_template": "Template de Shape:",
    "panel.active_collection_template": "Template de Collections:",
    "panel.template_none": "(nenhum)",
    "panel.template_save_replaces": "Já existe um template com esse nome, ele será substituído",
    "panel.template_save_replaces_builtin": "Substitui o template que vem com o addon (apague o seu para ele voltar)",
    "panel.load_shape_template": "Carregar Template de Shape...",
    "panel.load_collection_template": "Template de Collections",
    "panel.load_template_action": "Carregar",
    "panel.btn_reload_templates": "Recarregar Templates",
    "panel.btn_open_templates_folder": "Abrir Pasta de Templates",
    "panel.ik_chains_box": "Configurações de Bones",
    "panel.btn_auto_detect_bones": "Auto-Detectar Bones",
    # Headers dos grupos do formulário Arm/Leg ("Pole" é colapsável).
    "panel.bone_settings_group_bones": "Bones",
    "panel.bone_settings_group_pole": "Pole",
    "panel.load_preset": "Carregar Preset...",
    "panel.ctrl_tail_to_child": "Cadeia Contínua",
    "panel.field_root_bone": "Bone Raiz",
    "panel.field_tip_bone": "Bone da Ponta",
    "panel.field_pole_bone": "Referência do Pole",
    "panel.field_root_parent": "Pai da Raiz",
    "panel.field_side": "Lado",
    # Textos pelo efeito do toggle, não pelo mecanismo.
    "panel.field_pole_in_front": "Inverter Direção",
    # v0.7.5 -- prefixo "do Pole" removido (redundante dentro da caixa
    # "Pole" -- ver bone_settings_group_pole acima).
    "panel.field_pole_distance": "Distância",
    "panel.field_pole_angle_mode": "Modo do Ângulo",
    "panel.field_pole_angle_manual": "Ângulo (graus)",
    "panel.field_pole_angle_fine_tune": "Ajuste Fino do Ângulo (graus)",
    "panel.btn_create_rig": "Criar Rig",
    "panel.btn_remove_generated": "Remover Bones Gerados",

    # --- interface: campos por chain_type (aba Rig) ---
    "panel.field_chain_type": "Tipo",
    "panel.field_arm_shoulder": "Ombro / Parent Raiz",
    "panel.field_arm_upper": "Braço / Bone Raiz",
    "panel.field_arm_forearm": "Antebraço / Referência do Pole",
    "panel.field_arm_hand": "Mão / Bone Ponta",
    "panel.field_leg_pelvis": "Pelve / Parent Raiz",
    "panel.field_leg_thigh": "Coxa / Bone Raiz",
    "panel.field_leg_calf": "Panturrilha / Referência do Pole",
    "panel.field_leg_foot": "Pé / Bone Ponta",
    "panel.field_tail_parent": "Anexar A (Parent)",
    "panel.field_tail_start": "Bone Inicial",
    "panel.field_tail_end": "Bone Final",
    "panel.field_tail_tip_rotation_axis": "Eixo de Rotação da Ponta",
    "panel.field_tail_tip_rotation_deg": "Rotação da Ponta (graus)",
    "panel.field_tail_use_connect": "Conectado",
    "panel.hint_tail_no_ik": "Pronto para add-ons de física",
    "panel.field_neck_count": "Quantidade de Bones do Pescoço",
    "panel.field_neck_1": "Pescoço",
    "panel.field_neck_2": "Pescoço 2",
    "panel.field_neck_3": "Pescoço 3",
    "panel.field_neck_4": "Pescoço 4",
    "panel.field_neck_5": "Pescoço 5",
    "panel.field_head_bone": "Cabeça",
    "panel.field_head_end_bone": "Fim da Cabeça",
    "panel.field_spine_count": "Quantidade de Bones da Coluna",
    "panel.field_pelvis_bone": "Pelve",
    "panel.field_spine_1": "Coluna1",
    "panel.field_spine_2": "Coluna2",
    "panel.field_spine_3": "Coluna3",
    "panel.field_spine_4": "Coluna4",
    "panel.field_spine_ctrl_enabled": "Controlador Root da Coluna",
    "panel.hint_spine_no_ik": "Só organizacional",
    "panel.field_head_is_main": "Cabeça Principal",
    "panel.field_head_follow_enabled": "Cabeça Livre/Travada",
    "panel.head_camera_section": "Câmera em Primeira Pessoa",
    "panel.field_head_camera_enabled": "Criar Câmera em Primeira Pessoa",
    "panel.field_head_camera_parent_bone": "Bone Pai da Câmera",
    "panel.head_camera_offset_label": "Offset da Câmera",
    "panel.field_head_camera_offset_x": "X",
    "panel.field_head_camera_offset_y": "Y",
    "panel.field_head_camera_offset_z": "Z",
    "panel.head_camera_rotation_label": "Rotação da Câmera (graus)",
    "panel.field_head_camera_rotation_x": "X",
    "panel.field_head_camera_rotation_y": "Y",
    "panel.field_head_camera_rotation_z": "Z",
    "panel.field_head_camera_fov": "FOV (graus)",
    "panel.hint_head_camera": (
        "Posição/rotação são um ponto de partida -- ajuste fino pra alinhar com os olhos deste "
        "personagem"
    ),
    "panel.field_attachments_count": "Quantidade de Bones de Attachment",
    "panel.field_attachment": "Attachment",
    "panel.hint_attachments_no_ik": "Só organizacional",
    # Parte 3 -- entrada ROOT do Bone Settings.
    "panel.field_root_count": "Quantidade de Roots",
    "panel.field_root_origin": "Origin",
    "panel.field_root": "Root",
    "panel.hint_root_order": "Cada Root controla o de cima (Root 2 move o Origin)",
    "panel.hint_root_new_bone": "+ = cria o bone (só no Blender, nunca exportado)",
    # Parte 4 -- Rename Bones.
    "panel.field_rename_enabled": "Renomear Bones (nomes do Hytale)",
    "panel.hint_rename": "Campos marcados ganham o nome do Hytale (L-Arm, Head...). O export ainda pode usar os nomes originais",
    "panel.btn_rename_bones": "Renomear Bones",
    "panel.rename_nothing": "Nada pra renomear -- os bones marcados já usam os nomes padrão",
    "panel.rename_preview_title": "{count} bone(s) vão ser renomeados:",
    "panel.rename_preview_more": "...e mais {count}",
    "panel.rename_preview_title_ctrl": "{count} bone(s) vão ter controles com nome do Hytale (os originais mantêm o nome):",
    "panel.hint_rename_only_ctrl": "Só os bones de controle (_CTRL, _IK, Pole) ganham nome do Hytale. ORG/MCH mantêm o deles",
    "panel.rename_will_clear": "O rig gerado vai ser removido antes -- rode o Create Rig depois",
    "panel.field_texture_picker_bone": "Bone Alvo",
    "panel.field_texture_picker_ui_parent_bone": "Parent do Picker (opc.)",
    "panel.texture_picker_section_plane": "Imagem de Referência",
    "panel.field_texture_picker_plane_scale": "Tamanho",
    "panel.field_texture_picker_plane_offset_x": "Offset X",
    "panel.field_texture_picker_plane_offset_y": "Offset Y",
    "panel.hint_texture_picker_no_ik": "Cria um texture picker, não uma cadeia de bones",
    "panel.texture_picker_section_companions": "Companion Bones",
    "panel.field_texture_picker_extra_count": "Quantidade",
    "panel.field_texture_picker_extra_bone": "Bone",
    "panel.hint_texture_picker_companions_empty": (
        "Para bones extras que se movem junto com este (ex.: metades espelhadas)"
    ),
    "panel.texture_picker_extra_target_bones": "Companion Target Bones (preenchido automaticamente)",
    "panel.texture_picker_section_grid": "Grade",
    "panel.field_texture_picker_grid_cols": "Colunas",
    "panel.field_texture_picker_grid_rows": "Linhas",
    "panel.field_texture_picker_grid_cell_width": "Largura da Célula",
    "panel.field_texture_picker_grid_cell_height": "Altura da Célula",
    "panel.field_collection": "Collection",

    # --- interface: Collection Settings ---
    "panel.bone_collections_box": "Configurações de Collection",
    "panel.btn_load_default_collections": "Carregar Collections Padrão",
    "panel.btn_reset_bone_collection_grid": "Restaurar Linha/Coluna aos Padrões",
    "panel.hint_bone_collections": "Organize como os bones são agrupados para animação.",
    "panel.field_entry_type": "Tipo",
    "panel.field_section": "Seção",
    "panel.field_section_order": "Ordem",
    "panel.bone_collection_options_for": "Opções de '{name}'",
    "panel.field_parent": "Parent",
    "panel.field_show_in_animation": "Mostrar na Aba Animation",
    "panel.field_grid_row": "Linha",
    "panel.field_grid_column": "Coluna",

    # --- interface: Validate Rig / Shape Edit Mode / Vertex Edit Mode / Mirror Shape ---
    "panel.btn_validate_rig": "Verificar Rig",
    "panel.btn_shape_edit_enter": "Modo de Edição de Shape",
    "panel.btn_shape_edit_finish": "Finalizar Modo de Edição de Shape",
    "panel.hint_shape_edit_no_active_bone": (
        "Selecione um bone em Pose Mode para editar ou espelhar seu custom shape."
    ),
    "panel.btn_mirror_shape": "Espelhar Shape",
    "panel.btn_use_selected_as_widget": "Usar Objeto Selecionado como Widget",
    "panel.field_shape_translation": "Posição do Shape",
    "panel.field_shape_rotation": "Rotação do Shape",
    "panel.field_shape_scale": "Escala do Shape",
    "panel.btn_shape_vertex_edit_enter": "Editar Vértices do Shape",
    "panel.btn_shape_vertex_edit_finish": "Finalizar Edição de Vértices",
    "panel.label_vertex_edit_active": "Editando vértices do custom shape",
    # Dica + botão de voltar pra Armature presa em Shape Edit Mode.
    "panel.hint_shape_edit_active_elsewhere": "'{name}' ainda está em Shape Edit Mode.",
    "panel.btn_shape_edit_mode_reselect": "Selecionar",
    # v0.17 -- caminho de recuperação quando o widget foi deletado no
    # meio do Vertex Edit Mode (ver RIG_OT_hytale_shape_vertex_edit_mode_finish).
    "panel.hint_vertex_edit_orphaned": "A malha do widget sendo editada foi apagada -- finalize pra limpar esse estado.",

    # --- interface: aba Animation ---
    "panel.hint_anim_none": "Selecione uma armature para ver seus controles de animação.",
    "panel.anim_collections_box": "Collections de Bones",
    "panel.hint_anim_no_rig": "Nenhuma bone collection encontrada ainda -- gere o rig primeiro.",
    "panel.anim_fkik_box": "FK / IK",
    "panel.btn_snap_selected": "Snap FK/IK",
    "panel.hint_anim_no_fkik": "Nenhuma cadeia de Braço/Perna com switch de FK/IK gerado ainda.",
    "panel.anim_head_follow_box": "Cabeça Livre/Travada",

    # --- interface: avisos usados em mais de uma aba ---
    "panel.warn_anim_experimental": "Experimental",
    "panel.warn_texture_picker_wip_short": "WIP",
    "panel.warn_rig_experimental": "Geração de rig é experimental",

    # --- rigger: Shape Edit Mode, Vertex Edit Mode, Mirror Shape (botões) ---
    "rigger.tooltip.shape_edit_mode_enter": (
        "Muta os drivers de escala de shape FK/IK pra você poder redimensionar livremente o "
        "custom shape de cada controle -- use 'Finish Shape Edit Mode' depois pra travar o novo "
        "tamanho como o novo valor máximo do driver"
    ),
    "rigger.tooltip.shape_edit_mode_finish": (
        "Trava os tamanhos de custom shape definidos durante o Shape Edit Mode como o novo "
        "tamanho máximo, e restaura os drivers de escala de shape FK/IK"
    ),
    "rigger.tooltip.shape_vertex_edit_mode_enter": (
        "Entra em Edit Mode direto na malha do custom shape do bone ativo, escondendo todo "
        "outro widget deste personagem -- use 'Finish Vertex Edit' depois pra voltar ao Pose "
        "Mode"
    ),
    "rigger.tooltip.shape_vertex_edit_mode_finish": (
        "Sai do Edit Mode do widget, esconde de novo os widgets deste personagem, e volta ao "
        "Pose Mode"
    ),
    "rigger.tooltip.mirror_shape": (
        "Apaga o shape próprio do bone oposto L-/R- (se houver) e substitui por uma cópia "
        "espelhada da malha de shape deste bone, incluindo Location/Rotation/Scale"
    ),
    "rigger.tooltip.use_selected_as_widget": (
        "Copia a geometria do outro objeto de malha selecionado pro custom shape do bone ativo -- "
        "permite usar uma malha totalmente customizada, modelada à mão, como widget, em vez de "
        "editar em cima do shape da biblioteca"
    ),
    "rigger.tooltip.shape_edit_mode_reselect": (
        "Seleciona e ativa a Armature que ainda está em Shape Edit Mode, pra dar pra usar "
        "'Finish Shape Edit Mode' nela"
    ),

    # --- rigger: lista de cadeias (botões e campos) ---
    "rigger.tooltip.ik_chain_add": "Adiciona uma entrada vazia (Arm/Leg/Tail/Head/Spine) à lista",
    "rigger.tooltip.ik_chain_remove": "Remove a cadeia de IK selecionada da lista",
    "rigger.tooltip.ik_chain_move": "Move a entrada selecionada pra cima ou pra baixo na lista",
    "rigger.prop.ik_chain_move_direction_item_up": "Move a entrada uma posição pra cima",
    "rigger.prop.ik_chain_move_direction_item_down": "Move a entrada uma posição pra baixo",
    "rigger.tooltip.ik_chain_set_count": "Define a quantidade exata de cadeias IK na lista, adicionando ou removendo no fim",
    "rigger.tooltip.ik_chain_pick_bone": "Copia o nome do bone atualmente selecionado pra este campo",
    "rigger.tooltip.ik_chain_auto_detect": (
        "Varre os nomes de bone deste armature e tenta adicionar entradas de Head, Spine, Arm L/R "
        "e Leg L/R automaticamente, com base em palavras-chave comuns (Head/Neck, Pelvis/Spine, "
        "Shoulder/Arm/Forearm/Hand, Thigh/Calf/Foot) e prefixos de lado L-/R-. Nunca sobrescreve "
        "uma entrada que já existe pro mesmo tipo/lado -- sempre confira os bones preenchidos "
        "antes de usar o Create Rig"
    ),
    "rigger.tooltip.ik_chain_load_defaults": "Carrega um rig template calibrado, substituindo a lista atual de cadeias IK",
    "rigger.prop.ik_chain_load_defaults_preset": "Rig template pra carregar (vazio = o selecionado em Character Templates)",

    # --- rigger: Collection Settings (botões e campos) ---
    "rigger.tooltip.bone_collection_load_defaults": (
        "Preenche a lista com as collections nativas (Head/Spine/Body/Arm L/Arm R/Leg L/Leg R/"
        "Root)"
    ),
    "rigger.tooltip.bone_collection_reset_grid": (
        "Corrige Linha/Coluna das collections nativas (Head/Spine/Body/Arm L/Arm R/Leg L/Leg R/"
        "Root/Tail/Attachments) de volta pra posição de grade padrão, readicionando qualquer uma "
        "que tenha sido apagada da lista. Collections customizadas nunca são tocadas"
    ),
    "rigger.tooltip.bone_collection_add": (
        "Adiciona uma nova Collection (uma bone collection de verdade) ou Section (um cabeçalho "
        "visual) à lista"
    ),
    "rigger.prop.bone_collection_add_entry_type_item_collection": (
        "Uma bone collection de verdade -- bones podem ser atribuídos a ela"
    ),
    "rigger.prop.bone_collection_add_entry_type_item_section": (
        "Um cabeçalho visual na aba Animation -- não cria nenhuma bone collection real"
    ),
    "rigger.tooltip.bone_collection_remove": "Remove a entrada selecionada da lista",
    "rigger.tooltip.bone_collection_move": "Move a entrada selecionada pra cima ou pra baixo na lista",
    "rigger.prop.bone_collection_move_direction_item_up": "Move a entrada uma posição pra cima",
    "rigger.prop.bone_collection_move_direction_item_down": "Move a entrada uma posição pra baixo",

    # --- rigger: Validate Rig ---
    "rigger.tooltip.validate_rig": (
        "Verifica a lista de cadeias IK e a bone collection de exportação em busca de erros "
        "comuns (só relatório)"
    ),
    "rigger.prop.validate_rig_export_collection_name": (
        "Nome da bone collection onde os bones originais (não gerados) devem estar -- mesmo nome "
        "que exporter.py usa por padrão; mude só se você renomeou essa collection"
    ),

    # --- rigger: Remove Generated ---
    "rigger.tooltip.clear_generated": "Apaga todo bone gerado, mantendo só os originais",
    "rigger.prop.clear_generated_mode_item_only_rig": (
        "Apaga bones e collections gerados. Widgets, Collection Settings e Bone Settings são "
        "mantidos -- seguro se você editou shapes à mão em Shape Edit Mode"
    ),
    "rigger.prop.clear_generated_mode_item_delete_all": (
        "Apaga tudo: bones, collections, widgets, Collection Settings e Bone Settings -- volta a "
        "ser uma armature recém-importada"
    ),

    # --- rigger: Texture Picker + First Person Camera ---
    "rigger.tooltip.texture_picker_create": (
        "Constrói um rig de UV-picker de atlas de textura pra ela (um par de bones root.ui/"
        "cursor dedicado + plane de referência) a partir dos valores de Manual Grid"
    ),
    "rigger.tooltip.texture_picker_remove": (
        "Remove o rig de Texture Picker gerado (par de bones root.ui/cursor, plane de "
        "referência, driver de material) desta entrada"
    ),
    "rigger.tooltip.camera_create": "Cria (ou atualiza) um objeto Camera em Primeira Pessoa, parentado ao bone escolhido",
    "rigger.tooltip.camera_remove": "Remove o objeto Camera em Primeira Pessoa gerado para esta armature",

    # --- rigger: Create Rig ---
    "rigger.tooltip.generate_rig": "Cria ou atualiza as camadas do rig, constraints e custom shapes",

    # --- rigger: templates Rig/Shape/Collection ---
    "rigger.tooltip.shape_template_apply": "Define o shape template ativo (rode 'Create Rig' de novo pra aplicar)",
    "rigger.prop.shape_template_apply_template": "Shape template pra usar (vazio = o selecionado em Character Templates)",
    "rigger.tooltip.rig_template_save": "Salva a lista do Bone Settings (mais Continuous Chain e Rename Bones) como template na sua pasta Documents/Hyblend. Serve num import novo do mesmo modelo, mesmo depois de renomear os bones",
    "rigger.tooltip.rig_template_delete": "Apaga o rig template selecionado da sua pasta Documents/Hyblend (só templates de usuário)",
    "rigger.tooltip.shape_template_save": "Salva os custom shapes atuais como um template novo na sua pasta Documents/Hyblend",
    "rigger.tooltip.shape_template_delete": "Apaga o shape template selecionado da sua pasta Documents/Hyblend (só templates de usuário)",
    "rigger.tooltip.collection_template_save": (
        "Salva as bone collections customizadas da armature (criadas via o painel nativo Bone "
        "Collections do Blender) como um template novo na sua pasta Documents/Hyblend"
    ),
    "rigger.tooltip.collection_template_apply": "Aplica o collection template selecionado na armature ativa",
    "rigger.prop.collection_template_apply_template_name": "Collection template pra aplicar (vazio = o selecionado em Character Templates)",
    "rigger.tooltip.collection_template_delete": (
        "Apaga o collection template selecionado da sua pasta Documents/Hyblend (só templates de "
        "usuário)"
    ),

    # --- rigger: tooltip da custom property de switch (recriada a cada Create Rig) ---
    "rigger.runtime.fk_ik_switch_description": "0 = FK, 1 = IK",
    "rigger.runtime.head_follow_switch_description": (
        "1 = Segue {source} (padrão), 0 = Rotação livre (Head_CTRL continua seguindo a "
        "posição de {source}, mas a rotação/escala passam a seguir o Origin)"
    ),

    # --- rigger: HytaleBoneCollectionItem (campos) ---
    "rigger.prop.bone_collection_item_name": (
        "Nome -- para uma Collection, é também o nome real da bone collection do Blender depois "
        "de 'Create Rig'. Para uma Section, é só o texto do cabeçalho mostrado na aba Animation"
    ),
    "rigger.prop.bone_collection_item_entry_type_item_collection": (
        "Uma bone collection de verdade -- bones podem ser atribuídos a ela (via "
        "'Collection' nas entradas de Bone Settings)"
    ),
    "rigger.prop.bone_collection_item_entry_type_item_section": (
        "Um cabeçalho visual na aba Animation, agrupando Collections -- não cria "
        "nenhuma bone collection real"
    ),
    "rigger.prop.bone_collection_item_parent": (
        "Sob qual Section esta entrada fica -- para uma Collection, onde o botão dela aparece na "
        "aba Animation; para uma Section, sob qual outra Section ela está aninhada. 'Root / None' "
        "significa nível raiz (Section) ou cai pra 'Main' (Collection). Puramente visual, não afeta "
        "a hierarquia real de bone collection"
    ),
    "rigger.prop.bone_collection_item_show_in_animation_tab": (
        "Se um botão de mostrar/esconder desta collection aparece na caixa 'Bone Collections' da "
        "aba Animation. Desligado só esconde o botão aqui -- a collection em si não é afetada em "
        "nenhum outro lugar"
    ),
    "rigger.prop.bone_collection_item_row": (
        "Posição vertical entre irmãos (0 = topo, quanto maior, mais pra baixo). Para uma "
        "Collection, irmãos que compartilham a mesma Row ficam lado a lado, ordenados por Column"
    ),
    "rigger.prop.bone_collection_item_column": (
        "Posição horizontal dentro da Row (0 = mais à esquerda, quanto maior, mais à direita). "
        "Entradas com a mesma Row E Column são ordenadas alfabeticamente. Só pra Collection -- uma "
        "Section só usa Row"
    ),

    # --- rigger: HytaleIKChainItem (campos) ---
    "rigger.prop.ik_chain_chain_type": "O que esta entrada configura -- veja o seletor de tipo abaixo pros detalhes de cada um",
    "rigger.prop.ik_chain_chain_type_item_arm": (
        "Membro de dois segmentos (padrão ombro-braço-antebraço-mão) -- cadeia trocável entre IK/FK"
    ),
    "rigger.prop.ik_chain_chain_type_item_leg": (
        "Membro de dois segmentos (padrão pelve-coxa-panturrilha-pé) -- cadeia trocável entre IK/FK"
    ),
    "rigger.prop.ik_chain_chain_type_item_chain": (
        "Cadeia de bones conectados, da raiz até a ponta, sem IK -- pra caudas, orelhas compridas, "
        "ou qualquer sequência de bones que deva se mover junto"
    ),
    "rigger.prop.ik_chain_chain_type_item_head": (
        "Identifica os bones de controle Pescoço (1-5 bones) + Cabeça + Fim da Cabeça -- sem IK, "
        "só organizacional"
    ),
    "rigger.prop.ik_chain_chain_type_item_spine": (
        "Identifica os bones de controle Pelve + Coluna (1-4 bones) -- sem IK, só organizacional"
    ),
    "rigger.prop.ik_chain_chain_type_item_attachments": (
        "Identifica bones de controle de Attachment específicos por nome -- sem IK, só "
        "organizacional, além da detecção automática por nome"
    ),
    "rigger.prop.ik_chain_chain_type_item_texture_picker": (
        "Identifica um bone de controle cujo material é um atlas de textura -- constrói um rig de "
        "UV-picker pra ele. Sem IK"
    ),
    "rigger.prop.ik_chain_chain_type_item_root": (
        "Marca o(s) bone(s) de root: o Root 1 é o Origin principal, roots extras ficam acima dele. "
        "Pode criar os bones de root que faltarem (só no Blender, nunca exportados)"
    ),
    "rigger.prop.ik_chain_label": "Nome livre só pra identificar esta entrada na lista (ex.: Arm L)",
    "rigger.prop.ik_chain_root_bone": "Primeiro bone da cadeia (ex.: L-Arm, L-Thigh, ou o primeiro bone de cauda)",
    "rigger.prop.ik_chain_tip_bone": (
        "Último bone da cadeia -- o alvo/efetor pra Arm/Leg (ex.: L-Hand, L-Foot), ou o último "
        "bone de cauda pra Tail"
    ),
    "rigger.prop.ik_chain_pole_bone": (
        "Só Arm/Leg. Bone usado como referência de posição/orientação pro pole target (ex.: "
        "L-Forearm). Vazio = usa automaticamente o bone do meio do caminho raiz->ponta"
    ),
    "rigger.prop.ik_chain_parent_override": (
        "Bone ao qual a raiz desta cadeia é parentada (ex.: L-Shoulder_CTRL, Pelvis). Vazio = "
        "sem parent"
    ),
    "rigger.prop.ik_chain_tail_tip_rotation_axis": "Eixo local em torno do qual o ângulo de Tip Rotation dobra",
    "rigger.prop.ik_chain_tail_tip_rotation_axis_item_x": "Eixo X local",
    "rigger.prop.ik_chain_tail_tip_rotation_axis_item_y": (
        "Eixo Y local (a direção própria do bone -- só gira o roll, não dobra)"
    ),
    "rigger.prop.ik_chain_tail_tip_rotation_axis_item_z": "Eixo Z local",
    "rigger.prop.ik_chain_tail_tip_rotation_deg": (
        "Rotação extra aplicada à pose de repouso do bone da ponta, em torno de Tip Rotation Axis"
    ),
    "rigger.prop.ik_chain_tail_use_connect": (
        "Ativa o 'Connected' nativo do Blender (bone.use_connect) nos bones de controle desta "
        "cadeia -- desligado por padrão, já que a posição da cadeia já bate certo sem isso"
    ),
    "rigger.prop.ik_chain_side": (
        "Lado do corpo desta cadeia -- dá nome ao switch FK/IK, escolhe a collection e a cor de "
        "Arm/Leg e espelha a orientação dos controles entre esquerda e direita"
    ),
    "rigger.prop.ik_chain_pole_invert": (
        "Pole na frente (eixo Z positivo do bone de referência) em vez de atrás (padrão, -Z)"
    ),
    "rigger.prop.ik_chain_pole_distance": "Distância do pole target até o bone de referência (pole_bone)",
    "rigger.prop.ik_chain_pole_angle_mode_item_auto": (
        "Calcula o ângulo do pole automaticamente a partir da pose de repouso -- padrão seguro "
        "pra qualquer personagem"
    ),
    "rigger.prop.ik_chain_pole_angle_mode_item_manual": "Usa o valor digitado em Pole Angle diretamente",
    "rigger.prop.ik_chain_pole_angle_manual": (
        "Valor final de pole_angle, usado só em modo Manual. Ponto de partida sugerido: 90 ou -90 "
        "(cotovelo/joelho típico) -- ajuste o sinal/valor visualmente até o pole centralizar"
    ),
    "rigger.prop.ik_chain_pole_angle_fine_tune": "Somado ao valor calculado automaticamente -- usado só em modo Auto",
    "rigger.prop.ik_chain_neck_count": "Quantos campos de bone de Pescoço mostrar abaixo (0-5). Head/Head End são separados, sempre mostrados",
    "rigger.prop.ik_chain_org_bone_name_hint": (
        "Nome do bone original -- digite/escolha o nome do bone ORIGINAL (ex.: 'Head'), não "
        "'_CTRL': o bone de controle correspondente é resolvido automaticamente"
    ),
    "rigger.prop.ik_chain_head_bone": (
        "Bone original da cabeça (usa por padrão o mesmo bone que HEAD_COLLECTION_ROOT já aponta "
        "pro rig 'Player', sem o sufixo '_CTRL' -- ver constants.py) -- digite/escolha o nome do "
        "bone ORIGINAL (ex.: 'Head'), não '_CTRL': o bone de controle correspondente é resolvido "
        "automaticamente"
    ),
    "rigger.prop.ik_chain_head_end_bone": (
        "Bone opcional na ponta extrema da cabeça (ex.: um bone de fim de queixo/maxilar) -- "
        "deixe vazio se este rig não tiver um -- digite/escolha o nome do bone ORIGINAL (ex.: "
        "'Head'), não '_CTRL': o bone de controle correspondente é resolvido automaticamente"
    ),
    "rigger.prop.ik_chain_spine_count": (
        "Número total de bones nesta coluna, incluindo Pelvis (1-5). Ex.: 3 = Pelvis + Spine1 + "
        "Spine2"
    ),
    "rigger.prop.ik_chain_spine_ctrl_enabled": (
        "Se 'Create Rig' cria o root.spine_CTRL, além dos constraints de Spine Follow em "
        "Belly_CTRL/Chest_CTRL que dependem dele. Ligado por padrão. Desligar depois que o "
        "root.spine_CTRL já existe não apaga ele -- rode 'Remove Generated Bones' + 'Create Rig' "
        "de novo pra remover de vez."
    ),
    "rigger.prop.ik_chain_head_is_main": (
        "Marca esta como A cabeça principal -- a usada pro PROPERTIES (switch FK/IK), Head Follow, "
        "a bone collection Main/Head e o widget/cor dedicados de Head, quando existe mais de uma "
        "entrada HEAD na lista (ex.: uma criatura com várias cabeças). Funciona como um radio button: "
        "marcar aqui desmarca automaticamente qualquer outra entrada HEAD. A primeira entrada HEAD que "
        "você adiciona já nasce marcada; qualquer HEAD adicionada depois nasce desmarcada"
    ),
    "rigger.prop.ik_chain_head_follow_enabled": (
        "Trava a rotação de Head_CTRL ao bone predecessor (Neck, ou Chest), alternável em tempo "
        "de pose"
    ),
    "rigger.prop.ik_chain_head_camera_enabled": (
        "Adiciona um botão 'Create Camera' abaixo que parenta um objeto Camera real do Blender ao "
        "bone escolhido -- útil pra pré-visualizar/animar uma visão em primeira pessoa"
    ),
    "rigger.prop.ik_chain_head_camera_parent_bone": (
        "A qual bone a câmera deve ser parentada (bone parenting -- segue a pose do bone "
        "automaticamente). Pode ser qualquer bone desta armature, não só um bone de Head/Neck -- "
        "digite/escolha o nome do bone ORIGINAL (ex.: 'Head'), não '_CTRL': o bone de controle "
        "correspondente é resolvido automaticamente"
    ),
    "rigger.prop.ik_chain_head_camera_offset_x": "Ajusta a câmera pra esquerda/direita, local à orientação de repouso do bone pai",
    "rigger.prop.ik_chain_head_camera_offset_y": "Ajusta a câmera pra frente/trás, local à orientação de repouso do bone pai",
    "rigger.prop.ik_chain_head_camera_offset_z": "Ajusta a câmera pra cima/baixo, local à orientação de repouso do bone pai",
    "rigger.prop.ik_chain_head_camera_rotation_x": "Rotação extra (graus, X local ao bone pai)",
    "rigger.prop.ik_chain_head_camera_rotation_y": (
        "Rotação extra (graus, Y local ao bone pai) -- padrão confirmado pra deixar a câmera de "
        "frente na orientação de repouso do bone pai"
    ),
    "rigger.prop.ik_chain_head_camera_rotation_z": "Rotação extra (graus, Z local ao bone pai)",
    "rigger.prop.ik_chain_head_camera_fov": (
        "Campo de visão horizontal da câmera gerada, em graus -- não é um valor confirmado do "
        "Hytale, só um ponto de partida razoável de jogo em primeira pessoa"
    ),
    "rigger.prop.ik_chain_attachments_count": "Quantos campos de bone de Attachment mostrar abaixo (0-{max})",
    "rigger.prop.armature_rename_mode": "O que o 'Renomear Bones' renomeia",
    "rigger.prop.armature_rename_mode_item_all": (
        "Renomeia os bones originais -- todo bone gerado acompanha (L-Arm, L-Arm_CTRL, L-Arm_MCH...). Os "
        "nomes antigos ficam guardados: 'Use Original Names' no export .blockymodel/.blockyanim usa eles"
    ),
    "rigger.prop.armature_rename_mode_item_only_ctrl": (
        "Mantém os bones originais (ORG) e os MCH como estão; só os bones de controle (_CTRL, _IK, _Pole_CTRL, "
        "_Pole_Line) ganham os nomes do Hytale. Nada muda no modelo nem no export FBX"
    ),
    "rigger.prop.armature_rename_enabled": (
        "Mostra uma caixinha ao lado de cada picker de bone no Bone Settings e o botão 'Renomear Bones', "
        "que renomeia os bones marcados pros nomes padrão do Hytale (L-Arm, L-Forearm, Head, Pelvis...) "
        "pro espelhamento L/R funcionar. Os nomes antigos ficam guardados (botão de reverter, 'Use Original "
        "Names' no export)"
    ),
    "rigger.prop.ik_chain_rename_field": (
        "Renomeia este bone pro nome padrão do Hytale quando 'Renomear Bones' rodar. Desmarcado = mantém "
        "o nome original"
    ),
    "rigger.prop.ik_chain_rename_middle": (
        "Renomeia o Pole Reference e todo bone entre o Root e o Tip (Forearm, Forearm2... / Calf...) "
        "quando 'Renomear Bones' rodar. Desmarcado = mantêm os nomes originais"
    ),
    "rigger.tooltip.rename_bones": (
        "Renomeia os bones marcados no Bone Settings pros nomes padrão do Hytale. Remove o rig gerado antes, "
        "se houver (rode o Create Rig depois). Os nomes antigos ficam guardados pro botão de reverter e pro "
        "'Use Original Names' do export. Desfaça com Ctrl+Z"
    ),
    "rigger.tooltip.revert_bone_names": (
        "Reverte o 'Renomear Bones': todo bone renomeado volta pro nome original e os nomes de controle do "
        "Hytale (Only CTRL) são limpos -- os dois modos de uma vez. Remove o rig gerado antes, se houver (rode "
        "o Create Rig depois). Desfaça com Ctrl+Z"
    ),
    "panel.revert_nothing": "Nada pra reverter -- nenhum bone foi renomeado",
    "panel.revert_preview_title": "{count} nome(s) vão voltar pro original:",
    "exporter.prop.use_original_names": (
        "Bones renomeados com o 'Renomear Bones' (All Bones) são gravados com o nome que tinham antes do "
        "rename (o nome do jogo) em vez do novo. DESLIGADO (padrão): grava os nomes novos. Só disponível "
        "quando algum bone foi renomeado"
    ),
    "exporter.prop.blockymodel_use_original_bone_positions": (
        "Exporta cada bone na posição/rotação que tinha quando o modelo foi importado, ignorando o que foi "
        "movido ou girado no Edit Mode (padrão: LIGADO). DESLIGADO: usa os bones como estão agora (mover um bone "
        "muda só o pivô; o shape fica onde a malha está). Bones importados antes desta versão ficam na "
        "posição atual"
    ),
    "exporter.prop.blockymodel_export_texture": (
        "Salva a textura do modelo ao lado do .blockymodel como '<nome do "
        "modelo>.png' (o nome que o plugin do Hytale no Blockbench procura). "
        "Só quando a textura ainda não é um arquivo em disco -- ex: modelo "
        "convertido do Minecraft, cuja textura foi ampliada pra densidade do "
        "Hytale e só existe dentro do .blend. Nunca sobrescreve um '<nome do "
        "modelo>.png' que já exista"
    ),
    "rigger.prop.ik_chain_root_count": (
        "Quantos bones de root (1-{max}). O Root 1 é o Origin principal; o Root 2 vira pai do Root 1, "
        "o Root 3 pai do Root 2, e assim por diante -- tudo que já está no Origin continua nele"
    ),
    "rigger.prop.ik_chain_root_slot_bone": (
        "Nome do bone ORIGINAL (não '_CTRL') usado como este root. Com 'New Bone' ligado, é o nome do "
        "bone a ser criado (vazio = 'Origin' pro Root 1, 'Root<N>' pros outros)"
    ),
    "rigger.prop.ik_chain_root_create": (
        "Cria este bone de root em vez de usar um do modelo. O bone criado existe só no Blender, como "
        "controle -- nunca é exportado pro .blockymodel/.blockyanim"
    ),
    "rigger.prop.ik_chain_texture_picker_bone": (
        "O bone cuja malha tem o atlas de textura (ex.: todas as expressões de boca numa imagem "
        "só) -- digite/escolha o nome do bone ORIGINAL (ex.: 'Head'), não '_CTRL': o bone de "
        "controle correspondente é resolvido automaticamente"
    ),
    "rigger.prop.ik_chain_texture_picker_ui_parent_bone": (
        "Só necessário se o picker deve se anexar em algum lugar diferente do Target Bone. Deixe "
        "vazio na maioria dos casos -- digite/escolha o nome do bone ORIGINAL (ex.: 'Head'), não "
        "'_CTRL': o bone de controle correspondente é resolvido automaticamente"
    ),
    "rigger.prop.ik_chain_texture_picker_plane_scale": (
        "Tamanho da imagem de referência mostrada na viewport pra seleção. Não afeta a animação "
        "exportada"
    ),
    "rigger.prop.ik_chain_texture_picker_plane_offset_x": "Ajusta a imagem de referência pra esquerda/direita, se não estiver alinhada certo",
    "rigger.prop.ik_chain_texture_picker_plane_offset_y": "Ajusta a imagem de referência pra cima/baixo, se não estiver alinhada certo",
    "rigger.prop.ik_chain_texture_picker_grid_cols": "Quantas células de atlas de textura na horizontal (esquerda pra direita)",
    "rigger.prop.ik_chain_texture_picker_grid_rows": "Quantas linhas de células de atlas de textura -- geralmente 1",
    "rigger.prop.ik_chain_texture_picker_grid_cell_width": "Distância em pixels de uma célula de atlas de textura até a próxima, como visto no Blockbench",
    "rigger.prop.ik_chain_texture_picker_grid_cell_height": "Distância em pixels entre linhas de células de atlas de textura. Não importa se Rows é 1",
    "rigger.prop.ik_chain_texture_picker_extra_bone_count": (
        "Quantos outros bones compartilham a textura deste alvo e devem se mover junto com ele "
        "(0-{max})"
    ),
    "rigger.prop.ik_chain_texture_picker_extra_bone": (
        "Outro bone cuja malha compartilha essa mesma textura de boca (ex.: uma metade esquerda/"
        "direita espelhada) e deve mudar de expressão junto com o Target Bone -- digite/escolha o "
        "nome do bone ORIGINAL (ex.: 'Head'), não '_CTRL': o bone de controle correspondente é "
        "resolvido automaticamente"
    ),
    "rigger.prop.ik_chain_collection_override": (
        "Em qual bone collection os bones desta cadeia vão (Main ou Face, conforme organizado em "
        "'Collection Settings'). 'Auto (default)' mantém o comportamento nativo -- Arm L/Arm R/Leg "
        "L/Leg R"
    ),

    # --- rigger/__init__: properties soltas do Armature ---
    "rigger.prop.armature_ctrl_tail_to_child": (
        "No 'Create Rig', aponta o Tail de cada _CTRL das entradas Head, Spine, Arm e Leg pro início do "
        "próximo bone daquela entrada (o último bone da Spine aponta pro primeiro bone da entrada Head). "
        "Hand/Foot apontam pro attachment deles, igual à ponta do IK; um último bone sem próximo segue a "
        "direção do bone anterior. O próprio bone Head mantém a orientação original. Só o Tail se move -- o "
        "início de cada bone fica no lugar. Os controles de Arm/Leg sempre ganham o roll de membro, ligado ou não"
    ),
    "rigger.prop.armature_active_rig_template": (
        "Nome do rig template (templates/rig/*.json) atualmente carregado nesta armature -- "
        "definido automaticamente por 'Load Hytale IK Chain Preset', e o nome sugerido ao salvar um template"
    ),
    "rigger.prop.armature_active_shape_template": (
        "Nome do shape template (templates/shapes/*.json) atualmente ativo pros custom shapes "
        "desta armature -- independente do rig template, dá pra combinar à vontade"
    ),
    "rigger.prop.armature_active_collection_template": (
        "Nome do collection template (templates/collections/*.json) salvo ou aplicado mais "
        "recentemente nesta armature -- puramente informativo (diferente dos templates de rig/"
        "shape, este nunca é auto-aplicado por 'Create Rig')"
    ),
    "rigger.prop.armature_shape_edit_mode": (
        "Verdadeiro enquanto o mute de RIG_OT_hytale_shape_edit_mode_enter está em efeito nos "
        "drivers de escala de shape FK/IK desta armature -- definido/limpo automaticamente por "
        "'Enter'/'Finish Shape Edit Mode', lido por interface.py pra decidir qual dos dois botões "
        "mostrar e por 'Create Rig'/'Remove Generated Hytale Rig Bones' pra recusar rodar no meio "
        "de uma edição"
    ),
    "rigger.prop.armature_shape_vertex_edit_mode": (
        "Verdadeiro enquanto a malha de um custom shape (o widget usado pelo pose bone ativo) "
        "está aberta em Edit Mode via 'Edit Shape Vertices' -- definido/limpo automaticamente por "
        "esse operador e 'Finish Vertex Edit', lido por interface.py pra desenhar o painel certo "
        "(active_object é a MALHA do widget nesse estado, não a Armature) e por 'Create Rig'/"
        "'Remove Generated Hytale Rig Bones'/'Finish Shape Edit Mode' pra recusar rodar com uma "
        "sessão de edição de vértice pendurada"
    ),

    # --- templates: tooltips de botão ---
    "templates.tooltip.reload": "Reescaneia as pastas de templates em busca de arquivos .json novos ou editados",
    "templates.tooltip.open_user_folder": "Abre sua pasta Documents/Hyblend/templates no explorador de arquivos",

    # --- importer: tooltips de botão ---
    "importer.tooltip.bbmodel": "Importa um personagem/criatura do Hytale de um projeto Blockbench (.bbmodel)",

    # --- exporter: tooltips de botão ---
    "exporter.tooltip.select_all_actions": "Marca ou desmarca todas as Actions da lista abaixo",
    "exporter.prop.blockyanim_keyframe_mode": "Quais keyframes vão pro arquivo",
    "exporter.prop.blockyanim_keyframe_mode_item_exact": "Toca igualzinho ao Blender. Guarda só os keyframes que fazem diferença (recomendado)",
    "exporter.prop.blockyanim_keyframe_mode_item_keys": "Os frames que você chaveou, mais alguns keys extras só onde o jogo se afastaria do Blender -- mais fácil de editar no Blockbench",
    "exporter.tooltip.blockyanim": (
        "Exporta em lote uma ou mais Actions da Armature selecionada/ativa pro formato "
        ".blockyanim do Hytale -- um arquivo por Action, numa pasta escolhida"
    ),
    "exporter.tooltip.blockymodel": (
        "Exporta a pose de repouso (bind pose) da Armature selecionada/ativa pro formato "
        ".blockymodel do Hytale -- posição/orientação vêm dos transforms atuais dos "
        "bones, shape/UV vêm do que foi capturado quando o personagem foi importado"
    ),
    "exporter.tooltip.fbx_model": (
        "Exporta a pose de repouso (bind pose) da Armature selecionada/ativa -- e, "
        "opcionalmente, suas malhas de referência -- pra um único arquivo .fbx. Nenhuma "
        "animação é incluída; use 'Hytale Animations (.fbx)' pra isso"
    ),
    "exporter.tooltip.fbx_anim": (
        "Exporta em lote uma ou mais Actions da Armature selecionada/ativa pra .fbx -- um "
        "arquivo por Action (rig + animação assada, e opcionalmente as malhas de "
        "referência), numa pasta escolhida"
    ),

    # --- exporter: relatório de pivô movido ({count} bones, {names} prévia) ---
    "exporter.runtime.blockymodel_no_original_positions": (
        "'Use Original Bone Positions': {count} bone(s) não têm a posição do import salva (importados "
        "antes desta versão, ou criados à mão) -- exportados na posição atual: {names}. Reimporte o "
        "modelo pra corrigir"
    ),
    "exporter.runtime.blockymodel_pivot_shifted": (
        "{count} bone(s) só tiveram o pivô movido no Edit Mode -- o shape ficou onde a malha "
        "está: {names}"
    ),
    "exporter.runtime.blockymodel_pivot_rotated": (
        "{count} bone(s) foram girados no Edit Mode desde o import -- o shape do Hytale não tem "
        "rotação própria, então a peça inteira foi exportada girando junto com o pivô: {names}. Só "
        "mover (sem girar) um bone mantém o shape no lugar"
    ),

    # --- anim_importer: tooltip de botão ---
    "anim_importer.tooltip.blockyanim": "Importa um arquivo .blockyanim pra armature ativa",

    # --- interface: tooltips das abas e sub-abas ---
    "panel.tab_import_tooltip": "Importar modelos e attachments",
    "panel.tab_export_tooltip": "Exportar animações",
    "panel.tab_rig_tooltip": "Cadeias IK e geração de rig",
    "panel.tab_animation_tooltip": "Visibilidade de bone collection e switches de FK/IK",
    "panel.tab_info_tooltip": "Créditos e links",
    # Rótulos das sub-abas: "Setup" e "Bone Settings" ficam em inglês de propósito (pedido do usuário).
    "panel.rig_subtab_setup_label": "Setup",
    "panel.rig_subtab_setup_tooltip": "Criar/atualizar o rig e ações do dia a dia",
    "panel.rig_subtab_bone_settings_label": "Bone Settings",
    "panel.rig_subtab_bone_settings_tooltip": "Cadeias IK e configuração por bone",
    "panel.rig_subtab_advanced_label": "Avançado",
    "panel.rig_subtab_advanced_tooltip": "Bone collections e templates de personagem",

    # --- rigger: tooltips de Menu ---
    "rigger.tooltip.ik_chain_add_menu": "Escolha qual tipo de entrada adicionar à lista",
    "rigger.tooltip.clear_generated_menu": "Apaga bones gerados -- escolha o quanto remover",

    # --- common: HYTALE_OT_pick_bone_into_field ---
    "common.tooltip.pick_bone_into_field": "Copia o nome do bone atualmente selecionado pra este campo",
    "common.prop.pick_bone_data_path": (
        "Caminho, relativo ao objeto ativo, até o datablock dono do campo (ex.: "
        "'data.hytale_export_settings')"
    ),
    "common.prop.pick_bone_field": "Nome da StringProperty a preencher",

    # --- importer/bedrock: IMPORT_OT_hytale_bedrock_model ---
    "importer.tooltip.bedrock_model": (
        "Importa um modelo Bedrock do Minecraft (.json -- addons Bedrock e "
        "mods) convertido pro padrão do Hytale: "
        "escala, densidade de textura e inflate"
    ),
    "importer.bedrock_section_conversion": "Conversão",
    "importer.bedrock_geometry_identifier": "Geometria",
    "importer.bedrock_inflate_to_stretch": "Inflate para Stretch",
    "importer.bedrock_drop_locator_bones": "Remover Bones de Locator",
    "importer.prop.bedrock_model_format_item_character": (
        "Criaturas, mobs, personagens, vestíveis -- geometria e textura x4 (16 -> 64 por bloco)"
    ),
    "importer.prop.bedrock_model_format_item_prop": (
        "Blocos, móveis, props -- geometria e textura x2 (16 -> 32 por bloco)"
    ),
    "importer.prop.bedrock_geometry_identifier": (
        "Qual geometria importar quando o arquivo tem mais de uma (ex: "
        "geometry.meu_modelo ou só meu_modelo). Vazio = a primeira"
    ),
    "importer.prop.bedrock_inflate_to_stretch": (
        "O Hytale não tem 'inflate'. Converte pra 'stretch' em torno do "
        "centro do cubo, que dá o mesmo resultado sem mexer na UV. "
        "Cubos achatados (tamanho 0) continuam achatados"
    ),
    "importer.prop.bedrock_drop_locator_bones": (
        "Pula bones que só guardam locators (pontos de efeito/item usados "
        "por mods do Minecraft, ex: locator_mouth) e não têm cubos"
    ),

    # --- importer/common_options: opções comuns dos importadores ---

    # interface/gpu_ui/ -- UI experimental por GPU (Blender 5.0+)
    "gpu_ui.tip_visibility": "Clique: mostrar/esconder esta Bone Collection · segure e passe por cima de outras pra aplicar o mesmo · I ou botão direito: inserir keyframe",
    "gpu_ui.toast_keyframe": "Keyframe inserido: {name}",
    "gpu_ui.tip_fk_ik": "Clique: troca esta cadeia · segure e passe por cima de outras cadeias pra trocar também · I: keyframe no switch",
    "gpu_ui.tip_head_follow": "Head Free/Lock · I: keyframe no switch",
    "gpu_ui.undo_visibility": "Visibilidade da Bone Collection",
}
