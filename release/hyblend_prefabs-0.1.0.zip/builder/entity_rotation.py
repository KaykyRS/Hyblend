"""entity_rotation.py -- decodifica a rotacao (Pitch/Yaw/Roll, radianos) de
uma entrada de entities[] do .prefab.json pra um Quaternion Blender. Formula
unificada, fonte e historico em DEVELOPER_NOTES.md ("Rotacao de entities")."""

from __future__ import annotations

import math

from mathutils import Matrix, Quaternion

_IDENTITY = Quaternion((1.0, 0.0, 0.0), 0.0)


def _valid(pitch, yaw, roll) -> bool:
    return pitch is not None and yaw is not None and roll is not None


def decode_block_entity_rotation(pitch, yaw, roll, apply_heuristic: bool = True) -> Quaternion:
    """Block entities (Components.BlockEntity presente), angulos de
    Components.HeadRotation.Rotation. Mesma formula de item/model entity
    (delega pra decode_item_or_model_entity_rotation) -- so o campo de
    origem dos angulos muda, nao a formula. Pivo e' responsabilidade do
    chamador (_place_entities)."""
    if not apply_heuristic or not _valid(pitch, yaw, roll):
        return Quaternion(_IDENTITY)

    return decode_item_or_model_entity_rotation(pitch, yaw, roll, apply_heuristic)


def decode_item_or_model_entity_rotation(pitch, yaw, roll, apply_heuristic: bool = True) -> Quaternion:
    """Item entities (Components.Item sem BlockEntity) e model entities
    (Components.Model), angulos de Components.Transform.Rotation.

    R = Ry(Yaw) @ Rx(Pitch) @ Rz(Roll) @ Ry(pi)

    O Ry(pi) final e porque modelos de item/personagem "olham" pro lado
    oposto dos modelos de bloco (sem ele, trofeus de parede ficam de costas)."""
    if not apply_heuristic or not _valid(pitch, yaw, roll):
        return Quaternion(_IDENTITY)

    ry_pi = Matrix.Rotation(math.pi, 4, "Y")
    rz = Matrix.Rotation(float(roll), 4, "Z")
    rx = Matrix.Rotation(float(pitch), 4, "X")
    ry_yaw = Matrix.Rotation(float(yaw), 4, "Y")
    return (ry_yaw @ rx @ rz @ ry_pi).to_quaternion()
