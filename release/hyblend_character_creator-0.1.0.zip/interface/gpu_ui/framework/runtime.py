"""Hospedagem da UI dentro do Blender.

Como a UI entra na tela:
  1. O painel-gancho do app (um Panel sem cabeçalho) chama `ensure_host()` no draw.
  2. Panel.draw não pode rodar operadores → um timer de 0 s invoca
     `<namespace>.gpu_ui_host` (framework.configure), um operador modal que
     vive enquanto a aba existir.
  3. Esse operador cria um `PanelHost`, que registra:
       - dois draw handlers POST_PIXEL (sidebar e viewport);
       - o modal handler (mouse/teclado chegam antes do Blender);
       - um timer cuja frequência depende do que está acontecendo.

Onde desenha:
  - Region Overlap ligado (padrão): tudo no viewport (a sidebar é transparente
    por cima), então não existe emenda de cor entre duas regiões.
  - Region Overlap desligado: cada região mostra a sua parte.

Vários addons na MESMA aba (seletor dos addons Hyblend): cada addon tem o
seu runtime, mas só o host do addon ATIVO aparece -- `register(active=fn)`;
fn() False = o host age como se a aba estivesse fechada (não desenha, não
come evento) e continua vivo, então voltar pra ele é instantâneo.

Custo:
  - A UI é renderizada numa textura (GPUOffScreen) só quando algo muda; nos
    outros redesenhos do viewport ela é só copiada (1 draw call).
  - Eventos longe do painel saem por um caminho rápido que usa números
    guardados no último desenho, sem consultar o Blender.
"""

import math
import re
import time
import traceback
from types import SimpleNamespace

import bpy
import gpu
from bpy.app.handlers import persistent

from . import CONFIG, ops_namespace
from .core import Frame, KeyEvent, Rect, Theme, draw_tooltip, find_by_key, scroll_target, tooltip_text
from .motion import animate, forget, prune
from .navigator import Navigator
from .renderer import Renderer, forget_fonts, release_resources, render_to_texture

CATEGORY = "Hyblend"       # aba na sidebar (N) -- a mesma do painel clássico (e dos outros addons Hyblend)
TABS_WIDTH = 26.0          # faixa das abas verticais do Blender
GAP = 8.0                  # respiro entre o painel e as bordas da região
MIN_WIDTH = 220.0          # padrão; o app pode pedir outra em register(min_width=)
GRIP = 5.0                 # meia-largura da faixa "pegável" da borda esquerda
GRIP_X, GRIP_Y = "_grip_x", "_grip_y"   # bordas arrastáveis (largura / altura)
HEIGHT_SPRING = 0.22       # duração da animação quando a altura muda sozinha
CACHE_PAD = 20.0           # folga da textura para a sombra
SAFETY_REFRESH = 1.0       # reconstrói no máx. 1x/s mesmo sem motivo aparente
TICK_FAST, TICK_BLINK, TICK_IDLE = 1 / 60, 0.1, 1.0
EXIT_DURATION = 0.15       # animação de saída ao esconder a sidebar (N)
EXIT_HOLD = 1.0            # saída pela tecla, mas a sidebar não fechou nesse tempo: volta ao normal
STALE_AFTER = 10.0         # sem eventos por X s → o modal morreu (folga p/ operações longas)

# Funções fornecidas pelo app em register()
_app = SimpleNamespace(build=None, extra_scale=None, size_get=None, size_set=None, signature=None,
                       text=None, theme=None, default_width=0.0, min_width=MIN_WIDTH, tooltip=None,
                       active=None)
_OPERATOR = []             # classe do operador modal (criada no register com o namespace do app)
_HOSTS = {}


def _t(key, fallback):
    """Texto traduzido pelo app (translations/), com fallback em inglês."""
    if _app.text is not None:
        try:
            return _app.text(key)
        except Exception:
            pass
    return fallback

_BOOTING = {}             # ptrs -> quando o timer de montagem foi pedido
BOOT_TIMEOUT = 2.0        # timer que não disparou nesse tempo (ex.: apagado ao abrir .blend) é refeito
_BROKEN = set()
_ERRORS = {}              # ptrs -> última linha do erro (mostrada no painel-gancho, pra relato de bug)


def _mark_broken(ptrs):
    """Painel desta sidebar quebrou: guarda o erro (chamar dentro do except)."""
    _BROKEN.add(ptrs)
    _ERRORS[ptrs] = traceback.format_exc().strip().splitlines()[-1][:300]


def host_error(context):
    """Última linha do erro desta sidebar ("" se não houver)."""
    try:
        return _ERRORS.get(_ptrs(context.window, context.area, context.region), "")
    except AttributeError:
        return ""

_PASS = {"PASS_THROUGH"}
_PASS_KEYS = {"ESC", "SPACE", "LEFT_CTRL", "RIGHT_CTRL", "LEFT_ALT", "RIGHT_ALT", "LEFT_SHIFT",
              "RIGHT_SHIFT", "OSKEY"}
FKEY = re.compile(r"^F\d{1,2}$")
_EAT = {"RUNNING_MODAL"}


# --------------------------------------------------------------------------
# Localizar janela/área/regiões pelos ponteiros
# --------------------------------------------------------------------------

def _ptrs(window, area, region):
    return (window.as_pointer(), area.as_pointer(), region.as_pointer())


def _lookup(ptrs):
    """(janela, área, sidebar, viewport) atuais, ou None se sumiram.

    Nunca guardamos esses objetos por muito tempo: uma área fechada deixaria
    uma referência inválida. Procurar de novo é barato.
    """
    wm = bpy.context.window_manager
    for window in (wm.windows if wm else ()):
        if window.as_pointer() != ptrs[0]:
            continue
        for area in window.screen.areas:
            if area.as_pointer() != ptrs[1]:
                continue
            sidebar = next((r for r in area.regions if r.as_pointer() == ptrs[2]), None)
            viewport = next((r for r in area.regions if r.type == "WINDOW"), None)
            return (window, area, sidebar, viewport) if sidebar else None
    return None


def _app_active():
    """Este addon é o escolhido no seletor dos addons Hyblend? (sem seletor: sim)"""
    if _app.active is None:
        return True
    try:
        return bool(_app.active())
    except Exception:
        traceback.print_exc()
        return True


def _category_open(space, sidebar):
    return (space.show_region_ui and sidebar.width > 60
            and getattr(sidebar, "active_panel_category", CATEGORY) == CATEGORY
            and _app_active())


# --------------------------------------------------------------------------
# API usada pelo painel-gancho
# --------------------------------------------------------------------------

def host_status(context):
    try:
        ptrs = _ptrs(context.window, context.area, context.region)
    except AttributeError:
        return "OFF"
    if ptrs in _BROKEN:
        return "ERROR"
    if ptrs in _HOSTS:
        return "READY"
    return "BOOTING" if ptrs in _BOOTING else "OFF"


def ensure_host(context):
    """Chamado no Panel.draw: garante que existe um host vivo para esta sidebar."""
    if not (context.window and context.area and context.region) or context.region.type != "UI":
        return
    ptrs = _ptrs(context.window, context.area, context.region)
    if ptrs in _BROKEN:
        return
    # Não confiar só na "flag": abrir outro .blend apaga timers não
    # persistentes. Pedido velho sem timer vivo = pede de novo.
    if ptrs in _BOOTING and time.monotonic() - _BOOTING[ptrs] < BOOT_TIMEOUT:
        return
    host = _HOSTS.get(ptrs)
    if host is not None:
        if time.monotonic() - host.heartbeat < STALE_AFTER:
            return
        host.close()                       # o modal parou (ex.: arquivo reaberto)
    _BOOTING[ptrs] = time.monotonic()
    bpy.app.timers.register(lambda: _boot(ptrs), first_interval=0.0)


def _boot(ptrs):
    _BOOTING.pop(ptrs, None)
    found = _lookup(ptrs)
    if found is None or ptrs in _HOSTS:
        return None
    window, area, sidebar, _ = found
    try:
        with bpy.context.temp_override(window=window, area=area, region=sidebar):
            ops_namespace().gpu_ui_host("INVOKE_DEFAULT")
    except Exception:
        traceback.print_exc()
        _mark_broken(ptrs)
        sidebar.tag_redraw()
    return None


def clear_error(context):
    ptrs = _ptrs(context.window, context.area, context.region)
    _BROKEN.discard(ptrs)
    _ERRORS.pop(ptrs, None)


def shutdown_all():
    for host in list(_HOSTS.values()):
        try:
            host.close()
        except Exception:            # janela fechando etc.: os outros hosts saem mesmo assim
            traceback.print_exc()
            _HOSTS.pop(host.ptrs, None)
    _BOOTING.clear()
    _BROKEN.clear()
    _ERRORS.clear()


def apply_size(axis, value):
    """Largura/altura editada nas preferências ("width"/"height"): aplica nos hosts abertos."""
    for host in list(_HOSTS.values()):
        key = _Grip.STATE_KEYS[axis]
        if value > 0:
            host.state[key] = value
        else:
            host.state.pop(key, None)
        host.request(viewport=True)


# --------------------------------------------------------------------------
# PanelHost
# --------------------------------------------------------------------------

class _Clipboard:
    def __init__(self, wm):
        self.wm = wm

    def get(self):
        return self.wm.clipboard or ""

    def set(self, value):
        self.wm.clipboard = value


class PanelHost:
    """Tudo o que uma sidebar com a UI customizada precisa."""

    def __init__(self, context):
        self.ptrs = _ptrs(context.window, context.area, context.region)
        self.window = context.window
        self.state = {}
        for axis, key in _Grip.STATE_KEYS.items():     # tamanho salvo nas preferências
            saved = _app.size_get(context, axis) if _app.size_get else 0.0
            if saved > 0:
                self.state[key] = saved
        self.theme = _app.theme or Theme()
        self.renderer = Renderer()
        self.navigator = Navigator(self)
        self.tree = None
        self.closed = False
        self.heartbeat = time.monotonic()
        # Geometria do último desenho, em números (o caminho rápido de eventos usa isto)
        self.geo = SimpleNamespace(visible=False, overlap=True, scale=1.0, sx=0, sy=0, sh=0,
                                   ax=0, aw=0, ay=0, ah=0, frame=Rect(0, 0, 0, 0), panel=Rect(0, 0, 0, 0),
                                   widest=1e9, resizable=True)
        self.grips = {GRIP_X: _Grip(self, "width"), GRIP_Y: _Grip(self, "height")}
        self._frame_key = None             # (área disponível, escala) da última renderização
        self._shown_height = None          # altura exibida (animada)
        self._fit_width = None             # largura usada no último _fit_height
        self._height_range = (0.0, 1e9)    # (mínima, máxima) útil da página atual
        self._nav_hidden = False          # escondemos o gizmo nativo?
        # cache
        self._offscreen = None
        self._placement = None            # (x0, y0, w, h, escala) da última renderização
        self._dirty = True
        self._animating = False
        self._tooltip_waiting = False
        self._signature = None
        self._built_at = 0.0
        self._blink = None
        self._reveal = 0.0
        self._exit = None                  # (início, x, y da sidebar) durante a animação de saída
        self._timer = None
        self._tick = None
        self._last_tick = 0.0
        self._handles = (
            (bpy.types.SpaceView3D.draw_handler_add(self.on_draw, (), "UI", "POST_PIXEL"), "UI"),
            (bpy.types.SpaceView3D.draw_handler_add(self.on_draw, (), "WINDOW", "POST_PIXEL"), "WINDOW"),
        )
        self._set_tick(TICK_IDLE)
        _HOSTS[self.ptrs] = self
        self.request()

    # ---------------------------------------------------------------- estado
    @property
    def panel(self):
        return self.geo.panel

    @property
    def extended(self):
        return self.geo.visible and self.geo.panel.x < 0

    def lookup(self):
        return _lookup(self.ptrs)

    def request(self, viewport=False, content=True):
        """Pede redesenho. content=False = só recompor (nada dentro da UI mudou)."""
        if content:
            self._dirty = True
        found = self.lookup()
        if found is None:
            return
        _, _, sidebar, vp = found
        if not self.geo.overlap:
            sidebar.tag_redraw()
        if vp is not None and (self.geo.overlap or self.extended or viewport):
            vp.tag_redraw()

    def invalidate(self):
        """Dados mudaram por fora (undo etc.): reconstruir tudo."""
        self._signature = None
        self.request()

    def _set_tick(self, interval):
        if self.closed or interval == self._tick:
            return
        wm = bpy.context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
        self._timer = wm.event_timer_add(interval, window=self.window)
        self._tick = interval

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.state.pop("_drag", {}).get("cursor") or self.state.pop("_mmb", None):
            try:
                self.window.cursor_modal_restore()
            except (ReferenceError, AttributeError):
                pass
        self._show_native_nav()
        for handle, kind in self._handles:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, kind)
            except (ValueError, ReferenceError):
                pass
        if self._timer is not None:
            try:
                bpy.context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        if _HOSTS.get(self.ptrs) is self:
            del _HOSTS[self.ptrs]
        self.tree = self._offscreen = None
        try:
            self.request(viewport=True)
        except Exception:            # tela já sumiu (janela fechando): nada pra redesenhar
            pass

    # ------------------------------------------------- gizmo nativo de navegação
    def _sync_native_nav(self, space):
        """Painel alargado cobriria o gizmo nativo: escondemos e o Navigator assume."""
        if self.extended:
            if space.show_gizmo_navigate and not self._nav_hidden:
                space.show_gizmo_navigate = False
                self._nav_hidden = True
        elif self._nav_hidden:
            self._show_native_nav(space)

    def _show_native_nav(self, space=None):
        if not self._nav_hidden:
            return
        try:
            if space is None:
                found = self.lookup()
                space = found[1].spaces.active if found else None
            if space is not None:
                space.show_gizmo_navigate = True
        except (ReferenceError, AttributeError):
            pass
        self._nav_hidden = False

    # ------------------------------------------------------------- geometria
    def _measure(self, context, space, sidebar, area, viewport):
        g = self.geo
        was_visible = g.visible
        g.visible = _category_open(space, sidebar)
        g.overlap = viewport is not None and viewport.x + viewport.width >= sidebar.x + sidebar.width - 1
        g.sx, g.sy, g.sh = sidebar.x, sidebar.y, sidebar.height
        g.ax, g.aw = area.x, area.width
        g.ay, g.ah = area.y, area.height
        extra = _app.extra_scale(context) if _app.extra_scale else 1.0
        # já inclui o DPI do sistema; sem janela (background) o Blender informa 0
        g.scale = max(0.1, context.preferences.system.ui_scale * extra)
        g.resizable = getattr(sidebar, "alignment", "RIGHT") != "LEFT"
        w, h = sidebar.width / g.scale, sidebar.height / g.scale
        # `frame` = espaço disponível (largura escolhida × altura toda da sidebar).
        # A altura REAL do painel sai da árvore em _render (conteúdo + ajuste manual).
        if not g.resizable:   # sidebar à esquerda: sem redimensionar a largura
            g.widest = max(0.0, w - TABS_WIDTH - 2 * GAP)
            g.frame = Rect(GAP + TABS_WIDTH, GAP, g.widest, max(0.0, h - 2 * GAP))
        else:
            right = w - TABS_WIDTH - GAP
            fits = max(0.0, right - GAP)
            g.widest = max(_app.min_width, right - ((area.x - sidebar.x) / g.scale + GAP))
            wanted = self.state.get("_panel_width")
            # Sem largura salva: a largura padrão do app (pode passar da sidebar).
            automatic = max(fits, _app.default_width)
            width = min(g.widest, max(_app.min_width, wanted) if wanted else automatic)
            g.frame = Rect(right - width, GAP, width, max(0.0, h - 2 * GAP))
        shown = min(g.frame.h, self._shown_height if self._shown_height is not None else g.frame.h)
        g.panel = Rect(g.frame.x, g.frame.top - shown, g.frame.w, shown)   # ancorado no topo
        if g.visible != was_visible:
            if g.visible:
                forget(self.state, "host.reveal")
                self._dirty = True
            else:
                self.state.pop("_hover", None)
                # Aba escondida: tira o foco SEM on_blur (confirmar a edição
                # aqui rodaria o commit dentro do desenho) e descarta o
                # texto em edição, senão ele voltaria ao reabrir.
                focus = self.state.pop("_focus", None)
                if focus:
                    for suffix in (".edit", ".caret", ".blink", ".select_all"):
                        self.state.pop(focus + suffix, None)
        return was_visible

    def _frame(self, context, now):
        return Frame(self.renderer, self.state, self.theme, context, now, host=self)

    # ----------------------------------------------------------------- desenho
    def on_draw(self):
        context = bpy.context
        region, area = context.region, context.area
        if self.closed or region is None or area is None or area.as_pointer() != self.ptrs[1]:
            return            # handlers valem para TODAS as views 3D
        in_sidebar = region.as_pointer() == self.ptrs[2]
        if not in_sidebar and region.type != "WINDOW":
            return
        try:
            found = self.lookup()
            if found is None:
                return
            sidebar, viewport = found[2], found[3]
            was_extended = self.extended
            last_origin = (self.geo.sx, self.geo.sy)      # onde a sidebar estava (antes de medir)
            was_visible = self._measure(context, context.space_data, sidebar, area, viewport)
            g = self.geo
            if not g.visible:
                self._show_native_nav(context.space_data)
                if was_visible and self._exit is None and self._placement is not None \
                        and not context.space_data.show_region_ui:
                    # Sidebar ESCONDIDA (N / clique): anima a saída com a última
                    # textura. Trocar de aba da sidebar não anima -- o fantasma
                    # apareceria por baixo dos painéis da outra aba.
                    self._exit = (time.monotonic(),) + last_origin
                    self._set_tick(TICK_FAST)
                if self._exit is not None and not in_sidebar:
                    self._draw_exit(region)
                elif was_visible and viewport:
                    viewport.tag_redraw()      # apaga o que estava no viewport
                return
            if self._exit is not None:
                if time.monotonic() - self._exit[0] < EXIT_HOLD:
                    # Tecla de fechar já apertada; o Blender ainda está
                    # esmaecendo a sidebar (ela só vira "escondida" no fim).
                    if not in_sidebar:
                        self._draw_exit(region)
                    return
                self._exit = None              # a sidebar não fechou: volta ao normal
                self._set_tick(TICK_IDLE)
                self._dirty = True
            self._sync_native_nav(context.space_data)
            if in_sidebar:
                self._hide_host_panel(context, sidebar)
            if in_sidebar and g.overlap:
                if not was_visible and viewport:
                    viewport.tag_redraw()      # aba acabou de abrir: o viewport desenha
                return                         # com overlap, o viewport desenha tudo
            if not in_sidebar and not g.overlap and not self.extended:
                return                         # sem overlap e sem vazar: nada aqui

            now = time.monotonic()
            if self._render(context, now) and not g.overlap:
                other = viewport if in_sidebar else sidebar   # a outra metade mostra a mesma textura
                if other is not None and (not in_sidebar or self.extended or was_extended):
                    other.tag_redraw()
            self._reveal = animate(self.state, "host.reveal", 1.0, 0.28, initial=0.0, now=now)
            self._present(region, sidebar, in_sidebar)
            if not in_sidebar:
                self.navigator.draw(context, region, sidebar)
            self._schedule()
        except Exception:
            traceback.print_exc()
            _mark_broken(self.ptrs)
            bpy.app.timers.register(lambda: self.close(), first_interval=0.0)   # não remover handler durante o draw

    def _hide_host_panel(self, context, sidebar):
        """Some com a "caixa" que o Blender desenha para o painel-gancho vazio.

        Mesmo sem conteúdo, o Panel sem cabeçalho ganha uma moldura de poucos
        pixels no topo da sidebar. Este draw handler roda DEPOIS dos painéis,
        então cobrimos a coluna da sidebar (menos as abas verticais):
          - com overlap: escrevemos pixels transparentes (sem mistura), e o
            viewport, onde o nosso painel é desenhado, aparece por baixo;
          - sem overlap: a sidebar é opaca, então pintamos com a cor dela.
        """
        g = self.geo
        tabs = round(TABS_WIDTH * g.scale)
        x = tabs if not g.resizable else 0
        w = max(0, sidebar.width - tabs)
        if g.overlap:
            self.renderer.cover(x, 0, w, sidebar.height, (0.0, 0.0, 0.0, 0.0), replace=True)
        else:
            self.renderer.cover(x, 0, w, sidebar.height, _sidebar_color(context), replace=True)

    def _render(self, context, now):
        """Renderiza a UI na textura, se algo mudou. Retorna True se renderizou."""
        g = self.geo
        s = g.scale
        frame_key = (g.frame, s)
        signature = _app.signature(context) if _app.signature else None
        stale = signature != self._signature or now - self._built_at >= SAFETY_REFRESH
        if not (self._dirty or self._animating or stale or frame_key != self._frame_key):
            return False

        st = self.state
        st["_motion_active"] = False
        st["_mouse_rects"] = []
        st.pop("_wake_at", None)
        f = self._frame(context, now)
        self.tree = _app.build(f)               # árvore sempre nova: barata (lista é virtual)
        self._signature, self._built_at = signature, now
        g.panel = self._fit_height(f, now)
        self.tree.layout(f, g.panel)

        area = g.panel.expand(CACHE_PAD)
        x0, y0 = math.floor(area.x * s), math.floor(area.y * s)
        w = max(1, math.ceil(area.right * s) - x0)
        h = max(1, math.ceil(area.top * s) - y0)
        r = self.renderer

        def draw():
            self.tree.draw(f)
            self._draw_grips(f)
            self._tooltip_waiting = self._draw_tooltip(f)
        self._offscreen = render_to_texture(self._offscreen, r, s, x0, y0, w, h, draw)
        self._placement = (x0, y0, w, h, s)
        self._frame_key = frame_key
        self._dirty = False
        # Imagem na fila de decodificação (renderer.texture) também mantém o
        # render: o PNG chega em alguns quadros, sem precisar de evento.
        self._animating = bool(st.get("_motion_active")) or r.pending_images
        prune(st, now)
        return True

    def _fit_height(self, f, now):
        """Escolhe a altura do painel a partir do conteúdo.

        A raiz informa (mínima, preferida, máxima). A altura manual (borda de
        baixo) é tratada como "tamanho útil máximo": nunca abaixo da mínima nem
        acima da máxima (sem espaço vazio), e nunca maior que a sidebar.
        Mudanças automáticas (trocar de aba, lista filtrada...) animam com
        mola; durante o arrasto o painel segue o mouse direto.
        """
        frame, st = self.geo.frame, self.state
        low, preferred, high = self.tree.extent(f, frame.w)
        low, high = min(low, frame.h), min(max(high, low), frame.h)
        self._height_range = (low, high)
        wanted = st.get("_panel_height") or preferred
        target = max(low, min(high, wanted))
        # Sem mola enquanto a LARGURA muda (arrasto da borda esquerda ou a
        # sidebar do Blender redimensionada): texto que quebra muda a altura
        # ideal a cada quadro e a borda de baixo ficaria "bombeando". A mola
        # continua pras mudanças de CONTEÚDO (trocar de aba etc.).
        width_changed = self._fit_width is not None and abs(self._fit_width - frame.w) > 0.01
        self._fit_width = frame.w
        if st.get("_drag", {}).get("key") in (GRIP_X, GRIP_Y) or width_changed or self._shown_height is None:
            forget(st, "panel.height")
            height = target
        else:
            height = animate(st, "panel.height", target, HEIGHT_SPRING,
                             initial=self._shown_height, now=now)
        self._shown_height = height = max(0.0, min(frame.h, height))
        return Rect(frame.x, frame.top - height, frame.w, height)

    def _is_sidebar_toggle(self, context, event):
        """O evento é o atalho de mostrar/esconder a sidebar (N por padrão,
        lido do keymap do usuário) com o mouse NESTA View3D?"""
        g = self.geo
        if not (g.ax <= event.mouse_x < g.ax + g.aw and g.ay <= event.mouse_y < g.ay + g.ah):
            return False
        combo = (event.type, event.shift, event.ctrl, event.alt, event.oskey)
        return combo in _sidebar_toggle_keys(context)

    def _draw_exit(self, region):
        """Saída: o inverso da entrada -- a última textura desce e some.
        Desenhada no viewport (a sidebar já não existe mais), na posição
        em que a sidebar estava."""
        start, sx, sy = self._exit
        t = (time.monotonic() - start) / EXIT_DURATION
        if t >= 1.0 or self._offscreen is None:
            if self.geo.visible:               # saída pela tecla: sidebar ainda esmaecendo --
                return                         # não desenha nada até ela fechar de vez
            self._exit = None
            self._set_tick(TICK_IDLE)
            region.tag_redraw()                # último quadro: limpa
            return
        # Reage NA HORA (ease-out): já no primeiro quadro some bastante;
        # começar devagar (t²) passava a sensação de atraso.
        ease = 1.0 - (1.0 - t) ** 2
        x0, y0, _, _, s = self._placement
        drop = round(10.0 * ease * s)
        self.renderer.blit(self._offscreen.texture_color, x0 + sx - region.x, y0 + sy - region.y - drop,
                           self._offscreen.width, self._offscreen.height,
                           opacity=max(0.0, 1.0 - ease), linear=True)

    def _present(self, region, sidebar, in_sidebar):
        """Copia a textura para a região atual."""
        x0, y0, _, _, s = self._placement
        rise = round(10.0 * (1.0 - self._reveal) * s)   # ao abrir: sobe e aparece
        ox, oy = (0, 0) if in_sidebar else (sidebar.x - region.x, sidebar.y - region.y)
        split = not in_sidebar and not self.geo.overlap
        if split:   # sem overlap: o viewport mostra só o que passou da sidebar
            gpu.state.scissor_set(0, 0, max(0, sidebar.x - region.x), region.height)
            gpu.state.scissor_test_set(True)
        try:
            self.renderer.blit(self._offscreen.texture_color, x0 + ox, y0 + oy - rise,
                               self._offscreen.width, self._offscreen.height,
                               opacity=max(0.0, min(1.0, self._reveal)), linear=not in_sidebar)
        finally:
            if split:
                gpu.state.scissor_test_set(False)

    def _schedule(self):
        st = self.state
        if self._animating or self._reveal < 0.999 or st.get("_drag"):
            self._set_tick(TICK_FAST)
        elif st.get("_focus") or self._tooltip_waiting or st.get("_wake_at"):
            self._set_tick(TICK_BLINK)
        else:
            self._set_tick(TICK_IDLE)

    def _draw_grips(self, f):
        """Realce das bordas arrastáveis (só aparecem onde fazem sentido)."""
        st, th, r, p = self.state, f.theme, f.renderer, self.panel
        grabbed = st.get("_drag", {}).get("key")
        for key, grip in self.grips.items():
            if not grip.available():
                continue
            hot = f.animate(key + ".glow", 1.0 if grabbed == key or st.get("_hover") == key else 0.0, 0.15)
            if key == GRIP_X:
                if hot > 0.01:
                    r.rect(Rect(p.x - 1, p.y + 12, 2, p.h - 24), th.accent[:3] + (0.3 * hot,), radius=1)
                    r.rect(Rect(p.x - 2, p.y + p.h / 2 - 22, 4, 44), th.accent[:3] + (hot,), radius=2)
            else:   # a pílula de baixo fica sempre visível (discreta) para ser descoberta
                width = 32 + 12 * hot
                pill = th.text_muted[:3] + (0.35,)
                r.rect(Rect(p.x + (p.w - width) / 2, p.y + 4, width, 3),
                       tuple(a + (b - a) * hot for a, b in zip(pill, th.accent)), radius=1.5)

    def _draw_tooltip(self, f):
        st = self.state
        key = st.get("_hover")
        if not key or st.get("_pressed") or st.get("_drag") or st.get("_tooltip_off"):
            return False
        widget = self._widget(key)
        if widget is None or not widget.tooltip:
            return False
        if f.now - st.get("_hover_since", f.now) < 0.6:
            return True                      # ainda esperando o atraso
        text = tooltip_text(widget)          # string, ou função chamada só agora
        if not text:
            return False
        # Tooltip com quebra de linha: as descrições dos operadores/campos
        # do Hyblend costumam ser frases longas. O app pode ter o próprio
        # balão (register(tooltip=)).
        (_app.tooltip or draw_tooltip)(f, key, text, st.get("_hover_pos", f.mouse), self.panel)
        return False

    # ----------------------------------------------------------------- eventos
    def _hit(self, x, y):
        for grip in self.grips.values():
            if grip.available() and grip.rect().contains(x, y):
                return grip
        return self.tree.hit(x, y) if self.tree else None

    def _blur(self, f, keep=None):
        """Tira o foco do teclado; o widget focado pode confirmar a edição
        (on_blur) -- ex.: campo de número/texto clicado fora = confirma,
        igual ao Blender."""
        focus = self.state.get("_focus")
        if not focus or focus == keep:
            return False
        widget = find_by_key(self.tree, focus)
        self.state.pop("_focus", None)
        blur = getattr(widget, "on_blur", None)
        if blur is not None:
            try:
                blur(f)
            except Exception:
                traceback.print_exc()
            self.invalidate()
        return True

    def _widget(self, key):
        return self.grips.get(key) or find_by_key(self.tree, key)

    def _tick_wants_render(self, now):
        st = self.state
        if self._animating or st.get("_drag"):
            return True
        if self._tooltip_waiting and now - st.get("_hover_since", now) >= 0.6:
            return True
        if st.get("_wake_at") is not None and now >= st["_wake_at"]:
            return True
        focus = st.get("_focus")
        if focus:
            lit = (now - st.get(focus + ".blink", now)) % 1.0 < 0.55
            if lit != self._blink:
                self._blink = lit            # o cursor de texto acendeu/apagou
                return True
        return False

    def on_event(self, context, event):
        st, g = self.state, self.geo
        now = time.monotonic()
        self.heartbeat = now

        if event.type == "TIMER":
            return self._on_tick(now)

        if (event.value == "PRESS" and g.visible and self._exit is None and self._placement is not None
                and not st.get("_focus") and self._is_sidebar_toggle(context, event)):
            # Começa a saída JÁ no aperto da tecla. Sem isso, com Region
            # Overlap, o painel ficava inteiro durante o fade próprio do
            # Blender (que só marca a sidebar como escondida no fim) e só
            # então a nossa saída começava -- dava sensação de atraso.
            self._exit = (now, g.sx, g.sy)
            self._set_tick(TICK_FAST)
            found = self.lookup()
            if found is not None and found[3] is not None:
                found[3].tag_redraw()
            return _PASS                        # o Blender fecha a sidebar normalmente

        if not g.visible:
            if event.type == "LEFTMOUSE" and event.value == "RELEASE":
                self._check_visibility()     # talvez a aba tenha sido aberta
            return _PASS

        x = (event.mouse_x - g.sx) / g.scale
        y = (event.mouse_y - g.sy) / g.scale
        near = g.panel.expand(GRIP).contains(x, y) and g.ax <= event.mouse_x < g.ax + g.aw \
            and g.sy <= event.mouse_y < g.sy + g.sh
        nav = self.navigator.contains(x, y)
        busy = st.get("_drag") or st.get("_focus") or st.get("_pressed") or st.get("_hover") \
            or st.get("_swipe") or st.get("_mmb") or self.navigator.hover is not None

        # Caminho rápido: evento longe de tudo e nada em andamento → nem consulta o Blender.
        if not (near or nav or busy):
            if event.type == "LEFTMOUSE" and event.value == "RELEASE":
                self._check_visibility()     # clique nas abas pode ter trocado a categoria
            return _PASS

        found = self.lookup()
        if found is None:
            self.close()
            return {"CANCELLED"}
        window = found[0]
        previous = st.get("_mouse", (x, y))
        st["_mouse"] = (x, y)
        f = self._frame(context, now)

        # 0a) arrasto-alternar (segurar e passar por cima, como no Blender)
        if st.get("_swipe"):
            return self._on_swipe(f, event, x, y)

        # 0b) rolagem arrastando com o botão do meio
        if st.get("_mmb"):
            return self._on_mmb(f, event, window, y)

        # 1) arrasto em andamento
        drag = st.get("_drag")
        if drag:
            widget = self._widget(drag["key"])
            if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
                if widget:
                    widget.drag(f, x, y, drag["data"])
                self.request()
            elif (event.type == "LEFTMOUSE" and event.value == "RELEASE") or event.type in {"ESC", "RIGHTMOUSE"}:
                cancel = event.type != "LEFTMOUSE"
                if widget:
                    if cancel:
                        widget.drag(f, drag["data"].get("x", 0), drag["data"].get("y", 0), drag["data"])
                    widget.end_drag(f, drag["data"], cancel)
                if st.pop("_drag", {}).get("cursor"):
                    window.cursor_modal_restore()
                self.request(viewport=True)
            return _EAT

        # 2) teclado vai para o campo focado (senão G/S/X mexeriam na cena)
        focus = st.get("_focus")
        if focus and is_keyboard(event.type):
            widget = find_by_key(self.tree, focus)
            if widget is None:
                st.pop("_focus", None)
                return _PASS
            if event.value == "PRESS" or event.type == "TEXTINPUT":
                key_event = KeyEvent(event.type, event.unicode or "", event.ctrl or event.oskey)
                if widget.handle_key(f, key_event, _Clipboard(context.window_manager)):
                    self.invalidate()
                elif key_event.ctrl and event.type not in {"A", "Z", "Y", "X"}:
                    return _PASS             # Ctrl+S, Ctrl+O... continuam do Blender
            return _EAT

        # 3) navegador (orbe + botões) à esquerda do painel alargado
        nav_result = self.navigator.on_event(context, event, x, y, found)
        if nav_result is not None:
            return nav_result

        # 4) hover
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            hit = self._hit(x, y) if near else None
            key = hit.key if hit else None
            old = st.get("_hover")
            if key != old:
                st["_hover"], st["_hover_since"], st["_hover_pos"] = key, now, (x, y)
                st.pop("_tooltip_off", None)
                forget(st, "tip.%s" % old)
                if key in self.grips:
                    window.cursor_set(self.grips[key].cursor)
                elif old in self.grips:
                    window.cursor_set("DEFAULT")
                self.request()
            elif any(r.contains(px, py) for r in st.get("_mouse_rects", ()) for px, py in ((x, y), previous)):
                self.request()               # abas / barra de rolagem reagem à posição
            return _EAT if key in self.grips else _PASS

        if not near:
            if event.type == "LEFTMOUSE" and event.value == "PRESS" and self._blur(f):
                self.request()
            if st.pop("_hover", None) is not None:
                self.request()
            return _PASS

        # 4b) I com o mouse em cima = keyframe na property do widget
        if event.type == "I" and event.value == "PRESS":
            if not (event.ctrl or event.shift or event.alt or event.oskey):
                hit = self._hit(x, y)
                handler = getattr(hit, "on_insert_key", None)
                if handler is not None:
                    try:
                        handler(f)
                    except Exception as error:
                        traceback.print_exc()
                        f.toast(_t("gpu_ui.error_prefix", "Error:") + " %s" % error, error=True)
                    self.invalidate()
                    self.request(viewport=True)
            # Em cima do painel, I nunca cai no viewport (keyframe nos bones
            # selecionados seria uma surpresa).
            return _EAT

        # 4b') painel alargado por cima do viewport: tecla ali não pode cair
        # na cena (G, X, Tab...). Em cima da sidebar em si o Blender já não
        # manda tecla pra cena. Passam modificadores, F1-F24, Esc, espaço e o
        # atalho da sidebar.
        if (is_keyboard(event.type) and event.mouse_x < g.sx
                and not (event.ctrl or event.alt or event.oskey)
                and event.type not in _PASS_KEYS and not FKEY.match(event.type)
                and not self._is_sidebar_toggle(context, event)):
            return _EAT

        # 4c) botão do meio: segurar e arrastar rola a área sob o mouse
        if event.type == "MIDDLEMOUSE" and event.value == "PRESS":
            view = scroll_target(self.tree, x, y)
            if view is not None and view.max_scroll > 0:
                st["_mmb"] = {"key": view.key, "y": y, "start": st.get(view.key, 0.0)}
                window.cursor_modal_set("SCROLL_Y")
                st["_tooltip_off"] = True
            return _EAT

        # 5) rolagem
        if event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE", "TRACKPADPAN"}:
            view = scroll_target(self.tree, x, y)
            if view is not None:
                if event.type == "TRACKPADPAN":
                    delta = (event.mouse_prev_y - event.mouse_y) / g.scale
                else:
                    delta = -48.0 if event.type == "WHEELUPMOUSE" else 48.0
                view.scroll_by(f, delta)
                st["_tooltip_off"] = True
                self.request()
            return _EAT

        # 6) clique
        if event.type == "LEFTMOUSE":
            hit = self._hit(x, y)
            if event.value in {"PRESS", "DOUBLE_CLICK"}:
                st["_tooltip_off"] = True
                if isinstance(hit, _Grip) and event.value == "DOUBLE_CLICK":
                    hit.reset(f)
                    self.request(viewport=True)
                    return _EAT
                if hit is not None and hit.focusable:
                    self._blur(f, keep=hit.key)
                    st["_focus"] = hit.key
                    hit.on_focus(f, x, y)
                elif not getattr(hit, "keeps_focus", False):
                    # keeps_focus: widget que trabalha JUNTO do campo focado
                    # (ex.: sugestão de nome de bone) -- o clique nele não
                    # pode tirar o foco antes de chegar ao on_click.
                    self._blur(f)
                if (hit is not None and getattr(hit, "swipe_group", None) and hit.enabled
                        and event.value == "PRESS"):
                    self._begin_swipe(f, hit)
                    return _EAT
                if hit is not None and hit.interactive:
                    data = hit.begin_drag(f, x, y)
                    if data is not None:
                        st["_drag"] = {"key": hit.key, "data": data, "cursor": bool(hit.cursor)}
                        if hit.cursor:
                            window.cursor_modal_set(hit.cursor)
                    else:
                        st["_pressed"] = hit.key
                self.request()
                return _EAT
            if event.value == "RELEASE":
                pressed = st.pop("_pressed", None)
                if hit is not None and pressed == hit.key:
                    try:
                        hit.on_click(f, x, y)   # dispara ao soltar em cima (como na web)
                    except Exception as error:
                        traceback.print_exc()
                        f.toast(_t("gpu_ui.error_prefix", "Error:") + " %s" % error, error=True)
                    self.invalidate()
                    self.request(viewport=True)
                else:
                    self.request()
                return _EAT

        if event.type == "RIGHTMOUSE" and event.value == "PRESS":
            hit = self._hit(x, y)
            handler = getattr(hit, "on_context", None)
            if handler is not None:
                try:
                    handler(f, x, y)
                except Exception as error:
                    traceback.print_exc()
                    f.toast(_t("gpu_ui.error_prefix", "Error:") + " %s" % error, error=True)
                self.invalidate()
                self.request(viewport=True)
            return _EAT
        if event.type in {"RIGHTMOUSE", "MIDDLEMOUSE"}:
            return _EAT
        return _PASS

    # ------------------------------------------------ arrasto-alternar / meio
    def _begin_swipe(self, f, widget):
        """Aplica o valor no PRIMEIRO botão já no aperto; os que o mouse
        atravessar (mesmo grupo) recebem o MESMO valor."""
        value = widget.swipe_value
        self.state["_swipe"] = {"group": widget.swipe_group, "value": value,
                                "done": {widget.swipe_id}, "finish": widget.swipe_finish}
        self._swipe_apply(f, widget, value)

    def _swipe_apply(self, f, widget, value):
        try:
            widget.swipe_apply(f, value)
        except Exception as error:
            traceback.print_exc()
            f.toast(_t("gpu_ui.error_prefix", "Error:") + " %s" % error, error=True)
        self.invalidate()
        self.request(viewport=True)

    def _on_swipe(self, f, event, x, y):
        swipe = self.state["_swipe"]
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            hit = self._hit(x, y)
            if (hit is not None and getattr(hit, "swipe_group", None) == swipe["group"]
                    and hit.enabled and hit.swipe_id not in swipe["done"]):
                swipe["done"].add(hit.swipe_id)
                self._swipe_apply(f, hit, swipe["value"])
            return _EAT
        if (event.type == "LEFTMOUSE" and event.value == "RELEASE") or event.type in {"ESC", "RIGHTMOUSE"}:
            self.state.pop("_swipe", None)
            if swipe.get("finish") is not None:
                try:
                    swipe["finish"](f, len(swipe["done"]))   # ex.: UM undo pro arrasto inteiro
                except Exception:
                    traceback.print_exc()
            self.request(viewport=True)
            return _EAT
        return _EAT

    def _on_mmb(self, f, event, window, y):
        st = self.state
        mmb = st["_mmb"]
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            view = find_by_key(self.tree, mmb["key"])
            if view is not None:
                # conteúdo acompanha o mouse (arrastar pra cima sobe o conteúdo)
                st[mmb["key"]] = min(view.max_scroll, max(0.0, mmb["start"] + (y - mmb["y"])))
                forget(st, mmb["key"] + ".anim")      # direto, sem mola
                self.request()
            return _EAT
        if (event.type == "MIDDLEMOUSE" and event.value == "RELEASE") or event.type == "ESC":
            st.pop("_mmb", None)
            window.cursor_modal_restore()
            self.request()
        return _EAT

    def _on_tick(self, now):
        if self._exit is not None:           # animação de saída: redesenhar o viewport
            found = self.lookup()
            if found is not None and found[3] is not None:
                found[3].tag_redraw()
            return _PASS
        if self._tick != TICK_IDLE and now - self._last_tick >= self._tick * 0.8:
            self._last_tick = now
            self.request(content=self._tick_wants_render(now))
        elif self._tick == TICK_IDLE:
            self._check_visibility()
        return _PASS

    def _check_visibility(self):
        found = self.lookup()
        if found is None:
            return
        if _category_open(found[1].spaces.active, found[2]) != self.geo.visible:
            self.request(viewport=True)


class _Grip:
    """Borda arrastável do painel: "width" (esquerda) ou "height" (baixo).

    Comporta-se como um widget (hover, cursor, arrasto, tooltip), então o
    tratamento de eventos do host não precisa de casos especiais.
    """
    interactive = True
    focusable = False
    STATE_KEYS = {"width": "_panel_width", "height": "_panel_height"}

    def __init__(self, host, axis):
        self.host, self.axis = host, axis
        self.key = GRIP_X if axis == "width" else GRIP_Y
        self.state_key = self.STATE_KEYS[axis]
        self.cursor = "MOVE_X" if axis == "width" else "MOVE_Y"
        self.tooltip = _t("gpu_ui.grip_width" if axis == "width" else "gpu_ui.grip_height",
                          "Drag to resize · double-click: automatic")

    def available(self):
        if self.axis == "width":
            return self.host.geo.resizable
        low, high = self.host._height_range
        return high - low > 1.0            # página sem nada que cresça: sem alça

    def rect(self):
        p = self.host.panel
        if self.axis == "width":
            return Rect(p.x - GRIP, p.y + 16, GRIP * 2, max(0.0, p.h - 32))
        return Rect(p.x + 16, p.y - GRIP, max(0.0, p.w - 32), GRIP * 2)

    def begin_drag(self, f, x, y):
        size = self.host.panel.w if self.axis == "width" else self.host.panel.h
        return {"x": x, "y": y, "size": size, "saved": f.state.get(self.state_key)}

    def drag(self, f, x, y, data):
        if self.axis == "width":        # puxar para a esquerda alarga
            value = min(self.host.geo.widest, max(_app.min_width, data["size"] + (data["x"] - x)))
        else:                            # puxar para baixo aumenta (topo fica parado)
            low, high = self.host._height_range
            value = min(high, max(low, data["size"] + (data["y"] - y)))
        f.state[self.state_key] = value

    def end_drag(self, f, data, cancelled):
        if cancelled:
            if data["saved"]:
                f.state[self.state_key] = data["saved"]
            else:
                f.state.pop(self.state_key, None)
        elif _app.size_set:
            _app.size_set(bpy.context, self.axis, f.state.get(self.state_key, 0.0))

    def reset(self, f):
        f.state.pop(self.state_key, None)
        if _app.size_set:
            _app.size_set(bpy.context, self.axis, 0.0)

    def on_click(self, f, x, y):
        pass

    def on_focus(self, f, x, y):
        pass


_TOGGLE_KEYS = {"at": -1e9, "keys": frozenset()}


def _sidebar_toggle_keys(context):
    """Combinações de tecla que alternam `space_data.show_region_ui` nos
    keymaps da View3D (cache de 5 s -- o usuário pode editar o keymap)."""
    now = time.monotonic()
    if now - _TOGGLE_KEYS["at"] < 5.0:
        return _TOGGLE_KEYS["keys"]
    keys, found_keymap = set(), False
    try:
        keyconfig = context.window_manager.keyconfigs.user
        for name in ("3D View", "3D View Generic"):
            keymap = keyconfig.keymaps.get(name)
            found_keymap = found_keymap or keymap is not None
            for item in (keymap.keymap_items if keymap else ()):
                if not item.active or item.idname != "wm.context_toggle" or item.value != "PRESS":
                    continue
                if getattr(item.properties, "data_path", "") != "space_data.show_region_ui":
                    continue
                keys.add((item.type, bool(item.shift), bool(item.ctrl), bool(item.alt), bool(item.oskey)))
    except Exception:
        keys = set()
    if not found_keymap:
        # Keymap indisponível (ex.: sem janela): assume o padrão. Com keymap
        # mas SEM o toggle (ex.: "region toggle pie" ligado, N abre um menu)
        # não assume nada -- a saída espera a sidebar fechar de fato.
        keys = {("N", False, False, False, False)}
    _TOGGLE_KEYS["at"], _TOGGLE_KEYS["keys"] = now, frozenset(keys)
    return _TOGGLE_KEYS["keys"]


def _sidebar_color(context):
    """Cor de fundo da sidebar no tema do usuário (o lugar mudou no Blender 5.2)."""
    themes = context.preferences.themes
    theme = themes[0] if len(themes) else None
    for path in (("regions", "sidebars", "back"), ("view_3d", "space", "button")):
        owner = theme
        for name in path:
            owner = getattr(owner, name, None)
        if owner is not None:
            color = tuple(owner)
            return color[:3] + (1.0,)
    return (0.19, 0.19, 0.19, 1.0)


def is_keyboard(event_type):
    if event_type == "NONE" or "MOUSE" in event_type:
        return False
    return not event_type.startswith(("TIMER", "TRACKPAD", "NDOF", "WINDOW", "ACTIONZONE",
                                      "XR_", "PEN", "ERASER", "EVT_", "FILE_"))


# --------------------------------------------------------------------------
# Operador modal que mantém o host vivo
# --------------------------------------------------------------------------

class _HostOperator:
    """Corpo do operador modal; a classe registrada (com o bl_idname do
    namespace do app) é criada em register()."""
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        if _ptrs(context.window, context.area, context.region) in _HOSTS:
            return {"CANCELLED"}
        self._host = PanelHost(context)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        host = self._host
        if host.closed:
            return {"CANCELLED"}
        try:
            return host.on_event(context, event)
        except Exception:
            traceback.print_exc()
            return _PASS

    def cancel(self, context):
        self._host.close()


@persistent
def _before_load(*_):
    shutdown_all()          # abrir .blend derruba os modais; os draw handlers ficariam órfãos


@persistent
def _after_load(*_):
    forget_fonts()          # o Blender descarregou as fontes do blf.load ao ler o arquivo


@persistent
def _after_undo(*_):
    for host in list(_HOSTS.values()):
        host.invalidate()


@persistent
def _before_save(*_):
    for host in list(_HOSTS.values()):
        host._show_native_nav()     # nunca gravar no .blend o gizmo escondido


DEPSGRAPH_THROTTLE = 0.1   # s -- no máx. 10 reconstruções/s por mudanças de fora


def _depsgraph_tick():
    for host in list(_HOSTS.values()):
        host._signature = None
        host._dirty = True
        host.request()
    return None


@persistent
def _after_depsgraph(scene, depsgraph=None):
    """Dados mudaram por fora da UI (outro editor, script, operador...):
    reconstruir. Arrastar um bone (G) dispara dezenas de eventos por
    segundo -- em vez de invalidar a cada um, agenda UM timer; a última
    mudança nunca se perde. Durante o play da timeline, nada (o
    SAFETY_REFRESH já cobre). Sem flag própria: is_registered."""
    if not _HOSTS:
        return
    screen = getattr(bpy.context, "screen", None)
    if screen is not None and screen.is_animation_playing:
        return
    if not bpy.app.timers.is_registered(_depsgraph_tick):
        bpy.app.timers.register(_depsgraph_tick, first_interval=DEPSGRAPH_THROTTLE)


_APP_HANDLERS = (("load_pre", _before_load), ("load_post", _after_load), ("undo_post", _after_undo),
                 ("redo_post", _after_undo), ("save_pre", _before_save),
                 ("depsgraph_update_post", _after_depsgraph))


def _make_operator():
    ns = CONFIG.namespace
    return type("%s_OT_gpu_ui_host" % ns.upper(), (_HostOperator, bpy.types.Operator),
                {"bl_idname": ns + ".gpu_ui_host", "bl_label": CONFIG.label})


def register(build, extra_scale=None, size_get=None, size_set=None, signature=None, text=None, theme=None,
             default_width=0.0, min_width=MIN_WIDTH, tooltip=None, active=None):
    """build(frame) -> Widget; size_get(context, "width"|"height") -> float;
    size_set(context, eixo, valor); signature(context) -> tupla barata;
    text(key) -> texto traduzido; theme = core.Theme do app (None = padrão);
    default_width/min_width: largura inicial e mínima do painel (unidades
    lógicas; 0 = a sidebar); tooltip(f, key, texto, mouse, área) = balão
    próprio do app (None = core.draw_tooltip); active() -> bool = este
    addon é o escolhido no seletor (None = sempre)."""
    _app.build, _app.extra_scale, _app.signature, _app.text = build, extra_scale, signature, text
    _app.theme = theme
    _app.size_get, _app.size_set = size_get, size_set
    _app.default_width, _app.min_width = default_width, min_width
    _app.tooltip, _app.active = tooltip, active
    _OPERATOR[:] = [_make_operator()]
    bpy.utils.register_class(_OPERATOR[0])
    for name, callback in _APP_HANDLERS:
        handlers = getattr(bpy.app.handlers, name)
        if callback not in handlers:
            handlers.append(callback)


def unregister():
    if bpy.app.timers.is_registered(_depsgraph_tick):
        bpy.app.timers.unregister(_depsgraph_tick)
    shutdown_all()
    release_resources()
    for name, callback in _APP_HANDLERS:
        handlers = getattr(bpy.app.handlers, name)
        if callback in handlers:
            handlers.remove(callback)
    for cls in _OPERATOR:
        bpy.utils.unregister_class(cls)
    _OPERATOR.clear()
    _app.active = _app.tooltip = None
