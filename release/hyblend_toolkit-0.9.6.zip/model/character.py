"""Import de um personagem do jogo pelo id de Server/Models: Armature com o corpo + os anexos padrão (olhos,
roupa, cabelo...), cada peça com a própria textura. Mesmo resultado do File > Import (Armature nova + Attach),
então o rig e o export do Anim funcionam igual."""

import posixpath

from . import build, catalog, geometry, materials
from .props import ARMATURE_MODEL_FORMAT_PROP, UNIT_SCALE_DEFAULT, effective_unit_scale

# Na Armature: id de Server/Models de onde veio.
MODEL_ID_PROP = "hytale_model_id"


class _Materials:
    """Um material por textura (anexos que repetem a textura do corpo usam o mesmo)."""

    def __init__(self):
        self.cache = {}

    def get(self, entry, atlas):
        """(material, atlas) da entrada {Texture, GradientSet?, GradientId?}; sem textura: placeholder."""
        tex_rel = entry.get("Texture") or ""
        ramp_rel = catalog.gradient_ramp(entry.get("GradientSet"), entry.get("GradientId")) \
            if entry.get("GradientSet") and entry.get("GradientId") else None
        key = (tex_rel, ramp_rel)
        if key in self.cache:
            mat, image = self.cache[key]
        else:
            image = materials.load_image(catalog.common_file(tex_rel))
            ramp = materials.load_image(catalog.common_file(ramp_rel)) if ramp_rel else None
            if image is None:
                mat = None
            elif ramp is not None:
                mat, _ = materials.gradient_material(f"{materials.material_name(image)}_{entry['GradientId']}",
                                                     image, ramp)
            else:
                mat = materials.flat_material(image)
            self.cache[key] = (mat, image)
        if image is not None and image.size[0] > 0 and image.size[1] > 0:
            atlas = (image.size[0], image.size[1])
        if mat is None:
            mat = materials.flat_material(materials.placeholder_image(*atlas), name="Hytale_Placeholder")
            self.cache[key] = (mat, None)
        return mat, atlas


def import_character(context, ident, *, orient=True, unit_scale=UNIT_SCALE_DEFAULT):
    """Importa o personagem `ident` (id de Server/Models). Devolve build.Result (warnings inclui os anexos que
    falharam). Levanta catalog.CatalogError se nem o corpo der."""
    data = catalog.resolved(ident)
    if not data or not data.get("Model"):
        raise catalog.CatalogError("model.error.unknown_character", name=ident)
    body = catalog.read_model(data["Model"])
    model_format = build.resolve_format("AUTO", body, data["Model"])
    scale = effective_unit_scale(unit_scale, model_format)
    armature_obj, main = build.new_armature(context, ident, model_format)
    armature_obj[MODEL_ID_PROP] = ident
    mats = _Materials()
    material, atlas = mats.get(data, geometry.atlas_size(body["nodes"]))
    result = build.build(context, body, armature_obj, unit_scale=scale, collection=main, atlas=atlas,
                         material=material)
    attachments, _ = build.attachments_collection(context, armature_obj)
    for entry in catalog.pick_attachments(data):
        try:
            part = catalog.read_model(entry["Model"])
        except catalog.CatalogError:
            result.warnings.append(("WARNING", "model.warn.attachment_failed", {"path": entry["Model"]}))
            continue
        mat, part_atlas = mats.get(entry, geometry.atlas_size(part["nodes"]))
        stem = posixpath.splitext(posixpath.basename(entry["Model"]))[0]
        sub = build.build(context, part, armature_obj, unit_scale=scale, attach=True, stem=stem,
                          collection=attachments, atlas=part_atlas, material=mat)
        result.objects += sub.objects
        result.bones += sub.bones
        result.nodes += sub.nodes
        result.warnings += sub.warnings
    if orient:
        build.orient_z_up(armature_obj)
    armature_obj[ARMATURE_MODEL_FORMAT_PROP] = model_format
    for obj in context.view_layer.objects.selected:
        obj.select_set(False)
    armature_obj.select_set(True)
    context.view_layer.objects.active = armature_obj
    context.view_layer.update()
    return result
