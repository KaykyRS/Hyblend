"""emitters.py -- transforma a lista de "colocacoes" resolvidas pelo import
(prefab_importer.py) no resultado final da cena. O import agora roda em
DUAS fases:

1. Resolver (prefab_importer.py): le blocks[]/entities[], monta TODAS as
   malhas unicas e calcula a matriz final de cada instancia -- sem criar
   nenhum Object ainda. Uma `Placement` por bloco/entity.
2. Emitir (este arquivo), conforme `Output` do Optimizer:
   - `emit_objects`   -- 1 Object por bloco/entity (padrao, comportamento
                         classico: selecionavel, inspector, custom props).
   - `emit_instances` -- 1 Object por item unico, com Geometry Nodes
                         espalhando as copias (Instance on Points).
   - `emit_single_mesh` -- tudo fundido numa malha so (com opcao de
                         remover faces escondidas entre cubos).

Por que duas fases (ver DEVELOPER_NOTES.md, "Desempenho do import"):
- Criar Objects em ORDEM ALFABETICA de nome e ~15x mais rapido num prefab
  grande: o Blender guarda os IDs ordenados por nome, e inserir um nome
  "fora de ordem" faz ele percorrer a lista inteira (medido: 60k Objects
  em ordem embaralhada 50s, em ordem alfabetica 3.3s). Resultado final
  identico -- so muda qual copia ganha qual sufixo .001/.002.
- Montar as malhas ANTES de existir qualquer Object: montar uma malha de
  .blockymodel cria/remove malhas temporarias, e remover um datablock fica
  mais caro quanto mais Objects existem na cena (0.5ms com 1k Objects,
  52ms com 93k).

Todas as matrizes de `Placement.matrix` estao no espaco LOCAL do Empty
raiz do prefab (espaco do arquivo, Y-up) -- o +90 X do raiz converte pra
Z-up, igual antes."""

from __future__ import annotations

import bpy

from ..common import (
    PROP_BLOCK_FILLER_RAW,
    PROP_BLOCK_GRID_POS,
    PROP_BLOCK_NAME,
    PROP_BLOCK_ROTATION_RAW,
    PROP_BLOCK_STATE,
    PROP_BLOCK_SUPPORT_RAW,
)

# Custom properties dos Objects gerados pelos modos otimizados.
PROP_OPT_INSTANCER_ITEM = "hyblend_instancer_item"  # modo Instances: item que este Object espalha
PROP_OPT_INSTANCE_COUNT = "hyblend_instance_count"
PROP_OPT_SINGLE_MESH = "hyblend_single_mesh"  # modo Single Mesh: True

INSTANCER_NODE_GROUP = "Hyblend Prefab Instancer"
SOURCES_COLLECTION_SUFFIX = " (sources)"


class Placement:
    """Uma instancia resolvida (bloco ou entity), ainda sem Object.

    `block` -- dict cru do blocks[] (so pra blocos; as custom properties
    sao montadas so na hora de criar o Object, pra nao duplicar memoria
    num prefab com centenas de milhares de blocos). `props` -- dict pronto
    (entities, que sao poucas). `grid` -- (x,y,z) inteiro da celula (so
    blocos; usado pelo culling do Optimizer)."""

    __slots__ = ("name", "entry", "matrix", "block", "state", "props", "grid")

    def __init__(self, name, entry, matrix, block=None, state=None, props=None, grid=None):
        self.name = name
        self.entry = entry
        self.matrix = matrix
        self.block = block
        self.state = state
        self.props = props
        self.grid = grid


def _block_props(p: Placement) -> dict:
    block = p.block
    return {
        PROP_BLOCK_NAME: block.get("name", ""),
        PROP_BLOCK_ROTATION_RAW: block.get("rotation", 0),
        PROP_BLOCK_SUPPORT_RAW: block.get("support", 0),
        PROP_BLOCK_FILLER_RAW: block.get("filler", 0),
        PROP_BLOCK_STATE: p.state or "",
        PROP_BLOCK_GRID_POS: p.grid,
    }


class _Progress:
    """wm.progress_* (cursor com porcentagem na barra de status) -- no-op
    sem janela (modo background)."""

    def __init__(self, context, start: float, end: float, total: int):
        self.wm = context.window_manager
        self.start, self.end, self.total = start, end, max(total, 1)
        self.step = max(self.total // 200, 1)

    def update(self, i: int) -> None:
        if i % self.step == 0:
            try:
                self.wm.progress_update(self.start + (self.end - self.start) * (i / self.total))
            except Exception:  # noqa: BLE001 -- progresso nunca pode travar o import
                pass


# ---------------------------------------------------------------------------
# Output = Objects (padrao)
# ---------------------------------------------------------------------------


def emit_objects(context, placements, collection, root, progress_range=(50.0, 100.0)) -> int:
    """1 Object por Placement, criados em ordem ALFABETICA de nome (ver
    docstring do modulo). sort() e estavel: dentro do mesmo nome mantem a
    ordem do prefab."""
    order = sorted(range(len(placements)), key=lambda i: placements[i].name)
    progress = _Progress(context, *progress_range, len(order))
    objects_new = bpy.data.objects.new
    link = collection.objects.link
    for n, i in enumerate(order):
        p = placements[i]
        obj = objects_new(p.name, p.entry["mesh"])
        obj.matrix_basis = p.matrix
        obj.parent = root
        props = p.props if p.props is not None else _block_props(p)
        for key, value in props.items():
            obj[key] = value
        link(obj)
        progress.update(n)
    return len(order)


# ---------------------------------------------------------------------------
# Output = Instances (Geometry Nodes)
# ---------------------------------------------------------------------------


def _get_instancer_node_group():
    """Node group compartilhado: Pontos (com atributos hp_rotation/hp_scale)
    -> Instance on Points usando a geometria do Object de origem."""
    group = bpy.data.node_groups.get(INSTANCER_NODE_GROUP)
    if group is not None and group.bl_idname == "GeometryNodeTree":
        return group

    group = bpy.data.node_groups.new(INSTANCER_NODE_GROUP, "GeometryNodeTree")
    iface = group.interface
    iface.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    iface.new_socket("Source", in_out="INPUT", socket_type="NodeSocketObject")
    iface.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")

    nodes, links = group.nodes, group.links
    n_in = nodes.new("NodeGroupInput")
    n_out = nodes.new("NodeGroupOutput")
    n_info = nodes.new("GeometryNodeObjectInfo")
    n_info.transform_space = "ORIGINAL"
    n_info.inputs["As Instance"].default_value = True
    n_rot = nodes.new("GeometryNodeInputNamedAttribute")
    n_rot.data_type = "QUATERNION"
    n_rot.inputs["Name"].default_value = "hp_rotation"
    n_scale = nodes.new("GeometryNodeInputNamedAttribute")
    n_scale.data_type = "FLOAT_VECTOR"
    n_scale.inputs["Name"].default_value = "hp_scale"
    n_iop = nodes.new("GeometryNodeInstanceOnPoints")

    n_in.location = (-600, 0)
    n_info.location = (-350, -150)
    n_rot.location = (-350, -350)
    n_scale.location = (-350, -500)
    n_iop.location = (0, 0)
    n_out.location = (250, 0)

    links.new(n_in.outputs["Source"], n_info.inputs["Object"])
    links.new(n_in.outputs["Geometry"], n_iop.inputs["Points"])
    links.new(n_info.outputs["Geometry"], n_iop.inputs["Instance"])
    links.new(n_rot.outputs["Attribute"], n_iop.inputs["Rotation"])
    links.new(n_scale.outputs["Attribute"], n_iop.inputs["Scale"])
    links.new(n_iop.outputs["Instances"], n_out.inputs["Geometry"])
    return group


def _set_modifier_input(mod, identifier: str, value) -> None:
    """Preenche uma entrada do modificador Geometry Nodes nas duas APIs:
    Blender 5.2+ (`mod.properties.inputs.<identifier>.value`) e ate 5.1
    (`mod[identifier] = value`, ID property). Bug real no 5.2: "bpy_struct
    [key] = val: id properties not supported for this type"."""
    props = getattr(mod, "properties", None)
    inputs = getattr(props, "inputs", None) if props is not None else None
    socket = getattr(inputs, identifier, None) if inputs is not None else None
    if socket is not None:
        socket.value = value
        return
    mod[identifier] = value


def _socket_identifier(group, name: str) -> str:
    for item in group.interface.items_tree:
        if getattr(item, "in_out", None) == "INPUT" and item.name == name:
            return item.identifier
    raise KeyError(name)


def emit_instances(context, placements, collection, root, prefab_name, progress_range=(50.0, 100.0)) -> dict:
    """1 Object "espalhador" por malha unica: uma nuvem de pontos (1 ponto
    por copia) + modificador Geometry Nodes que instancia o Object de
    origem em cada ponto com a rotacao/escala da copia. Os Objects de
    origem ficam numa Collection filha EXCLUIDA da View Layer (nao
    aparecem, mas o Geometry Nodes continua lendo a geometria deles).

    Instancias sao desenhadas/renderizadas muito mais rapido que Objects
    separados (Cycles/EEVEE instanciam nativamente). Perde: selecionar um
    bloco individual, o inspector por bloco e "Select All Instances"."""
    import numpy as np

    groups: dict = {}
    for p in placements:
        groups.setdefault(id(p.entry["mesh"]), []).append(p)
    if not groups:
        return {"objects": 0}

    sources = bpy.data.collections.new(f"{prefab_name}{SOURCES_COLLECTION_SUFFIX}")
    collection.children.link(sources)
    # Exclui em TODAS as View Layers da cena (nao so na ativa) -- senao, em
    # outra View Layer, os Objects de origem apareceriam empilhados na origem.
    for view_layer in context.scene.view_layers:
        layer = _find_layer_collection(view_layer.layer_collection, sources)
        if layer is not None:
            layer.exclude = True

    node_group = _get_instancer_node_group()
    source_socket = _socket_identifier(node_group, "Source")
    progress = _Progress(context, *progress_range, len(groups))

    created = 0
    for n, plist in enumerate(sorted(groups.values(), key=lambda pl: pl[0].name)):
        mesh = plist[0].entry["mesh"]
        item_name = plist[0].name

        src = bpy.data.objects.new(f"{item_name} (source)", mesh)
        sources.objects.link(src)

        count = len(plist)
        locs = np.empty((count, 3), dtype=np.float32)
        quats = np.empty((count, 4), dtype=np.float32)
        scales = np.empty((count, 3), dtype=np.float32)
        for i, p in enumerate(plist):
            loc, rot, scale = p.matrix.decompose()
            locs[i] = loc
            quats[i] = rot  # (w, x, y, z)
            scales[i] = scale

        points = bpy.data.meshes.new(f"{item_name} (instances)")
        points.vertices.add(count)
        points.vertices.foreach_set("co", locs.ravel())
        attr_rot = points.attributes.new("hp_rotation", "QUATERNION", "POINT")
        attr_rot.data.foreach_set("value", quats.ravel())
        attr_scale = points.attributes.new("hp_scale", "FLOAT_VECTOR", "POINT")
        attr_scale.data.foreach_set("vector", scales.ravel())
        points.update()

        obj = bpy.data.objects.new(f"{item_name} (instances)", points)
        obj.parent = root
        obj[PROP_OPT_INSTANCER_ITEM] = item_name
        obj[PROP_OPT_INSTANCE_COUNT] = count
        mod = obj.modifiers.new("Hyblend Instances", "NODES")
        mod.node_group = node_group
        _set_modifier_input(mod, source_socket, src)
        collection.objects.link(obj)
        created += 1
        progress.update(n)
    return {"objects": created}


def _find_layer_collection(layer, collection):
    if layer.collection == collection:
        return layer
    for child in layer.children:
        found = _find_layer_collection(child, collection)
        if found is not None:
            return found
    return None


# ---------------------------------------------------------------------------
# Output = Single Mesh
# ---------------------------------------------------------------------------


def _mesh_arrays(mesh):
    """Arrays numpy da malha compartilhada (lidos UMA vez por malha unica)."""
    import numpy as np

    nv, nl, np_ = len(mesh.vertices), len(mesh.loops), len(mesh.polygons)
    co = np.empty(nv * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    loop_vert = np.empty(nl, dtype=np.int32)
    mesh.loops.foreach_get("vertex_index", loop_vert)
    loop_start = np.empty(np_, dtype=np.int32)
    mesh.polygons.foreach_get("loop_start", loop_start)
    loop_total = np.empty(np_, dtype=np.int32)
    mesh.polygons.foreach_get("loop_total", loop_total)
    mat_index = np.empty(np_, dtype=np.int32)
    mesh.polygons.foreach_get("material_index", mat_index)
    uv = np.zeros(nl * 2, dtype=np.float32)
    if mesh.uv_layers.active is not None:
        mesh.uv_layers.active.data.foreach_get("uv", uv)
    return {
        "co": co.reshape(-1, 3),
        "loop_vert": loop_vert,
        "loop_start": loop_start,
        "loop_total": loop_total,
        "mat_index": mat_index,
        "uv": uv.reshape(-1, 2),
        "materials": list(mesh.materials),
    }


def _cube_face_sides(arr):
    """(npoly,3): pra cada face de uma malha de cubo centrada na origem, o
    vetor de eixo (+-1 no eixo dominante) do lado em que a face esta,
    calculado pelo centro da face."""
    import numpy as np

    centers = np.array(
        [arr["co"][arr["loop_vert"][s:s + t]].mean(axis=0) for s, t in zip(arr["loop_start"], arr["loop_total"])],
        dtype=np.float64,
    )
    side = np.zeros_like(centers)
    dominant = np.argmax(np.abs(centers), axis=1)
    side[np.arange(len(centers)), dominant] = np.sign(centers[np.arange(len(centers)), dominant])
    return side


def _grid_key(xyz):
    """(N,3) int -> (N,) int64 unico por celula (offset pra aceitar negativos)."""
    import numpy as np

    xyz = np.asarray(xyz, dtype=np.int64) + (1 << 20)
    return (xyz[:, 0] << 42) | (xyz[:, 1] << 21) | xyz[:, 2]


def emit_single_mesh(
    context,
    placements,
    collection,
    root,
    prefab_name,
    opaque_cells=None,
    remove_hidden_faces=False,
    weld=False,
    progress_range=(50.0, 100.0),
) -> dict:
    """Funde TODAS as copias numa unica malha (materiais preservados,
    1 slot por material distinto). Feito em lote com numpy por malha unica
    (todas as copias de um item de uma vez), nao copia-por-copia.

    `remove_hidden_faces`: face de um bloco CUBO cuja celula vizinha (na
    direcao da face, ja considerando a rotacao do bloco) e um cubo OPACO
    (`opaque_cells`, chaves de _grid_key) e descartada -- nunca aparece.
    `weld`: funde vertices na mesma posicao (Merge by Distance, 0.0001
    unidade). UV e por canto de face no Blender, entao a textura nao muda."""
    import numpy as np

    groups: dict = {}
    for p in placements:
        groups.setdefault(id(p.entry["mesh"]), []).append(p)

    opaque_sorted = None
    if remove_hidden_faces and opaque_cells is not None and len(opaque_cells):
        opaque_sorted = np.sort(np.asarray(opaque_cells, dtype=np.int64))

    mat_slots: dict = {}
    mat_list: list = []
    out_co, out_loop_vert, out_loop_total, out_mat, out_uv = [], [], [], [], []
    vert_offset = 0
    faces_removed = 0
    progress = _Progress(context, progress_range[0], progress_range[0] + (progress_range[1] - progress_range[0]) * 0.7, len(groups))

    for n, plist in enumerate(groups.values()):
        arr = _mesh_arrays(plist[0].entry["mesh"])
        k = len(plist)
        nv = len(arr["co"])
        npoly = len(arr["loop_start"])
        if nv == 0 or npoly == 0:
            continue

        # Slots de material globais. Malha sem nenhum slot conta como 1 slot
        # vazio (None) -- senao o indice 0 dela apontaria pro material de
        # OUTRO item no slot global 0.
        local_mats = arr["materials"] or [None]
        local_to_global = np.zeros(len(local_mats), dtype=np.int32)
        for li, mat in enumerate(local_mats):
            key = mat.name if mat is not None else None
            if key not in mat_slots:
                mat_slots[key] = len(mat_list)
                mat_list.append(mat)
            local_to_global[li] = mat_slots[key]

        mats = np.array([p.matrix for p in plist], dtype=np.float32)  # (k,4,4)
        rot = mats[:, :3, :3]
        trans = mats[:, :3, 3]
        co = np.einsum("kij,vj->kvi", rot, arr["co"]) + trans[:, None, :]  # (k,nv,3)

        poly_keep = np.ones((k, npoly), dtype=bool)
        is_cube = plist[0].entry.get("draw_type") == "CUBE"
        if opaque_sorted is not None and is_cube and plist[0].grid is not None:
            grid = np.array([p.grid for p in plist], dtype=np.int64)  # (k,3)
            # Lado de cada face pela POSICAO dela no cubo (cubo centrado na
            # origem: o centro da face +X esta em +X), NAO pela normal -- nao
            # depende da ordem dos cantos. Bug real (dev-0.2.1): as normais do
            # cubo apontavam pra dentro e o culling apagava a face VISIVEL.
            side = _cube_face_sides(arr)  # (npoly,3), vetores unitarios de eixo
            nrm = np.einsum("kij,pj->kpi", rot, side)  # (k,npoly,3), ja rotacionado
            nrm /= np.maximum(np.linalg.norm(nrm, axis=2, keepdims=True), 1e-9)
            step = np.rint(nrm).astype(np.int64)
            axis_aligned = (np.abs(nrm) > 0.99).any(axis=2)
            neighbor = grid[:, None, :] + step  # (k,npoly,3)
            keys = _grid_key(neighbor.reshape(-1, 3)).reshape(k, npoly)
            idx = np.searchsorted(opaque_sorted, keys)
            idx = np.clip(idx, 0, len(opaque_sorted) - 1)
            hidden = (opaque_sorted[idx] == keys) & axis_aligned
            poly_keep = ~hidden
            faces_removed += int(hidden.sum())

        # Loops de todas as copias de uma vez (sem loop Python por copia):
        # reordena os loops em ordem de face, replica por copia com offset
        # de vertice e filtra pelas faces mantidas.
        loop_total = arr["loop_total"]
        order = np.concatenate([np.arange(s, s + t) for s, t in zip(arr["loop_start"], loop_total)])
        n_loops = len(order)
        lv = arr["loop_vert"][order]
        uvs = arr["uv"][order]
        poly_mat = local_to_global[np.minimum(arr["mat_index"], len(local_to_global) - 1)]
        loop_mask = np.repeat(poly_keep, loop_total, axis=1)  # (k, n_loops)
        offsets = (np.arange(k, dtype=np.int64) * nv + vert_offset)[:, None]
        out_loop_vert.append((lv[None, :] + offsets)[loop_mask])
        out_uv.append(np.broadcast_to(uvs, (k, n_loops, 2))[loop_mask])
        out_loop_total.append(np.broadcast_to(loop_total, (k, npoly))[poly_keep])
        out_mat.append(np.broadcast_to(poly_mat, (k, npoly))[poly_keep])
        out_co.append(co.reshape(-1, 3))
        vert_offset += k * nv
        progress.update(n)

    if not out_co:
        return {"objects": 0, "faces_removed": faces_removed, "faces": 0}

    co = np.concatenate(out_co)
    loop_vert = np.concatenate(out_loop_vert)
    loop_total = np.concatenate(out_loop_total)
    mat_index = np.concatenate(out_mat)
    uv = np.concatenate(out_uv)
    del out_co, out_loop_vert, out_loop_total, out_mat, out_uv

    # Remove vertices que ficaram sem face (faces escondidas) e, com weld,
    # funde vertices na mesma posicao.
    if weld:
        q = np.round(co / 1e-4).astype(np.int64)
        _uniq, first, inverse = np.unique(q, axis=0, return_index=True, return_inverse=True)
        co = co[first]
        loop_vert = inverse.reshape(-1)[loop_vert]
    used = np.zeros(len(co), dtype=bool)
    used[loop_vert] = True
    remap = np.cumsum(used, dtype=np.int64) - 1
    co = co[used]
    loop_vert = remap[loop_vert].astype(np.int32)
    loop_total = loop_total.astype(np.int32)
    mat_index = mat_index.astype(np.int32)

    loop_start = np.zeros(len(loop_total), dtype=np.int32)
    if len(loop_total) > 1:
        np.cumsum(loop_total[:-1], out=loop_start[1:])

    mesh = bpy.data.meshes.new(f"{prefab_name} (single mesh)")
    mesh.vertices.add(len(co))
    mesh.vertices.foreach_set("co", co.ravel())
    mesh.loops.add(len(loop_vert))
    mesh.loops.foreach_set("vertex_index", loop_vert)
    mesh.polygons.add(len(loop_total))
    mesh.polygons.foreach_set("loop_start", loop_start)
    mesh.polygons.foreach_set("material_index", mat_index)
    uv_layer = mesh.uv_layers.new(name="UVMap")
    uv_layer.data.foreach_set("uv", uv.ravel())
    for mat in mat_list:
        mesh.materials.append(mat)
    mesh.update(calc_edges=True)

    obj = bpy.data.objects.new(f"{prefab_name} (single mesh)", mesh)
    obj.parent = root
    obj[PROP_OPT_SINGLE_MESH] = True
    collection.objects.link(obj)
    try:
        context.window_manager.progress_update(progress_range[1])
    except Exception:  # noqa: BLE001
        pass
    return {"objects": 1, "faces_removed": faces_removed, "faces": len(loop_total)}


def remove_unused_meshes(meshes) -> None:
    """Remove de uma vez (batch_remove) malhas que ficaram sem usuario --
    usado pelos modos Instances/Single Mesh, onde as malhas compartilhadas
    viram so "fonte" (Single Mesh copia a geometria e descarta a original)."""
    dead = [m for m in meshes if m is not None and m.users == 0]
    if dead:
        bpy.data.batch_remove(dead)

