"""Seletor dos addons Hyblend -- a faixa no topo da aba "Hyblend" (UI por GPU).

Com 2+ addons Hyblend instalados (Toolkit, Character Creator, Prefabs...),
cada um com a própria UI por GPU, só UM aparece na aba de cada vez; esta
faixa troca qual. A lista, o ativo e a troca em si vêm do hub
(hyblend_hub.py na raiz de cada addon) -- aqui é só o desenho:

    switcher.wrap(f, root, entries, on_pick, resolve)

  entries  [(id, rótulo, habilitado, ativo, tooltip)] na ordem da faixa
           (hub.entries). Quem chama só embrulha com 2+ addons presentes
           (hub.switcher_visible); sozinho, a árvore do addon fica
           exatamente como era
  on_pick  on_pick(f, id) -- clique num botão habilitado
  resolve  resolve("raiz:caminho.png") -> caminho existente ou "" (arte do
           jogo, cada addon resolve pela pasta Hytale dele)

VISUAL = o do Hyblend Toolkit, em qualquer addon: mesmo tema (THEME =
app.THEME do Toolkit), mesmos botões de aba (Button variant="tab", arte
Secondary/Tertiary_Active do jogo) e a moldura ContainerPatch. `Themed`
troca tema, skin e as opções de desenho do framework SÓ dentro da faixa
-- a tela do addon embaixo continua com as dele (o CC não muda nada).
"""

from dataclasses import replace

from . import CONFIG, core
from .core import Button, Column, Fade, Rect, Row, Style, Theme, Widget, fit_text


def _rgb(hex_color, a=1.0):
    value = hex_color.lstrip("#")
    return tuple(int(value[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (a,)


# = app.THEME do Hyblend Toolkit (interface/gpu_ui/app.py). Mudou lá -> copiar aqui.
# heading_weight "Title!" = a fonte "Title" do jogo (Lexend) ou a Geist
# padrão do framework -- igual em todo addon (ver renderer._font_path).
THEME = Theme(
    canvas=_rgb("#151f2c"), surface=_rgb("#1f2c44"), surface_raised=_rgb("#21344b"),
    surface_hover=_rgb("#2b3a55"), surface_pressed=_rgb("#253f60"), input=_rgb("#263047"),
    border=_rgb("#42526d", 0.9), text=_rgb("#dfe7ee"), text_muted=_rgb("#96a9be"),
    accent=_rgb("#e6c279"), accent_hover=_rgb("#f1ba50"), accent_pressed=_rgb("#c09953"),
    accent_soft=_rgb("#e6c279", 0.14), accent_text=_rgb("#151f2c"), track_off=_rgb("#0d1217"),
    shadow=(0.0, 0.0, 0.02, 0.6), dots=_rgb("#7a9cc6", 0.10), danger=_rgb("#e0526f"),
    danger_soft=_rgb("#c83a5f", 0.16), warning=_rgb("#f1ba50"), warning_soft=_rgb("#f1ba50", 0.12),
    success=_rgb("#57d9af"), primary=_rgb("#4470a4"), primary_hover=_rgb("#3858a2"),
    primary_pressed=_rgb("#2f6db0"), primary_text=_rgb("#ffffff"),
    heading_weight="Title!", heading_upper=True, heading_tracking=0.5, radius_scale=0.45,
)

_BTN = (24, 24, 24, 24)
# Peças do jogo usadas pela faixa (= game.ART do Toolkit). Só a raiz
# "game_common" (existe no hytale_install.ROOTS dos 3 addons).
ART = {
    "frame": ("game_common:ContainerPatch@2x.png", (46, 46, 46, 46), 0.5),
    "btn_secondary": ("game_common:Buttons/Secondary@2x.png", _BTN, 0.25),
    "btn_secondary_hover": ("game_common:Buttons/Secondary_Hovered@2x.png", _BTN, 0.25),
    "btn_secondary_pressed": ("game_common:Buttons/Secondary_Pressed@2x.png", _BTN, 0.25),
    "btn_disabled": ("game_common:Buttons/Disabled@2x.png", _BTN, 0.25),
    "btn_active": ("game_common:Buttons/Tertiary_Active@2x.png", _BTN, 0.25),
}

# Ícone de cada addon no modo compacto (painel estreito: texto não cabe nem
# encolhido -> os botões viram só ícone, o nome fica no tooltip). Ícones
# PROCEDURAIS do framework que nenhum addon redesenha (o CC troca alguns,
# ver cc_icons.py) -- a faixa sai igual em todo addon. Addon novo sem
# entrada aqui = "dot".
ICONS = {"toolkit": "bone", "character_creator": "head", "prefabs": "cube"}
COMPACT_MIN_SIZE = 10.0          # = CompactButton do Prefabs: menor tamanho de texto antes de virar ícone

KEY = "hub.switcher"
DISABLED_ALPHA = 0.45           # addon ausente/indisponível: botão apagado (sem clique, com tooltip)
BUTTON_HEIGHT = 30.0
GAP = 6.0                       # entre a faixa e a tela do addon
PADDING = (10, 8, 10, 9)


class Themed(Widget):
    """Desenha/mede o filho com OUTRO tema, outra skin e as opções de desenho
    padrão do framework (tracking "prefix", 8 amostras) -- e devolve tudo
    como estava no fim. Eventos (on_click...) vão direto pro widget filho."""

    def __init__(self, child, theme, skin):
        super().__init__(style=child.style, children=[child])
        self.theme, self.skin = theme, skin

    @property
    def fills(self):
        return self.children[0].fills

    def _swap(self, f):
        old = (f.theme, core._skin, CONFIG.text_tracking, CONFIG.image_samples, f.renderer.plain_icons)
        f.theme, core._skin = self.theme, self.skin
        CONFIG.text_tracking, CONFIG.image_samples = "prefix", 8
        # Ícones: sempre o desenho procedural calculado (sem a arte de ícone
        # do addon nem as máscaras prontas, que só alguns addons têm).
        f.renderer.plain_icons = True
        return old

    @staticmethod
    def _restore(f, old):
        f.theme, core._skin, CONFIG.text_tracking, CONFIG.image_samples, f.renderer.plain_icons = old

    def measure(self, f, max_w):
        old = self._swap(f)
        try:
            return self.children[0].measure(f, max_w)
        finally:
            self._restore(f, old)

    def _extent(self, f, width):
        old = self._swap(f)
        try:
            return self.children[0].extent(f, width)
        finally:
            self._restore(f, old)

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        old = self._swap(f)
        try:
            self.children[0].layout(f, rect, clip)
        finally:
            self._restore(f, old)

    def draw(self, f):
        old = self._swap(f)
        try:
            self.children[0].draw(f)
        finally:
            self._restore(f, old)


class _Tabs(Row):
    """Linha dos botões. Se o texto de QUALQUER botão não couber nem
    encolhido (o "…" ia aparecer), TODOS viram só ícone -- mistura de
    texto e ícone fica desencontrada."""

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        buttons = [c.children[0] if isinstance(c, Fade) else c for c in self.children]
        compact = any(not _fits(f, b) for b in buttons)
        for b in buttons:
            if compact:
                b.text, b.icon = "", ICONS.get(b.key[len("hub.tab."):], "dot")


def _fits(f, button):
    label, weight, tracking, size = button._label(f.theme)
    room = button.rect.w - 18
    size, tracking = fit_text(f.renderer, label, room, size, weight, tracking, min_size=COMPACT_MIN_SIZE)
    return f.renderer.text_width(label, size, weight, tracking) <= room


class _Frame(Column):
    """Corpo da faixa com a moldura do jogo (ContainerPatch). No jogo essa
    peça fica EMBAIXO de uma faixa de título, então só a borda de baixo tem
    o acabamento (a de cima é reta, "cortada"). Aqui ela fica sozinha: a
    metade de cima é desenhada espelhada da de baixo (flip_y), com a borda
    acabada nos dois lados. Sem a arte: a caixa procedural do Style."""

    def __init__(self, children, frame, key, style):
        super().__init__(children, key=key, style=style)
        self.frame = frame

    def draw_box(self, f):
        if not self.frame:
            return super().draw_box(f)
        r, rect = f.renderer, self.rect
        path, slices, scale = self.frame
        half = rect.h / 2
        r.push_clip(Rect(rect.x, rect.y, rect.w, half))
        try:
            ok = r.nine_slice(rect, path, slices, scale=scale)
        finally:
            r.pop_clip()
        r.push_clip(Rect(rect.x, rect.y + half, rect.w, rect.h - half))
        try:
            ok = r.nine_slice(rect, path, slices, scale=scale, flip_y=True) and ok
        finally:
            r.pop_clip()
        if not ok:               # PNG ainda decodificando: a caixa de reserva
            super().draw_box(f)


def _skin_fn(resolve):
    cache = {}

    def skin(part):
        if part not in cache:
            spec = ART.get(part)
            path = resolve(spec[0]) if spec else ""
            cache[part] = (path, spec[1], spec[2]) if path else None
        return cache[part]
    return skin


def build(f, entries, on_pick, resolve):
    """A faixa sozinha (Themed). Ver wrap()."""
    skin = _skin_fn(resolve)
    paths = [s[0] for s in (skin(p) for p in ART) if s]
    if paths:
        from .renderer import preload
        preload(paths)               # só fila + timer: seguro no build
    th = THEME

    def pick(ident):
        return lambda f: on_pick(f, ident)

    buttons = []
    for ident, label, enabled, active, tip in entries:
        button = Button("hub.tab." + ident, label, pick(ident) if enabled else None, variant="tab",
                        selected=active, enabled=enabled, tooltip=tip or None,
                        style=Style(height=BUTTON_HEIGHT, flex=1.0, radius=7 * th.radius_scale))
        # Desligado = apagado (com ou sem a arte do jogo, a aba inativa e a
        # desligada teriam quase a mesma cara).
        buttons.append(button if enabled else Fade(button, alpha=DISABLED_ALPHA))
    frame = skin("frame")
    # Reserva (sem a pasta do jogo, ou PNG ainda carregando): caixa procedural
    # da moldura do Toolkit (app.window).
    style = Style(padding=PADDING, background=th.canvas, border=th.border, radius=12 * th.radius_scale)
    body = _Frame([_Tabs(buttons, style=Style(gap=3))], frame, KEY, style)
    return Themed(body, THEME, skin)


def wrap(f, root, entries, on_pick, resolve):
    """Faixa em cima + tela do addon embaixo. Menos de 2 entradas: `root`
    intacto. A tela do addon recebe flex (cresce com a altura manual do
    painel, como quando era a raiz)."""
    if root is None or len(entries) < 2:
        return root
    if not root.style.flex:
        root.style = replace(root.style, flex=1.0)
    return Column([build(f, entries, on_pick, resolve), root], key=KEY + ".wrap", style=Style(gap=GAP))
