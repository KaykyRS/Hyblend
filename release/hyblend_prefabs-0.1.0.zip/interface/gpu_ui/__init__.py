"""interface/gpu_ui/ -- painel da Sidebar desenhado com gpu/blf (Blender 5.0+).

Portado do Hyblend Toolkit (mesmo framework, mesmo visual do jogo). Regras:
  * só roda no Blender >= MIN_BLENDER (5.0). No 4.5 nada daqui é
    registrado (nem shaders/handlers) e o painel clássico continua sozinho;
  * LIGADA POR PADRÃO no 5.x (Preferences > Experimental > GPU Interface);
    desligar volta pro painel clássico. Um ou outro, nunca os dois
    (poll de HYBLENDPREFABS_PT_main);
  * a escolha (ligada/desligada) é UMA pra todos os addons Hyblend
    (hyblend_hub.py na raiz do addon);
  * aba "Hyblend" (framework/runtime.CATEGORY), a MESMA do Toolkit e do
    Character Creator: com 2+ addons Hyblend instalados, a faixa do seletor
    (framework/switcher.py) fica no topo e só o host do addon escolhido
    aparece (runtime.register(active=...)). Sozinho, tudo como antes.

Zero lógica de import aqui: a página (pages/prefabs_page.py) lê as MESMAS
properties e chama os MESMOS operadores do painel clássico; textos e
formatadores compartilhados moram em interface/common_ui.py.

Arquivos:
  framework/   mini framework genérico UNIFICADO: idêntico, byte a byte, ao
               do Toolkit e do CC; os nomes deste addon (operador
               hyblendprefabs.gpu_ui_host, pasta temporária das fontes...)
               entram por framework.configure() no register()
  widgets.py   widgets do Hyblend (cópia do Toolkit)
  bind.py      ponte widgets <-> RNA/operadores (versão enxuta, sem traduções)
  game.py      arte/fontes do jogo lidas da pasta do Hytale (IGUAL ao do Toolkit)
  hytale_install.py  mapa da pasta de instalação (cópia do Toolkit)
  app.py       tema, moldura do jogo, cabeçalho, toast, build/signature
  pages/       prefabs_page.py (o painel) + common.py (ImageButton)
  fonts/       Geist (OFL) -- reserva sem o jogo
  icons/       máscaras PNG dos ícones procedurais (framework/icons.py gera)
"""


import bpy

from ... import hyblend_hub
from ...common import ADDON_PACKAGE, HUB_ID, game_found

MIN_BLENDER = (5, 0, 0)

_registered = False


def is_supported():
    return bpy.app.version >= MIN_BLENDER


def _prefs(context=None):
    context = context or bpy.context
    try:
        return context.preferences.addons[ADDON_PACKAGE].preferences
    except (KeyError, AttributeError):
        return None


def is_enabled(context=None):
    """True = a UI por GPU está ativa (Blender suporta E preference ligada)."""
    if not (_registered and is_supported()):
        return False
    prefs = _prefs(context)
    return bool(prefs is not None and getattr(prefs, "use_gpu_ui", True))


# --------------------------------------------------------------------------
# Chamado pelas Preferences (preferences.py) -- import tardio lá
# --------------------------------------------------------------------------

def on_preference_changed(context):
    """Ligou/desligou a UI, ou mudou escala/tamanho."""
    if _registered:
        from .framework import runtime
        if not is_enabled(context):
            runtime.shutdown_all()           # derruba hosts e draw handlers
        else:
            prefs = _prefs(context)
            runtime.apply_size("width", prefs.gpu_ui_panel_width)
            runtime.apply_size("height", prefs.gpu_ui_panel_height)
    hyblend_hub.redraw_view3d(context)


def hub_refresh():
    """Aviso do hub (addon entrou/saiu, troca no seletor): reconstruir."""
    if _registered:
        from .framework import runtime
        for host in list(runtime._HOSTS.values()):
            host.invalidate()


def host_ok(context):
    """O host desta sidebar NÃO está quebrado (com erro, o painel-gancho
    mostra o aviso nativo -- e o seletor nativo volta junto)."""
    if not _registered:
        return False
    from .framework import runtime
    return runtime.host_status(context) != "ERROR"


def _hub_pick(f, ident):
    hyblend_hub.set_active(ident, f.context)


def _hub_resolve(ref):
    from . import game
    return game.file(ref)


def _build(f):
    """Tela do Prefabs + faixa do seletor dos addons Hyblend em cima (só com
    2+ addons; sozinho, a árvore é exatamente a de antes)."""
    from . import app
    from .framework import switcher
    root = app.build(f)
    if not hyblend_hub.switcher_visible():
        return root
    return switcher.wrap(f, root, hyblend_hub.entries(f.context), _hub_pick, _hub_resolve)


def _hub_active():
    return hyblend_hub.is_active(HUB_ID)


def on_hytale_path_changed(context):
    """Pasta/modo do Hytale mudou: esquece o caminho resolvido; o próximo
    build troca arte e fontes (game.sync) -- a assinatura do app muda."""
    from . import game
    game.invalidate()
    if _registered and not game_found():
        from .framework import runtime
        runtime.shutdown_all()          # jogo "sumiu": o N-Panel por GPU sai junto com a aba
    hyblend_hub.redraw_view3d(context)


def draw_preferences(prefs, layout):
    """Conteúdo da sub-aba "GPU Interface (N-Panel)" (dentro de Experimental,
    montada por preferences.py): o desenho do hub, IGUAL no Toolkit e no CC."""
    hyblend_hub.draw_gpu_settings(layout, prefs, is_supported(), MIN_BLENDER)


# --------------------------------------------------------------------------
# Ligação com o runtime
# --------------------------------------------------------------------------

def _extra_scale(context):
    prefs = _prefs(context)
    return prefs.gpu_ui_scale if prefs is not None else 1.0


_SIZE_PROPS = {"width": "gpu_ui_panel_width", "height": "gpu_ui_panel_height"}


def _get_size(context, axis):
    prefs = _prefs(context)
    return getattr(prefs, _SIZE_PROPS[axis]) if prefs is not None else 0.0


def _set_size(context, axis, value):
    prefs = _prefs(context)
    if prefs is not None:
        setattr(prefs, _SIZE_PROPS[axis], value)   # get/set do hub: vai pro ui.json (todos os addons)


# --------------------------------------------------------------------------
# Painel-gancho
# --------------------------------------------------------------------------

class HYBLENDPREFABS_OT_gpu_ui_retry(bpy.types.Operator):
    bl_idname = "hyblendprefabs.gpu_ui_retry"
    bl_label = "Try Again"
    bl_description = "Try to start the GPU interface again"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        from .framework import runtime
        runtime.clear_error(context)
        if context.region is not None:
            context.region.tag_redraw()
        return {"FINISHED"}


class HYBLENDPREFABS_OT_gpu_ui_disable(bpy.types.Operator):
    bl_idname = "hyblendprefabs.gpu_ui_disable"
    bl_label = "Use Classic Panel"
    bl_description = "Turn off the GPU interface (in all Hyblend addons) and go back to the classic panel"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        prefs = _prefs(context)
        if prefs is not None:
            prefs.use_gpu_ui = False         # o set= do hub avisa todos os addons (on_preference_changed)
        return {"FINISHED"}


def _make_host_panel():
    from .framework import runtime

    class HYBLENDPREFABS_PT_gpu_ui_host(bpy.types.Panel):
        """Não desenha nada útil: só avisa o runtime que a aba está visível
        (o painel de verdade é desenhado por cima, via draw handler)."""
        bl_space_type = "VIEW_3D"
        bl_region_type = "UI"
        bl_category = runtime.CATEGORY
        bl_label = "Hyblend Prefabs GPU UI"
        bl_options = {"HIDE_HEADER"}

        @classmethod
        def poll(cls, context):
            # sem o jogo: aba some (common.game_found); com outros addons
            # Hyblend: só se o Prefabs é o escolhido no seletor
            return is_enabled(context) and game_found() and hyblend_hub.is_active(HUB_ID, context)

        def draw(self, context):
            runtime.ensure_host(context)
            # Erro / montando: o desenho do hub, IGUAL nos addons Hyblend.
            hyblend_hub.draw_gpu_host_status(self.layout, runtime.host_status(context), runtime.host_error(context),
                                             HYBLENDPREFABS_OT_gpu_ui_retry.bl_idname, HYBLENDPREFABS_OT_gpu_ui_disable.bl_idname)

    return HYBLENDPREFABS_PT_gpu_ui_host


_classes = []


def register():
    """Só registra algo no Blender suportado -- abaixo de 5.0 nem os
    shaders/handlers da UI por GPU são carregados."""
    global _registered
    if not is_supported() or _registered:
        return
    from . import framework
    # Framework unificado (igual nos addons Hyblend): nomes deste addon.
    framework.configure(namespace="hyblendprefabs", label="Hyblend Prefabs GPU UI",
                        font_copy_dir="hyblend_prefabs_fonts")
    from . import app, game
    from .framework import core, renderer, runtime
    runtime.register(_build, _extra_scale, _get_size, _set_size, app.signature, None, theme=app.THEME,
                     active=_hub_active)
    renderer.set_image_icon_resolver(game.glyph_icon)     # ícones do jogo (procedural sem a pasta)
    core.set_skin(game.skin_part)                          # arte do jogo por peça (idem)
    _classes[:] = [HYBLENDPREFABS_OT_gpu_ui_retry, HYBLENDPREFABS_OT_gpu_ui_disable, _make_host_panel()]
    for cls in _classes:
        bpy.utils.register_class(cls)
    _registered = True


def unregister():
    global _registered
    if not _registered:
        return
    from . import game
    from .framework import core, renderer, runtime
    renderer.set_image_icon_resolver(None)
    core.set_skin(None)
    game.invalidate()
    game.forget_sync()
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    _classes.clear()
    runtime.unregister()
    _registered = False
