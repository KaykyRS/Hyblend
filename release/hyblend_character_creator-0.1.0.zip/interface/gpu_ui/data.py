"""interface/gpu_ui/data.py -- adaptador: catálogo REAL do CC -> estrutura que
a tela (app.py) desenha. Substitui o `catalog.py` do protótipo (que lia
PNGs provisórios de assets/).

Só LEITURA de dado já carregado: nada aqui toca `bpy.data`, carrega
catálogo do disco nem escreve em property. O que precisa disso (carregar
catálogo/idioma, sincronizar slots com o Armature, cortar margem dos
ícones do jogo) roda em `bind.sync_tick` -- um bpy.app.timers, FORA do
draw handler (DEVELOPER_NOTES itens 14-16 e 57). Aqui, se algo ainda não
está pronto, a tela mostra "Loading…" e pede um sync.

Estrutura devolvida por `load()`: lista de Category(id, label, icon,
icon_selected, subs=[Sub(id, label, icon, icon_selected, optional)]).
Itens de uma Sub são montados SOB DEMANDA (`items_for`) -- só a
sub-categoria ativa é desenhada, igual à UI clássica.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path

from ...common import (
    _CATEGORY_ICON_FILES,
    _EMPTY_PART_ICON_REF,
    _LINK_TOGGLE_ICON_FILES,
    _MANDATORY_CATEGORIES,
    _SECTION_ICON_FILES,
    _game_file,
    _hytale_dir,
    _prettify_key,
)
from ...scanner import hytale_install
from ...scanner.catalog import get_cache
from ...thumbnails.cache import thumbnail_path
from ..ui_data import _group_categories

_UI_DIR = Path(__file__).resolve().parent / "assets" / "ui"


# Pasta Hytale gravada UMA vez por build (sync()) e usada no desenho: ler as
# Preferences a cada peça desenhada custava ~150 leituras por quadro
# (correção 8 do Hyblend Toolkit 0.9.3). Fora do ciclo build/draw (timer,
# antes do 1o build) cai na leitura normal.
_current = {"dir": None, "set": False}


def _root():
    return _current["dir"] if _current["set"] else _hytale_dir()


def sync() -> None:
    """No começo de cada build(). Pasta mudou (ou 1a vez): zera o cache de
    existência, carrega as fontes do jogo e pré-carrega toda a arte das
    tabelas (sem isso, o 1o hover mostra 1 quadro do procedural)."""
    root = _hytale_dir()
    changed = not _current["set"] or _current["dir"] != root
    _current["dir"], _current["set"] = root, True
    if changed:
        _existing["dir"], _existing["paths"] = root, {}
        _on_root_changed()


def _game_icon(ref: str) -> str:
    """Caminho (str) de um icone do jogo na pasta Hytale, ou "" sem pasta
    configurada. Arquivo inexistente/"" -> o widget cai no icone
    procedural (renderer.image devolve False, nunca quebra)."""
    root = _root()
    return str(hytale_install.resolve(root, ref)) if root is not None else ""


# Icones reais do jogo pra pecas da tela que o prototipo desenhava com
# icone procedural (referencias em common.py). O que NAO tem equivalente
# real ainda continua procedural -- lista em DEVELOPER_NOTES secao 6.
def empty_part_icon() -> str:
    """Tile "Nenhum"."""
    return _game_icon(_EMPTY_PART_ICON_REF)


def link_icons() -> dict:
    """{linkado: caminho} pro LinkButton (pele e fundo dos olhos)."""
    return {state: _game_icon(ref) for state, ref in _LINK_TOGGLE_ICON_FILES.items()}


def ui_asset(name: str) -> str:
    """Moldura/título/ornamento PROVISÓRIOS (assets/ui/ desta pasta) --
    só usados como reserva quando a pasta Hytale não está configurada
    (ou o arquivo do jogo não existe). O normal é a versão do jogo, ver
    frame_style()/title_assets()."""
    return str(_UI_DIR / name)


# --------------------------------------------------------------------------
# Peças da interface com arte REAL do jogo (conferidas com os PNGs e .ui
# reais do usuário, set/2026). Referências "raiz:arquivo" -> ver
# scanner/hytale_install.py. Trocar/adicionar = editar só estas tabelas.
# --------------------------------------------------------------------------

# Nome do ícone procedural -> (referência, tingir?). tingir=True: glifo
# claro do jogo usado como máscara com a cor do estado (hover, desabilitado,
# dourado), igual ao procedural. False: cores do próprio PNG. Nome fora
# daqui continua procedural (hoje só "dot", o marcador de carregando, e
# o "x" de reserva do tile Nenhum). Escolhas aprovadas pelo usuário por
# folha de comparação (set/2026).
GLYPH_ICONS = {
    "search": ("avatar:SearchIcon@2x.png", True),
    "check": ("game_common:Checkmark@2x.png", True),
    "chevron_down": ("game_common:AltDropdownCaretDown@2x.png", True),
    "chevron_up": ("game_common:AltDropdownCaretUp@2x.png", True),
    "caret": ("game_common:ContainerTitleArrow@2x.png", False),   # triângulo dourado do título do jogo
    "chevron": ("inventory:RightMenuSelectedArrow@2x.png", False),   # ">" da categoria ativa (seta de item selecionado do jogo)
    "trash": ("avatar_presets:IconDelete@2x.png", True),
    "plus": ("avatar_presets:IconAdd@2x.png", True),
    "gear": ("shared_icons:IconSettings.png", True),
    "user": ("shared_icons:IconPlayers.png", True),
    "rig": ("shared_editor_icons:ParticleSystem.png", True),     # nós ligados = articulações/ossos (sem ícone de rig no jogo)
    "bookmark": ("shared_icons:IconStarFill.png", True),         # Presets
    "save": ("editor_asset:ExportIcon@2x.png", True),
    "load": ("shop:IconRedirect@2x.png", True),
    "refresh": ("shared_icons:IconClockwise.png", True),
    "folder": ("shared_editor_icons:Folder.png", True),
    "exit": ("shared_icons:IconExit.png", True),                 # Use Classic Interface
    "error": ("game_settings:IconWarning@2x.png", False),
}

# Cadeado da sub-categoria: no jogo é o BOTÃO inteiro (o PNG já traz o
# quadrado de fundo), 3 estados -> substitui o SquareButton todo, sem tinta.
LOCK_ICONS = {
    "on": "avatar:RandomizationLockedIcon@2x.png",
    "off": "avatar:RandomizationUnlockedIcon@2x.png",
    "off_hover": "avatar:RandomizationUnlockedIconHovered@2x.png",
}

# Selo de "equipado" no tile escolhido (círculo verde com check).
EQUIPPED_ICON = "avatar:EquippedIcon@2x.png"

# Moldura/título/ornamento: Common/Container.ui (@DecoratedContainer).
# Bordas do .ui são em unidades lógicas; o PNG é @2x -> x2 em pixel.
FRAME_REF = "game_common:ContainerPatch@2x.png"          # Border: 23 -> 46 px
FRAME_SLICE = 46
HEADER_REF = "game_common:ContainerHeader@2x.png"        # HorizontalBorder: 50 -> 100 px, VerticalBorder: 0
HEADER_SLICE = 100
ORNAMENT_REF = "game_common:ContainerDecorationTop@2x.png"   # 236x11 lógico no jogo
ORNAMENT_BOTTOM_REF = "game_common:ContainerDecorationBottom@2x.png"   # 236x11, Bottom -6


def _all_art_refs():
    """Toda referência de arte fixa da tela (pro pré-carregamento)."""
    yield from (ref for ref, _tint in GLYPH_ICONS.values())
    yield from LOCK_ICONS.values()
    yield from _LINK_TOGGLE_ICON_FILES.values()
    yield from (EQUIPPED_ICON, FRAME_REF, HEADER_REF, ORNAMENT_REF, ORNAMENT_BOTTOM_REF,
                _EMPTY_PART_ICON_REF)


# Fontes do jogo (Shared/UI/Fonts), lidas da instalação -- não vêm no addon.
# Nos .ui: FontName "Secondary" = Lexend-Bold (títulos/botões em caixa alta)
# e "Default" = Nunito Sans. Peso sem arquivo -> Geist embutida (reserva).
GAME_FONTS = {
    "Regular": "shared_fonts:NunitoSans-Regular.ttf",
    "Medium": "shared_fonts:NunitoSans-Medium.ttf",
    "SemiBold": "shared_fonts:NunitoSans-SemiBold.ttf",
    "Bold": "shared_fonts:NunitoSans-ExtraBold.ttf",
    "Title": "shared_fonts:Lexend-Bold.ttf",
}


def load_game_fonts() -> None:
    """Registra no renderer as fontes do jogo que existem na pasta atual
    (sem pasta: {} -> todas voltam pra Geist). Chamado por sync() quando a
    pasta muda; forget_fonts() do load_post continua valendo."""
    from .framework import renderer
    renderer.set_font_files({weight: _game_icon_if_exists(ref) for weight, ref in GAME_FONTS.items()})


def _on_root_changed() -> None:
    from .framework import renderer
    load_game_fonts()
    renderer.preload(_game_icon(ref) for ref in _all_art_refs())

_existing: dict = {"dir": None, "paths": {}}


def _game_icon_if_exists(ref: str) -> str:
    """Como _game_icon, mas "" se o arquivo não existe -- cacheado por
    pasta Hytale (o build roda a cada mudança; sem stat repetido)."""
    root = _root()
    if _existing["dir"] != root:
        _existing["dir"], _existing["paths"] = root, {}
    cache = _existing["paths"]
    if ref not in cache:
        path = _game_icon(ref)
        cache[ref] = path if path and Path(path).is_file() else ""
    return cache[ref]


def glyph_icon(name: str):
    """Resolver registrado no renderer (framework.renderer.
    set_image_icon_resolver): nome procedural -> (caminho, tingir) ou None."""
    entry = GLYPH_ICONS.get(name)
    if entry is None:
        return None
    path = _game_icon_if_exists(entry[0])
    return (path, entry[1]) if path else None


def lock_images() -> dict:
    """{"on", "off", "off_hover"} -> caminho ("" = usa o procedural)."""
    return {state: _game_icon_if_exists(ref) for state, ref in LOCK_ICONS.items()}


def equipped_icon() -> str:
    return _game_icon_if_exists(EQUIPPED_ICON)


def frame_style() -> tuple:
    """Style.frame da janela: ContainerPatch do jogo, ou o provisório.
    Escala 0.5 = tamanho lógico do jogo (canto de 23)."""
    path = _game_icon_if_exists(FRAME_REF)
    if path:
        return (path, (FRAME_SLICE,) * 4, FRAME_SCALE)
    return (ui_asset("frame.png"), (12, 12, 12, 12), 1.0)


FRAME_SCALE = 0.5


def decorated() -> bool:
    """Arte da janela do jogo disponível (moldura + faixa do título)?"""
    return bool(_game_icon_if_exists(FRAME_REF) and _game_icon_if_exists(HEADER_REF))


def bottom_ornament() -> str:
    return _game_icon_if_exists(ORNAMENT_BOTTOM_REF)


def title_assets() -> dict:
    """kwargs do TitleBar: faixa (9-slice horizontal) + ornamento do jogo,
    ou o arabesco/ornamento provisórios."""
    header = _game_icon_if_exists(HEADER_REF)
    if header:
        return {"header": header, "header_slice": HEADER_SLICE,
                "ornament": _game_icon_if_exists(ORNAMENT_REF) or None}
    return {"pattern": ui_asset("title_pattern.png"), "ornament": ui_asset("ornament.png")}


# --------------------------------------------------------------------------
# Ícones: caminho do PNG já CORTADO (margem transparente removida)
# --------------------------------------------------------------------------

# (kind, key, selecionado) -> caminho (str). Preenchido por warm_icons()
# no timer, PRA pasta Hytale em `_icons_for`; enquanto nao aquece, usa o
# PNG original (margem maior, mas nunca quebra).
_icon_paths: dict = {}
_icons_for = {"dir": None}


def warm_icons() -> None:
    """Corta a margem transparente dos icones reais (mesmo corte em PAR
    normal/selecionado da UI classica -- ver common._cropped_icon_path_pair).
    Usa bpy.data -> SO no timer (bind.sync_tick). Trocar a pasta Hytale
    descarta o que foi aquecido pra pasta anterior."""
    from ...common import _cropped_icon_path, _cropped_icon_path_pair

    root = _hytale_dir()
    if root is None:
        return
    if _icons_for["dir"] != root:
        _icon_paths.clear()
        _icons_for["dir"] = root
    for kind, table in (("section", _SECTION_ICON_FILES), ("category", _CATEGORY_ICON_FILES)):
        for key, (normal_ref, selected_ref) in table.items():
            if (kind, key, False) in _icon_paths:
                continue
            normal, selected = _game_file(normal_ref), _game_file(selected_ref)
            for want_selected in (False, True):
                src = selected if want_selected else normal
                if normal_ref != selected_ref and normal.is_file() and selected.is_file():
                    out = _cropped_icon_path_pair(normal, selected, want_selected=want_selected)
                else:
                    out = _cropped_icon_path(src) if src.is_file() else None
                _icon_paths[(kind, key, want_selected)] = str(out or src)
    from .framework import renderer
    renderer.preload(_icon_paths.values())      # timer: já fora do desenho


def icon_path(kind: str, key: str, selected: bool) -> str:
    cached = _icon_paths.get((kind, key, selected))
    if cached is not None:
        return cached
    table = _SECTION_ICON_FILES if kind == "section" else _CATEGORY_ICON_FILES
    pair = table.get(key)
    if pair is None:
        return empty_part_icon()          # icone faltando: usa o "peca vazia" do jogo
    return _game_icon(pair[1 if selected else 0])


def forget_icons() -> None:
    """Clear Cache apagou os PNGs cortados: o próximo sync corta de novo."""
    _icon_paths.clear()
    _icons_for["dir"] = None


def icons_warm() -> bool:
    """Icones aquecidos PRA pasta Hytale atual (trocar a pasta reaquece)."""
    return bool(_icon_paths) and _icons_for["dir"] == _root()


# --------------------------------------------------------------------------
# Catálogo
# --------------------------------------------------------------------------

@dataclass
class Sub:
    id: str                 # chave do catálogo (ex. "Haircuts")
    label: str
    icon: str
    icon_selected: str
    optional: bool          # mostra o tile "Nenhum"


@dataclass
class Category:
    id: str                 # chave de _SECTION_CATEGORIES (ex. "Head")
    label: str
    icon: str
    icon_selected: str
    subs: list = field(default_factory=list)


@dataclass
class ItemEntry:
    id: str
    name: str
    thumb: str | None       # PNG da miniatura gerada (None = ainda não gerada)
    item: object            # scanner.manifest_parser.Item


def catalog_loaded() -> bool:
    return bool(get_cache().catalogs)


def load() -> list:
    """Categorias/sub-categorias PRESENTES no catálogo carregado (mesmo
    agrupamento da UI clássica: interface/ui_data._group_categories --
    inclui o grupo "Other" e respeita _HIDDEN_CATEGORIES)."""
    groups = _group_categories(get_cache())
    result = []
    for section, subcats in groups.items():
        cat = Category(section, _prettify_key(section),
                       icon_path("section", section, False), icon_path("section", section, True))
        for key in subcats:
            cat.subs.append(Sub(key, _prettify_key(key),
                                icon_path("category", key, False), icon_path("category", key, True),
                                optional=key not in _MANDATORY_CATEGORIES))
        result.append(cat)
    return result


# Miniatura: existência em disco cacheada (a grade é redesenhada muitas
# vezes; is_file() a cada quadro pra cada célula seria desperdício).
# Positivo fica pra sempre; negativo expira (a miniatura pode ser gerada
# a qualquer momento -- aqui ou pela UI clássica).
_thumb_cache: dict = {}
_NEGATIVE_TTL = 2.0


def _reference_color(cache, item):
    from ...picker import _item_reference_color
    return _item_reference_color(cache, item)


def thumb_for(category: str, item) -> str | None:
    key = (category, item.id)
    hit = _thumb_cache.get(key)
    now = time.monotonic()
    if hit is not None and (hit[0] is not None or now - hit[1] < _NEGATIVE_TTL):
        return hit[0]
    cache = get_cache()
    color = _reference_color(cache, item)
    path = None
    if color is not None:
        candidate = thumbnail_path(category, item.id, color)
        if candidate.is_file():
            path = str(candidate)
    _thumb_cache[key] = (path, now)
    return path


_items_cache: dict = {}


def items_for(category: str) -> list:
    """[ItemEntry] ordenados pelo nome exibido (mesma ordem do dropdown
    clássico, `picker._slot_item_enum_items`). Nomes cacheados por
    (categoria, idioma carregado)."""
    cache = get_cache()
    key = (category, cache.language, id(cache.catalogs.get(category)))
    base = _items_cache.get(key)
    if base is None:
        labeled = sorted(((it, cache.display_name(it.name_key)) for it in cache.catalogs.get(category, [])),
                         key=lambda e: e[1].lower())
        base = _items_cache[key] = labeled
    return [ItemEntry(it.id, name, thumb_for(category, it), it) for it, name in base]


def invalidate() -> None:
    """Catálogo recarregado / miniaturas regeneradas / idioma trocado."""
    _items_cache.clear()
    _thumb_cache.clear()


def hex_to_rgba(hex_color) -> tuple:
    if not hex_color:
        return (0.35, 0.37, 0.42, 1.0)
    value = str(hex_color).lstrip("#")
    try:
        return tuple(int(value[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (1.0,)
    except ValueError:
        return (0.35, 0.37, 0.42, 1.0)
