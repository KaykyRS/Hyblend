"""Painel clássico do núcleo: aba Info (créditos/links, também desenhada pelo Anim), engrenagem das Preferences,
seletor dos addons Hyblend e o painel de espera quando nenhum addon com tela (o Anim) está ligado.
Registra também a UI por GPU, a Home e o Welcome. Textos por tr() (keys "panel.")."""

import os

import blf
import bpy
import bpy.utils.previews
from bpy.props import EnumProperty
from bpy.types import Panel, WindowManager

from ..common import ADDON_PACKAGE, HUB_ID, HYBLEND_AUTHOR_YOUTUBE_URL, game_found
from ..translations import get_language, tr
from .. import hyblend_hub  # seletor/sincronia entre os addons Hyblend, ver hyblend_hub.py
from . import gpu_ui  # UI experimental por GPU (Blender 5.0+), ver gpu_ui/__init__.py
from . import welcome  # janela de boas-vindas (nativa + GPU), ver welcome.py
from . import home  # Home em tela cheia (Blender 5.0+, gpu_ui), ver home/__init__.py

# String vazia = botão correspondente fica desabilitado no painel (ver _draw_info).
HYBLEND_PATREON_URL = "https://www.patreon.com/cw/kaayky"
HYBLEND_NEXUSMODS_URL = "https://www.nexusmods.com/hytale/mods/164"
HYBLEND_GITHUB_URL = "https://github.com/KaykyRS/Hyblend"
# Créditos: "Created by:" / estúdio (linha própria) / autor + redes sociais.
HYBLEND_STUDIO_NAME = "Trupe Forge"
HYBLEND_AUTHOR_NAME = "Kaayky (Ká)"
HYBLEND_AUTHOR_INSTAGRAM_URL = "https://www.instagram.com/kaayky_r.s/"
HYBLEND_AUTHOR_TWITTER_URL = "https://x.com/kaayky_anim"
# Redes do autor (linha "Kaayky (Ká)" dos créditos), na ordem dos botões:
# (url, logo em assets/icons/, ícone embutido do painel clássico, ícone da UI por GPU).
HYBLEND_SOCIAL_LINKS = (
    (HYBLEND_PATREON_URL, "patreon", "FUND", "heart"),
    (HYBLEND_AUTHOR_INSTAGRAM_URL, "instagram", "IMAGE_DATA", "image"),
    (HYBLEND_AUTHOR_TWITTER_URL, "twitter_x", "WORLD", "globe"),
    (HYBLEND_AUTHOR_YOUTUBE_URL, "youtube", "FILE_MOVIE", "play"),
)
# Site oficial do Hytale (Hypixel Studios) -- crédito, não patrocínio/afiliação.
HYBLEND_HYTALE_URL = "https://hytale.com"
# Janela de boas-vindas (welcome.py): "Changelog" e "Apoie o Hyblend".
# Provisórios -- trocar quando houver as páginas definitivas.
HYBLEND_CHANGELOG_URL = "https://github.com/KaykyRS/Hyblend/releases"
HYBLEND_SUPPORT_URL = HYBLEND_PATREON_URL

# Ícones customizados (bpy.utils.previews) em assets/icons/; sem o arquivo, cai no ícone genérico.
_PANEL_ICON_FILES = {
    "instagram": "instagram.png",
    "twitter_x": "twitter_x.png",
    "youtube": "youtube.png",
    "hytale": "hytale.png",
    "patreon": "patreon.png",
    "nexus_mods": "nexus_mods.png",
    "github": "github.png",
}
_panel_icons_pcoll = None


def _load_panel_icons():
    """Carrega os PNGs de assets/icons/ num preview collection. Silencioso
    se a pasta/arquivo não existir (permite trabalhar sem os ícones ainda)."""
    global _panel_icons_pcoll
    pcoll = bpy.utils.previews.new()
    # assets/ fica na raiz do addon (um nível acima deste arquivo).
    addon_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    icons_dir = os.path.join(addon_root, "assets", "icons")
    for key, filename in _PANEL_ICON_FILES.items():
        path = os.path.join(icons_dir, filename)
        if os.path.isfile(path):
            try:
                pcoll.load(key, path, "IMAGE")
            except Exception:
                pass  # PNG existe mas o Blender não conseguiu ler -- cai pro ícone genérico
    _panel_icons_pcoll = pcoll


def _unload_panel_icons():
    global _panel_icons_pcoll
    if _panel_icons_pcoll is not None:
        bpy.utils.previews.remove(_panel_icons_pcoll)
        _panel_icons_pcoll = None


def _panel_icon_value(key):
    """icon_id carregado pra `key`, ou None se o PNG não foi carregado --
    _draw_info decide entre icon_value= (logo customizado) e icon= (fallback)."""
    if _panel_icons_pcoll is not None and key in _panel_icons_pcoll:
        return _panel_icons_pcoll[key].icon_id
    return None


def _draw_wrapped_label(layout, context, text):
    """Label quebrado em várias linhas pela largura real das palavras (blf); a largura da coluna é estimada pela região."""
    available_px = context.region.width - _WRAPPED_LABEL_MARGIN_PX
    font_id = 0
    line = ""
    for word in text.split(" "):
        candidate = f"{line} {word}".strip()
        width_px, _height_px = blf.dimensions(font_id, candidate)
        if width_px > available_px and line:
            layout.label(text=line)
            line = word
        else:
            line = candidate
    if line:
        layout.label(text=line)


# Margem estimada (px) entre context.region.width e a largura de texto
# disponível dentro de credits_box -- ajustado no olho (Blender não expõe isso).
_WRAPPED_LABEL_MARGIN_PX = 40


# Engrenagem como item do Enum (mesmo visual das abas); get() sempre IDLE e set() abre as Preferences num timer.
_PREFS_BUTTON_ITEMS_CACHE = []


def _prefs_button_items(self, context):
    lang = get_language(context)
    _PREFS_BUTTON_ITEMS_CACHE.clear()
    _PREFS_BUTTON_ITEMS_CACHE.extend(
        [
            ("IDLE", "", "", "NONE", 0),
            ("OPEN", "", tr("importer.tooltip.open_addon_preferences", lang), "PREFERENCES", 1),
        ]
    )
    return _PREFS_BUTTON_ITEMS_CACHE


def _prefs_button_get(self):
    return 0


_prefs_button_window = [None]      # janela do clique (o timer não tem window no contexto)


def _open_prefs_timer():
    wm = bpy.context.window_manager
    window = _prefs_button_window[0]
    _prefs_button_window[0] = None
    if not any(w == window for w in wm.windows):
        window = wm.windows[0] if wm.windows else None
    if window is not None:
        try:
            with bpy.context.temp_override(window=window, screen=window.screen):
                bpy.ops.hytale.open_addon_preferences()
        except Exception:
            import traceback
            traceback.print_exc()
    return None


def _prefs_button_set(self, value):
    if value != 1:
        return
    _prefs_button_window[0] = bpy.context.window
    if not bpy.app.timers.is_registered(_open_prefs_timer):
        bpy.app.timers.register(_open_prefs_timer, first_interval=0.0)


def draw_info(layout, context, lang):
    """Aba Info (também usada pelo painel do Anim): créditos e links (wm.url_open); URL vazia deixa o botão desabilitado."""
    # Reabre a janela de boas-vindas (welcome.py), mesmo com "Não
    # mostrar novamente" marcado.
    welcome_row = layout.row()
    welcome_row.scale_y = 1.3
    welcome_row.operator(welcome.HYBLEND_OT_welcome.bl_idname, text=tr("panel.btn_welcome", lang), icon="INFO")
    # Crédito ao Hytale/Hypixel Studios com aviso de não afiliação.
    hypixel_col = layout.box().column(align=True)
    hytale_row = hypixel_col.row(align=True)
    hytale_row.label(text=tr("panel.info_credits_hytale_label", lang), icon="WORLD")
    hytale_sub = hytale_row.row(align=True)
    hytale_sub.alignment = "RIGHT"
    _url_button(hytale_sub, HYBLEND_HYTALE_URL, "Hytale", "hytale", None)
    _draw_wrapped_label(hypixel_col, context, tr("panel.info_credits_hytale_disclaimer", lang))

    layout.separator()

    links_box = layout.box()
    links_box.label(text=tr("panel.info_links_label", lang), icon="URL")
    links_row = links_box.row(align=True)
    links_row.scale_y = 1.2
    _url_button(links_row, HYBLEND_NEXUSMODS_URL, "Nexus Mods", "nexus_mods", "WORLD")
    _url_button(links_row, HYBLEND_GITHUB_URL, "GitHub", "github", "COMMUNITY")

    layout.separator()

    header_col = layout.box().column(align=True)
    header_col.label(text=tr("panel.info_credits_label", lang), icon="USER")
    header_col.label(text=tr("panel.info_credits_created_by_label", lang))
    header_col.label(text=HYBLEND_STUDIO_NAME)
    credits_row = header_col.row(align=True)
    credits_row.label(text=HYBLEND_AUTHOR_NAME)
    icons_sub = credits_row.row(align=True)
    icons_sub.alignment = "RIGHT"
    for url, brand, fallback, _gpu_icon in HYBLEND_SOCIAL_LINKS:
        _url_button(icons_sub, url, "", brand, fallback)


def _url_button(layout, url, text, brand, fallback):
    """Botão wm.url_open com o logo (assets/icons/<brand>.png) ou o ícone
    embutido `fallback` (None = sem ícone); URL vazia = desabilitado."""
    cell = layout.row(align=True)
    cell.enabled = bool(url)
    icon_value = _panel_icon_value(brand)
    icon = {"icon_value": icon_value} if icon_value else ({"icon": fallback} if fallback else {})
    cell.operator("wm.url_open", text=text, **icon).url = url or ""

# Onde baixar os addons Hyblend (botão da espera do núcleo).
ADDONS_URL = HYBLEND_GITHUB_URL


def draw_waiting(layout, context, lang):
    """Núcleo sem addon com tela (o Anim): o Toolkit é só a base; as ferramentas ficam nos addons Hyblend."""
    box = layout.box()
    box.label(text=tr("panel.core_waiting_title", lang), icon="INFO")
    _draw_wrapped_label(box.column(align=True), context, tr("panel.core_waiting_body", lang))
    row = box.row()
    row.scale_y = 1.2
    _url_button(row, ADDONS_URL, tr("panel.core_waiting_button", lang), "github", "COMMUNITY")


class HYBLEND_PT_toolkit(Panel):
    """Painel do núcleo na aba "Hyblend" quando nenhum addon com tela está ligado: aviso + Info."""

    bl_label = "Hyblend Toolkit"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Hyblend"
    bl_order = 10        # abaixo do seletor dos addons Hyblend (hyblend_hub, bl_order 0)

    @classmethod
    def poll(cls, context):
        from ..api import current_app
        return (current_app() is None and game_found() and not gpu_ui.is_enabled(context)
                and hyblend_hub.is_active(HUB_ID, context))

    def draw(self, context):
        layout = self.layout
        lang = get_language(context)
        row = layout.row(align=True)
        row.scale_y = 0.9
        row.label(text="")
        row.prop_enum(context.window_manager, "hytale_prefs_button", "OPEN", text="", icon="PREFERENCES")
        draw_waiting(layout, context, lang)
        layout.separator()
        draw_info(layout, context, lang)


# --- Seletor dos addons Hyblend (hyblend_hub.py) ---

def _hub_register():
    """Seletor nativo, inscrição e pasta do Hytale no boot: o desenho padrão
    dos addons Hyblend (hyblend_hub.register_addon). O núcleo é dono da pasta do Hytale, por isso é ELE que se
    inscreve (como "toolkit"); o Anim só troca o rótulo do botão (api.register_app)."""
    hyblend_hub.register_addon(HUB_ID, "Toolkit", ADDON_PACKAGE, "hyblend", game_found=game_found, gpu_ui=gpu_ui,
                               reason="Hytale folder not found: set it in the Hyblend Toolkit Preferences")


def _hub_unregister():
    hyblend_hub.unregister_addon(HUB_ID, ADDON_PACKAGE)


def set_hub_label(label):
    """Rótulo do botão do núcleo no seletor ("Toolkit" sozinho, "Anim" com o Anim). IMPORTANTE: o protocolo 1
    do hub não tem campo pra isso; trocar o rótulo da inscrição é compatível com as cópias antigas (CC/Prefabs)."""
    for provider in hyblend_hub.present():
        if provider.ident == HUB_ID and getattr(provider, "owner", None) == ADDON_PACKAGE:
            provider.label = label
    hyblend_hub.redraw_view3d()


def register():
    _load_panel_icons()
    WindowManager.hytale_prefs_button = EnumProperty(items=_prefs_button_items, get=_prefs_button_get,
                                                     set=_prefs_button_set)
    _hub_register()     # seletor (painel bl_order 0) antes dos painéis da aba
    bpy.utils.register_class(HYBLEND_PT_toolkit)
    gpu_ui.register()   # não faz nada abaixo do Blender 5.0
    # Abertura do Blender x usuário instalando/habilitando: decidido UMA vez
    # aqui (olha a pilha do register) e passado pra Home e pro Welcome.
    startup = welcome.registered_by_session_load()
    home.register(startup)      # depois do gpu_ui; não faz nada abaixo do 5.0
    welcome.register(startup)   # depois dos dois: decide Home x Welcome x splash


def unregister():
    welcome.unregister()
    home.unregister()
    gpu_ui.unregister()
    bpy.utils.unregister_class(HYBLEND_PT_toolkit)
    _hub_unregister()
    del WindowManager.hytale_prefs_button
    if bpy.app.timers.is_registered(_open_prefs_timer):     # clique na engrenagem ainda pendente
        bpy.app.timers.unregister(_open_prefs_timer)
    _prefs_button_window[0] = None
    _unload_panel_icons()
