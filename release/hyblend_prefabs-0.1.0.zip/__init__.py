"""Hyblend Prefabs -- importa Prefabs completos do Hytale (estruturas de
blocos + props soltos) pra dentro do Blender, resolvendo cada bloco contra
a pasta/zip de Assets do jogo configurada nas Preferences.

Antes chamado "Hyblend Builder" (ate a dev-0.1.30). Ver DEVELOPER_NOTES.md pra
visao geral do pipeline e README.md pro changelog completo."""

from . import builder, common, interface, preferences  # noqa: F401
from .builder import debug_export, prefab_importer, prefab_ops

# Ordem importa: interface/ importa classes de todos os outros modulos, e
# precisa ser registrada por ultimo (e desregistrada primeiro).
_MODULES = (preferences, prefab_importer, prefab_ops, debug_export, interface)


def register():
    for module in _MODULES:
        module.register()


def unregister():
    for module in reversed(_MODULES):
        module.unregister()
