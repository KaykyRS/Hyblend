"""Aba Import -- mesmos botões de HYTALE_PT_main._draw_import."""

from ..framework.core import Row, Style
from ..widgets import Hint, card
from ....anim import IMPORT_OT_hytale_blockyanim
from ....importer import IMPORT_OT_hytale_bbmodel, IMPORT_OT_hytale_bedrock_model, IMPORT_OT_hytale_blockymodel
from .common import active_armature


def build(ui):
    t = ui.t
    active = active_armature(ui.context)

    # "New Model": .blockymodel (NEW_ARMATURE) e .bbmodel, + "More Options"
    # (importadores de formatos de fora do Hytale -- hoje só Bedrock).
    more_button, more_list = ui.menu(
        "import.more", t("panel.btn_more_import_options"), "chevron_down",
        [ui.op_item(t("panel.btn_import_bedrock"), "cube", IMPORT_OT_hytale_bedrock_model)],
        variant="ghost", height=24)
    new_model = card(
        Row(
            ui.op("import.new_blocky", IMPORT_OT_hytale_blockymodel, t("panel.btn_new_blockymodel"),
                  props={"import_mode": "NEW_ARMATURE"}, variant="primary", height=36, flex=1),
            ui.op("import.new_bb", IMPORT_OT_hytale_bbmodel, t("panel.btn_new_bbmodel"), height=36, flex=1),
            style=Style(gap=6),
        ),
        more_button,
        more_list,
        title=t("panel.new_model_header"), icon="cube",
    )

    # Attach: travado sem Armature ativa; pré-preenche o alvo.
    attach_props = {"import_mode": "ATTACH_EXISTING"}
    if active is not None:
        attach_props["target_armature_name"] = active.name
    attach = card(
        ui.op("import.attach", IMPORT_OT_hytale_blockymodel, t("panel.btn_import_attach"), icon="import",
              props=attach_props, enabled=active is not None, height=36),
        Hint("%s %s" % (t("panel.hint_import_attach_target"), active.name), icon="rig")
        if active is not None else Hint(t("panel.hint_import_attach_none"), icon="info"),
    )

    anim = card(
        Hint(t("panel.warn_anim_experimental"), icon="experimental", tone="warning"),
        ui.op("import.anim", IMPORT_OT_hytale_blockyanim, t("panel.btn_import_anim"), icon="anim", height=36),
        Hint("%s %s" % (t("panel.hint_import_anim_target"), active.name), icon="rig")
        if active is not None else Hint(t("panel.hint_import_anim_none"), icon="info"),
    )
    return [new_model, attach, anim]
