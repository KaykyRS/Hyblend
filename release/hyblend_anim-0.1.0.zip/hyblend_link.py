"""hyblend_link.py -- ligação entre o Hyblend Toolkit (núcleo) e os addons que dependem dele (Anim, ...).

ESTE ARQUIVO É IDÊNTICO NO NÚCLEO E EM CADA DEPENDENTE. Mudou num -> copiar pros outros.

IMPORTANTE (por que existe): o manifest do Blender não declara dependência entre extensões e a ordem de
carga não é garantida. O estado mora em sys.modules (criado por quem carrega primeiro), então:
  * dependente antes do núcleo: fica PENDENTE e é ativado quando o núcleo registra;
  * núcleo desligado/atualizado: os dependentes são desativados ANTES (e reativados quando ele volta);
  * núcleo ausente ou antigo (Toolkit monolítico <= 0.9.5): o dependente não registra nada além do aviso.
Campo novo no estado compartilhado = sempre lido com getattr(..., padrão) (a cópia mais velha pode ter criado).
"""

import sys
import traceback
import types

PROTOCOL = 1
_SHARED_NAME = "_hyblend_link_shared"
CORE_ID = "hyblend_toolkit"          # id do manifest do núcleo
CORE_API_ATTR = "HYBLEND_CORE_API"   # versão da API, no módulo raiz do núcleo

# status() de um dependente
OK, MISSING, DISABLED, OUTDATED, ERROR = "OK", "MISSING", "DISABLED", "OUTDATED", "ERROR"


def _shared():
    shared = sys.modules.get(_SHARED_NAME)
    if shared is None:
        shared = types.ModuleType(_SHARED_NAME)
        shared.protocol = PROTOCOL
        shared.core = None           # SimpleNamespace(package, api) com o núcleo registrado
        shared.dependents = {}       # pacote -> SimpleNamespace (ver attach)
        sys.modules[_SHARED_NAME] = shared
    return shared


def _live(dep):
    """Dependente ainda carregado? (register() que falhou some de sys.modules sem chamar unregister)."""
    return dep.package in sys.modules


def _activate(dep):
    if dep.active:
        return
    dep.error = None
    try:
        dep.activate()
        dep.active = True
    except Exception as exc:
        traceback.print_exc()
        dep.error = "%s: %s" % (type(exc).__name__, exc)
        try:                          # desfaz o registro parcial
            dep.deactivate()
        except Exception:
            traceback.print_exc()


def _deactivate(dep):
    if not dep.active:
        return
    dep.active = False
    try:
        dep.deactivate()
    except Exception:
        traceback.print_exc()


# --- Lado do núcleo ---------------------------------------------------------

def publish_core(package, api_version):
    """Fim do register() do núcleo: fica disponível e ativa os dependentes pendentes."""
    shared = _shared()
    shared.core = types.SimpleNamespace(package=package, api=api_version)
    for dep in list(shared.dependents.values()):
        if _live(dep) and dep.requires <= api_version:
            _activate(dep)


def withdraw_core(package):
    """Começo do unregister() do núcleo: desativa os dependentes (na ordem inversa) antes de sair."""
    shared = _shared()
    core = shared.core
    if core is None or core.package != package:
        return
    for dep in reversed(list(shared.dependents.values())):
        _deactivate(dep)
    shared.core = None


# --- Lado do dependente -----------------------------------------------------

def attach(package, *, requires, activate, deactivate):
    """register() do dependente: activate() roda já (núcleo pronto) ou quando o núcleo registrar."""
    shared = _shared()
    old = shared.dependents.get(package)
    if old is not None:
        _deactivate(old)
    dep = types.SimpleNamespace(package=package, requires=requires, activate=activate, deactivate=deactivate,
                                active=False, error=None)
    shared.dependents[package] = dep
    core = shared.core
    if core is not None and requires <= core.api:
        _activate(dep)


def detach(package):
    """unregister() do dependente."""
    dep = _shared().dependents.pop(package, None)
    if dep is not None:
        _deactivate(dep)


def is_active(package):
    dep = _shared().dependents.get(package)
    return bool(dep is not None and dep.active)


def core():
    """Módulo raiz do núcleo registrado, ou None."""
    shared = _shared()
    return sys.modules.get(shared.core.package) if shared.core is not None else None


def _core_installed():
    """Pacote do núcleo nas Preferences (ligado), ou None. Aceita extensão (bl_ext.<repo>.<id>) e instalação legada."""
    try:
        import bpy
        names = bpy.context.preferences.addons.keys()
    except Exception:
        return None
    for name in names:
        if name == CORE_ID or name.endswith("." + CORE_ID):
            return name
    return None


def status(package):
    """OK, MISSING (não instalado/ligado), DISABLED (ligado, ainda não registrou), OUTDATED (antigo/API menor),
    ERROR (activate falhou)."""
    shared = _shared()
    dep = shared.dependents.get(package)
    if dep is not None and dep.active:
        return OK
    if dep is not None and dep.error:
        return ERROR
    core = shared.core
    if core is not None:
        if dep is not None and dep.requires > core.api:
            return OUTDATED
        return DISABLED if dep is not None else OK     # dependente que ainda não ativou: esperando
    name = _core_installed()
    if name is None:
        return MISSING
    module = sys.modules.get(name)
    if module is not None and getattr(module, CORE_API_ATTR, None) is None:
        return OUTDATED               # Toolkit monolítico antigo: os dois registrariam as mesmas classes
    return DISABLED


def error(package):
    dep = _shared().dependents.get(package)
    return dep.error if dep is not None else None
