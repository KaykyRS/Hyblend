"""character_assembly.py -- v3.

Anexa um .blockymodel de roupa/acessorio num Armature JA EXISTENTE do
Player, reproduzindo o mecanismo REAL do "Attach to Existing Armature" do
Hyblend (importer/__init__.py, build_bones_recursive + add_reference_visuals)
-- copiado/adaptado de proposito.

POR QUE ESTA E A TERCEIRA VERSAO (ver conversa de design):

  v1 (bone-parenting): funcionava pra posicao simples, mas usava
  parent_type='BONE' -- mecanismo antigo do Hyblend, ja abandonado la
  pra geometria de personagem (so sobrou pra Camera/Texture Picker).

  v2 (vertex group + Armature modifier, SEM bone novo por peca): corrigiu
  o mecanismo de anexo, mas assumia que toda peca de geometria e filha
  DIRETA de um bone-pivo ja existente -- verdade pra Pants/Overtops/
  Gloves (testado), FALSA pra itens com caixa-dentro-de-caixa (ex:
  chapeus com aba+copa, cabelo com varias mechas -- confirmado: "itens de
  cabeca quebrando" no teste real). Quando uma peca de geometria tem
  OUTRA peca de geometria como filha, a v2 ignorava a posicao/rotacao da
  peca-pai inteira (so herdava o shape.offset dela, nao a transformacao
  completa), porque nunca materializava um bone pra ela.

  v3 (aqui): cria um bone de verdade pra CADA no da arvore (nao so pros
  nos-pivo), reaproveitando bones ja existentes quando o nome bate E o
  no e "anchor candidate" (isPiece==true OU e a raiz do arquivo) --
  exatamente a logica de build_bones_recursive do Hyblend, incluindo o
  tratamento de nomes duplicados (unique_bone_name +
  BONE_ORIGINAL_NAME_PROP, pedido explicito: o Blockbench permite duas
  pastas-irmas com o MESMO nome, e o Blender nao aceita dois bones
  identicos no mesmo Armature).

DIFERENCAS CONSCIENTES vs o Hyblend original (documentadas, nao
esquecidas -- primeiro lugar a revisar se aparecer bug relacionado):

  - So o caminho ATTACH_EXISTING existe aqui -- este addon nunca cria
    Armature novo, sempre trabalha em cima de um Player ja importado
    (pelo Hyblend) e ativo na cena.
  - Diferente do Hyblend, que so cria geometria visual se
    `generate_reference_boxes` estiver ligado (opcao do operador de
    import), aqui SEMPRE geramos a geometria -- e o unico motivo deste
    addon existir.
  - O bone "wrapper" (`"{arquivo}:{no}"`) que o Hyblend cria ao
    reaproveitar um bone JA E replicado aqui (ver _build_bones_recursive)
    -- pedido explicito, pra manter o Armature 100% legivel/reimportavel
    pelo proprio Hyblend depois, e pra reimportar/trocar a mesma peca
    nao colidir bone-a-bone com uma peca anterior.

Requer bpy/bmesh/mathutils -- so roda dentro do Blender.
"""

from __future__ import annotations

import json
from pathlib import Path

import bpy
from mathutils import Matrix, Quaternion, Vector

from .box_mesh import build_shape_mesh
from .model_tree import UNIT_SCALE_DEFAULT
from ..compat import get_id_prop

BONE_DISPLAY_LENGTH_GAME_UNITS = 4.0  # puramente estetico, escalado igual ao resto (mesmo valor do Hyblend)

# Custom properties que o Hyblend grava nos bones que ele cria -- LEMOS as
# mesmas aqui (nunca inventamos nomes novos) pra ficar 100% compativel
# com Armature que o proprio Hyblend tambem mexe. Ver common.py dele.
_BONE_SHAPE_OFFSET_PROP = "hytale_shape_offset"
_BONE_ORIGINAL_NAME_PROP = "hytale_original_name"
_ATTACHMENTS_COLLECTION_PROP = "hytale_meshes_attachments_collection"


class AssemblyError(Exception):
    """Levantado quando a peca nao pode ser anexada com seguranca (ex:
    arquivo .blockymodel vazio/invalido)."""


def _vec3(d: dict, default: float = 0.0) -> Vector:
    return Vector((d.get("x", default), d.get("y", default), d.get("z", default)))


def _quat(d: dict) -> Quaternion:
    # Ordem do arquivo e x,y,z,w -- Quaternion do Blender e w,x,y,z.
    return Quaternion((d.get("w", 1.0), d.get("x", 0.0), d.get("y", 0.0), d.get("z", 0.0)))


def unique_bone_name(base_name: str, edit_bones) -> str:
    """Copiado de importer/__init__.py do Hyblend -- gera um nome unico
    pra colisao de nomes DENTRO do mesmo arquivo (Blockbench permite duas
    pastas com o mesmo nome; o Blender nao aceita dois bones com nome
    identico no mesmo Armature). O nome ORIGINAL fica preservado na
    custom property `hytale_original_name` (ver _build_bones_recursive)
    -- e ela, nao este sufixo ".dupNN", que deve ser usada como "nome de
    verdade" do bone se algum dia formos exportar/reexportar."""
    if base_name not in edit_bones:
        return base_name
    n = 1
    while True:
        candidate = f"{base_name}.dup{n:02d}"
        if candidate not in edit_bones:
            return candidate
        n += 1


def _shape_offset_of(node: dict, unit_scale: float) -> Vector:
    return _vec3(node.get("shape", {}).get("offset", {})) * unit_scale


def _node_local_matrix(node: dict, parent_shape_offset: Vector, unit_scale: float) -> Matrix:
    """Matriz local (relativa ao pai) deste no. Ver nota grande no
    importer do Hyblend: translacao local = position(no) +
    shape.offset(pai), rotacao aplicada por cima via composicao de
    matriz."""
    pos = _vec3(node.get("position", {})) * unit_scale
    pos = pos + parent_shape_offset
    rot = _quat(node.get("orientation", {"w": 1.0}))
    return Matrix.Translation(pos) @ rot.to_matrix().to_4x4()


def _is_piece(node: dict) -> bool:
    return bool(node.get("shape", {}).get("settings", {}).get("isPiece"))


def _build_bones_recursive(
    armature_data,
    node: dict,
    parent_bone_name,
    parent_world_matrix: Matrix,
    parent_shape_offset: Vector,
    world_matrices: dict,
    node_id_to_bone_name: dict,
    node_own_offsets: dict,
    reusable_bone_names: set,
    unit_scale: float,
    attachment_stem: str,
    warnings: list,
    created_bone_names: list,
    suppress_root_warning: bool = False,
) -> None:
    """Adaptado de build_bones_recursive do Hyblend -- so o caminho
    ATTACH_EXISTING. Inclui o bone "wrapper" (ver mais abaixo) que o
    Hyblend cria quando reaproveita um bone existente -- copiado de
    proposito, pra este Armature continuar 100% legivel/reimportavel
    pelo proprio Hyblend depois.

    `suppress_root_warning`: usado por create_player() (ver __init__.py)
    -- quando o Armature de destino esta VAZIO de proposito (criando o
    Player do zero, nao anexando roupa), e ESPERADO que nenhum bone da
    raiz seja reaproveitado (nao ha nada pra reaproveitar ainda). O
    Hyblend evita esse aviso checando `import_mode == "ATTACH_EXISTING"`
    antes de avisar (ver importer/__init__.py) -- aqui replicamos o mesmo
    efeito com uma flag explicita, ja que este addon nao tem o conceito
    de "import_mode" (sempre foi so ATTACH_EXISTING ate agora).

    `created_bone_names`: preenchido (na ORDEM de criacao -- pai antes de
    filho) com todo bone NOVO criado por esta chamada (wrapper + bones de
    geometria, NUNCA bones reaproveitados). E o que permite desfazer uma
    aplicacao anterior por completo antes de aplicar outra no mesmo slot
    -- ver remove_equipped_slot()."""
    name = node["name"]
    edit_bones = armature_data.edit_bones
    is_anchor_candidate = _is_piece(node) or parent_bone_name is None

    reuse = is_anchor_candidate and name in reusable_bone_names and name in edit_bones

    # Fallback tolerante: nome exato nao bateu, tenta achar um unico
    # candidato ignorando maiuscula/minuscula e espacos nas pontas (mesma
    # logica do Hyblend -- causa comum de "bateu de um lado, nao bateu do
    # outro").
    if not reuse and is_anchor_candidate:
        needle = name.strip().lower()
        candidates = [n for n in reusable_bone_names if n.strip().lower() == needle and n in edit_bones]
        if len(candidates) == 1:
            name = candidates[0]
            reuse = True

    if not reuse and is_anchor_candidate and parent_bone_name is None and not suppress_root_warning:
        warnings.append(
            f"'{name}' is the root of the file but no existing bone with that name was found to "
            f"attach to -- it was created as a new bone, at the file's raw position (likely close to "
            f"world origin). Check the exact name of that bone on your Armature."
        )

    if reuse:
        bone = edit_bones[name]
        world = bone.matrix.copy()

        # O Hyblend, ao anexar num bone/pasta que JA EXISTE, nao substitui
        # nem funde direto nele -- cria um bone "wrapper" extra DENTRO do
        # bone reaproveitado, nomeado "{arquivo_sem_extensao}:{nome_do_no}"
        # (ex: "Pants_Large:Belly", vindo de "Pants_Large.blockymodel"), e
        # e dentro desse wrapper que os FILHOS deste no (nao o no em si)
        # passam a ser parentados. Copiado de proposito -- garante que
        # reimportar/trocar a mesma peca depois nao colide bone-a-bone
        # com uma peca anterior, e mantem o Armature legivel pelo proprio
        # Hyblend do mesmo jeito que ele proprio produziria.
        wrapper_name = f"{attachment_stem}:{name}"
        wrapper = edit_bones.new(wrapper_name)
        wrapper.head = (0, 0, 0)
        wrapper.tail = (0, BONE_DISPLAY_LENGTH_GAME_UNITS * unit_scale, 0)
        wrapper.matrix = world
        wrapper.parent = bone
        wrapper.use_connect = False
        children_parent_name = wrapper.name
        created_bone_names.append(wrapper.name)
    else:
        local = _node_local_matrix(node, parent_shape_offset, unit_scale)
        world = parent_world_matrix @ local

        bone_display_length = BONE_DISPLAY_LENGTH_GAME_UNITS * unit_scale
        final_name = unique_bone_name(name, edit_bones)
        if final_name != name:
            warnings.append(
                f"Duplicate bone name '{name}' within this file -- renamed to '{final_name}' "
                f"in Blender (original name preserved in the custom property '{_BONE_ORIGINAL_NAME_PROP}')."
            )

        bone = edit_bones.new(final_name)
        bone.head = (0, 0, 0)
        bone.tail = (0, bone_display_length, 0)
        bone.matrix = world
        if final_name != name:
            bone[_BONE_ORIGINAL_NAME_PROP] = name

        if parent_bone_name is not None and parent_bone_name in edit_bones:
            bone.parent = edit_bones[parent_bone_name]
            bone.use_connect = False

        children_parent_name = bone.name
        created_bone_names.append(bone.name)

    world_matrices[id(node)] = world.copy()
    node_id_to_bone_name[id(node)] = bone.name

    # Mesma logica do Hyblend: se o bone foi REAPROVEITADO, o
    # shape.offset que ESTE arquivo descreve pra esse no pode nao bater
    # com o valor "de origem" (o Armature do Player pode ter sido
    # importado com um shape.offset diferente pra esse mesmo bone) --
    # usamos o valor GRAVADO no bone (por quem o criou de verdade,
    # normalmente o proprio Hyblend) em vez do arquivo de roupa. Ver
    # conversa de design ("a causa" do primeiro bug de posicao).
    if reuse:
        stored = get_id_prop(bone, _BONE_SHAPE_OFFSET_PROP)
        this_node_shape_offset = Vector(stored) if stored is not None else _shape_offset_of(node, unit_scale)
    else:
        this_node_shape_offset = _shape_offset_of(node, unit_scale)
        bone[_BONE_SHAPE_OFFSET_PROP] = tuple(this_node_shape_offset)

    # Guarda o valor RESOLVIDO (nao o cru do arquivo) pra este no --
    # usado depois em assemble_item pra posicionar a mesh visual desta
    # MESMA peca (nao dos filhos). Ate agora, na pratica, um no
    # reaproveitado nunca e tambem geometria visivel (isPiece so aparece
    # em nos tipo "none" nos dados reais) -- mas guardar isso aqui em vez
    # de reler o arquivo cru evita uma inconsistencia latente caso isso
    # mude (ex: uma categoria futura com root node que e pivo E geometria
    # ao mesmo tempo).
    node_own_offsets[id(node)] = this_node_shape_offset

    for child in node.get("children", []):
        _build_bones_recursive(
            armature_data, child, children_parent_name, world, this_node_shape_offset,
            world_matrices, node_id_to_bone_name, node_own_offsets, reusable_bone_names, unit_scale, attachment_stem,
            warnings, created_bone_names, suppress_root_warning,
        )


def _reattach_children(edit_bones, reattach_children: dict, warnings: list) -> None:
    """Religa por NOME os bones externos que remove_equipped_slot()
    desligou (ver o docstring dela). So o parent muda: a rest pose fica
    como estava (o corpo e recriado do mesmo esqueleto do Player). Pai
    que nao voltou (corpo novo sem esse bone) = fica solto + aviso."""
    missing = []
    for child_name, parent_name in reattach_children.items():
        child = edit_bones.get(child_name)
        if child is None:
            continue
        # NAO pular filho que ja tem pai: ao apagar um bone, o Blender
        # sobe os filhos pro AVO -- se so parte da cadeia foi removida, o
        # filho fica preso num ancestral errado, nao solto.
        parent = edit_bones.get(parent_name)
        if parent is None:
            missing.append(f"'{child_name}' (was under '{parent_name}')")
            continue
        child.parent = parent
        child.use_connect = False
    if missing:
        warnings.append(
            "Some bones could not be reattached because their parent no longer exists: "
            + ", ".join(missing) + ". Re-apply those items."
        )


def _collect_visual_shape_nodes(node: dict, out: list) -> None:
    shape_type = node.get("shape", {}).get("type")
    if shape_type in ("box", "quad"):
        out.append(node)
    for child in node.get("children", []):
        _collect_visual_shape_nodes(child, out)


def _get_or_create_child_collection(parent_collection, name):
    """Copiado de get_or_create_child_collection do Hyblend."""
    for child in parent_collection.children:
        if child.name == name:
            return child
    new_coll = bpy.data.collections.new(name)
    parent_collection.children.link(new_coll)
    return new_coll


def _resolve_attachments_collection(context, armature_obj):
    """Adaptado de find_attachments_collection do Hyblend -- reaproveita
    a MESMA collection 'Mesh Attachments - <nome>' que ele ja usa.

    Corrigido apos reler o codigo real do Hyblend: mesmo no caso de
    FALLBACK (Armature sem a property ainda -- ex: criada por uma versao
    antiga, ou por este addon antes desta correcao), o Hyblend GRAVA a
    property de volta no Armature (`armature_obj["hytale_meshes_
    attachments_collection"] = ...`) -- eu tinha decidido de proposito
    NAO fazer isso por cautela, mas isso diverge do comportamento real
    deles. Corrigido pra bater 100% -- pedido explicito de fidelidade
    estrutural."""
    stored_name = get_id_prop(armature_obj, _ATTACHMENTS_COLLECTION_PROP)
    if stored_name:
        existing = bpy.data.collections.get(stored_name)
        if existing is not None:
            return existing

    fallback_name = f"Mesh Attachments - {armature_obj.name}"
    parent = armature_obj.users_collection[0] if armature_obj.users_collection else context.scene.collection
    attachments_collection = _get_or_create_child_collection(parent, fallback_name)
    armature_obj[_ATTACHMENTS_COLLECTION_PROP] = attachments_collection.name
    return attachments_collection


def assemble_item(
    context,
    armature_obj: "bpy.types.Object",
    blockymodel_path: Path,
    atlas_w: float,
    atlas_h: float,
    unit_scale: float = UNIT_SCALE_DEFAULT,
    generate_uvs: bool = True,
    collection=None,
    suppress_root_warning: bool = False,
    reattach_children: dict | None = None,
) -> tuple:
    """Le `blockymodel_path`, cria/reaproveita bones no `armature_obj`
    (Edit Mode) e gera a geometria visual (Object Mode) presa via Vertex
    Group + modifier Armature ao bone DE CADA peca (nao mais ao bone-pai
    mais proximo -- ver docstring do modulo).

    `suppress_root_warning`: passa direto pra _build_bones_recursive --
    usar True ao criar um personagem do ZERO (Armature vazio de
    proposito), onde "nao achou bone pra reaproveitar" e o esperado, nao
    um aviso relevante.

    `reattach_children`: o dict devolvido por remove_equipped_slot()
    ({filho: pai}) -- bones de OUTROS slots (ou do Create Rig do Toolkit)
    que eram filhos dos bones removidos. Religados por NOME aos bones
    recem-criados, na mesma sessao de Edit Mode. Sem isso, reconstruir o
    corpo soltava rosto/boca/orelhas/cabelo do Head (bug real).

    Devolve (created_objs, created_bone_names, warnings). `created_bone_names`
    e todo bone NOVO criado (nunca reaproveitado) -- guarde isso (ver
    record_equipped_slot) se quiser poder desfazer essa aplicacao depois
    (ex: trocar de item/cor na mesma categoria). `warnings` e uma lista de
    string (avisos nao-fatais, ex: nome duplicado renomeado, bone raiz
    nao encontrado) que quem chamar deve reportar via self.report()."""
    with blockymodel_path.open(encoding="utf-8") as f:
        data = json.load(f)
    root_nodes = data.get("nodes", [])
    if not root_nodes:
        raise AssemblyError(f"'{blockymodel_path.name}' has no nodes at all (empty or invalid .blockymodel).")

    warnings: list = []
    created_bone_names: list = []
    reusable_bone_names = {b.name for b in armature_obj.data.bones}
    attachment_stem = blockymodel_path.stem  # ex: "Pants_Large" -- usado no nome do bone wrapper

    prev_active = context.view_layer.objects.active
    prev_mode = armature_obj.mode
    context.view_layer.objects.active = armature_obj
    armature_obj.select_set(True)

    armature_data = armature_obj.data
    # Mesmo cuidado do Hyblend com X-Axis Mirror: se ligado, o commit de
    # um bone "R-..." antes do "L-..." irmao correspondente ainda nao
    # existir faz o Blender resetar a posicao dele sozinho. Desligamos
    # aqui e restauramos no final.
    original_use_mirror_x = armature_data.use_mirror_x
    if original_use_mirror_x:
        armature_data.use_mirror_x = False

    world_matrices: dict = {}
    node_id_to_bone_name: dict = {}
    node_own_offsets: dict = {}

    bpy.ops.object.mode_set(mode="EDIT")
    try:
        for root_node in root_nodes:
            _build_bones_recursive(
                armature_data, root_node, None, Matrix.Identity(4), Vector((0.0, 0.0, 0.0)),
                world_matrices, node_id_to_bone_name, node_own_offsets, reusable_bone_names, unit_scale, attachment_stem,
                warnings, created_bone_names, suppress_root_warning,
            )
        if reattach_children:
            _reattach_children(armature_data.edit_bones, reattach_children, warnings)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        if original_use_mirror_x:
            armature_data.use_mirror_x = original_use_mirror_x
        if prev_active is not None:
            context.view_layer.objects.active = prev_active
        try:
            bpy.ops.object.mode_set(mode=prev_mode)
        except RuntimeError:
            pass

    if collection is None:
        collection = _resolve_attachments_collection(context, armature_obj)

    shape_nodes: list = []
    for root_node in root_nodes:
        _collect_visual_shape_nodes(root_node, shape_nodes)

    created_objs = []
    for node in shape_nodes:
        bone_name = node_id_to_bone_name[id(node)]
        shape = node["shape"]
        mesh = build_shape_mesh(node["name"], shape, unit_scale, atlas_w, atlas_h, generate_uvs=generate_uvs)

        obj = bpy.data.objects.new(f"{armature_obj.name}_{node['name']}", mesh)
        collection.objects.link(obj)

        own_offset = node_own_offsets[id(node)]
        local_offset = Matrix.Translation(own_offset)
        node_world = world_matrices[id(node)]
        desired_world = armature_obj.matrix_world @ node_world @ local_offset

        obj.parent = armature_obj
        obj.matrix_world = desired_world

        vgroup = obj.vertex_groups.new(name=bone_name)
        vgroup.add(range(len(mesh.vertices)), 1.0, "REPLACE")

        armature_mod = obj.modifiers.new(name="Armature", type="ARMATURE")
        armature_mod.object = armature_obj

        created_objs.append(obj)

    return created_objs, created_bone_names, warnings


# ---------------------------------------------------------------------------
# "Slot equipado" -- rastreia o que foi criado pra cada categoria (ex.
# "Pants", "Gloves") num Armature, pra poder DESFAZER por completo antes
# de aplicar um item novo na mesma categoria. Sem isso, trocar de
# item/cor repetidas vezes so empilha bones/meshes -- cada troca deixaria
# a peca anterior grudada, ao inves de substituir.
#
# Guardado como JSON dentro de uma unica custom property por slot no
# proprio Armature Object (`hyblendcc_slot_<categoria>`) -- sobrevive
# salvar/reabrir o .blend, e nao depende de nenhum estado do addon em
# memoria (troca de sessao do Blender nao perde o rastro).
# ---------------------------------------------------------------------------

_SLOT_PROP_PREFIX = "hyblendcc_slot_"


def _slot_prop_name(slot_key: str) -> str:
    return f"{_SLOT_PROP_PREFIX}{slot_key}"


def record_equipped_slot(
    armature_obj: "bpy.types.Object",
    slot_key: str,
    created_objs: list,
    created_bone_names: list,
    item_id: str = "",
    color: str = "",
    variant: str = "",
    gradient_set: str = "",
    background_color: str = "",
    background_linked: bool = False,
    skin_linked: bool = True,
    atlas_size=None,
) -> None:
    """Grava o que foi criado nesta aplicacao, pra uma remocao futura
    (ver remove_equipped_slot) saber exatamente o que desfazer.

    `item_id`/`color`/`variant`/`gradient_set`: guardados so pra UI
    conseguir se RESINCRONIZAR depois (ex: trocar de Armature ativo e
    voltar, reabrir o .blend) -- sem isso, o picker nao tem como saber o
    que ja esta equipado de verdade, so o que foi selecionado nesta
    sessao do Blender. `variant` e o key de uma ItemVariant (ver
    manifest_parser.py), vazio pra maioria dos itens. `gradient_set` e o
    GradientSet ESCOLHIDO PELO USUARIO pra esse item (pode ser diferente
    do que o manifest declara como padrao -- pedido explicito, o usuario
    pode trocar Skin por Hair/etc manualmente), vazio pra itens em modo
    discreto (sem GradientSet nenhum envolvido).

    `background_color`/`background_linked`: feature pedida pelo usuario
    -- alguns itens tem um no "*Background*" separado na malha (ex.
    Eye-Background) que pode ter uma cor PROPRIA, independente da cor
    principal do item, controlada por um botao de "link" na UI (ver
    picker.py -- so importa quando o item de fato tem um no assim,
    senao fica so gravado sem uso nenhum).

    `skin_linked`: feature pedida pelo usuario -- BodyCharacteristics/
    Faces/Mouths/Ears cada um mantem a PROPRIA paleta, mas pode estar
    "linkado" (default True, pra bater com o comportamento anterior a
    esta feature -- eram sempre linkados, sem opcao de desligar) com as
    outras categorias do grupo tambem linkadas no momento -- escolher
    uma cor numa propaga pras outras linkadas (ver
    _find_linked_skin_color/_slot_on_color_update em picker.py). So
    importa pras 4 categorias do grupo, gravado sem uso nenhum pras
    demais.

    `atlas_size`: (w, h) usado nas UVs; registro sem ele (antigo) nunca
    usa o atalho de so trocar o material (recolor_equipped_slot)."""
    payload = {
        "objects": [o.name for o in created_objs],
        "bones": list(created_bone_names),
        "item_id": item_id,
        "color": color,
        "variant": variant,
        "gradient_set": gradient_set,
        "background_color": background_color,
        "background_linked": background_linked,
        "skin_linked": skin_linked,
    }
    if atlas_size is not None:
        # Tamanho do atlas usado nas UVs -- recolor_equipped_slot so troca
        # o material no lugar se o atlas da cor nova for o MESMO.
        payload["atlas"] = [float(atlas_size[0]), float(atlas_size[1])]
    armature_obj[_slot_prop_name(slot_key)] = json.dumps(payload)


def get_equipped_item(armature_obj: "bpy.types.Object", slot_key: str):
    """Le de volta (item_id, color, variant, gradient_set,
    background_color, background_linked, skin_linked) do que esta
    gravado nesse slot, ou None se nada estiver equipado ali. Usado
    pela UI (Panel) pra mostrar o dropdown ja no valor certo, sem
    depender de estado em memoria que se perde ao trocar de Armature
    ativo ou reabrir o arquivo. `background_color`/`background_linked`
    vem com default seguro (""/False) pra dado gravado ANTES dessa
    feature existir. `skin_linked` default True -- ANTES desta feature,
    BodyCharacteristics/Faces/Ears eram SEMPRE linkados (sem opcao de
    desligar), entao dado antigo deve continuar se comportando como
    linkado."""
    raw = get_id_prop(armature_obj, _slot_prop_name(slot_key))
    if not raw:
        return None
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None
    item_id = payload.get("item_id", "")
    color = payload.get("color", "")
    variant = payload.get("variant", "")
    gradient_set = payload.get("gradient_set", "")
    background_color = payload.get("background_color", "")
    background_linked = bool(payload.get("background_linked", False))
    skin_linked = bool(payload.get("skin_linked", True))
    if not item_id:
        return None
    return item_id, color, variant, gradient_set, background_color, background_linked, skin_linked



def remove_equipped_slot(context, armature_obj: "bpy.types.Object", slot_key: str) -> dict:
    """Desfaz por completo a ultima aplicacao gravada nesse slot (se
    existir) -- remove os Objects (mesh + vertex group + modifier, tudo
    junto) e os bones que foram CRIADOS especificamente pra ela (nunca
    bones reaproveitados do Player, ver _build_bones_recursive). Chamar
    ANTES de aplicar um item novo na mesma categoria.

    Devolve {filho: pai} dos bones de FORA deste slot (wrappers de outros
    itens, bones do Create Rig do Toolkit) que eram filhos diretos de um
    bone removido. Apagar um bone faz o Blender subir os filhos pro avo
    -- removendo o corpo inteiro, rosto/boca/orelhas/cabelo ficavam SEM
    PAI (bug real). Quem vai recriar o slot passa isso pra
    assemble_item(reattach_children=...); quem so remove pode ignorar."""
    prop_name = _slot_prop_name(slot_key)
    raw = armature_obj.get(prop_name)
    if not raw:
        return {}

    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        del armature_obj[prop_name]
        return {}

    for obj_name in payload.get("objects", []):
        obj = bpy.data.objects.get(obj_name)
        if obj is not None:
            mesh_data = obj.data
            # Vazamento real corrigido: o material criado pra este item
            # (ver _resolve_item_material -- um material NOVO, com arvore
            # de nos propria, por item+cor) nunca era limpo aqui, so a
            # malha/objeto. Capturamos os materiais ANTES de remover a
            # malha, e limpamos os que ficaram sem nenhum usuario depois.
            materials = list(mesh_data.materials) if mesh_data is not None else []
            bpy.data.objects.remove(obj, do_unlink=True)
            if mesh_data is not None and mesh_data.users == 0:
                bpy.data.meshes.remove(mesh_data)
            for mat in materials:
                if mat is not None and mat.users == 0:
                    bpy.data.materials.remove(mat)

    # Lido em Object Mode (armature.bones), antes de entrar no Edit Mode.
    bone_names = [n for n in payload.get("bones", []) if n in armature_obj.data.bones]
    removed = set(bone_names)
    external_children: dict = {}
    for bone_name in bone_names:
        for child in armature_obj.data.bones[bone_name].children:
            if child.name not in removed:
                external_children[child.name] = bone_name

    if bone_names:
        prev_active = context.view_layer.objects.active
        prev_mode = armature_obj.mode
        context.view_layer.objects.active = armature_obj
        armature_obj.select_set(True)

        bpy.ops.object.mode_set(mode="EDIT")
        try:
            edit_bones = armature_obj.data.edit_bones
            # Remove na ordem REVERSA de criacao (filho antes de pai) --
            # created_bone_names foi preenchido pai-antes-de-filho durante
            # a criacao, entao invertido garante que nenhum bone seja
            # removido enquanto ainda tem filho vivo apontando pra ele.
            for bone_name in reversed(bone_names):
                bone = edit_bones.get(bone_name)
                if bone is not None:
                    edit_bones.remove(bone)
        finally:
            bpy.ops.object.mode_set(mode="OBJECT")
            if prev_active is not None:
                context.view_layer.objects.active = prev_active
            try:
                bpy.ops.object.mode_set(mode=prev_mode)
            except RuntimeError:
                pass

    del armature_obj[prop_name]
    return external_children


def recolor_equipped_slot(armature_obj: "bpy.types.Object", slot_key: str, atlas_size, material_for) -> bool:
    """Troca SO o material dos objetos ja equipados nesse slot, sem
    recriar bone nenhum -- usado quando o item e a variante nao mudaram
    (so cor/GradientSet/fundo; ex. o link de pele propagando pro corpo).
    Recriar os bones do corpo so pra trocar a cor soltava os outros itens
    e apagava constraints que o Create Rig do Toolkit pos nesses bones.

    `material_for(obj)` devolve o material daquele objeto (ou None).
    Devolve False (sem mexer em nada) quando nao da pra garantir o mesmo
    resultado de uma reaplicacao completa: registro antigo sem `atlas`,
    atlas diferente (a UV depende dele), ou algum objeto sumiu -- quem
    chama faz a reconstrucao normal nesse caso."""
    raw = get_id_prop(armature_obj, _slot_prop_name(slot_key))
    if not raw:
        return False
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return False
    stored_atlas = payload.get("atlas")
    if not stored_atlas or [float(v) for v in stored_atlas] != [float(v) for v in atlas_size]:
        return False
    objs = [bpy.data.objects.get(n) for n in payload.get("objects", [])]
    if not objs or any(o is None or o.type != "MESH" for o in objs):
        return False

    # Resolve TUDO antes de mexer: se material_for levantar erro (textura
    # faltando), nenhum objeto fica sem material pela metade.
    new_materials = [material_for(obj) for obj in objs]

    old_materials = set()
    for obj, mat in zip(objs, new_materials):
        old_materials.update(m for m in obj.data.materials if m is not None)
        obj.data.materials.clear()
        if mat is not None:
            obj.data.materials.append(mat)
    # Mesma limpeza do remove_equipped_slot (material sem usuario = vazamento).
    for mat in old_materials:
        if mat.users == 0:
            bpy.data.materials.remove(mat)
    return True


def equipped_slot_record(armature_obj: "bpy.types.Object", slot_key: str):
    """(objects, bones) gravados nesse slot -- pra regravar o registro
    depois de recolor_equipped_slot sem perder o que desfazer."""
    raw = get_id_prop(armature_obj, _slot_prop_name(slot_key))
    try:
        payload = json.loads(raw) if raw else {}
    except (json.JSONDecodeError, TypeError):
        payload = {}
    return payload.get("objects", []), payload.get("bones", [])
