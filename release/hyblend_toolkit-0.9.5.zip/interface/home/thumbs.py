"""Miniaturas em alta resolução dos arquivos recentes.

A miniatura que o Blender grava DENTRO do .blend tem no máximo 128x128 (limite
do próprio formato) -- ampliada pro card da Home fica borrada. Então, a cada
vez que um arquivo é salvo, a Home desenha a maior 3D Viewport numa textura de
640 px de largura (GPUOffScreen.draw_view3d, a mesma vista que está na tela) e
guarda um PNG no cache da extensão:

    <dados da extensão>/thumbs/<sha1 do caminho>.png

Os recentes usam esse PNG quando ele é tão novo quanto o .blend; senão, a
miniatura de 128 px de dentro do arquivo (data.py).

Captura num TIMER logo depois do save (fora do handler do save: falha aqui
nunca atrapalha o salvamento). PNG escrito à mão (zlib), sem criar imagem em
bpy.data -- o arquivo acabou de ser salvo e não pode ficar "modificado".
"""

import hashlib
import os
import struct
import zlib

import bpy
from bpy.app.handlers import persistent

from ...common import ADDON_PACKAGE

WIDTH = 640
MAX_FILES = 16              # mesmo tamanho da lista de recentes (data.MAX_RECENT)
FRESH_SLACK = 30.0          # s: PNG vale pra esse .blend se não for mais velho que o save (- folga)


def _cache_dir(create=False):
    try:
        base = bpy.utils.extension_path_user(ADDON_PACKAGE, create=create)
    except Exception:
        base = bpy.utils.user_resource("CONFIG", path="hyblend_toolkit", create=create)
    path = os.path.join(base, "thumbs")
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def cache_path(blend_path):
    key = hashlib.sha1(os.path.normcase(os.path.abspath(blend_path)).encode("utf-8")).hexdigest()
    return os.path.join(_cache_dir(), key + ".png")


def fresh_cache(blend_path, blend_mtime):
    """PNG em alta do arquivo, se existir e não for mais velho que o .blend
    (e a opção estiver ligada)."""
    if not enabled():
        return ""
    path = cache_path(blend_path)
    try:
        if os.path.getmtime(path) >= blend_mtime - FRESH_SLACK:
            return path
    except OSError:
        pass
    return ""


def enabled():
    """Preferences > Home > "Miniaturas em alta" (home_hires_thumbs, ligado por padrão)."""
    addon = bpy.context.preferences.addons.get(ADDON_PACKAGE)
    return bool(getattr(addon.preferences, "home_hires_thumbs", True)) if addon else True


def _cached_files():
    folder = _cache_dir()
    try:
        return [os.path.join(folder, n) for n in os.listdir(folder) if n.endswith(".png")]
    except OSError:
        return []


def cache_size():
    total = 0
    for path in _cached_files():
        try:
            total += os.path.getsize(path)
        except OSError:
            pass
    return total


def prune(keep_blends):
    """Apaga toda miniatura que não é de um dos `keep_blends` (os recentes,
    até MAX_FILES): o cache nunca passa de 16 PNGs (~2-6 MB)."""
    keep = {cache_path(p) for p in list(keep_blends)[:MAX_FILES]}
    for path in _cached_files():
        if path not in keep:
            try:
                os.remove(path)
            except OSError:
                pass


def clear_cache():
    for path in _cached_files():
        try:
            os.remove(path)
        except OSError:
            pass


def recent_blends():
    """Lista de recentes do Blender (recent-files.txt), na ordem."""
    paths = []
    try:
        with open(os.path.join(bpy.utils.user_resource("CONFIG"), "recent-files.txt"), encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if line and line not in paths:
                    paths.append(line)
    except OSError:
        pass
    return paths


def _write_png(path, width, height, rgba_rows_top_first):
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    raw = b"".join(b"\x00" + row for row in rgba_rows_top_first)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))
    tmp = path + ".tmp"
    with open(tmp, "wb") as handle:
        handle.write(png)
    os.replace(tmp, path)


def _largest_view3d():
    best = None
    wm = bpy.context.window_manager
    for window in (wm.windows if wm else ()):
        for area in window.screen.areas:
            if area.type == "VIEW_3D" and (best is None or area.width * area.height > best[1].width * best[1].height):
                best = (window, area)
    return best


def capture(blend_path):
    """Desenha a maior View3D e grava o PNG do cache. False se não deu."""
    import gpu
    import numpy as np
    found = _largest_view3d()
    if found is None or not blend_path:
        return False
    window, area = found
    space = area.spaces.active
    region = next((r for r in area.regions if r.type == "WINDOW"), None)
    if region is None or region.width < 16 or region.height < 16 or space.region_3d is None:
        return False
    if space.shading.type == "RENDERED":
        return False                       # render engine numa miniatura: lento demais pro save
    width = WIDTH
    height = max(16, round(WIDTH * region.height / region.width))   # mesma proporção da vista
    offscreen = gpu.types.GPUOffScreen(width, height)
    try:
        rv3d = space.region_3d
        offscreen.draw_view3d(window.scene, window.view_layer, space, region, rv3d.view_matrix,
                              rv3d.window_matrix, do_color_management=True)
        buf = offscreen.texture_color.read()
        buf.dimensions = width * height * 4
        pixels = np.array(buf)
    finally:
        offscreen.free()
    if pixels.dtype != np.uint8:
        pixels = (np.clip(pixels, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
    img = pixels.reshape(height, width, 4).copy()
    img[..., 3] = 255                      # fundo da vista: sempre opaco
    rows = [img[y].tobytes() for y in range(height - 1, -1, -1)]   # textura: linha 0 = base
    _cache_dir(create=True)
    _write_png(cache_path(blend_path), width, height, rows)
    return True


_pending = {"path": ""}


def _has_ui():
    return not bpy.app.background


def _capture_tick():
    path, _pending["path"] = _pending["path"], ""
    if path and _has_ui() and enabled():
        try:
            capture(path)
        except Exception as error:
            print("[Hyblend] Home: thumbnail capture failed:", error)
        # o arquivo salvo entra no topo dos recentes; mantém só os 16 da lista
        prune([path] + [p for p in recent_blends() if p != path])
    return None


def _home_available():
    """Sem a pasta do jogo a Home nunca abre: nada de capturar a cada save."""
    from . import available
    return available()


@persistent
def _after_save(*_):
    if not _has_ui() or not enabled() or not _home_available():
        return
    _pending["path"] = bpy.data.filepath
    if not bpy.app.timers.is_registered(_capture_tick):
        bpy.app.timers.register(_capture_tick, first_interval=0.05)


def register():
    if _after_save not in bpy.app.handlers.save_post:
        bpy.app.handlers.save_post.append(_after_save)


def unregister():
    if _after_save in bpy.app.handlers.save_post:
        bpy.app.handlers.save_post.remove(_after_save)
    if bpy.app.timers.is_registered(_capture_tick):
        bpy.app.timers.unregister(_capture_tick)
