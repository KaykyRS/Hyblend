"""cache.py -- resolucao de caminho do cache de thumbnails em disco.
Puro Python, sem bpy -- so decide ONDE cada PNG deveria estar, nao
gera nada (isso e render.py).

Pasta: paths.data_root()/thumbnail_cache (Documentos/Hyblend/CharacterCreator,
regra de "Documentos" do hyblend_hub)."""

from __future__ import annotations

from pathlib import Path

from ..paths import data_root

_made = set()       # pastas já criadas nesta sessão (cache_root roda por item, a cada redesenho)


def cache_root() -> Path:
    root = data_root() / "thumbnail_cache"
    if root not in _made or not root.is_dir():
        root.mkdir(parents=True, exist_ok=True)
        _made.add(root)
    return root


def _sanitize(name: str) -> str:
    """Nomes de categoria/item/cor viram nome de arquivo -- troca
    qualquer coisa que nao seja seguro em path por '_'. Os Ids do jogo
    ate agora so usaram letras/numeros/underscore, mas nao confiamos
    nisso pra sempre (ex: um personagem custom da comunidade pode ter
    Ids mais criativos)."""
    return "".join(c if (c.isalnum() or c in "-_") else "_" for c in name)


def thumbnail_path(category: str, item_id: str, color_name: str) -> Path:
    safe_category = _sanitize(category)
    safe_item = _sanitize(item_id)
    safe_color = _sanitize(color_name) if color_name else "_default"
    return cache_root() / safe_category / f"{safe_item}__{safe_color}.png"
