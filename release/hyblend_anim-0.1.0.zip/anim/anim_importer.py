"""Import de .blockyanim numa Armature existente: Original Bones (keya os ORG) ou Controllers (FK/IK/Tweak, pela pose de mundo)."""


import json
import os
from collections import deque, namedtuple

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper
from mathutils import Matrix, Quaternion, Vector

from ..common import (
    game_found,
    BONE_RIGGER_CREATED_PROP,
    FPS_HYTALE,
    UNIT_SCALE_DEFAULT,
    armature_model_format,
    bone_file_name,
    effective_unit_scale,
    is_active_armature,
    shape_offsets,
    vec3,
    vec_to_dict,
)
from ..rigger import (
    BONE_PROPERTIES,
    BONE_ROOT_MASTER,
    BONE_ROOT_PELVIS,
    PROP_RIG_LAYER,
    SUFFIX_CTRL,
    SUFFIX_IK,
    SUFFIX_MCH,
    SUFFIX_MCH_IK_TRANSFER,
    SUFFIX_MCH_TRANSFER,
    SUFFIX_POLE,
    SUFFIX_TWEAK,
    control_name,
    ik_solver_target_index,
    pole_position_for_root,
    resolve_pelvis_org_name,
    source_org_of,
    switch_property_name,
    basis_for_world,
    pose_world_fn,
    tweak_basis,
)
from ..rigger.constants import IK_STRETCH_FOLLOWS_PARENT
from .blocky_curves import KIND_ORIENTATION, KIND_POSITION, KIND_STRETCH, Channel, bezier_segments
from .stretch_fit import (
    bone_position, clean, export_delta, inverse_start, lengths as _lengths, solve_basis, target_from_delta,
)
from ..translations import localized_props, register_localized_class, tr, unregister_localized_class

# Inverso de exporter.compute_deltas: delta_local = rest_local⁻¹ @ pose_local (ORG: delta = matrix_basis), com a
# posição já no espaço do bone (_positions_in_bone_space).


def parse_blockyanim(filepath):
    """Lê e valida minimamente um .blockyanim. Levanta ValueError com
    mensagem legível se o arquivo não bater com o formato esperado."""
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    if "nodeAnimations" not in data:
        raise ValueError("Missing 'nodeAnimations' -- this doesn't look like a .blockyanim file.")

    return data


def hytale_time_to_frame(time, start_frame, fps):
    """Inverso de exporter.frame_to_hytale_time: 'time' do arquivo -> frame da timeline (fps da cena + start_frame)."""
    seconds = time / FPS_HYTALE
    return start_frame + round(seconds * fps)


def _remap_renamed_bone_names(armature_obj, node_animations):
    """Nome do arquivo que não existe como bone -> o bone renomeado cujo nome original é esse (só se for um só)."""
    bones = armature_obj.data.bones
    by_original = {}
    for bone in bones:
        original = bone_file_name(bone)
        if original:
            by_original.setdefault(original, []).append(bone.name)
    if not by_original:
        return node_animations
    # Nome exato vence; os outros só vão pra bone que ninguém reservou.
    remapped = {name: channels for name, channels in node_animations.items() if bones.get(name) is not None}
    for name, channels in node_animations.items():
        if name in remapped:
            continue
        candidates = by_original.get(name, ())
        target = candidates[0] if len(candidates) == 1 else name
        if target in remapped:
            target = name
        remapped[target] = channels
    return remapped


def _positions_in_bone_space(armature_obj, node_animations):
    """Posição dos keys: do espaço do pai (como o jogo soma) pro do bone, a convenção do resto do import."""
    pose_bones = armature_obj.pose.bones
    out = {}
    for name, channels in node_animations.items():
        pbone = pose_bones.get(name)
        keys = channels.get(KIND_POSITION)
        if pbone is None or not keys:
            out[name] = channels
            continue
        rest_local = _rest_local_matrix(pbone)
        moved = [dict(key, delta=vec_to_dict(bone_position(rest_local, vec3(key.get("delta") or {})))) for key in keys]
        out[name] = dict(channels, **{KIND_POSITION: moved})
    return out


def _shape_offsets(armature_obj, hierarchy):
    """{ORG: centro da caixa na rest atual} (o jogo estica a caixa por ele)."""
    bones = armature_obj.data.bones
    names = [name for name, _parent, _rest in hierarchy]
    rest = {name: bones[name].matrix_local for name in names}
    return shape_offsets(armature_obj, rest, names, _armature_unit_scale(armature_obj))


def collect_target_bone_names(armature_obj, node_animations):
    """(existentes, ausentes) dos nomes do arquivo; ausente vira aviso, não erro."""
    pose_bones = armature_obj.pose.bones
    existing = [name for name in node_animations if name in pose_bones]
    missing = [name for name in node_animations if name not in pose_bones]
    return existing, missing


def _assign_fcurve_group_legacy(action, datablock, fcurve, group_name):
    """4.4/4.5: põe a F-Curve no grupo do bone (só organização visual)."""
    try:
        slot = datablock.animation_data.action_slot
        for layer in action.layers:
            for strip in layer.strips:
                channelbag = strip.channelbag(slot)
                if channelbag is None:
                    continue
                group = channelbag.groups.get(group_name) or channelbag.groups.new(group_name)
                fcurve.group = group
                return
    except (AttributeError, RuntimeError, TypeError):
        pass


def _get_or_create_fcurve(action, datablock, data_path, index, group_name):
    """F-Curve do canal: fcurve_ensure_for_datablock (4.4+, liga o slot certo); Action.fcurves só como reserva."""
    if hasattr(action, "fcurve_ensure_for_datablock"):
        try:
            return action.fcurve_ensure_for_datablock(
                datablock, data_path, index=index, group_name=group_name
            )
        except TypeError:
            # 4.4/4.5: sem o parâmetro group_name (entrou no 5.0) --
            # cria sem grupo e agrupa na mão pelo channelbag do slot.
            fcurve = action.fcurve_ensure_for_datablock(datablock, data_path, index=index)
            if group_name and fcurve.group is None:
                _assign_fcurve_group_legacy(action, datablock, fcurve, group_name)
            return fcurve
    if hasattr(action, "fcurves"):
        fcurve = action.fcurves.find(data_path, index=index)
        if fcurve is None:
            fcurve = action.fcurves.new(data_path, index=index, action_group=group_name)
        return fcurve
    return action.fcurve_ensure_for_datablock(
        datablock, data_path, index=index, group_name=group_name
    )


def _write_channel(action, datablock, data_path, group_name, components, samples):
    """F-Curves lineares, uma por componente, a partir de `samples` denso [(frame, valor)]."""
    if not samples:
        return
    fcurves = [
        _get_or_create_fcurve(action, datablock, data_path, i, group_name) for i in range(components)
    ]
    for i, fcurve in enumerate(fcurves):
        points = fcurve.keyframe_points
        start = len(points)
        points.add(len(samples))
        for j, (frame, value) in enumerate(samples):
            kp = points[start + j]
            kp.co = (frame, value[i])
            kp.interpolation = "LINEAR"
        fcurve.update()


def _frame_time(frame, start_frame, fps):
    return (frame - start_frame) * FPS_HYTALE / fps


def _write_sparse_channel(action, datablock, data_path, group_name, channel, start_frame, fps, scale=1.0):
    """Keys do arquivo com alças Bézier que desenham a mesma curva do jogo (blocky_curves.bezier_segments)."""
    times = channel.key_times()
    # Frame exato, mesmo quebrado (cena fora de 60 FPS): arredondar tiraria
    # o key do lugar e a curva do jogo junto.
    frames = [start_frame + t * fps / FPS_HYTALE for t in times]
    values, segments = bezier_segments(channel, times)
    components = 4 if channel.kind == KIND_ORIENTATION else 3
    for c in range(components):
        fcurve = _get_or_create_fcurve(action, datablock, data_path, c, group_name)
        points = fcurve.keyframe_points
        start = len(points)
        points.add(len(times))
        for j, frame in enumerate(frames):
            kp = points[start + j]
            kp.co = (frame, values[j][c] * scale)
            kp.interpolation = "BEZIER"
            kp.handle_left_type = kp.handle_right_type = "FREE"
            kp.handle_left = (frame - 1.0, kp.co[1])  # pontas: horizontal, por fora
            kp.handle_right = (frame + 1.0, kp.co[1])
        for j, (_p0, out_handle, in_handle, _p3) in enumerate(segments):
            points[start + j].handle_right = (
                start_frame + out_handle[0] * fps / FPS_HYTALE, out_handle[1][c] * scale
            )
            points[start + j + 1].handle_left = (
                start_frame + in_handle[0] * fps / FPS_HYTALE, in_handle[1][c] * scale
            )
        fcurve.update()


def _dense_channel_samples(channel, start_frame, end_frame, fps, scale=1.0):
    """Um valor por frame (Bake / modo Controllers), já em unidades do
    Blender; rotação com o sinal alinhado frame a frame."""
    samples = []
    previous = None
    for frame in range(start_frame, end_frame + 1):
        value = channel.evaluate(_frame_time(frame, start_frame, fps))
        if channel.kind == KIND_ORIENTATION:
            if previous is not None and value.dot(previous) < 0.0:
                value = -value
            previous = value
        else:
            value = value * scale
        samples.append((frame, value))
    return samples


def _armature_unit_scale(armature_obj):
    """Escala do delta de posição desta Armature (Prop = dobro de Character; ver effective_unit_scale)."""
    return effective_unit_scale(UNIT_SCALE_DEFAULT, armature_model_format(armature_obj))


def _apply_stretch_channels(armature_obj, action, node_animations, loop, start_frame, fps, bake_mode, skip=()):
    """Canal shapeStretch (escala): no `_CTRL` se existir (o ORG copia o MCH), senão no ORG; sempre por último."""
    pose_bones = armature_obj.pose.bones
    written_names = []
    for name, channels in node_animations.items():
        if name in skip:
            continue  # escala já gravada pelo ajuste (stretch_fit)
        ctrl_name = control_name(armature_obj.data, name, SUFFIX_CTRL)
        target_name = ctrl_name if ctrl_name in pose_bones else name
        if pose_bones.get(target_name) is None:
            continue
        channel = _channel(channels, KIND_STRETCH, loop)
        if not channel:
            continue
        data_path = f'pose.bones["{target_name}"].scale'
        if bake_mode:
            samples = _dense_channel_samples(channel, start_frame, loop.end_frame(start_frame, fps), fps)
            _write_channel(action, armature_obj, data_path, target_name, 3, samples)
        else:
            _write_sparse_channel(action, armature_obj, data_path, target_name, channel, start_frame, fps)
        written_names.append(target_name)
    return written_names


def _stretch_lookups(node_animations, loop, start_frame, fps):
    """{bone: frame -> stretch} dos bones que esticam em algum key."""
    lookups = {}
    for name, channels in node_animations.items():
        channel = _channel(channels, KIND_STRETCH, loop)
        keys = channels.get(KIND_STRETCH) or ()
        if not channel or all(
            abs((key.get("delta") or {}).get(axis, 1.0) - 1.0) < 1e-6 for key in keys for axis in "xyz"
        ):
            continue
        lookups[name] = (lambda c: lambda frame: c.evaluate(_frame_time(frame, start_frame, fps)))(channel)
    return lookups


def _stretch_affected(hierarchy, stretched):
    """Bones abaixo de um esticado (no Blender herdariam o stretch dele)."""
    affected = set()
    for name, parent_name, _rest_local in hierarchy:
        if parent_name is not None and (parent_name in stretched or parent_name in affected):
            affected.add(name)
    return affected


def _stretched_at(hierarchy, stretch_lookup, frame):
    """Bones esticados nesse frame e os abaixo deles: os que vão pelo ajuste."""
    stretched = {
        name for name, lookup in stretch_lookup.items() if any(abs(v - 1.0) > 1e-6 for v in lookup(frame))
    }
    return stretched | _stretch_affected(hierarchy, stretched)


def _file_delta(delta_lookup, stretch_lookup, name, frame):
    """(posição, quaternion, stretch) do arquivo nesse frame."""
    delta = delta_lookup[name](frame) if name in delta_lookup else Matrix.Identity(4)
    stretch = stretch_lookup[name](frame) if name in stretch_lookup else Vector((1.0, 1.0, 1.0))
    return delta.to_translation(), delta.to_quaternion(), Vector(stretch)


def _fit_org_stretch(hierarchy, delta_lookup, stretch_lookup, affected, start_frame, end_frame, unit_scale, offsets):
    """Modo ORG: keys dos bones em `affected` (esticados com caixa e os abaixo de um esticado), ajustados frame a frame.
    {bone: [(frame, loc, quat, escala)]}."""
    samples = {name: [] for name in affected}
    previous = {}  # resultado do frame anterior: a melhor partida
    for frame in range(start_frame, end_frame + 1):
        actual = {}
        solving = _stretched_at(hierarchy, stretch_lookup, frame)
        for name, parent_name, rest_local in hierarchy:
            pos, quat, stretch = _file_delta(delta_lookup, stretch_lookup, name, frame)
            basis = Matrix.Translation(pos) @ quat.to_matrix().to_4x4() @ Matrix.Diagonal((*stretch, 1.0))
            parent = actual.get(parent_name)
            parent_world = parent if parent is not None else Matrix.Identity(4)
            if name in solving:
                shape = (offsets.get(name), offsets.get(parent_name))
                basis, _ok = solve_basis(
                    lambda b: export_delta(parent, rest_local, parent_world @ rest_local @ b, *shape),
                    (pos, quat, stretch),
                    [
                        previous.get(name), basis,
                        inverse_start(
                            parent_world @ rest_local, target_from_delta(parent, rest_local, pos, quat, stretch, *shape)
                        ),
                    ],
                    unit_scale,
                )
                previous[name] = basis
            if name in affected:
                loc, rot, scale = basis.decompose()
                samples[name].append((frame, loc, rot, scale))
            actual[name] = parent_world @ rest_local @ basis
    return samples


def fit_fk_ctrl(
    ctrl_parent, ctrl_rest, offset, rest_local, parent, connected, goal, unit_scale, starts, shape=(None, None)
):
    """`_CTRL` (FK) que faz o export devolver `goal`, pelo caminho Transfer -> MCH (= ORG). (basis, `_CTRL`, MCH).
    `offset`: Transfer em relação ao `_CTRL` (a rest, ou já com o Tweak); `parent`: mundo do ORG pai ou None;
    `shape`: centro da caixa do bone e do pai (stretch_fit.export_delta)."""

    def mch_of(basis):
        mch = clean(ctrl_parent @ ctrl_rest @ basis @ offset)
        if connected:  # sem FK_CopyLocation: a posição vem do MCH pai
            mch.translation = ((parent if parent is not None else Matrix.Identity(4)) @ rest_local).translation
        return mch

    def forward(basis):
        return export_delta(parent, rest_local, mch_of(basis), *shape)

    target_world = target_from_delta(parent, rest_local, *goal, *shape)
    basis, _ok = solve_basis(
        forward, goal, list(starts) + [inverse_start(ctrl_parent @ ctrl_rest, target_world, offset)], unit_scale,
    )
    return basis, ctrl_parent @ ctrl_rest @ basis, mch_of(basis)


def transfer_rest(ctrl_pbone, transfer_pbone):
    """Transfer em relação ao `_CTRL` na rest, sem o Tweak (o `_MCH_Tweak_FK` pode estar entre os dois)."""
    return ctrl_pbone.bone.matrix_local.inverted() @ transfer_pbone.bone.matrix_local


def transfer_offset(ctrl_pbone, transfer_pbone):
    """Transfer em relação ao `_CTRL` na pose avaliada (rest @ Tweak do FK)."""
    return ctrl_pbone.matrix.inverted() @ transfer_pbone.matrix


class _StretchFit:
    """Ajuste de stretch do modo Controllers: guarda a pose real (com escala) do que já foi ajustado no frame."""

    def __init__(self, hierarchy, delta_lookup, stretch_lookup, pose_bones, rest_cache, unit_scale, offsets=None):
        self.stretch = stretch_lookup
        self.shape_offsets = offsets or {}  # {ORG: centro da caixa} (o jogo estica por ele)
        self.hierarchy = hierarchy
        self.solve_names = set()
        self._solve_cache = {}
        self.delta_lookup = delta_lookup
        self.pose_bones = pose_bones
        self.rest_cache = rest_cache
        self.unit_scale = unit_scale
        self.ctrl, self.mch = {}, {}  # MCH = ORG (o ORG copia o MCH no mundo)
        self.offsets = {}  # {ORG: Transfer em relação ao `_CTRL`} quando o Tweak do FK mexe
        self.previous = {}  # resultado do frame anterior por bone: a melhor partida

    def __bool__(self):  # False = arquivo sem stretch
        return bool(self.stretch)

    def solving_at(self, frame):
        """_stretched_at com cache."""
        if frame not in self._solve_cache:
            self._solve_cache[frame] = _stretched_at(self.hierarchy, self.stretch, frame)
        return self._solve_cache[frame]

    def new_frame(self, frame):
        """Zera a pose ajustada e marca quem se ajusta nesse frame."""
        self.ctrl, self.mch = {}, {}
        self.solve_names = self.solving_at(frame)

    def _fitted_world(self, pbone):
        """Pose ajustada de um pai `_CTRL` ou `_MCH` (dedos ficam no `_MCH` da mão), ou None."""
        if pbone is None:
            return None
        if pbone.name in self.ctrl:
            return self.ctrl[pbone.name]
        if pbone.name.endswith(SUFFIX_MCH):
            return self.mch.get(source_org_of(pbone))
        return None

    def shape(self, name):
        """(centro da caixa do bone, do pai) pra export_delta."""
        parent = self.pose_bones[name].parent
        return self.shape_offsets.get(name), self.shape_offsets.get(parent.name if parent is not None else None)

    def target(self, name, frame):
        """(posição, quaternion, stretch) do arquivo."""
        return _file_delta(self.delta_lookup, self.stretch, name, frame)

    def parent(self, parent_name, world_target):
        """Mundo do ORG pai: o ajustado, ou o alvo sem stretch; None sem pai."""
        if parent_name is None:
            return None
        return self.mch.get(parent_name, world_target[parent_name])

    def fk(self, name, parent_name, rest_local, ctrl_pbone, start_basis, world_target, frame):
        """(loc, quat, escala) do `_CTRL`, ou None quando a conta fechada serve."""
        parent = ctrl_pbone.parent
        ctrl_parent = self._fitted_world(parent)
        if name not in self.solve_names and ctrl_parent is None:
            return None
        transfer = self.pose_bones.get(name + SUFFIX_MCH_TRANSFER)
        if transfer is None:
            return None
        if ctrl_parent is None:
            ctrl_parent = _resolve_parent_world(parent, world_target, self.rest_cache, self.pose_bones)
        ctrl_rest = _get_rest_local(ctrl_pbone, self.rest_cache)
        offset = self.offsets[name] if name in self.offsets else transfer_rest(ctrl_pbone, transfer)
        basis, ctrl, mch = fit_fk_ctrl(
            ctrl_parent, ctrl_rest, offset, rest_local, self.parent(parent_name, world_target),
            self.pose_bones[name].bone.use_connect, self.target(name, frame), self.unit_scale,
            [self.previous.get(ctrl_pbone.name), start_basis], self.shape(name),
        )
        self.previous[ctrl_pbone.name] = basis
        self.ctrl[ctrl_pbone.name] = ctrl
        self.mch[name] = mch
        return basis.decompose()


def _apply_org_mode(
    operator, context, armature_obj, data, start_frame, action_name, loop_mode, bake_mode, keep_spine_follow,
    spine_mode="DEFAULT", arms_mode="BOTH", legs_mode="BOTH",
):
    """Modo Original Bones: keya os ORG direto (delta do arquivo = matrix_basis); os outros argumentos só mantêm a assinatura."""
    scene = context.scene
    fps = scene.render.fps / scene.render.fps_base

    _warn_if_fps_mismatch(operator, fps)

    node_animations = _positions_in_bone_space(
        armature_obj, _remap_renamed_bone_names(armature_obj, data["nodeAnimations"])
    )
    loop = _LoopSettings(data, loop_mode)
    end_frame = loop.end_frame(start_frame, fps)

    existing_names, missing_names = collect_target_bone_names(armature_obj, node_animations)

    if not existing_names:
        operator.report(
            {"ERROR"},
            "None of the bones in this .blockyanim exist on the selected armature -- wrong file or "
            "wrong armature?",
        )
        return {"CANCELLED"}

    action = bpy.data.actions.new(action_name)
    anim_data = armature_obj.animation_data_create()
    anim_data.action = action

    pose_bones = armature_obj.pose.bones
    unit_scale = _armature_unit_scale(armature_obj)
    bones_with_rotation = set()
    warned_rotation_mode = set()
    # Bone esticado com caixa e os abaixo de um esticado vão pelo ajuste (stretch_fit), um key por frame:
    # o jogo estica a caixa pelo centro e não passa a escala pros filhos.
    hierarchy = _org_hierarchy(armature_obj)
    stretch_lookup = _stretch_lookups({n: node_animations[n] for n in existing_names}, loop, start_frame, fps)
    offsets = _shape_offsets(armature_obj, hierarchy)
    affected = _stretch_affected(hierarchy, stretch_lookup) | (set(stretch_lookup) & set(offsets))

    for name in existing_names:
        if name in affected:
            continue
        channels = node_animations[name]
        for kind, data_path, scale in (
            (KIND_POSITION, f'pose.bones["{name}"].location', unit_scale),
            (KIND_ORIENTATION, f'pose.bones["{name}"].rotation_quaternion', 1.0),
        ):
            channel = _channel(channels, kind, loop)
            if not channel:
                continue
            if kind == KIND_ORIENTATION:
                # As F-Curves w,x,y,z só valem em modo Quaternion -- avisa
                # se o bone estava noutro modo.
                _ensure_quaternion_rotation(operator, pose_bones[name], warned_rotation_mode)
                bones_with_rotation.add(name)
            if bake_mode:
                samples = _dense_channel_samples(channel, start_frame, end_frame, fps, scale)
                _write_channel(action, armature_obj, data_path, name, 4 if kind == KIND_ORIENTATION else 3, samples)
            else:
                _write_sparse_channel(action, armature_obj, data_path, name, channel, start_frame, fps, scale)

    if affected:
        delta_lookup = {
            name: _delta_lookup(node_animations[name], loop, start_frame, fps, unit_scale) for name in existing_names
        }
        fitted = _fit_org_stretch(
            hierarchy, delta_lookup, stretch_lookup, affected, start_frame, end_frame, unit_scale, offsets,
        )
        for name in fitted:
            _ensure_quaternion_rotation(operator, pose_bones[name], warned_rotation_mode)
            if node_animations.get(name, {}).get(KIND_ORIENTATION):
                bones_with_rotation.add(name)
        _write_pose_samples(action, armature_obj, fitted)
    stretch_names = _apply_stretch_channels(
        armature_obj, action, node_animations, loop, start_frame, fps, bake_mode, skip=affected
    )
    _set_frame_ranges(operator, scene, action, start_frame, end_frame, loop.looping)

    if missing_names:
        operator.report(
            {"WARNING"},
            f"{len(missing_names)} bone(s) from the file don't exist on this armature and were "
            f"skipped (expected when importing onto a different creature/character): "
            f"{', '.join(sorted(missing_names)[:8])}"
            + ("..." if len(missing_names) > 8 else ""),
        )

    operator.report(
        {"INFO"},
        f"Imported '{action.name}' onto {len(existing_names)} bone(s) "
        f"({len(bones_with_rotation)} with rotation, {len(set(stretch_names) | set(stretch_lookup))} with shape stretch).",
    )
    return {"FINISHED"}


# --- Modo CTRL: alvo de mundo pela hierarquia ORG, reprojetado no pai real do `_CTRL` (um key por frame) ---


def _rest_local_matrix(pbone):
    """Matriz de repouso (local, relativa ao pai) de um pose bone --
    mesma convenção do exporter.py: bone sem pai, local == armature space."""
    bone = pbone.bone
    if pbone.parent is None:
        return bone.matrix_local.copy()
    return pbone.parent.bone.matrix_local.inverted() @ bone.matrix_local


def _org_hierarchy(armature_obj):
    """[(nome, pai ORG ou None, rest_local)] dos bones ORG (sem PROP_RIG_LAYER), pai antes do filho."""
    pose_bones = armature_obj.pose.bones
    org_names = {pb.name for pb in pose_bones if PROP_RIG_LAYER not in pb.bone.keys()}

    entries = {}
    for name in org_names:
        pb = pose_bones[name]
        parent_name = pb.parent.name if (pb.parent is not None and pb.parent.name in org_names) else None
        entries[name] = (parent_name, _rest_local_matrix(pb))

    depth = {}

    def get_depth(name):
        if name in depth:
            return depth[name]
        parent_name = entries[name][0]
        d = 0 if parent_name is None else get_depth(parent_name) + 1
        depth[name] = d
        return d

    for name in entries:
        get_depth(name)

    return [(name, entries[name][0], entries[name][1]) for name in sorted(entries, key=lambda n: depth[n])]


def _delta_lookup(channels, loop, start_frame, fps, unit_scale):
    """lookup(frame) -> Matrix do delta_local (posição+rotação) de um bone,
    avaliado como no jogo (blocky_curves.Channel)."""
    position = _channel(channels, KIND_POSITION, loop)
    orientation = _channel(channels, KIND_ORIENTATION, loop)

    def lookup(frame):
        t = _frame_time(frame, start_frame, fps)
        pos = position.evaluate(t) * unit_scale if position else Vector((0.0, 0.0, 0.0))
        quat = orientation.evaluate(t) if orientation else Quaternion((1.0, 0.0, 0.0, 0.0))
        return Matrix.Translation(pos) @ quat.to_matrix().to_4x4()

    return lookup


# --- Helpers compartilhados ---


def _warn_if_fps_mismatch(operator, fps):
    """FPS de cena != FPS_HYTALE ainda dá a duração certa, só não é 1:1 com
    os números do arquivo."""
    if round(fps) != FPS_HYTALE:
        operator.report(
            {"WARNING"},
            f"Scene is at {fps:g} FPS, not {FPS_HYTALE}. The animation's timing will be scaled "
            f"to match real-world duration, but will occupy far fewer Blender frames than the "
            f"file's 'time' numbers suggest -- set Output Properties > Frame Rate to {FPS_HYTALE} "
            f"for an exact 1:1 match with the .blockyanim file.",
        )


class _LoopSettings:
    """Loop do arquivo: `looping`, `duration` (frames a 60 FPS, pode faltar) e `end_time` (onde a Action acaba)."""

    def __init__(self, data, loop_mode):
        # loop_mode do usuário sobrescreve o arquivo -- "AUTO" lê o
        # holdLastKeyframe; "CYCLE"/"ONE_SHOT" forçam.
        if loop_mode == "CYCLE":
            hold_last = False
        elif loop_mode == "ONE_SHOT":
            hold_last = True
        else:
            hold_last = bool(data.get("holdLastKeyframe", False))
        self.duration = data.get("duration") or None
        self.looping = not hold_last and self.duration is not None
        last_key = max(
            (key["time"] for channels in data["nodeAnimations"].values()
             for kind in (KIND_POSITION, KIND_ORIENTATION, KIND_STRETCH) for key in channels.get(kind) or ()),
            default=0,
        )
        self.end_time = self.duration if self.looping else max(last_key, self.duration or 0)

    def end_frame(self, start_frame, fps):
        return hytale_time_to_frame(self.end_time, start_frame, fps)


def _channel(channels, kind, loop):
    return Channel(channels.get(kind) or [], kind, loop.duration, loop.looping)


def _set_frame_ranges(operator, scene, action, start_frame, end_frame, looping):
    """Range da Action = animação inteira; o da cena num loop acaba um frame antes (o último repete o primeiro)."""
    end_frame = max(end_frame, start_frame + 1)
    action.use_frame_range = True
    action.frame_end = end_frame
    action.frame_start = start_frame
    action.use_cyclic = looping
    scene.frame_start = start_frame
    scene.frame_end = end_frame - 1 if looping else end_frame
    operator.report({"INFO"}, f"Scene frame range set to {scene.frame_start}-{scene.frame_end}.")


_ReprojectionSetup = namedtuple(
    "_ReprojectionSetup",
    ["scene", "fps", "node_animations", "hierarchy", "delta_lookup", "loop", "end_frame", "action", "pose_bones"],
)


def _prepare_reprojection_setup(operator, context, armature_obj, data, start_frame, action_name, loop_mode):
    """Modo Controllers: valida FPS, resolve o loop, monta hierarquia/deltas e cria a Action; None se nenhum bone bate."""
    scene = context.scene
    fps = scene.render.fps / scene.render.fps_base
    _warn_if_fps_mismatch(operator, fps)

    node_animations = _positions_in_bone_space(
        armature_obj, _remap_renamed_bone_names(armature_obj, data["nodeAnimations"])
    )
    loop = _LoopSettings(data, loop_mode)

    hierarchy = _org_hierarchy(armature_obj)
    org_names_in_file = [name for name, _, _ in hierarchy if name in node_animations]
    if not org_names_in_file:
        operator.report(
            {"ERROR"},
            "None of the bones in this .blockyanim exist as original (ORG) bones on this "
            "armature -- wrong file, wrong armature, or the rig hasn't been generated yet?",
        )
        return None

    unit_scale = _armature_unit_scale(armature_obj)
    delta_lookup = {
        name: _delta_lookup(node_animations[name], loop, start_frame, fps, unit_scale) for name in org_names_in_file
    }

    action = bpy.data.actions.new(action_name)
    anim_data = armature_obj.animation_data_create()
    anim_data.action = action

    return _ReprojectionSetup(
        scene=scene,
        fps=fps,
        node_animations=node_animations,
        hierarchy=hierarchy,
        delta_lookup=delta_lookup,
        loop=loop,
        end_frame=loop.end_frame(start_frame, fps),
        action=action,
        pose_bones=armature_obj.pose.bones,
    )


def _compute_world_targets(hierarchy, delta_lookup, frame):
    """Anda a hierarquia ORG inteira (pai antes de filho) pra um único
    frame, devolvendo {nome_org: Matrix de mundo pretendida}."""
    world_target = {}
    for name, parent_name, rest_local in hierarchy:
        delta = delta_lookup[name](frame) if name in delta_lookup else Matrix.Identity(4)
        parent_world = world_target[parent_name] if parent_name is not None else Matrix.Identity(4)
        world_target[name] = parent_world @ rest_local @ delta
    return world_target


def _get_rest_local(pbone, rest_cache):
    """Cache compartilhado de _rest_local_matrix, indexado por nome de
    pose bone."""
    if pbone.name not in rest_cache:
        rest_cache[pbone.name] = _rest_local_matrix(pbone)
    return rest_cache[pbone.name]


def _resolve_parent_world(parent, world_target, rest_cache, pose_bones):
    """Mundo do pai real de um controle: pai `_CTRL` = alvo do ORG @ rest do Transfer⁻¹; pai `_MCH` = alvo do ORG; outro = pose atual."""
    if parent is None:
        return Matrix.Identity(4)
    for suffix in (SUFFIX_CTRL, SUFFIX_MCH):
        if parent.name.endswith(suffix):
            # source_org_of: o `_CTRL` pode ter apelido; a marca de origem diz o ORG.
            org_name = source_org_of(parent)
            if org_name in world_target:
                target = world_target[org_name]
                if suffix == SUFFIX_CTRL:
                    bridge_pbone = pose_bones.get(org_name + SUFFIX_MCH_TRANSFER)
                    if bridge_pbone is not None:
                        return target @ transfer_rest(parent, bridge_pbone).inverted()
                return target
    return parent.matrix.copy()


def _without_child_of(pbone, world_matrix, world_target, rest_cache, pose_bones):
    """`world_matrix` sem os Child Of ativos (influência 1), pra basis não aplicar o alvo duas vezes."""
    for con in reversed(pbone.constraints):
        if con.type != "CHILD_OF" or con.mute or con.influence < 1.0 or con.subtarget not in pose_bones:
            continue
        target_world = _resolve_parent_world(pose_bones[con.subtarget], world_target, rest_cache, pose_bones)
        world_matrix = (target_world @ con.inverse_matrix).inverted() @ world_matrix
    return world_matrix


def _resolve_matrix_basis(pbone, world_matrix, world_target, rest_cache, pose_bones):
    """Basis que põe `pbone` em `world_matrix`, pelo pai real no Blender (a ponta IK usa _resolve_ik_tip_matrix_basis)."""
    rest_local = _get_rest_local(pbone, rest_cache)
    parent_world = _resolve_parent_world(pbone.parent, world_target, rest_cache, pose_bones)
    local = parent_world.inverted() @ world_matrix
    return rest_local.inverted() @ local


def _resolve_ctrl_matrix_basis(ctrl_pbone, org_name, world_matrix, world_target, rest_cache, pose_bones):
    """Basis do `_CTRL` que põe o `_MCH_Transfer` (o que o MCH copia) em `world_matrix`."""
    bridge_pbone = pose_bones.get(org_name + SUFFIX_MCH_TRANSFER)
    if bridge_pbone is None:
        return _resolve_matrix_basis(ctrl_pbone, world_matrix, world_target, rest_cache, pose_bones)
    ctrl_rest = _get_rest_local(ctrl_pbone, rest_cache)
    parent_world = _resolve_parent_world(ctrl_pbone.parent, world_target, rest_cache, pose_bones)
    local = parent_world.inverted() @ world_matrix
    return ctrl_rest.inverted() @ local @ transfer_rest(ctrl_pbone, bridge_pbone).inverted()


def _resolve_ik_tip_matrix_basis(ik_pbone, org_rest_world, world_matrix, rest_cache):
    """Basis da ponta `_IK` (rest própria, sem pai) que põe o bridge (rest do ORG) em `world_matrix`."""
    ik_rest = _get_rest_local(ik_pbone, rest_cache)  # sem parent -- já é a rest de mundo
    return ik_rest.inverted() @ world_matrix @ org_rest_world.inverted() @ ik_rest


def _compute_pole_world_matrix(chain, world_target, root_ik_world=None):
    """Pole que deixa o `_IK` raiz com a orientação do FK (pole_position_for_root); sem isso, eixo Z do bone do meio."""
    pole_ref_world = world_target.get(chain["pole_ref"])
    if pole_ref_world is None:
        return None
    end_world = world_target.get(chain["org_names"][chain["target_index"]])
    if root_ik_world is not None and chain["pole_angle"] is not None and end_world is not None:
        pole_pos = pole_position_for_root(
            root_ik_world, end_world.translation, chain["pole_angle"], chain["pole_distance"]
        )
        if pole_pos is not None:
            return Matrix.Translation(pole_pos)
    z_axis_world = pole_ref_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
    if z_axis_world.length < 1e-9:
        z_axis_world = Vector((0.0, 0.0, 1.0))
    z_axis_world.normalize()
    sign = 1.0 if chain["pole_invert"] else -1.0
    pole_world_pos = pole_ref_world.translation + z_axis_world * (chain["pole_distance"] * sign)
    return Matrix.Translation(pole_world_pos)


def _ensure_quaternion_rotation(operator, pbone, warned_set):
    """Força rotation_mode QUATERNION, avisando uma vez por bone."""
    if pbone.rotation_mode == "QUATERNION":
        return
    if pbone.name not in warned_set:
        operator.report(
            {"WARNING"},
            f"Bone '{pbone.name}' rotation mode was '{pbone.rotation_mode}' -- switched to "
            f"'QUATERNION' to import orientation keyframes.",
        )
        warned_set.add(pbone.name)
    pbone.rotation_mode = "QUATERNION"


_EULER_MODES = {"XYZ", "XZY", "YXZ", "YZX", "ZXY", "ZYX"}


def _ensure_ctrl_rotation_mode(operator, pbone, warned_set):
    """Mantém o modo de rotação do bone; só Axis Angle vira Quaternion (com aviso, uma vez)."""
    if pbone.rotation_mode in _EULER_MODES:
        return
    _ensure_quaternion_rotation(operator, pbone, warned_set)


def _mute_constraints_on(pbones, muted_constraints):
    """Muta toda constraint ativa desses bones (genérico, sem nomes fixos) e guarda quais foram."""
    for pbone in pbones:
        if pbone is None:
            continue
        for con in pbone.constraints:
            if not con.mute:
                con.mute = True
                muted_constraints.append((pbone.name, con.name))


def _write_pose_samples(action, armature_obj, target_values):
    """F-Curves de loc/rotação/escala de cada bone em `target_values`; rotação no modo do bone, sem salto entre frames."""
    pose_bones = armature_obj.pose.bones
    for bone_name, samples in target_values.items():
        samples = sorted(samples, key=lambda s: s[0])
        pos_samples = [(s[0], s[1]) for s in samples if s[1] is not None]
        rot_samples = [(s[0], s[2]) for s in samples if s[2] is not None]
        scale_samples = [(s[0], s[3]) for s in samples if len(s) > 3 and s[3] is not None]
        if scale_samples:  # frame sem ajuste = escala 1, não a interpolada
            scale_samples = [(s[0], s[3] if len(s) > 3 and s[3] is not None else Vector((1.0, 1.0, 1.0))) for s in samples]
        if pos_samples:
            _write_channel(action, armature_obj, f'pose.bones["{bone_name}"].location', bone_name, 3, pos_samples)
        if scale_samples:
            _write_channel(action, armature_obj, f'pose.bones["{bone_name}"].scale', bone_name, 3, scale_samples)
        if not rot_samples:
            continue
        pbone = pose_bones.get(bone_name)
        order = pbone.rotation_mode if pbone is not None else "QUATERNION"
        converted = []
        previous = None
        for f, quat in rot_samples:
            if order in _EULER_MODES:
                value = quat.to_euler(order, previous) if previous is not None else quat.to_euler(order)
            else:
                value = -quat if previous is not None and quat.dot(previous) < 0.0 else quat
            converted.append((f, value))
            previous = value
        if order in _EULER_MODES:
            _write_channel(action, armature_obj, f'pose.bones["{bone_name}"].rotation_euler', bone_name, 3, converted)
        else:
            _write_channel(
                action, armature_obj, f'pose.bones["{bone_name}"].rotation_quaternion', bone_name, 4, converted
            )


# Passadas do ajuste IK com stretch (mexer na ponta muda o IK).
IK_FIT_PASSES = 4


def matrix_change(a, b):
    """Maior diferença entre duas matrizes."""
    return max(abs(a[i][j] - b[i][j]) for i in range(4) for j in range(4))


def fit_ik_piece(holder, bridge, rest_local, parent, goal, unit_scale, starts, shape=(None, None)):
    """Tweak (ou `_IK` da ponta/jarrete) que faz o export devolver `goal`, pelo caminho bridge -> MCH (= ORG). (basis, MCH)."""
    holder_world = pose_world_fn(holder)
    bridge_rel = holder.bone.matrix_local.inverted() @ bridge.matrix_local
    inherited = _lengths(parent @ rest_local) if IK_STRETCH_FOLLOWS_PARENT else None

    def mch_of(basis):
        return clean(holder_world(basis) @ bridge_rel, inherited)

    def forward(basis):
        return export_delta(parent, rest_local, mch_of(basis), *shape)

    target_world = target_from_delta(parent, rest_local, *goal, *shape)
    basis, _ok = solve_basis(
        forward, goal, list(starts) + [basis_for_world(holder, target_world @ bridge_rel.inverted())], unit_scale,
    )
    return basis, mch_of(basis)


def ik_pieces(armature_obj, chain):
    """Peças da cadeia, raiz -> ponta: (ORG, Tweak ou `_IK` da ponta/jarrete, bridge, é Tweak?)."""
    pose_bones = armature_obj.pose.bones
    bones = armature_obj.data.bones
    pieces = []
    for index, org_name in enumerate(chain["org_names"]):
        is_tweak = index < chain["target_index"]
        holder = pose_bones.get(control_name(armature_obj.data, org_name, SUFFIX_TWEAK if is_tweak else SUFFIX_IK))
        bridge = bones.get(org_name + SUFFIX_MCH_IK_TRANSFER)
        if holder is None or bridge is None or bridge.parent != holder.bone:
            return pieces  # rig anterior ao Tweak: Create Rig de novo
        pieces.append((org_name, holder, bridge, is_tweak))
    return pieces


def _set_keyed(action, armature_obj, name, path, frame, value):
    """Grava (ou troca) o key de `pose.bones[name].<path>` nesse frame."""
    for i, component in enumerate(value):
        fcurve = _get_or_create_fcurve(action, armature_obj, f'pose.bones["{name}"].{path}', i, name)
        key = fcurve.keyframe_points.insert(frame, component)  # mesmo frame: substitui
        if key is not None:
            key.interpolation = "LINEAR"


def _set_keyed_pose(action, armature_obj, pbone, frame, loc, quat, scale):
    """Grava loc, rotação (no modo do bone) e escala nesse frame."""
    rot_path, rot = (
        ("rotation_euler", quat.to_euler(pbone.rotation_mode, pbone.rotation_euler))
        if pbone.rotation_mode in _EULER_MODES else ("rotation_quaternion", quat)
    )
    for path, value in (("location", loc), (rot_path, rot), ("scale", scale)):
        _set_keyed(action, armature_obj, pbone.name, path, frame, value)


def _write_ik_piece_samples(scene, armature_obj, action, ik_chains, targets_by_frame, unit_scale, stretch_fit):
    """Keys dos Tweaks (o que o IK sozinho não reproduz) avaliando o solver frame a frame; com stretch, também ponta/jarrete. Devolve os Tweaks keyados."""
    pose_bones = armature_obj.pose.bones
    chains = [pieces for pieces in (ik_pieces(armature_obj, chain) for chain in ik_chains) if pieces]
    for pieces in chains:
        for _org, holder, _bridge, is_tweak in pieces:
            if is_tweak:
                holder.matrix_basis = Matrix()  # ajuste de antes do import não fica por baixo
    if not chains:
        return set()
    frame_before = scene.frame_current
    scaled = set()  # ponta/jarrete que já ganhou canal de escala
    passes = IK_FIT_PASSES if stretch_fit else 1
    for pass_index in range(passes):
        can_move = pass_index < passes - 1  # a última passada só mede (Tweaks da pose final da ponta)
        samples, needed, moved = {}, set(), False
        for frame in sorted(targets_by_frame):
            scene.frame_set(frame)
            targets = targets_by_frame[frame]
            for pieces in chains:
                root_org = pose_bones[pieces[0][0]]
                parent = root_org.parent.matrix.copy() if root_org.parent else Matrix.Identity(4)
                solving = stretch_fit.solving_at(frame) if stretch_fit else set()
                # O jarrete é filho da ponta no rig: ponta ajustada = jarretes também.
                controls_fit = any(org in solving for org, _h, _b, is_tweak in pieces if not is_tweak)
                for org_name, holder, bridge, is_tweak in pieces:
                    target = targets.get(org_name)
                    if target is None:
                        break
                    rest_local = _rest_local_matrix(pose_bones[org_name])
                    fit = org_name in solving or (controls_fit and not is_tweak)
                    if fit:
                        basis, mch = fit_ik_piece(
                            holder, bridge, rest_local, parent, stretch_fit.target(org_name, frame),
                            unit_scale, [stretch_fit.previous.get(holder.name), None if is_tweak else holder.matrix_basis.copy()],
                            stretch_fit.shape(org_name),
                        )
                        stretch_fit.previous[holder.name] = basis
                        negligible = False
                    elif is_tweak:
                        basis, negligible = tweak_basis(holder, bridge, target, unit_scale)
                        mch = target
                    else:
                        mch = target  # jarrete/ponta sem stretch: o key do import já é exato
                    if is_tweak:
                        loc, quat, scale = basis.decompose()
                        samples.setdefault(holder.name, []).append((frame, loc, quat, scale if fit else None))
                        if not negligible:
                            needed.add(holder.name)
                    elif fit and can_move and matrix_change(holder.matrix_basis, basis) > 1e-5:
                        if holder.name not in scaled:  # escala 1 em todo frame antes do 1º key
                            scaled.add(holder.name)
                            for other in targets_by_frame:
                                _set_keyed(action, armature_obj, holder.name, "scale", other, (1.0, 1.0, 1.0))
                        _set_keyed_pose(action, armature_obj, holder, frame, *basis.decompose())
                        moved = True
                    parent = mch
        if not moved:
            break
    scene.frame_set(frame_before)
    _write_pose_samples(action, armature_obj, {name: samples[name] for name in needed})
    return needed


def _refit_below_ik(scene, armature_obj, action, ik_chains, hierarchy, delta_lookup, stretch_fit, frames, target_values):
    """Refaz o ajuste dos filhos de cadeia só-IK (dedos da mão) em cima da pose IK real."""
    pose_bones = armature_obj.pose.bones
    ik_only = {name for chain in ik_chains if chain["mode"] == "IK" for name in chain["org_names"]}
    below, below_names = [], set()
    ever_solved = set().union(*(stretch_fit.solving_at(frame) for frame in frames))
    for name, parent_name, rest_local in hierarchy:
        if name not in ik_only and (parent_name in ik_only or parent_name in below_names):
            below_names.add(name)
            if name in ever_solved:
                below.append((name, parent_name, rest_local))
    if not below:
        return
    frame_before = scene.frame_current
    scaled = set()
    for frame in frames:
        scene.frame_set(frame)
        world_target = _compute_world_targets(hierarchy, delta_lookup, frame)
        stretch_fit.new_frame(frame)
        for name in ik_only:
            stretch_fit.mch[name] = pose_bones[name].matrix.copy()
        for name, parent_name, rest_local in below:
            ctrl_pbone = pose_bones.get(control_name(armature_obj.data, name, SUFFIX_CTRL))
            if ctrl_pbone is None:
                continue
            fitted = stretch_fit.fk(
                name, parent_name, rest_local, ctrl_pbone, ctrl_pbone.matrix_basis.copy(), world_target, frame
            )
            if fitted is not None:
                _key_refitted(action, armature_obj, ctrl_pbone, frame, fitted, frames, target_values, scaled)
    scene.frame_set(frame_before)


def _key_refitted(action, armature_obj, ctrl_pbone, frame, fitted, frames, target_values, scaled):
    """Troca o key do `_CTRL` nesse frame pelo ajuste; escala 1 nos outros frames se ele não tinha escala."""
    has_scale = any(len(s) > 3 and s[3] is not None for s in target_values.get(ctrl_pbone.name, ()))
    if not has_scale and ctrl_pbone.name not in scaled:
        scaled.add(ctrl_pbone.name)
        for other in frames:
            _set_keyed(action, armature_obj, ctrl_pbone.name, "scale", other, (1.0, 1.0, 1.0))
    _set_keyed_pose(action, armature_obj, ctrl_pbone, frame, *fitted)


def _refit_fk_under_tweaks(scene, armature_obj, action, ik_chains, keyed, hierarchy, delta_lookup, stretch_fit, frames, target_values):
    """Modo FK+IK: o Tweak keyado (`keyed`) pro IK também vale no FK -- refaz os `_CTRL` da cadeia por cima dele."""
    pose_bones = armature_obj.pose.bones
    chains = [
        chain for chain in ik_chains
        if chain["mode"] == "BOTH" and any(
            control_name(armature_obj.data, name, SUFFIX_TWEAK) in keyed
            for name in chain["org_names"][: chain["target_index"]]
        )
    ]
    if not chains:
        return
    parents = {name: (parent_name, rest_local) for name, parent_name, rest_local in hierarchy}
    frame_before = scene.frame_current
    scaled = set()
    for frame in frames:
        scene.frame_set(frame)
        world_target = _compute_world_targets(hierarchy, delta_lookup, frame)
        stretch_fit.new_frame(frame)
        for chain in chains:
            parent_moved = False  # `_CTRL` de cima reajustado: os de baixo também
            for name in chain["org_names"]:
                ctrl_pbone = pose_bones.get(control_name(armature_obj.data, name, SUFFIX_CTRL))
                transfer = pose_bones.get(name + SUFFIX_MCH_TRANSFER)
                if name not in parents or ctrl_pbone is None or transfer is None:
                    break
                offset = transfer_offset(ctrl_pbone, transfer)
                if not parent_moved and matrix_change(offset, transfer_rest(ctrl_pbone, transfer)) < 1e-6:
                    continue
                parent_name, rest_local = parents[name]
                # Quem não foi reajustado entra com a pose real (já com o stretch do import).
                if ctrl_pbone.parent is not None and ctrl_pbone.parent.name not in stretch_fit.ctrl:
                    stretch_fit.ctrl[ctrl_pbone.parent.name] = ctrl_pbone.parent.matrix.copy()
                if parent_name is not None and parent_name not in stretch_fit.mch:
                    stretch_fit.mch[parent_name] = pose_bones[parent_name].matrix.copy()
                stretch_fit.offsets[name] = offset
                fitted = stretch_fit.fk(
                    name, parent_name, rest_local, ctrl_pbone, ctrl_pbone.matrix_basis.copy(), world_target, frame
                )
                del stretch_fit.offsets[name]
                if fitted is None:
                    break
                _key_refitted(action, armature_obj, ctrl_pbone, frame, fitted, frames, target_values, scaled)
                parent_moved = True
    scene.frame_set(frame_before)


def _report_muted_constraints(operator, muted_constraints, note):
    """Relatório final de quais constraints extras foram mutadas."""
    if not muted_constraints:
        return
    affected_bones = sorted({bone_name for bone_name, _con_name in muted_constraints})
    operator.report(
        {"WARNING"},
        f"Muted {len(muted_constraints)} extra constraint(s) on {len(affected_bones)} bone(s) "
        f"{note} so the imported pose isn't blended with anything else -- left muted after "
        f"import; re-enable manually if you want that behavior back: "
        f"{', '.join(affected_bones[:8])}" + ("..." if len(affected_bones) > 8 else ""),
    )


# --- Root Follow: root.master_CTRL/root.pelvis_CTRL não têm ORG; o Pelvis "empresta" a pose pra o corpo andar junto ---


def _pelvis_delta(pelvis_world, pelvis_rest_world):
    """Quanto o Pelvis se moveu desde a rest neste frame (sem a posição absoluta dele)."""
    return pelvis_rest_world.inverted() @ pelvis_world


def _compose_delta_world(rest_world, delta, use_loc, use_rot):
    """rest_world @ delta, com a translação e/ou rotação do delta
    zeradas conforme os toggles."""
    d_loc, d_quat, _d_scale = delta.decompose()
    loc = d_loc if use_loc else Vector((0.0, 0.0, 0.0))
    quat = d_quat if use_rot else Quaternion()
    return rest_world @ (Matrix.Translation(loc) @ quat.to_matrix().to_4x4())


def _apply_root_follow(
    operator, frame, pose_bones, world_target, rest_cache, target_values, warned_rotation_mode,
    root_master_follow_loc, root_master_follow_rot, root_pelvis_follow_rot,
):
    """Root Follow: root.master_CTRL/root.pelvis_CTRL somam o delta do Pelvis (loc/rot conforme as opções); True se escreveu algo."""
    # Pelvis da entrada SPINE do Bone Settings (sem ela, o nome "Pelvis").
    pelvis_name = resolve_pelvis_org_name(pose_bones.id_data.data)
    pelvis_world = world_target.get(pelvis_name)
    pelvis_pbone = pose_bones.get(pelvis_name)
    if pelvis_world is None or pelvis_pbone is None:
        return False  # rig/arquivo sem esse bone de Pelvis -- nada a fazer
    pelvis_delta = _pelvis_delta(pelvis_world, pelvis_pbone.bone.matrix_local)

    fired = False
    master_pbone = pose_bones.get(BONE_ROOT_MASTER)
    master_target_world = None  # None == master não foi tocado (fica na própria rest)

    if master_pbone is not None and (root_master_follow_loc or root_master_follow_rot):
        master_rest_world = master_pbone.bone.matrix_local
        master_target_world = _compose_delta_world(
            master_rest_world, pelvis_delta, root_master_follow_loc, root_master_follow_rot
        )
        world_target[BONE_ROOT_MASTER[: -len(SUFFIX_CTRL)]] = master_target_world
        matrix_basis = _resolve_matrix_basis(master_pbone, master_target_world, world_target, rest_cache, pose_bones)
        loc, quat, _scale = matrix_basis.decompose()
        _ensure_ctrl_rotation_mode(operator, master_pbone, warned_rotation_mode)
        target_values.setdefault(master_pbone.name, []).append((frame, loc, quat))
        fired = True

    pelvis_ctrl_pbone = pose_bones.get(BONE_ROOT_PELVIS)
    if pelvis_ctrl_pbone is not None and (master_target_world is not None or root_pelvis_follow_rot):
        # Pose que root.pelvis_CTRL herda do pai real (root.master_CTRL).
        if master_target_world is not None and pelvis_ctrl_pbone.parent is master_pbone:
            parent_world_for_pelvis = master_target_world
        else:
            parent_world_for_pelvis = _resolve_parent_world(
                pelvis_ctrl_pbone.parent, world_target, rest_cache, pose_bones
            )
        pelvis_ctrl_rest_local = _get_rest_local(pelvis_ctrl_pbone, rest_cache)
        inherited_world = parent_world_for_pelvis @ pelvis_ctrl_rest_local

        if root_pelvis_follow_rot:
            # Só o delta de rotação do Pelvis, por cima do herdado.
            pelvis_ctrl_target_world = _compose_delta_world(inherited_world, pelvis_delta, False, True)
        else:
            pelvis_ctrl_target_world = inherited_world

        world_target[BONE_ROOT_PELVIS[: -len(SUFFIX_CTRL)]] = pelvis_ctrl_target_world

        if root_pelvis_follow_rot:
            # Key só com pose própria; só herdando, a basis fica identidade.
            matrix_basis = _resolve_matrix_basis(
                pelvis_ctrl_pbone, pelvis_ctrl_target_world, world_target, rest_cache, pose_bones
            )
            quat = matrix_basis.decompose()[1]
            _ensure_ctrl_rotation_mode(operator, pelvis_ctrl_pbone, warned_rotation_mode)
            target_values.setdefault(pelvis_ctrl_pbone.name, []).append((frame, None, quat))
        fired = True

    return fired


def _report_root_follow(operator, root_follow_enabled, root_follow_fired):
    """Aviso final se algum toggle de Root Follow estava ligado mas
    nunca chegou a injetar/escrever nada em nenhum frame."""
    if not root_follow_enabled or root_follow_fired:
        return
    operator.report(
        {"WARNING"},
        f"Root Follow was enabled but '{BONE_ROOT_MASTER}'/'{BONE_ROOT_PELVIS}' and/or the Pelvis bone "
        f"weren't found -- skipped, no keyframes written for the root control bone(s). Was the "
        f"rig generated with a version of rigger.py that has root.master_CTRL/root.pelvis_CTRL?",
    )


# Spine mode -> (master loc, master rot, pelvis rot) do Root Follow; MANUAL deixa root.spine_CTRL livre.
_SPINE_MODE_ROOT_FOLLOW = {
    "DEFAULT": (True, True, False),
    "MANUAL": (False, False, False),
}


def _org_path(hierarchy, root_name, tip_name):
    """Caminho raiz->ponta na hierarquia ORG do arquivo (find_org_path sem Edit Mode)."""
    if root_name == tip_name:
        return None
    children = {}
    for name, parent_name, _rest in hierarchy:
        if parent_name is not None:
            children.setdefault(parent_name, []).append(name)

    queue = deque([[root_name]])
    visited = {root_name}
    while queue:
        path = queue.popleft()
        node = path[-1]
        for child in children.get(node, []):
            if child in visited:
                continue
            new_path = path + [child]
            if child == tip_name:
                return new_path
            visited.add(child)
            queue.append(new_path)
    return None


def _resolve_ik_chains(armature_obj, hierarchy):
    """Cadeias ARM/LEG do Bone Settings com os nomes reais dos bones; `group` deixa Arms e Legs em modos diferentes."""
    chains = []
    for item in armature_obj.data.hytale_ik_chains:
        if item.chain_type == "CHAIN":
            continue
        if not item.root_bone or not item.tip_bone:
            continue
        path = _org_path(hierarchy, item.root_bone, item.tip_bone)
        if not path or len(path) < 2:
            continue
        pole_ref_name = item.pole_bone if item.pole_bone else path[len(path) // 2]
        target_index = ik_solver_target_index(len(path))
        solver_end = armature_obj.pose.bones.get(control_name(armature_obj.data, path[target_index - 1], SUFFIX_IK))
        ik_con = next((c for c in solver_end.constraints if c.type == "IK"), None) if solver_end else None
        chains.append(
            {
                "label": item.label or item.root_bone,
                "group": "LEG" if item.chain_type == "LEG" else "ARM",
                "org_names": path,
                "ik_tip": control_name(armature_obj.data, path[-1], SUFFIX_IK),
                "ik_root": control_name(armature_obj.data, path[0], SUFFIX_IK),
                # Bone cujo Head o solver alcança, e os jarretes de baixo pra
                # cima (rigger.helpers.ik_solver_target_index).
                "target_index": target_index,
                "hocks": [
                    (name, control_name(armature_obj.data, name, SUFFIX_IK)) for name in reversed(path[target_index:-1])
                ],
                "pole": control_name(armature_obj.data, path[0], SUFFIX_POLE),
                # pole_angle da constraint IK (radianos) -- o que o rig usa de
                # verdade, qualquer que seja o Pole Angle Mode.
                "pole_angle": ik_con.pole_angle if ik_con is not None else None,
                "pole_ref": pole_ref_name,
                "pole_distance": item.pole_distance,
                "pole_invert": item.pole_invert,
                # O mesmo nome que o rigger dá ao switch desta cadeia no
                # bone PROPERTIES (ver _build_pose_constraints).
                "switch_prop": switch_property_name(path[-1], item.side),
            }
        )
    return chains


def _apply_ctrl_mode(
    operator, context, armature_obj, data, start_frame, action_name, loop_mode, bake_mode, keep_spine_follow,
    spine_mode="DEFAULT", arms_mode="BOTH", legs_mode="BOTH",
):
    """Modo Controllers: Arms/Legs em Default (FK+IK, switch em FK), Control FK ou Control IK; o resto sempre em FK."""
    setup = _prepare_reprojection_setup(operator, context, armature_obj, data, start_frame, action_name, loop_mode)
    if setup is None:
        return {"CANCELLED"}
    scene, fps, node_animations, hierarchy, delta_lookup, loop, end_frame, action, pose_bones = setup

    chains = _resolve_ik_chains(armature_obj, hierarchy)
    group_mode = {"ARM": arms_mode, "LEG": legs_mode}
    for chain in chains:
        chain["mode"] = group_mode.get(chain["group"], "BOTH")

    # Todo Tweak (braço/perna e Spine) começa zerado; os que o IK precisa são refeitos depois.
    for pbone in pose_bones:
        if pbone.bone.get(PROP_RIG_LAYER) == "CTRL-TWEAK":
            pbone.matrix_basis = Matrix()

    # Cadeias 100% IK pulam o loop de FK; as outras (BOTH/CTRL_FK)
    # passam por ele normalmente, igual bone fora de cadeia nenhuma.
    chain_bone_names_skip_fk = {
        name for chain in chains if chain["mode"] == "IK" for name in chain["org_names"]
    }
    # Só cadeias BOTH/IK recebem ponta (_IK) + pole.
    ik_chains = [chain for chain in chains if chain["mode"] in ("BOTH", "IK")]

    target_values = {}  # {bone_name: [(frame, loc_or_None, quat_or_None), ...]}
    rest_cache = {}
    warned_rotation_mode = set()

    # Muta constraints extras dos `_CTRL` keyados (Spine Follow) e os Child Of dos poles.
    muted_constraints = []
    if not keep_spine_follow:
        _mute_constraints_on(
            (
                pose_bones.get(control_name(armature_obj.data, name, SUFFIX_CTRL))
                for name, _parent_name, _rest_local in hierarchy
                if name not in chain_bone_names_skip_fk
            ),
            muted_constraints,
        )
    _mute_constraints_on((pose_bones.get(chain["pole"]) for chain in ik_chains), muted_constraints)

    # Switch da cadeia: Control IK -> 1, Default -> 0 (FK).
    props_pbone = pose_bones.get(BONE_PROPERTIES)
    tip_org_rest_world = {}
    for chain in ik_chains:
        ik_pbone = pose_bones.get(chain["ik_tip"])
        if ik_pbone is not None:
            tip_org_rest_world[chain["ik_tip"]] = pose_bones[chain["org_names"][-1]].bone.matrix_local.copy()
        if props_pbone is not None and chain["switch_prop"] in props_pbone.keys():
            props_pbone[chain["switch_prop"]] = 1 if chain["mode"] == "IK" else 0
        else:
            operator.report(
                {"WARNING"},
                f"FK/IK switch '{chain['switch_prop']}' not found on '{BONE_PROPERTIES}' -- '{chain['label']}' "
                f"left as it was. Run Create Rig again.",
            )

    root_master_follow_loc, root_master_follow_rot, root_pelvis_follow_rot = _SPINE_MODE_ROOT_FOLLOW[spine_mode]

    rigger_created_names = {
        name for name, _parent_name, _rest_local in hierarchy
        if pose_bones[name].bone.get(BONE_RIGGER_CREATED_PROP)
    }

    # Copy Location ativo num _CTRL (o Head Free prende a cabeça no
    # pescoço) ignora a location dele -- avisa se o arquivo move esse bone.
    for name, _parent_name, _rest_local in hierarchy:
        ctrl_pbone = pose_bones.get(control_name(armature_obj.data, name, SUFFIX_CTRL))
        moves = any(
            any(abs(v) > 1e-6 for v in (key.get("delta") or {}).values())
            for key in node_animations.get(name, {}).get(KIND_POSITION) or ()
        )
        if ctrl_pbone is not None and moves and any(
            c.type == "COPY_LOCATION" and not c.mute and c.influence > 0.0 for c in ctrl_pbone.constraints
        ):
            operator.report(
                {"WARNING"},
                f"'{ctrl_pbone.name}' has its position locked (Head Free), but this animation moves it -- "
                f"that movement is lost. Switch to Head Lock before importing to keep it.",
            )

    root_follow_fired = False
    tweak_targets = {}  # {frame: {ORG: pose do jogo}} das peças que o solver resolve
    stretch_fit = _StretchFit(
        hierarchy, delta_lookup, _stretch_lookups(node_animations, loop, start_frame, fps), pose_bones, rest_cache,
        _armature_unit_scale(armature_obj), _shape_offsets(armature_obj, hierarchy),
    )
    for frame in range(start_frame, end_frame + 1):
        world_target = _compute_world_targets(hierarchy, delta_lookup, frame)
        stretch_fit.new_frame(frame)
        tweak_targets[frame] = {
            name: world_target[name] for chain in ik_chains for name in chain["org_names"] if name in world_target
        }

        if _apply_root_follow(
            operator, frame, pose_bones, world_target, rest_cache, target_values, warned_rotation_mode,
            root_master_follow_loc, root_master_follow_rot, root_pelvis_follow_rot,
        ):
            root_follow_fired = True

        # FK: todo bone fora das cadeias 100% IK.
        for name, parent_name, rest_local in hierarchy:
            if name in chain_bone_names_skip_fk:
                continue
            if name in rigger_created_names:
                # Root criado pelo rigger não está no arquivo: fica livre, sem key.
                continue
            ctrl_pbone = pose_bones.get(control_name(armature_obj.data, name, SUFFIX_CTRL))
            if ctrl_pbone is None:
                continue
            world_matrix = _without_child_of(ctrl_pbone, world_target[name], world_target, rest_cache, pose_bones)
            matrix_basis = _resolve_ctrl_matrix_basis(ctrl_pbone, name, world_matrix, world_target, rest_cache, pose_bones)
            _ensure_ctrl_rotation_mode(operator, ctrl_pbone, warned_rotation_mode)
            fitted = stretch_fit.fk(name, parent_name, rest_local, ctrl_pbone, matrix_basis, world_target, frame) if stretch_fit else None
            if fitted is not None:
                target_values.setdefault(ctrl_pbone.name, []).append((frame, *fitted))
                continue
            loc, quat, _scale = matrix_basis.decompose()
            target_values.setdefault(ctrl_pbone.name, []).append((frame, loc, quat))

        # IK: raiz (só location), ponta, jarretes e pole, só das cadeias BOTH/IK.
        for chain in ik_chains:
            tip_org_name = chain["org_names"][-1]
            root_org_name = chain["org_names"][0]
            root_ik_pbone = pose_bones.get(chain["ik_root"])
            root_world = None
            if root_ik_pbone is not None and root_org_name in world_target:
                # O solver decide a rotação da raiz; a posição vem da pose
                # (o `_CTRL` da raiz pode ter location no FK).
                root_world = (
                    world_target[root_org_name]
                    @ pose_bones[root_org_name].bone.matrix_local.inverted()
                    @ root_ik_pbone.bone.matrix_local
                )
                matrix_basis = _resolve_matrix_basis(root_ik_pbone, root_world, world_target, rest_cache, pose_bones)
                target_values.setdefault(root_ik_pbone.name, []).append((frame, matrix_basis.decompose()[0], None))
            ik_pbone = pose_bones.get(chain["ik_tip"])
            if ik_pbone is not None:
                tip_world = _without_child_of(ik_pbone, world_target[tip_org_name], world_target, rest_cache, pose_bones)
                matrix_basis = _resolve_ik_tip_matrix_basis(
                    ik_pbone, tip_org_rest_world[chain["ik_tip"]], tip_world, rest_cache
                )
                loc, quat, _scale = matrix_basis.decompose()
                _ensure_ctrl_rotation_mode(operator, ik_pbone, warned_rotation_mode)
                target_values.setdefault(ik_pbone.name, []).append((frame, loc, quat))

                # Jarretes, de baixo pra cima: o bridge de cada um cai na pose do ORG.
                parent_world = (
                    world_target[tip_org_name] @ tip_org_rest_world[chain["ik_tip"]].inverted()
                    @ ik_pbone.bone.matrix_local
                )
                expected_parent = ik_pbone.name
                for hock_org_name, hock_name in chain["hocks"]:
                    hock_pbone = pose_bones.get(hock_name)
                    # Rig anterior aos jarretes: Create Rig de novo converte.
                    if (
                        hock_pbone is None or hock_org_name not in world_target
                        or hock_pbone.parent is None or hock_pbone.parent.name != expected_parent
                    ):
                        break
                    expected_parent = hock_name
                    hock_world = (
                        world_target[hock_org_name] @ pose_bones[hock_org_name].bone.matrix_local.inverted()
                        @ hock_pbone.bone.matrix_local
                    )
                    rest_local = hock_pbone.parent.bone.matrix_local.inverted() @ hock_pbone.bone.matrix_local
                    matrix_basis = rest_local.inverted() @ parent_world.inverted() @ hock_world
                    loc, quat, _scale = matrix_basis.decompose()
                    _ensure_ctrl_rotation_mode(operator, hock_pbone, warned_rotation_mode)
                    target_values.setdefault(hock_name, []).append((frame, loc, quat))
                    parent_world = hock_world

            pole_pbone = pose_bones.get(chain["pole"])
            if pole_pbone is not None:
                pole_world_matrix = _compute_pole_world_matrix(chain, world_target, root_world)
                if pole_world_matrix is not None:
                    matrix_basis = _resolve_matrix_basis(pole_pbone, pole_world_matrix, world_target, rest_cache, pose_bones)
                    loc = matrix_basis.decompose()[0]
                    target_values.setdefault(pole_pbone.name, []).append((frame, loc, None))

    _write_pose_samples(action, armature_obj, target_values)
    keyed = _write_ik_piece_samples(
        scene, armature_obj, action, ik_chains, tweak_targets, _armature_unit_scale(armature_obj), stretch_fit
    )
    _refit_fk_under_tweaks(
        scene, armature_obj, action, ik_chains, keyed, hierarchy, delta_lookup, stretch_fit, sorted(tweak_targets),
        target_values,
    )
    if stretch_fit:
        _refit_below_ik(
            scene, armature_obj, action, ik_chains, hierarchy, delta_lookup, stretch_fit, sorted(tweak_targets),
            target_values,
        )

    # Bone com `_CTRL` já levou o stretch no ajuste; o canal direto é só pra bone sem controle.
    stretch_names = _apply_stretch_channels(
        armature_obj, action, node_animations, loop, start_frame, fps, bake_mode,
        skip={name for name in stretch_fit.stretch if control_name(armature_obj.data, name, SUFFIX_CTRL) in pose_bones},
    )
    _set_frame_ranges(operator, scene, action, start_frame, end_frame, loop.looping)
    _report_muted_constraints(
        operator, muted_constraints, "(control bones with extra blend constraints, and IK pole targets' Child Of)"
    )
    _report_root_follow(operator, spine_mode == "DEFAULT", root_follow_fired)

    arm_chains = [chain for chain in chains if chain["group"] == "ARM"]
    leg_chains = [chain for chain in chains if chain["group"] == "LEG"]
    if arms_mode in ("BOTH", "IK") and not arm_chains:
        operator.report(
            {"WARNING"},
            "Arms is set to use IK, but no 'Arm'-type chain was found on this armature "
            "(armature.hytale_ik_chains) -- nothing written for arms via IK.",
        )
    if legs_mode in ("BOTH", "IK") and not leg_chains:
        operator.report(
            {"WARNING"},
            "Legs is set to use IK, but no 'Leg'-type chain was found on this armature "
            "(armature.hytale_ik_chains) -- nothing written for legs via IK.",
        )

    non_chain_ctrl_count = sum(
        1 for name in target_values if not any(name == chain["ik_tip"] or name == chain["pole"] for chain in chains)
    )
    mode_label = {"BOTH": "FK+IK", "CTRL_FK": "FK only", "IK": "IK only"}
    operator.report(
        {"INFO"},
        f"Imported '{action.name}' -- Spine: {'root controllers follow Pelvis' if spine_mode == 'DEFAULT' else 'Pelvis/Belly/Chest only, root.spine_CTRL free for manual tweaks'}; "
        f"Arms: {mode_label[arms_mode]} ({len(arm_chains)} chain(s)); "
        f"Legs: {mode_label[legs_mode]} ({len(leg_chains)} chain(s)); "
        f"{non_chain_ctrl_count} other control bone(s); {len(set(stretch_names) | set(stretch_fit.stretch))} bone(s) with shape "
        f"stretch; {end_frame - start_frame + 1} frame(s) each.",
    )
    return {"FINISHED"}


_MODE_HANDLERS = {
    "ORG": _apply_org_mode,
    "CTRL": _apply_ctrl_mode,
}

# Presets de Frame Rate -> (fps, fps_base), iguais aos do Blender (23.98 = 24000/1001).
_FPS_PRESET_VALUES = {
    "6": (6, 1.0),
    "8": (8, 1.0),
    "12": (12, 1.0),
    "23.98": (24000, 1001.0),
    "24": (24, 1.0),
    "25": (25, 1.0),
    "29.97": (30000, 1001.0),
    "30": (30, 1.0),
    "50": (50, 1.0),
    "59.94": (60000, 1001.0),
    "60": (60, 1.0),
    "120": (120, 1.0),
    "240": (240, 1.0),
}


def _blockyanim_import_props(lang):
    return {
        "filter_glob": StringProperty(default="*.blockyanim", options={"HIDDEN"}),
        "target_mode": EnumProperty(
            name="Target",
            description=tr("anim_importer.prop.target_mode", lang),
            items=[
                (
                    "ORG",
                    "Original Bones",
                    tr("anim_importer.prop.target_mode_item_org", lang),
                ),
                (
                    "CTRL",
                    "Controllers",
                    tr("anim_importer.prop.target_mode_item_ctrl", lang),
                ),
            ],
            default="ORG",
        ),
        "action_name": StringProperty(
            name="Action Name",
            description=tr("anim_importer.prop.action_name", lang),
            default="",
        ),
        "start_frame": IntProperty(
            name="Start Frame",
            description=tr("anim_importer.prop.start_frame", lang),
            default=1,
        ),
        "import_fps_preset": EnumProperty(
            name="Frame Rate",
            description=tr("anim_importer.prop.import_fps_preset", lang),
            items=[
                ("6", "6", tr("anim_importer.prop.import_fps_preset_item_6", lang)),
                ("8", "8", tr("anim_importer.prop.import_fps_preset_item_8", lang)),
                ("12", "12", tr("anim_importer.prop.import_fps_preset_item_12", lang)),
                ("23.98", "23.98", tr("anim_importer.prop.import_fps_preset_item_23_98", lang)),
                ("24", "24", tr("anim_importer.prop.import_fps_preset_item_24", lang)),
                ("25", "25", tr("anim_importer.prop.import_fps_preset_item_25", lang)),
                ("29.97", "29.97", tr("anim_importer.prop.import_fps_preset_item_29_97", lang)),
                ("30", "30", tr("anim_importer.prop.import_fps_preset_item_30", lang)),
                ("50", "50", tr("anim_importer.prop.import_fps_preset_item_50", lang)),
                ("59.94", "59.94", tr("anim_importer.prop.import_fps_preset_item_59_94", lang)),
                ("60", "60", tr("anim_importer.prop.import_fps_preset_item_60", lang)),
                ("120", "120", tr("anim_importer.prop.import_fps_preset_item_120", lang)),
                ("240", "240", tr("anim_importer.prop.import_fps_preset_item_240", lang)),
                ("CUSTOM", "Custom", tr("anim_importer.prop.import_fps_preset_item_custom", lang)),
            ],
            default="60",
        ),
        "import_fps_custom_fps": IntProperty(
            name="FPS",
            description=tr("anim_importer.prop.import_fps_custom_fps", lang),
            default=FPS_HYTALE,
            min=1,
            soft_max=240,
        ),
        "import_fps_custom_base": FloatProperty(
            name="Base",
            description=tr("anim_importer.prop.import_fps_custom_base", lang),
            default=1.0,
            min=0.001,
            soft_max=120.0,
        ),
        "loop_mode": EnumProperty(
            name="Looping",
            description=tr("anim_importer.prop.loop_mode", lang),
            items=[
                (
                    "AUTO",
                    "Auto (from file)",
                    tr("anim_importer.prop.loop_mode_item_auto", lang),
                ),
                (
                    "CYCLE",
                    "Cycle (loop)",
                    tr("anim_importer.prop.loop_mode_item_cycle", lang),
                ),
                (
                    "ONE_SHOT",
                    "Start & End (no loop)",
                    tr("anim_importer.prop.loop_mode_item_one_shot", lang),
                ),
            ],
            default="AUTO",
        ),
        "bake_mode": BoolProperty(
            name="Bake to Every Frame",
            description=tr("anim_importer.prop.bake_mode", lang),
            default=False,
        ),
        "keep_spine_follow": BoolProperty(
            name="Keep Spine-Follow Active",
            description=tr("anim_importer.prop.keep_spine_follow", lang),
            default=True,
        ),
        "spine_mode": EnumProperty(
            name="Spine",
            description=tr("anim_importer.prop.spine_mode", lang),
            items=[
                (
                    "DEFAULT",
                    "Default (Root CTRL)",
                    tr("anim_importer.prop.spine_mode_item_default", lang),
                ),
                (
                    "MANUAL",
                    "Spine CTRL",
                    tr("anim_importer.prop.spine_mode_item_manual", lang),
                ),
            ],
            default="DEFAULT",
        ),
        "arms_mode": EnumProperty(
            name="Arms",
            description=tr("anim_importer.prop.arms_mode", lang),
            items=[
                (
                    "BOTH",
                    "Default (FK + IK)",
                    tr("anim_importer.prop.arms_mode_item_both", lang),
                ),
                (
                    "CTRL_FK",
                    "Control FK",
                    tr("anim_importer.prop.arms_mode_item_ctrl_fk", lang),
                ),
                (
                    "IK",
                    "Control IK",
                    tr("anim_importer.prop.arms_mode_item_ik", lang),
                ),
            ],
            default="BOTH",
        ),
        "legs_mode": EnumProperty(
            name="Legs",
            description=tr("anim_importer.prop.legs_mode", lang),
            items=[
                (
                    "BOTH",
                    "Default (FK + IK)",
                    tr("anim_importer.prop.legs_mode_item_both", lang),
                ),
                (
                    "CTRL_FK",
                    "Control FK",
                    tr("anim_importer.prop.legs_mode_item_ctrl_fk", lang),
                ),
                (
                    "IK",
                    "Control IK",
                    tr("anim_importer.prop.legs_mode_item_ik", lang),
                ),
            ],
            default="BOTH",
        ),
    }


@localized_props(_blockyanim_import_props)
class IMPORT_OT_hytale_blockyanim(Operator, ImportHelper):
    """Import a .blockyanim file onto the active armature"""

    bl_idname = "import_scene.hytale_blockyanim"
    bl_label = "Import Hytale Animation"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".blockyanim"

    @classmethod
    def poll(cls, context):
        return game_found() and is_active_armature(context)   # sem o jogo: travado (common.game_found)

    def execute(self, context):
        obj = context.active_object

        try:
            data = parse_blockyanim(self.filepath)
        except (OSError, json.JSONDecodeError, ValueError) as e:
            self.report({"ERROR"}, f"Could not read '{self.filepath}': {e}")
            return {"CANCELLED"}

        handler = _MODE_HANDLERS[self.target_mode]
        action_name = self.action_name.strip() or os.path.splitext(os.path.basename(self.filepath))[0]

        if self.import_fps_preset == "CUSTOM":
            target_fps_int, target_fps_base = self.import_fps_custom_fps, self.import_fps_custom_base
        else:
            target_fps_int, target_fps_base = _FPS_PRESET_VALUES[self.import_fps_preset]
        target_fps = target_fps_int / target_fps_base

        current_fps = context.scene.render.fps / context.scene.render.fps_base
        if abs(target_fps - current_fps) > 1e-6:
            context.scene.render.fps = target_fps_int
            context.scene.render.fps_base = target_fps_base
            self.report(
                {"INFO"},
                f"Scene FPS changed from {current_fps:g} to {target_fps:g} for this import.",
            )

        return handler(
            self,
            context,
            obj,
            data,
            self.start_frame,
            action_name,
            self.loop_mode,
            self.bake_mode,
            self.keep_spine_follow,
            self.spine_mode,
            self.arms_mode,
            self.legs_mode,
        )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "target_mode")
        if self.target_mode == "CTRL":
            box = layout.box()
            box.prop(self, "spine_mode")
            box.prop(self, "arms_mode")
            box.prop(self, "legs_mode")
        layout.prop(self, "action_name")
        layout.prop(self, "start_frame")
        layout.prop(self, "import_fps_preset")
        if self.import_fps_preset == "CUSTOM":
            col = layout.column(align=True)
            col.prop(self, "import_fps_custom_fps")
            col.prop(self, "import_fps_custom_base")
        layout.prop(self, "loop_mode")
        layout.prop(self, "bake_mode")
        if self.target_mode == "CTRL":
            layout.prop(self, "keep_spine_follow")


def menu_func_import(self, context):
    if not game_found():          # sem a pasta do jogo: nada do addon nos menus
        return
    self.layout.operator(IMPORT_OT_hytale_blockyanim.bl_idname, text="Hytale Animation (.blockyanim)")


_CLASSES = (IMPORT_OT_hytale_blockyanim,)


def register():
    for cls in _CLASSES:
        register_localized_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    for cls in reversed(_CLASSES):
        unregister_localized_class(cls)


if __name__ == "__main__":
    register()
