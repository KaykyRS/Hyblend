"""Import de .bbmodel (projeto do Blockbench); import_bbmodel_data() é o núcleo reaproveitado (importer/bedrock.py)."""

import base64
import json
import math
import os
import tempfile

import bmesh
import bpy
from bpy.props import StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper
from mathutils import Euler, Matrix, Vector

from ..common import (
    game_found,
    BONE_ORIGINAL_NAME_PROP,
    BONE_SHAPE_JSON_PROP,
    BONE_SHAPE_OFFSET_PROP,
    MODEL_FORMAT_CHARACTER,
    MODEL_FORMAT_PROP,
    effective_unit_scale,
    normalize_model_format,
    store_import_rest,
)
from ..toolkit import api
from ..translations import (
    get_language,
    localized_props,
    tooltip,
    tr,
)

# Peças do import no núcleo (as mesmas do .blockymodel): tabelas de face/UV, collections, material, janela.
_geometry = api.model.geometry
_build = api.model.build
BONE_DISPLAY_LENGTH_GAME_UNITS = api.model.props.BONE_DISPLAY_LENGTH
BOX_FACES_LOOP_ORDER = _geometry.BOX_FACES_LOOP_ORDER
BOX_FACE_BASE_SIGN = _geometry.BOX_FACE_BASE_SIGN
BOX_FACE_FIXED_AXIS = _geometry.BOX_FACE_FIXED_AXIS
FACE_AXES_BY_FIXED_AXIS = _geometry.FACE_AXES_BY_FIXED_AXIS
unique_bone_name = _build.unique_bone_name
resolve_mesh_bone_collection = _build.bone_collection
draw_mesh_section = api.model.options.draw_mesh_section
draw_rig_section = api.model.options.draw_rig_section
import_option_props = api.model.options.import_option_props
model_format_enum = api.model.options.model_format_enum


# --- .bbmodel ---
# Três listas religadas por uuid: "elements" (cubos, coordenadas absolutas), "groups" (bones: origin absoluto,
# rotation Euler XYZ em graus) e "outliner" (a árvore: dict = group, string = uuid de element).
# Conferido numericamente contra o .blockymodel do mesmo personagem (erro < 4e-4):
# 1) Group = Translate(origin) @ Euler(rotation, 'XYZ' do mathutils) @ Translate(-origin).
# 2) Posição de um nó = origin transformado pelos ancestrais, sem a própria rotação; por isso dois acumuladores
#    em build_bbmodel_recursive: ancestor_pivot_matrix (posição) e ancestor_rotation_matrix (orientação do bone).
# 3) isPiece já vem como group normal (attachments fundidos): o import de .bbmodel só cria Armature novo.
# 4) "stretch" de cada element: escala em volta do origin; negativo = espelho (lado L). Sem ele a UV do L sai invertida.
# UV: o retângulo em pixels vem pronto; usa os mesmos BOX_FACE_BASE_SIGN e permutação de rotação do .blockymodel.
# Se alguma face sair espelhada/girada errado, o ajuste é em bbmodel_compute_face_uv.

BB_FACE_TO_HYTALE_FACE_KEY = {
    # Bússola do Minecraft/Blockbench (norte -Z, sul +Z, leste +X, oeste -X) -> chaves de face do módulo.
    "north": "back",
    "south": "front",
    "west": "left",
    "east": "right",
    "up": "top",
    "down": "bottom",
}


def bb_euler_matrix(rotation_deg):
    """Rotação 4x4 de [rx, ry, rz] em graus, ordem 'XYZ' do mathutils."""
    rx, ry, rz = rotation_deg
    return Euler((math.radians(rx), math.radians(ry), math.radians(rz)), "XYZ").to_matrix().to_4x4()


def bb_rotate_around_pivot(origin, rotation_deg):
    """Translate(origin) @ Rotate(rotation) @ Translate(-origin) de um group/element (origin já escalado)."""
    R = bb_euler_matrix(rotation_deg)
    return Matrix.Translation(origin) @ R @ Matrix.Translation(-origin)


def bbmodel_compute_face_uv(local_co, neg_extent, pos_extent, axis_u, axis_v, hytale_face_key, rect, rotation_deg, atlas_w, atlas_h):
    """compute_face_uv do .bbmodel: `rect` já em pixels e caixa possivelmente assimétrica (neg/pos por eixo)."""
    nu, pu = neg_extent[axis_u], pos_extent[axis_u]
    nv, pv = neg_extent[axis_v], pos_extent[axis_v]
    span_u = (pu - nu) or 1.0
    span_v = (pv - nv) or 1.0
    s = (local_co[axis_u] - nu) / span_u
    t = (local_co[axis_v] - nv) / span_v

    bs, bt = BOX_FACE_BASE_SIGN.get(hytale_face_key, (1, -1))
    s_bb = s if bs > 0 else 1.0 - s
    t_bb = t if bt > 0 else 1.0 - t

    # Mesma permutação do .blockymodel (geometry.face_uv do núcleo).
    k = int(round((rotation_deg or 0) / 90.0)) % 4
    for _ in range(k):
        s_bb, t_bb = t_bb, 1.0 - s_bb

    x1, y1, x2, y2 = rect
    px = x1 + (x2 - x1) * s_bb
    py = y1 + (y2 - y1) * t_bb

    u = px / atlas_w
    v = 1.0 - (py / atlas_h)
    return u, v


def bb_face_to_texture_layout(rect, rotation_deg=0):
    """Retângulo de UV de uma face do .bbmodel (+ rotação) -> textureLayout {offset, mirror, angle}.
    Réplica da regra do plugin oficial (blockymodel.ts compile, "// UV"): retângulo invertido = mirror."""
    x1, y1, x2, y2 = rect
    state = {"flip_x": False, "flip_y": False, "uv_x": min(x1, x2), "uv_y": min(y1, y2)}

    def flip(axis):
        if axis == "x":
            state["flip_x"] = not state["flip_x"]
            state["uv_x"] = max(x1, x2) if state["flip_x"] else min(x1, x2)
        else:
            state["flip_y"] = not state["flip_y"]
            state["uv_y"] = max(y1, y2) if state["flip_y"] else min(y1, y2)

    mirror_x = x1 > x2
    mirror_y = y1 > y2
    if mirror_x:
        flip("x")
    if mirror_y:
        flip("y")
    one_mirror = mirror_x != mirror_y
    rotation = int(rotation_deg or 0) % 360
    angle = 0
    if rotation == 90:
        angle = 90 if one_mirror else 270
        flip("y")
    elif rotation == 180:
        angle = 180
        flip("y")
        flip("x")
    elif rotation == 270:
        angle = 270 if one_mirror else 90
        flip("x")

    def clean(value):
        return int(value) if float(value).is_integer() else value

    return {
        "offset": {"x": clean(state["uv_x"]), "y": clean(state["uv_y"])},
        "mirror": {"x": mirror_x, "y": mirror_y},
        "angle": angle,
    }


def _face_has_texture(info):
    return info is not None and info.get("texture") is not None and len(info.get("uv") or []) == 4


_QUAD_AXIS_INFO = {
    # Eixo achatado -> face do lado negativo/positivo; os 2 eixos do quad vêm de FACE_AXES_BY_FIXED_AXIS
    # (a ordem "por simetria" saiu errada no X: HairTop com size trocado).
    "x": ("west", "east"),
    "y": ("down", "up"),
    "z": ("north", "south"),
}


def _bbmodel_quad_shape(flat_axis, size_raw_3, offset_raw, stretch, faces, side=None):
    """Shape 'quad' (element achatado num eixo): size 2D na ordem de FACE_AXES_BY_FIXED_AXIS e normal pela face com textura."""
    neg_face, pos_face = _QUAD_AXIS_INFO[flat_axis]
    i1, i2 = FACE_AXES_BY_FIXED_AXIS[flat_axis]
    size = {"x": size_raw_3[i1], "y": size_raw_3[i2]}
    axis_upper = flat_axis.upper()

    pos_info = faces.get(pos_face)
    neg_info = faces.get(neg_face)
    # `side` força um lado ("neg"/"pos") -- usado pro quad do lado de trás
    # de um plano com textura nos DOIS lados (ver bbmodel_element_to_shapes).
    if side == "neg":
        normal, chosen = f"-{axis_upper}", neg_info
    elif side == "pos" or _face_has_texture(pos_info):
        normal, chosen = f"+{axis_upper}", pos_info
    elif _face_has_texture(neg_info):
        normal, chosen = f"-{axis_upper}", neg_info
    else:
        normal, chosen = f"+{axis_upper}", None

    texture_layout = {}
    n_skipped = 0
    if _face_has_texture(chosen):
        texture_layout["front"] = bb_face_to_texture_layout(chosen["uv"], chosen.get("rotation", 0))

    shape = {
        "type": "quad",
        "offset": offset_raw,
        "stretch": {"x": stretch[0], "y": stretch[1], "z": stretch[2]},
        "settings": {"size": size, "normal": normal},
    }
    if texture_layout:
        shape["textureLayout"] = texture_layout
    return shape, n_skipped


def bbmodel_element_to_shape(elem):
    """Element do .bbmodel -> "shape" do .blockymodel (pra exportar personagem importado de .bbmodel).
    Conferido contra um export do Blockbench: stretch fica à parte (não entra no offset/size) e from==to vira quad.
    TextureLayout por bb_face_to_texture_layout. Devolve (shape, n_faces_skipped), este sempre 0."""
    from_v = elem.get("from", [0.0, 0.0, 0.0])
    to_v = elem.get("to", [0.0, 0.0, 0.0])
    origin_v = elem.get("origin", [0.0, 0.0, 0.0])
    stretch = elem.get("stretch", [1.0, 1.0, 1.0])
    faces = elem.get("faces", {}) or {}

    # Sem multiplicar por stretch aqui (ver docstring acima).
    neg = [min(from_v[i], to_v[i]) - origin_v[i] for i in range(3)]
    pos = [max(from_v[i], to_v[i]) - origin_v[i] for i in range(3)]
    size_raw_3 = [abs(pos[i] - neg[i]) for i in range(3)]
    offset_raw = {"x": (pos[0] + neg[0]) / 2.0, "y": (pos[1] + neg[1]) / 2.0, "z": (pos[2] + neg[2]) / 2.0}

    flat_axis = None
    for i, axis_name in enumerate(("x", "y", "z")):
        if abs(from_v[i] - to_v[i]) < 1e-6:
            flat_axis = axis_name
            break

    if flat_axis is not None:
        return _bbmodel_quad_shape(flat_axis, size_raw_3, offset_raw, stretch, faces)

    size_raw = {"x": size_raw_3[0], "y": size_raw_3[1], "z": size_raw_3[2]}

    texture_layout = {}
    n_skipped = 0
    for bb_key, hytale_key in BB_FACE_TO_HYTALE_FACE_KEY.items():
        info = faces.get(bb_key)
        if not _face_has_texture(info):
            continue
        texture_layout[hytale_key] = bb_face_to_texture_layout(info["uv"], info.get("rotation", 0))

    shape = {
        "type": "box",
        "offset": offset_raw,
        "stretch": {"x": stretch[0], "y": stretch[1], "z": stretch[2]},
        "settings": {"size": size_raw},
    }
    if texture_layout:
        shape["textureLayout"] = texture_layout
    return shape, n_skipped


def bbmodel_element_to_shapes(elem):
    """Como bbmodel_element_to_shape, mas em lista: plano com textura nos dois lados ganha um 2º quad virado
    (o quad do Hytale tem um lado só). Plano do Hytale (verso sem textura) sai com um shape."""
    shape, n_skipped = bbmodel_element_to_shape(elem)
    shapes = [shape]
    if shape.get("type") == "quad":
        flat_axis = shape["settings"]["normal"][1:].lower()
        neg_face, pos_face = _QUAD_AXIS_INFO[flat_axis]
        faces = elem.get("faces", {}) or {}
        if _face_has_texture(faces.get(neg_face)) and _face_has_texture(faces.get(pos_face)):
            from_v = elem.get("from", [0.0, 0.0, 0.0])
            to_v = elem.get("to", [0.0, 0.0, 0.0])
            origin_v = elem.get("origin", [0.0, 0.0, 0.0])
            stretch = elem.get("stretch", [1.0, 1.0, 1.0])
            neg = [min(from_v[i], to_v[i]) - origin_v[i] for i in range(3)]
            pos = [max(from_v[i], to_v[i]) - origin_v[i] for i in range(3)]
            size_raw_3 = [abs(pos[i] - neg[i]) for i in range(3)]
            offset_raw = {"x": (pos[0] + neg[0]) / 2.0, "y": (pos[1] + neg[1]) / 2.0, "z": (pos[2] + neg[2]) / 2.0}
            back, back_skipped = _bbmodel_quad_shape(flat_axis, size_raw_3, offset_raw, stretch, faces, side="neg")
            shapes.append(back)
            n_skipped += back_skipped
    return shapes, n_skipped


def bbmodel_element_local_transform(group_world_matrix, children_pivot_matrix, children_rotation_matrix, elem, unit_scale):
    """(position_raw, orientation, is_identity) do element relativo ao bone dono, pelas mesmas matrizes da malha.
    position_raw em unidades do jogo, ainda sem tirar o offset do shape primário (feito por quem chama).
    is_identity: rotação própria nula -> dá pra dobrar no shape do bone; senão vira node filho sintético."""
    elem_origin_scaled = Vector(elem.get("origin", [0.0, 0.0, 0.0])) * unit_scale
    elem_rotation_deg = elem.get("rotation", [0.0, 0.0, 0.0])
    elem_world_pos = children_pivot_matrix @ elem_origin_scaled
    elem_own_rotation = children_rotation_matrix @ bb_euler_matrix(elem_rotation_deg)
    elem_world_matrix = Matrix.Translation(elem_world_pos) @ elem_own_rotation

    local_matrix = group_world_matrix.inverted() @ elem_world_matrix
    local_pos, local_rot, _scale = local_matrix.decompose()

    is_identity = (
        abs(local_rot.w) > 0.999999
        and abs(local_rot.x) < 0.001
        and abs(local_rot.y) < 0.001
        and abs(local_rot.z) < 0.001
    )
    position_raw = local_pos / unit_scale
    orientation_dict = {
        "x": round(local_rot.x, 6),
        "y": round(local_rot.y, 6),
        "z": round(local_rot.z, 6),
        "w": round(local_rot.w, 6),
    }
    return position_raw, orientation_dict, is_identity


# Índice negativo = face real sem textura atribuída (ver import_bbmodel_data).
BBMODEL_UNASSIGNED_TEXTURE = -1


def make_bbmodel_cube_mesh(name, from_scaled, to_scaled, origin_scaled, stretch, faces, atlas_by_texture_index, generate_uvs):
    """Malha de um element cube: caixa pode ser assimétrica ao pivô. `stretch` (por eixo, em volta do origin)
    redimensiona e, negativo, espelha vértices e UV juntos (neg/pos invertem). `atlas_by_texture_index`:
    {índice da textura: (w, h)} pra normalizar a UV."""
    sx, sy, sz = stretch
    neg = ((min(from_scaled.x, to_scaled.x) - origin_scaled.x) * sx,
           (min(from_scaled.y, to_scaled.y) - origin_scaled.y) * sy,
           (min(from_scaled.z, to_scaled.z) - origin_scaled.z) * sz)
    pos = ((max(from_scaled.x, to_scaled.x) - origin_scaled.x) * sx,
           (max(from_scaled.y, to_scaled.y) - origin_scaled.y) * sy,
           (max(from_scaled.z, to_scaled.z) - origin_scaled.z) * sz)

    verts_co = [
        (neg[0], neg[1], neg[2]),
        (pos[0], neg[1], neg[2]),
        (pos[0], pos[1], neg[2]),
        (neg[0], pos[1], neg[2]),
        (neg[0], neg[1], pos[2]),
        (pos[0], neg[1], pos[2]),
        (pos[0], pos[1], pos[2]),
        (neg[0], pos[1], pos[2]),
    ]

    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bm_verts = [bm.verts.new(co) for co in verts_co]

    uv_layer = bm.loops.layers.uv.new() if generate_uvs else None

    for bb_key, idxs in BOX_FACES_LOOP_ORDER:
        # Chave do .bbmodel (north/south/...) da face hytale (front/back/...).
        bb_face_name = next((k for k, v in BB_FACE_TO_HYTALE_FACE_KEY.items() if v == bb_key), None)
        info = faces.get(bb_face_name) if bb_face_name else None
        tex_index = info.get("texture") if info else None

        # IMPORTANTE: o Blockbench grava "uv" em toda face; face que não existe tem texture=None.
        # Tem que pular antes de criar, senão sobra face preta sobreposta (bug do R-Ear2/R-Ear3).
        if tex_index is None:
            continue

        face = bm.faces.new([bm_verts[i] for i in idxs])
        if uv_layer is None:
            continue
        atlas = atlas_by_texture_index.get(tex_index)
        if atlas is None:
            # Textura não carregada (sem Create Materials): face real, sem UV.
            continue
        atlas_w, atlas_h = atlas
        rect = info["uv"]
        rotation_deg = info.get("rotation", 0)

        fixed_axis = BOX_FACE_FIXED_AXIS[bb_key]
        axis_u, axis_v = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
        for loop in face.loops:
            local_co = loop.vert.co
            u, v = bbmodel_compute_face_uv(local_co, neg, pos, axis_u, axis_v, bb_key, rect, rotation_deg, atlas_w, atlas_h)
            loop[uv_layer].uv = (u, v)

    # Faces pra fora (a tabela de cantos sai pra dentro; espelho do stretch também inverte).
    _geometry.orient_outward(bm, [(n + p) / 2.0 for n, p in zip(neg, pos)])
    bm.to_mesh(mesh)
    bm.free()
    return mesh


def decode_bbmodel_texture(texture_entry):
    """PNG embutido em base64 -> bpy.data.images empacotada no .blend; None sem source."""
    source = texture_entry.get("source", "")
    if not source.startswith("data:image"):
        return None
    header, _, b64data = source.partition(",")
    try:
        raw_bytes = base64.b64decode(b64data)
    except Exception:
        return None

    fd, tmp_path = tempfile.mkstemp(suffix=".png")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(raw_bytes)
        image = bpy.data.images.load(tmp_path, check_existing=False)
        image.name = texture_entry.get("name", "Hytale_Texture")
        image.pack()  # embute os pixels no .blend -- não depende mais do tmp_path
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
    return image


def prescan_bbmodel_mesh_groups(outliner_roots, groups_by_uuid):
    """Pré-scan do outliner (por uuid): groups com element direto e o pai de cada group.
    Precisa ser antes porque elements e sub-groups vêm misturados na ordem do arquivo."""
    uuids_with_direct_mesh = set()
    uuid_parent_map = {}

    def walk(children, current_group_uuid):
        for child in children:
            if isinstance(child, str):
                if current_group_uuid is not None:
                    uuids_with_direct_mesh.add(current_group_uuid)
                continue
            group = groups_by_uuid.get(child.get("uuid"))
            if group is None:
                continue
            uuid_parent_map[child["uuid"]] = current_group_uuid
            walk(child.get("children", []), child["uuid"])

    walk(outliner_roots, None)
    return uuids_with_direct_mesh, uuid_parent_map


def make_bbmodel_ancestor_fn(mesh_build_context):
    """nearest_ancestor_fn do .bbmodel (uuid -> nome de bone pelo contexto); modo flat sempre devolve None."""
    if mesh_build_context["settings"].flat_mesh_collections:
        return lambda bone_name: None

    uuid_parent_map = mesh_build_context["uuid_parent_map"]
    uuids_with_direct_mesh = mesh_build_context["uuids_with_direct_mesh"]
    group_uuid_to_bone_name = mesh_build_context["group_uuid_to_bone_name"]
    bone_name_to_group_uuid = mesh_build_context["bone_name_to_group_uuid"]

    def ancestor_fn(bone_name):
        uuid = bone_name_to_group_uuid.get(bone_name)
        if uuid is None:
            return None
        parent_uuid = uuid_parent_map.get(uuid)
        while parent_uuid is not None:
            if parent_uuid in uuids_with_direct_mesh:
                return group_uuid_to_bone_name.get(parent_uuid)
            parent_uuid = uuid_parent_map.get(parent_uuid)
        return None

    return ancestor_fn


def build_bbmodel_recursive(
    armature_data,
    outliner_children,
    parent_bone_name,
    ancestor_pivot_matrix,
    ancestor_rotation_matrix,
    groups_by_uuid,
    elements_by_uuid,
    unit_scale,
    stats,
    mesh_build_context,
    parent_group_uuid=None,
):
    """Constrói bones (groups) e malhas (elements) dos filhos do outliner, recursivo. Os dois acumuladores: ver o topo.
    `parent_group_uuid`: uuid do group dono (estável, independe do nome final do bone)."""
    edit_bones = armature_data.edit_bones

    for child in outliner_children:
        if isinstance(child, str):
            # Leaf: uuid de um element (cube) -- vira uma mesh, parentada
            # no bone ATUAL (parent_bone_name), não um bone novo.
            if not mesh_build_context["generate_meshes"]:
                continue
            elem = elements_by_uuid.get(child)
            if elem is None:
                continue
            elem_origin = Vector(elem.get("origin", [0, 0, 0])) * unit_scale
            elem_rotation = elem.get("rotation", [0, 0, 0])
            world_pos = ancestor_pivot_matrix @ elem_origin
            own_rotation = ancestor_rotation_matrix @ bb_euler_matrix(elem_rotation)
            obj_matrix = Matrix.Translation(world_pos) @ own_rotation

            from_scaled = Vector(elem.get("from", [0, 0, 0])) * unit_scale
            to_scaled = Vector(elem.get("to", [0, 0, 0])) * unit_scale
            stretch = elem.get("stretch", [1, 1, 1])
            faces = elem.get("faces", {}) or {}
            mesh = make_bbmodel_cube_mesh(
                elem.get("name", "Element"),
                from_scaled,
                to_scaled,
                elem_origin,
                stretch,
                faces,
                mesh_build_context["atlas_by_texture_index"],
                mesh_build_context["generate_uvs"],
            )
            obj = bpy.data.objects.new(elem.get("name", "Element"), mesh)

            # Collection do bone dono ("{bone} - {armature}"); sem group ancestral fica solto em target_collection.
            if parent_bone_name is not None:
                mesh_collection = resolve_mesh_bone_collection(
                    mesh_build_context["bone_collection_cache"],
                    mesh_build_context["target_collection"],
                    mesh_build_context["armature_obj"].name,
                    parent_bone_name,
                    mesh_build_context["ancestor_fn"],
                )
                mesh_collection.objects.link(obj)
            else:
                mesh_build_context["target_collection"].objects.link(obj)

            tex_index = next((f.get("texture") for f in faces.values() if f.get("texture") is not None), None)
            material = mesh_build_context["material_by_texture_index"].get(tex_index)
            if material is not None:
                obj.data.materials.append(material)

            armature_obj = mesh_build_context["armature_obj"]
            if parent_bone_name is not None:
                obj.parent = armature_obj
                obj.matrix_world = armature_obj.matrix_world @ obj_matrix

                vgroup = obj.vertex_groups.new(name=parent_bone_name)
                vgroup.add(range(len(mesh.vertices)), 1.0, "REPLACE")

                armature_mod = obj.modifiers.new(name="Armature", type="ARMATURE")
                armature_mod.object = armature_obj
            else:
                # Raro: element sem group ancestral; só posiciona a malha, sem deform.
                obj.matrix_world = armature_obj.matrix_world @ obj_matrix
                mesh_build_context["settings"].report(
                    {"WARNING"},
                    f"'{elem.get('name', 'Element')}' is a root-level element with no "
                    f"owning bone -- imported as a static mesh (not skinned).",
                )

            stats["meshes"] += 1
            continue

        # Não-string: nó de group de verdade, com seus próprios filhos.
        group = groups_by_uuid.get(child["uuid"])
        if group is None:
            continue

        name = group.get("name", "Bone")
        origin = Vector(group.get("origin", [0, 0, 0])) * unit_scale
        rotation_deg = group.get("rotation", [0, 0, 0])

        world_pos = ancestor_pivot_matrix @ origin
        own_rotation = ancestor_rotation_matrix @ bb_euler_matrix(rotation_deg)

        final_name = unique_bone_name(name, edit_bones)
        if final_name != name:
            mesh_build_context["settings"].report(
                {"WARNING"},
                f"Duplicate bone name '{name}' inside this .bbmodel -- renamed to "
                f"'{final_name}' in Blender. Original name preserved in the "
                f"'{BONE_ORIGINAL_NAME_PROP}' custom property for the exporter to use.",
            )

        bone = edit_bones.new(final_name)
        bone.head = (0, 0, 0)
        bone.tail = (0, BONE_DISPLAY_LENGTH_GAME_UNITS * unit_scale, 0)
        bone.matrix = Matrix.Translation(world_pos) @ own_rotation
        store_import_rest(bone)  # ver BONE_IMPORT_REST_PROP (common.py)
        if final_name != name:
            bone[BONE_ORIGINAL_NAME_PROP] = name

        if parent_bone_name is not None and parent_bone_name in edit_bones:
            bone.parent = edit_bones[parent_bone_name]
            bone.use_connect = False

        stats["bones"] += 1

        # BONE_SHAPE_JSON_PROP é lista: [shape do bone (offset já corrigido, ou {}), {shape, position, orientation}, ...].
        # Cada element direto: rotação nula dobra no shape do bone (offset + posição local); com rotação própria, ou cubo
        # além do primeiro, vira node filho sintético no export (o .blockymodel só tem 1 shape por node).
        direct_element_uuids = [c for c in child.get("children", []) if isinstance(c, str)]
        if direct_element_uuids:
            group_world_matrix = bone.matrix.copy()
            children_pivot_matrix = ancestor_pivot_matrix @ bb_rotate_around_pivot(origin, rotation_deg)
            children_rotation_matrix = own_rotation

            primary_shape = None
            extra_entries = []
            total_uv_skipped = 0
            for elem_uuid in direct_element_uuids:
                elem = elements_by_uuid.get(elem_uuid)
                if elem is None:
                    continue
                element_shapes, n_uv_skipped = bbmodel_element_to_shapes(elem)
                shape = element_shapes[0]
                total_uv_skipped += n_uv_skipped
                local_pos_raw, local_orient, is_identity = bbmodel_element_local_transform(
                    group_world_matrix, children_pivot_matrix, children_rotation_matrix, elem, unit_scale,
                )
                # Quad do lado de trás (plano com textura nos 2 lados) --
                # sempre peça extra, no MESMO lugar/orientação do element.
                for back_shape in element_shapes[1:]:
                    extra_entries.append({
                        "shape": back_shape,
                        "position": {"x": round(local_pos_raw.x, 6), "y": round(local_pos_raw.y, 6), "z": round(local_pos_raw.z, 6)},
                        "orientation": local_orient,
                    })
                if primary_shape is None and is_identity:
                    shape["offset"] = {
                        "x": round(shape["offset"]["x"] + local_pos_raw.x, 6),
                        "y": round(shape["offset"]["y"] + local_pos_raw.y, 6),
                        "z": round(shape["offset"]["z"] + local_pos_raw.z, 6),
                    }
                    primary_shape = shape
                else:
                    extra_entries.append({
                        "shape": shape,
                        "position": {"x": round(local_pos_raw.x, 6), "y": round(local_pos_raw.y, 6), "z": round(local_pos_raw.z, 6)},
                        "orientation": local_orient,
                    })

            # Extras relativos ao pivô; o .blockymodel soma o offset do pai, então tira o offset primário já aqui.
            primary_offset = primary_shape["offset"] if primary_shape else {"x": 0.0, "y": 0.0, "z": 0.0}
            for entry in extra_entries:
                entry["position"] = {
                    "x": round(entry["position"]["x"] - primary_offset["x"], 6),
                    "y": round(entry["position"]["y"] - primary_offset["y"], 6),
                    "z": round(entry["position"]["z"] - primary_offset["z"], 6),
                }

            shapes_list = [primary_shape if primary_shape is not None else {}] + extra_entries
            bone[BONE_SHAPE_JSON_PROP] = json.dumps(shapes_list)
            offset_scaled = Vector((primary_offset["x"], primary_offset["y"], primary_offset["z"])) * unit_scale
            bone[BONE_SHAPE_OFFSET_PROP] = tuple(offset_scaled)

        else:
            bone[BONE_SHAPE_JSON_PROP] = json.dumps([])

        # uuid -> nome final do bone, registrado assim que o bone nasce (antes dos filhos).
        mesh_build_context["group_uuid_to_bone_name"][child["uuid"]] = bone.name
        mesh_build_context["bone_name_to_group_uuid"][bone.name] = child["uuid"]

        child_ancestor_pivot = ancestor_pivot_matrix @ bb_rotate_around_pivot(origin, rotation_deg)
        build_bbmodel_recursive(
            armature_data,
            child.get("children", []),
            bone.name,
            child_ancestor_pivot,
            own_rotation,
            groups_by_uuid,
            elements_by_uuid,
            unit_scale,
            stats,
            mesh_build_context,
            parent_group_uuid=child["uuid"],
        )


def derive_default_bbmodel_name(filepath, data):
    """Nome padrão: o "name" do projeto, senão o nome do arquivo."""
    name = (data.get("name") or "").strip()
    if name:
        return name
    base = os.path.basename(filepath)
    if base.lower().endswith(".bbmodel"):
        base = base[: -len(".bbmodel")]
    return base or "Hytale_Rig"


def resolve_bbmodel_format(choice, data):
    """Character/Prop de um .bbmodel pelo meta.model_format; outro formato de projeto = character."""
    if choice != "AUTO":
        return MODEL_FORMAT_PROP if choice == "PROP" else MODEL_FORMAT_CHARACTER
    return normalize_model_format((data.get("meta") or {}).get("model_format"))


# --- Operador: import de .bbmodel (só cria Armature novo) ---


def _bbmodel_import_props(lang):
    return {
        "filter_glob": StringProperty(default="*.bbmodel", options={"HIDDEN"}),
        "model_format": model_format_enum(lang, "bbmodel"),
        **import_option_props(lang, "bbmodel", (
            "armature_name", "orient_z_up", "unit_scale", "generate_reference_boxes", "flat_mesh_collections",
            "generate_uvs", "create_material",
        )),
    }


@localized_props(_bbmodel_import_props)
class IMPORT_OT_hytale_bbmodel(Operator, ImportHelper):
    """Import a Hytale character/creature from a Blockbench project (.bbmodel)"""

    bl_idname = "import_scene.hytale_bbmodel"
    bl_label = "Import Hytale Model (.bbmodel)"
    description = tooltip("importer.tooltip.bbmodel")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return game_found()          # sem a pasta do jogo o addon fica travado (common.game_found)

    filename_ext = ".bbmodel"

    def draw(self, context):
        layout = self.layout
        lang = get_language(context)

        target_box = layout.box()
        target_box.label(text=tr("importer.section_target", lang))
        target_box.prop(self, "armature_name", text=tr("importer.armature_name", lang))

        draw_rig_section(layout, self, lang)
        draw_mesh_section(layout, self, lang)

    def execute(self, context):
        with open(self.filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        model_format = resolve_bbmodel_format(self.model_format, data)
        result, _armature_obj = import_bbmodel_data(self, context, data, self.filepath, model_format)
        return result


def import_bbmodel_data(operator, context, data, filepath, model_format, preloaded_images=None):
    """Núcleo do import de .bbmodel, também pra dicts montados em memória (converter/bedrock.py).
    `operator`: algo com armature_name, orient_z_up, unit_scale, generate_reference_boxes, create_material,
    flat_mesh_collections, generate_uvs e report(). `preloaded_images`: {índice: Image ou [principal, variantes]}.
    Devolve ({"FINISHED"}|{"CANCELLED"}, armature ou None)."""
    self = operator
    outliner_roots = data.get("outliner", [])
    if not outliner_roots:
        self.report({"ERROR"}, "No outliner data found in the file (.bbmodel is empty or invalid).")
        return {"CANCELLED"}, None

    groups_by_uuid = {g["uuid"]: g for g in data.get("groups", [])}
    elements_by_uuid = {e["uuid"]: e for e in data.get("elements", [])}

    # Sem a chave "texture" = face real sem textura (diferente de null = escondida; vem de modelos convertidos).
    # Com 1 textura no arquivo usa ela; senão o sentinel (só UV, sem material).
    project_textures = data.get("textures", [])
    unassigned_tex_index = 0 if len(project_textures) == 1 else BBMODEL_UNASSIGNED_TEXTURE
    for element in elements_by_uuid.values():
        for face_info in (element.get("faces") or {}).values():
            if isinstance(face_info, dict) and "texture" not in face_info:
                face_info["texture"] = unassigned_tex_index

    resolved_name = self.armature_name.strip() or derive_default_bbmodel_name(filepath, data)
    # Collections do personagem + formato (Character 64/bloco, Prop 32/bloco) gravado na Armature.
    armature_obj, main_collection = _build.new_armature(context, resolved_name, model_format)
    armature_data = armature_obj.data
    scale = effective_unit_scale(self.unit_scale, model_format)

    context.view_layer.objects.active = armature_obj
    armature_obj.select_set(True)

    # Texturas decodificadas antes do Edit Mode (os tamanhos de atlas já ficam prontos).
    atlas_by_texture_index = {}
    material_by_texture_index = {}
    if self.generate_reference_boxes and self.create_material:
        for idx, tex_entry in enumerate(data.get("textures", [])):
            preloaded = (preloaded_images or {}).get(idx)
            images = list(preloaded) if isinstance(preloaded, (list, tuple)) else [preloaded]
            images = [img for img in images if img is not None]
            if not images:
                decoded = decode_bbmodel_texture(tex_entry)
                images = [decoded] if decoded is not None else []
            if not images:
                continue
            image = images[0]
            atlas_by_texture_index[idx] = (image.size[0], image.size[1])
            name = os.path.splitext(tex_entry.get("name") or "Hytale_Material")[0]
            material_by_texture_index[idx] = api.model.materials.flat_material(image, name=name, variants=images[1:])
    # Atlas do sentinel: tamanho declarado do projeto.
    resolution = data.get("resolution") or {}
    atlas_by_texture_index[BBMODEL_UNASSIGNED_TEXTURE] = (
        resolution.get("width", 16) or 16,
        resolution.get("height", 16) or 16,
    )

    # Pré-scan (modo aninhado) dos groups com malha direta e seus pais.
    if self.flat_mesh_collections:
        uuids_with_direct_mesh, uuid_parent_map = set(), {}
    else:
        uuids_with_direct_mesh, uuid_parent_map = prescan_bbmodel_mesh_groups(outliner_roots, groups_by_uuid)

    mesh_build_context = {
        "target_collection": main_collection,
        "armature_obj": armature_obj,
        "atlas_by_texture_index": atlas_by_texture_index,
        "material_by_texture_index": material_by_texture_index,
        "generate_meshes": self.generate_reference_boxes,
        "generate_uvs": self.generate_reference_boxes and self.generate_uvs,
        "settings": self,
        # Cache de resolve_mesh_bone_collection desta chamada.
        "bone_collection_cache": {},
        # uuid <-> nome final do bone, preenchidos ao vivo durante build_bbmodel_recursive.
        "group_uuid_to_bone_name": {},
        "bone_name_to_group_uuid": {},
        "uuids_with_direct_mesh": uuids_with_direct_mesh,
        "uuid_parent_map": uuid_parent_map,
    }
    # ancestor_fn depois do dict (lê ele ao vivo).
    mesh_build_context["ancestor_fn"] = make_bbmodel_ancestor_fn(mesh_build_context)

    # Mesma cautela do import de .blockymodel -- ver a nota grande em
    # model/build.py do núcleo sobre X-Axis Mirror.
    original_use_mirror_x = armature_data.use_mirror_x
    if original_use_mirror_x:
        armature_data.use_mirror_x = False

    stats = {"bones": 0, "meshes": 0}
    bpy.ops.object.mode_set(mode="EDIT")
    try:
        build_bbmodel_recursive(
            armature_data,
            outliner_roots,
            None,
            Matrix.Identity(4),
            Matrix.Identity(4),
            groups_by_uuid,
            elements_by_uuid,
            scale,
            stats,
            mesh_build_context,
        )
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        if original_use_mirror_x:
            armature_data.use_mirror_x = original_use_mirror_x

    if self.orient_z_up:
        armature_obj.rotation_euler = Euler((math.radians(90.0), 0.0, 0.0), "XYZ")

    context.view_layer.update()

    self.report(
        {"INFO"},
        f"Imported {stats['bones']} bone(s) and {stats['meshes']} mesh(es) from '{resolved_name}' "
        f"({model_format}, scale={scale:.5f}).",
    )
    return {"FINISHED"}, armature_obj
