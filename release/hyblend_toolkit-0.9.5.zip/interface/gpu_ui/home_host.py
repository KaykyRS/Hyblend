"""Home do Hyblend em TELA CHEIA desenhada por cima do Blender (0.9.5).

Irmão do OverlayHost (framework/overlay.py), mas ocupando a janela inteira
(veio do protótipo "Hyblend Home"):
  1. a maior 3D Viewport da janela vira tela cheia
     (`screen.screen_full_area(use_hide_panels=True)`, o Ctrl+Alt+Espaço:
     some topbar e status bar);
  2. o tela cheia já esconde header, toolbar e sidebar; a Home esconde o
     resto (tool header, gizmos, overlays) e devolve ao fechar -- sobra UMA
     região (WINDOW) do tamanho da janela;
  3. um draw handler POST_PIXEL desenha a árvore de widgets numa textura
     (só quando algo muda) e copia pra tela.

Fechar (Esc, "Ir para o Blender", abrir/criar arquivo): o modal termina e
um timer -- FORA do modal -- devolve os painéis e volta do tela cheia. Ações
que mexem em arquivo rodam depois disso, no mesmo timer.

Eventos (modal da janela): tudo em cima da Home é comido; Esc fecha; atalhos
com Ctrl/Alt/Cmd e F1-F24 fecham a Home e seguem pro Blender (Ctrl+O, F4...).
Rolagem: roda, botão do meio e arrasto da barra (o OverlayHost não tinha).
Clique direito: `on_context(f, x, y)` do widget (mesma convenção do Toolkit);
o menu que ele abre vive em state["_popup"] -- Esc, rolagem ou clique fora fecham.
"""

import time
import traceback
from types import SimpleNamespace

import bpy
from bpy.app.handlers import persistent

from .framework.core import Frame, Rect, draw_tooltip, find_by_key, scroll_target
from .framework.motion import animate, forget, prune
from .framework.renderer import Renderer, render_to_texture
from .framework.runtime import FKEY, is_keyboard

ENTER_DURATION = 0.35
READY_TIMEOUT = 1.5         # espera a arte (fundo 1920x1080 incluso) antes de aparecer, no máx.
SAFETY_REFRESH = 2.0
TICK_FAST, TICK_IDLE = 1 / 60, 0.25
TOOLTIP_DELAY = 0.6
WHEEL_STEP = 64.0

_EAT = {"RUNNING_MODAL"}
_PASS = {"PASS_THROUGH"}
# Modificadoras apertadas SOZINHAS (Alt+Tab, segurar Ctrl...) não são atalho: não fecham a Home.
_MODIFIER_KEYS = {"LEFT_CTRL", "RIGHT_CTRL", "LEFT_ALT", "RIGHT_ALT", "LEFT_SHIFT", "RIGHT_SHIFT", "OSKEY",
                  "HYPER", "APP"}
_REGION_TYPES = ("WINDOW", "UI", "TOOLS", "HEADER", "TOOL_HEADER", "ASSET_SHELF", "ASSET_SHELF_HEADER",
                 "FOOTER", "HUD")
# Flags da View3D escondidas enquanto a Home está aberta (restauradas ao fechar).
# NÃO entram show_region_hud / show_region_asset_shelf: o update deles chama
# ED_area_init numa região que pode nem existir -> crash nativo (Blender 5.2,
# rna_Space_show_region_hud_update, achado pelo autor ao fechar a Home).
#
# screen_full_area(use_hide_panels=True) JÁ esconde (e devolve ao sair) header,
# toolbar e sidebar da View3D -- mexer neles também fazia o Blender "devolver"
# o valor errado (lido já escondido) e o header sumia de vez (achado pelo
# autor). Então: sempre só o que o Blender não esconde; os painéis só quando
# NÓS não entramos no tela cheia (a área já estava em tela cheia antes).
_SPACE_FLAGS = ("show_region_tool_header", "show_gizmo")
_PANEL_FLAGS = ("show_region_header", "show_region_toolbar", "show_region_ui")


def _set_flag(owner, name, value):
    """Só escreve se mudou (todo setattr dispara o update da região)."""
    try:
        if getattr(owner, name) != value:
            setattr(owner, name, value)
    except Exception:
        traceback.print_exc()

_app = SimpleNamespace(build=None, theme=None, scale=None, text=None, on_close=None)
_host = [None]
_session = {}               # tela cheia aberta por nós: ponteiros + flags pra restaurar


def _fkey(event_type):
    return bool(FKEY.match(event_type))


def configure(build, theme, scale=None, text=None, on_close=None):
    _app.build, _app.theme, _app.scale, _app.text, _app.on_close = build, theme, scale, text, on_close


def is_open():
    host = _host[0]
    return host is not None and not host.closed


def is_ready():
    """A Home já está desenhando (arte carregada ou tempo de espera vencido)?"""
    host = _host[0]
    return host is not None and not host.closed and host._ready


def refresh_all():
    host = _host[0]
    if host is not None and not host.closed:
        host.request()


def _largest_view3d(window):
    areas = [a for a in window.screen.areas if a.type == "VIEW_3D"]
    return max(areas, key=lambda a: a.width * a.height) if areas else None


def _window_region(area):
    return next((r for r in area.regions if r.type == "WINDOW"), None)


# --------------------------------------------------------------------------
# Abrir / fechar (sempre FORA de draw handler e de outro operador: timer)
# --------------------------------------------------------------------------

def open_home(window):
    """Tela cheia na maior View3D + modal da Home. Devolve True se abriu."""
    if is_open() or window is None:
        return is_open()
    area = _largest_view3d(window)
    if area is None:
        print("[Hyblend] Home: no 3D Viewport in this window: Home not opened")
        return False
    toggled = False
    if not window.screen.show_fullscreen:
        try:
            with bpy.context.temp_override(window=window, screen=window.screen, area=area,
                                           region=_window_region(area)):
                bpy.ops.screen.screen_full_area(use_hide_panels=True)
            toggled = True
        except Exception:
            traceback.print_exc()
            return False
        area = _largest_view3d(window)       # a área de tela cheia é outra
        if area is None:
            return False
    space = area.spaces.active
    flags = {}
    for name in _SPACE_FLAGS + (() if toggled else _PANEL_FLAGS):
        if hasattr(space, name):
            flags[name] = getattr(space, name)
            _set_flag(space, name, False)
    overlays = getattr(space.overlay, "show_overlays", None)
    if overlays is not None:
        _set_flag(space.overlay, "show_overlays", False)
    _session.clear()
    _session.update(window=window.as_pointer(), toggled=toggled, flags=flags, overlays=overlays)
    region = _window_region(area)
    try:
        with bpy.context.temp_override(window=window, screen=window.screen, area=area, region=region):
            bpy.ops.hyblend.home_host("INVOKE_DEFAULT")
    except Exception:
        traceback.print_exc()
        restore_layout()
        return False
    return is_open()


def _find_window(ptr):
    wm = bpy.context.window_manager
    return next((w for w in (wm.windows if wm else ()) if w.as_pointer() == ptr), None)


def restore_layout(after_load=False, then=None, sync=False):
    """Devolve o layout (só o que NÓS mudamos) e depois roda `then(window)`.

    Em DOIS tiques, nesta ordem:
      1. sai do tela cheia com o MESMO operador que entrou
         (screen_full_area(use_hide_panels=True) = Ctrl+Alt+Espaço). O
         back_to_previous devolvia as áreas mas deixava a topbar/status bar
         escondidas (achado pelo autor no 5.2);
      2. no tique seguinte -- com as áreas já redimensionadas pelo Blender --
         devolve o que a Home escondeu (tool header, gizmos, overlays; os
         painéis só se a área já estava em tela cheia antes) e roda `then`.
    after_load: um .blend abriu com a Home aberta -- se a UI veio do arquivo,
    a tela cheia sumiu junto (nada a fazer); se ficou, restaura."""
    if not _session:
        if then is not None:
            wm = bpy.context.window_manager
            _run_then(then, wm.windows[0] if wm and wm.windows else None)
        return
    session = dict(_session)
    _session.clear()
    wm = bpy.context.window_manager
    window = (wm.windows[0] if wm.windows else None) if after_load else _find_window(session["window"])
    if window is None or (after_load and not window.screen.show_fullscreen):
        return
    area = _largest_view3d(window)
    if area is not None and session["toggled"] and window.screen.show_fullscreen:
        try:
            with bpy.context.temp_override(window=window, screen=window.screen, area=area,
                                           region=_window_region(area)):
                bpy.ops.screen.screen_full_area(use_hide_panels=True)
        except Exception:
            traceback.print_exc()
    ptr = window.as_pointer()

    def step2():
        win = _find_window(ptr)
        view = _largest_view3d(win) if win is not None else None
        if view is not None:
            space = view.spaces.active
            for name, value in session["flags"].items():
                _set_flag(space, name, value)
            if session["overlays"] is not None:
                _set_flag(space.overlay, "show_overlays", session["overlays"])
            view.tag_redraw()
        if then is not None:
            _run_then(then, win)
        return None
    if sync:        # unregister: nenhum timer pode sobrar depois do addon sair
        step2()
        return
    bpy.app.timers.register(step2, first_interval=0.05)


def _run_then(then, window):
    try:
        then(window or bpy.context.window_manager.windows[0])
    except Exception:
        traceback.print_exc()


def close_home(then=None):
    """Fecha (se aberta) e roda `then(window)` depois do layout voltar."""
    host = _host[0]
    if host is not None and not host.closed:
        host.close()
    bpy.app.timers.register(lambda: (restore_layout(then=then), None)[1], first_interval=0.0)


# --------------------------------------------------------------------------
# Host
# --------------------------------------------------------------------------

class HomeHost:
    def __init__(self, context):
        self.ptrs = (context.window.as_pointer(), context.area.as_pointer())
        self.window = context.window
        self.state = {}
        self.theme = _app.theme
        self.renderer = Renderer()
        self.tree = None
        self.closed = False
        self.scale = 1.0
        self.screen = Rect(0, 0, 0, 0)
        self._offscreen = None
        self._dirty = True
        self._animating = True
        self._opened = time.monotonic()
        self._ready = False
        self._tooltip_waiting = False
        self._built_at = 0.0
        self._size_key = None
        self._timer = None
        self._tick = None
        self._handles = []
        for region_type in _REGION_TYPES:
            try:
                handle = bpy.types.SpaceView3D.draw_handler_add(self.on_draw, (), region_type, "POST_PIXEL")
            except (TypeError, ValueError):
                continue
            self._handles.append((handle, region_type))
        self._set_tick(TICK_FAST)
        _host[0] = self
        self.request()

    # ---------------------------------------------------------------- estado
    def lookup(self):
        """(janela, área, viewport, viewport) -- formato que bind/UI esperam."""
        window = _find_window(self.ptrs[0])
        if window is None:
            return None
        for area in window.screen.areas:
            if area.as_pointer() == self.ptrs[1]:
                viewport = _window_region(area)
                return (window, area, viewport, viewport) if viewport else None
        return None

    def request(self, content=True):
        if content:
            self._dirty = True
        found = self.lookup()
        if found is not None:
            for region in found[1].regions:
                region.tag_redraw()

    def _set_tick(self, interval):
        if self.closed or interval == self._tick:
            return
        wm = bpy.context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
        self._timer = wm.event_timer_add(interval, window=self.window)
        self._tick = interval

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.state.pop("_mmb", None):           # fechou rolando com o botão do meio
            try:
                self.window.cursor_modal_restore()
            except Exception:
                pass
        for handle, kind in self._handles:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, kind)
            except (ValueError, ReferenceError):
                pass
        self._handles = []
        if self._timer is not None:
            try:
                bpy.context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        if _host[0] is self:
            _host[0] = None
        self.request(content=False)
        self.tree = self._offscreen = None
        if _app.on_close is not None:
            try:
                _app.on_close()
            except Exception:
                traceback.print_exc()

    # ----------------------------------------------------------------- desenho
    def on_draw(self):
        context = bpy.context
        region, area = context.region, context.area
        if self.closed or self._failed or region is None or area is None or area.as_pointer() != self.ptrs[1]:
            return
        try:
            found = self.lookup()
            if found is None:
                return
            viewport = found[2]
            r = self.renderer
            if region.as_pointer() != viewport.as_pointer():
                # Região que sobrou visível (não deveria): cobre com o fundo do tema.
                r.cover(0, 0, region.width, region.height, self.theme.canvas)
                return
            now = time.monotonic()
            self._render(context, viewport, now)
            # Base opaca SEMPRE: até a arte chegar (e durante a entrada) a cena
            # 3D nunca aparece por baixo.
            r.cover(0, 0, viewport.width, viewport.height, _linear(self.theme.canvas))
            if self._ready and self._offscreen is not None:
                alpha = animate(self.state, "home.reveal", 1.0, ENTER_DURATION, initial=0.0, now=now)
                self._revealing = alpha < 0.999
                r.blit(self._offscreen.texture_color, 0, 0, self._offscreen.width, self._offscreen.height,
                       opacity=alpha, linear=True)
            self._schedule()
        except Exception:
            # Erro no desenho: um traceback e UM pedido de fechar (o handler não
            # pode ser removido de dentro do desenho, nem repetir o erro a cada quadro).
            traceback.print_exc()
            self._failed = True
            bpy.app.timers.register(lambda: (close_home(), None)[1], first_interval=0.0)

    _revealing = True
    _failed = False

    def _schedule(self):
        busy = self._animating or self._revealing or self._tooltip_waiting or not self._ready
        self._set_tick(TICK_FAST if busy else TICK_IDLE)

    def _measure(self, context, viewport):
        extra = _app.scale(context) if _app.scale else 1.0
        s = max(0.1, context.preferences.system.ui_scale * extra)
        return s, viewport.width / s, viewport.height / s

    def _render(self, context, viewport, now):
        s, vw, vh = self._measure(context, viewport)
        size_key = (s, viewport.width, viewport.height)
        stale = now - self._built_at >= SAFETY_REFRESH
        if not (self._dirty or self._animating or stale or size_key != self._size_key):
            return False
        self.scale = s
        st = self.state
        st["_motion_active"] = False
        st["_mouse_rects"] = []
        st.pop("_wake_at", None)
        f = Frame(self.renderer, st, self.theme, context, now, host=self)
        self.screen = Rect(0, 0, vw, vh)
        self.tree = _app.build(f)
        self._built_at = now
        self.tree.extent(f, vw)
        self.tree.layout(f, self.screen)

        def draw():
            self.tree.draw(f)
            self._tooltip_waiting = self._draw_tooltip(f)
        r = self.renderer
        self._offscreen = render_to_texture(self._offscreen, r, s, 0, 0, viewport.width, viewport.height, draw)
        self._size_key = size_key
        self._dirty = False
        self._animating = bool(st.get("_motion_active")) or r.pending_images
        if not self._ready and (not r.pending_images or now - self._opened >= READY_TIMEOUT):
            self._ready = True
            forget(st, "home.reveal")
        prune(st, now)
        return True

    def _draw_tooltip(self, f):
        st = self.state
        key = st.get("_hover")
        if not key or st.get("_pressed") or st.get("_drag") or st.get("_tooltip_off"):
            return False
        widget = find_by_key(self.tree, key)
        if widget is None or not widget.tooltip:
            return False
        if f.now - st.get("_hover_since", f.now) < TOOLTIP_DELAY:
            return True
        text = widget.tooltip() if callable(widget.tooltip) else widget.tooltip
        if text:
            draw_tooltip(f, key, text, st.get("_hover_pos", f.mouse), self.screen)
        return False

    # ----------------------------------------------------------------- eventos
    def frame(self, context=None):
        return Frame(self.renderer, self.state, self.theme, context or bpy.context, time.monotonic(), host=self)

    def on_event(self, context, event):
        st = self.state
        now = time.monotonic()
        found = self.lookup()
        if found is None:
            self.close()
            return {"CANCELLED"}
        if event.type == "TIMER":
            return self._on_tick(now)
        if event.type.startswith(("WINDOW", "TIMER")):
            return _PASS

        viewport = found[2]
        s = self.scale
        x = (event.mouse_x - viewport.x) / s
        y = (event.mouse_y - viewport.y) / s
        previous = st.get("_mouse", (x, y))
        st["_mouse"] = (x, y)

        if event.type == "ESC" and event.value == "PRESS":
            if st.pop("_popup", None):           # menu de contexto aberto: Esc fecha só ele
                self.request()
                return _EAT
            close_home()
            return {"FINISHED"}
        if is_keyboard(event.type):
            if event.type in _MODIFIER_KEYS:
                return _EAT
            if event.value == "PRESS" and (event.ctrl or event.alt or event.oskey or _fkey(event.type)):
                close_home()                   # Ctrl+O, F4...: o Blender recebe com o layout de volta
                return {"FINISHED", "PASS_THROUGH"}
            return _EAT
        if not self._ready or self.tree is None:
            return _EAT

        f = self.frame(context)

        # arrasto em andamento (barra de rolagem)
        drag = st.get("_drag")
        if drag:
            widget = find_by_key(self.tree, drag["key"])
            if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
                if widget is not None:
                    widget.drag(f, x, y, drag["data"])
                self.request()
            elif event.type == "LEFTMOUSE" and event.value == "RELEASE":
                if widget is not None:
                    widget.end_drag(f, drag["data"], False)
                st.pop("_drag", None)
                self.request()
            return _EAT

        # rolagem com o botão do meio
        mmb = st.get("_mmb")
        if mmb:
            if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
                view = find_by_key(self.tree, mmb["key"])
                if view is not None:
                    st[mmb["key"]] = min(view.max_scroll, max(0.0, mmb["start"] + (y - mmb["y"])))
                    forget(st, mmb["key"] + ".anim")
                    self.request()
            elif event.type == "MIDDLEMOUSE" and event.value == "RELEASE":
                st.pop("_mmb", None)
                self.window.cursor_modal_restore()
                self.request()
            return _EAT

        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            hit = self.tree.hit(x, y)
            key = hit.key if hit else None
            if key != st.get("_hover"):
                old = st.get("_hover")
                st["_hover"], st["_hover_since"], st["_hover_pos"] = key, now, (x, y)
                st.pop("_tooltip_off", None)
                forget(st, "tip.%s" % old)
                self.request()
            elif any(r.contains(px, py) for r in st.get("_mouse_rects", ()) for px, py in ((x, y), previous)):
                self.request()
            return _EAT

        if st.get("_popup") and (event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE", "TRACKPADPAN"}
                                 or (event.type == "MIDDLEMOUSE" and event.value == "PRESS")):
            st.pop("_popup", None)                # rolar com o menu aberto: fecha o menu
            self.request()
            return _EAT

        if event.type == "RIGHTMOUSE":
            if event.value == "PRESS":
                hit = self.tree.hit(x, y)
                handler = getattr(hit, "on_context", None)
                st.pop("_popup", None)            # clique direito em outro lugar fecha o anterior
                st["_tooltip_off"] = True
                if handler is not None:
                    try:
                        handler(f, x, y)
                    except Exception as error:
                        traceback.print_exc()
                        f.toast("%s %s" % (self._t("home.error_prefix", "Error:"), error), error=True)
                self.request()
            return _EAT

        if event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE", "TRACKPADPAN"}:
            view = scroll_target(self.tree, x, y)
            if view is not None:
                if event.type == "TRACKPADPAN":
                    delta = (event.mouse_prev_y - event.mouse_y) / s
                else:
                    delta = -WHEEL_STEP if event.type == "WHEELUPMOUSE" else WHEEL_STEP
                view.scroll_by(f, delta)
                st["_tooltip_off"] = True
                self.request()
            return _EAT

        if event.type == "MIDDLEMOUSE" and event.value == "PRESS":
            view = scroll_target(self.tree, x, y)
            if view is not None and view.max_scroll > 0:
                st["_mmb"] = {"key": view.key, "y": y, "start": st.get(view.key, 0.0)}
                self.window.cursor_modal_set("SCROLL_Y")
                st["_tooltip_off"] = True
            return _EAT

        if event.type == "LEFTMOUSE":
            hit = self.tree.hit(x, y)
            if event.value in {"PRESS", "DOUBLE_CLICK"}:
                st["_tooltip_off"] = True
                if hit is not None and hit.interactive:
                    data = hit.begin_drag(f, x, y)
                    if data is not None:
                        st["_drag"] = {"key": hit.key, "data": data}
                    else:
                        st["_pressed"] = hit.key
                self.request()
            elif event.value == "RELEASE":
                pressed = st.pop("_pressed", None)
                if hit is not None and pressed == hit.key:
                    try:
                        hit.on_click(f, x, y)
                    except Exception as error:
                        traceback.print_exc()
                        f.toast("%s %s" % (self._t("home.error_prefix", "Error:"), error), error=True)
                self.request()
            if self.closed:
                return {"FINISHED"}
            return _EAT
        return _EAT

    def _t(self, key, fallback):
        try:
            return _app.text(key) if _app.text else fallback
        except Exception:
            return fallback

    def _on_tick(self, now):
        st = self.state
        wants = self._animating or not self._ready
        if self._tooltip_waiting and now - st.get("_hover_since", now) >= TOOLTIP_DELAY:
            wants = True
        if st.get("_wake_at") is not None and now >= st["_wake_at"]:
            wants = True
        if wants:
            self.request()
        elif self._revealing:
            self.request(content=False)
        self._schedule()
        return _PASS


def _linear(c):
    return tuple(max(0.0, v) ** 2.2 for v in c[:3]) + (c[3],)


# --------------------------------------------------------------------------
# Operador modal
# --------------------------------------------------------------------------

class HYBLEND_OT_home_host(bpy.types.Operator):
    bl_idname = "hyblend.home_host"
    bl_label = "Hyblend Home"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        if is_open() or context.area is None or context.area.type != "VIEW_3D":
            return {"CANCELLED"}
        self._host = HomeHost(context)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        host = self._host
        if host.closed:
            return {"CANCELLED"}
        try:
            return host.on_event(context, event)
        except Exception:
            traceback.print_exc()
            close_home()
            return {"CANCELLED"}

    def cancel(self, context):
        self._host.close()


@persistent
def _before_load(*_):
    """Abrir .blend por outro caminho: os modais morrem. Fecha o host já; o
    layout (tela cheia/flags) é devolvido no load_post se a UI não veio do
    arquivo."""
    host = _host[0]
    if host is not None:
        host.close()


@persistent
def _after_load(*_):
    # (as fontes do blf.load são esquecidas pelo load_post do runtime.py)
    if _session:
        bpy.app.timers.register(lambda: (restore_layout(after_load=True), None)[1], first_interval=0.0)


CLASSES = (HYBLEND_OT_home_host,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    if _before_load not in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.append(_before_load)
    if _after_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_after_load)


def unregister():
    host = _host[0]
    if host is not None:
        host.close()
    restore_layout(sync=True)
    for handlers, fn in ((bpy.app.handlers.load_pre, _before_load), (bpy.app.handlers.load_post, _after_load)):
        if fn in handlers:
            handlers.remove(fn)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    # texturas/fontes: liberadas pelo runtime.unregister (gpu_ui.unregister)
