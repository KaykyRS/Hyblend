"""Auto-Rigger -- helpers de constraint/driver/switch e cálculo de pole angle."""

import bpy
from mathutils import Vector

from ..translations import get_language, tr

from .constants import (
    CONSTRAINT_IK,
    PROP_FK_IK_SWITCH,
    PROP_RIG_LAYER,
    _COPY_CONSTRAINT_TYPES,
)


def ensure_copy_constraint(pose_bone, target_obj, subtarget_name, copy_type, name, space="LOCAL", head_tail=None):
    con = pose_bone.constraints.get(name)
    if con is None:
        con = pose_bone.constraints.new(_COPY_CONSTRAINT_TYPES[copy_type])
        con.name = name
    con.target = target_obj
    con.subtarget = subtarget_name
    con.target_space = space
    con.owner_space = space
    con.mute = False
    if head_tail is not None and copy_type == "LOCATION":  # head_tail só existe em COPY_LOCATION
        con.head_tail = head_tail
    return con


def ensure_copy_set(pose_bone, target_obj, subtarget_name, name_prefix, types=("LOCATION", "ROTATION", "SCALE"), space="LOCAL"):
    result = {}
    for copy_type in types:
        cname = f"{name_prefix}_{copy_type.title()}"
        result[copy_type] = ensure_copy_constraint(pose_bone, target_obj, subtarget_name, copy_type, cname, space=space)
    return result


def ensure_ik_constraint(pose_bone, armature_obj, target_name, pole_name, chain_count, pole_angle_rad):
    con = pose_bone.constraints.get(CONSTRAINT_IK)
    if con is None:
        con = pose_bone.constraints.new("IK")
        con.name = CONSTRAINT_IK
    con.target = armature_obj
    con.subtarget = target_name
    con.pole_target = armature_obj
    con.pole_subtarget = pole_name
    con.chain_count = chain_count
    con.pole_angle = pole_angle_rad
    con.use_tail = True
    return con


def ensure_child_of_constraint(pose_bone, armature_obj, subtarget_name, name, influence):
    con = pose_bone.constraints.get(name)
    if con is None:
        con = pose_bone.constraints.new("CHILD_OF")
        con.name = name
    con.target = armature_obj
    con.subtarget = subtarget_name
    con.influence = influence
    return con


def ensure_stretch_to_constraint(pose_bone, armature_obj, subtarget_name, name):
    """Stretch To simples, sempre esticando pro subtarget -- usado pelo
    bone "_Pole_Line" mirando no "_Pole_CTRL" do mesmo lado/cadeia."""
    con = pose_bone.constraints.get(name)
    if con is None:
        con = pose_bone.constraints.new("STRETCH_TO")
        con.name = name
    con.target = armature_obj
    con.subtarget = subtarget_name
    con.rest_length = 0.0
    return con


def switch_property_name(tip_org_name, side):
    """Custom property do switch FK/IK da cadeia (no PROPERTIES): ORG da ponta + lado ("L-Hand" -> "hand_fk_ik_switch_L")."""
    base = tip_org_name
    for prefix in ("L-", "R-"):
        if base.startswith(prefix):
            base = base[len(prefix):]
            break
    prefix_word = base.lower()
    suffix = "L" if side == "LEFT" else "R"
    return f"{prefix_word}_{PROP_FK_IK_SWITCH}_{suffix}"


def ensure_switch_property(pose_bone, prop_name, description=None, default_value=0):
    """Custom property 0..1 de switch; default_value só na criação (não sobrescreve o valor do usuário)."""
    if description is None:
        description = tr("rigger.runtime.fk_ik_switch_description", get_language(bpy.context))
    if prop_name not in pose_bone.keys():
        pose_bone[prop_name] = default_value
    try:
        ui = pose_bone.id_properties_ui(prop_name)
        ui.update(min=0, max=1, default=default_value, description=description)
    except Exception:
        pass


def ensure_switch_parent_constraint(pose_bone, armature_obj, ik_name, fk_name, name):
    """Armature com 2 alvos (`ik_name`, `fk_name`): o bone segue um deles como se fosse filho; pesos ligados ao switch."""
    con = pose_bone.constraints.get(name)
    if con is None:
        con = pose_bone.constraints.new("ARMATURE")
        con.name = name
    while len(con.targets) < 2:
        con.targets.new()
    while len(con.targets) > 2:
        con.targets.remove(con.targets[-1])
    for target, subtarget in zip(con.targets, (ik_name, fk_name)):
        target.target = armature_obj
        target.subtarget = subtarget
    con.mute = False
    return con


def ensure_local_add_constraint(pose_bone, armature_obj, subtarget_name, name):
    """Copy Transforms que soma o local do alvo por cima do bone (nos eixos do bone)."""
    con = pose_bone.constraints.get(name)
    if con is None:
        con = pose_bone.constraints.new("COPY_TRANSFORMS")
        con.name = name
    con.target = armature_obj
    con.subtarget = subtarget_name
    con.target_space = "LOCAL_OWNER_ORIENT"
    con.owner_space = "LOCAL"
    con.mix_mode = "AFTER_FULL"
    con.mute = False
    return con


def add_switch_driver(constraint, armature_obj, switch_bone_name, switch_prop_name, expression="switch", path="influence"):
    """Liga `path` (influence da constraint, weight do alvo da Armature) à custom property de switch do bone
    PROPERTIES. `expression`: "switch" segue o IK, "1 - switch" o FK."""
    constraint.driver_remove(path)
    fcurve = constraint.driver_add(path)
    driver = fcurve.driver
    driver.type = "SCRIPTED"
    driver.expression = expression
    for existing_var in list(driver.variables):
        driver.variables.remove(existing_var)
    var = driver.variables.new()
    var.name = "switch"
    var.type = "SINGLE_PROP"
    target = var.targets[0]
    target.id_type = "OBJECT"
    target.id = armature_obj
    target.data_path = f'pose.bones["{switch_bone_name}"]["{switch_prop_name}"]'


def add_custom_shape_scale_switch_driver(pose_bone, armature_obj, switch_bone_name, switch_prop_name, target_scale, mode):
    """Driver por eixo de custom_shape_scale_xyz: `target_scale` × switch (IK) ou × (1 - switch) (FK)."""
    template = "{v}*switch" if mode == "IK" else "{v}*(1 - switch)"
    for i in range(3):
        pose_bone.driver_remove("custom_shape_scale_xyz", i)
        fcurve = pose_bone.driver_add("custom_shape_scale_xyz", i)
        driver = fcurve.driver
        driver.type = "SCRIPTED"
        driver.expression = template.format(v=target_scale[i])
        for existing_var in list(driver.variables):
            driver.variables.remove(existing_var)
        var = driver.variables.new()
        var.name = "switch"
        var.type = "SINGLE_PROP"
        target = var.targets[0]
        target.id_type = "OBJECT"
        target.id = armature_obj
        target.data_path = f'pose.bones["{switch_bone_name}"]["{switch_prop_name}"]'


def armature_has_generated_bones(armature):
    """True se o Create Rig já rodou (algum bone com PROP_RIG_LAYER)."""
    return any(PROP_RIG_LAYER in b.keys() for b in armature.bones)


def _angle_on_plane(plane, vec1, vec2):
    """Ângulo entre dois vetores projetados num plano."""
    v1 = vec1 - plane * plane.dot(vec1)
    v2 = vec2 - plane * plane.dot(vec2)
    if v1.length < 1e-9 or v2.length < 1e-9:
        return 0.0
    v1.normalize()
    v2.normalize()
    angle = v1.angle(v2)
    if v1.cross(v2).dot(plane) < 0:
        angle = -angle
    return angle


def compute_pole_angle(armature_obj, base_bone_name, end_bone_name, pole_bone_name):
    """Pole angle cru da rest (quem chama inverte o sinal), pelo plano (raiz, fim do solver, pole);
    `end_bone_name` = último bone do solver."""
    bones = armature_obj.data.bones
    base = bones.get(base_bone_name)
    end = bones.get(end_bone_name)
    pole = bones.get(pole_bone_name)
    if base is None or end is None or pole is None:
        return 0.0

    arm_matrix = armature_obj.matrix_world
    base_head = arm_matrix @ base.head_local
    base_tail = arm_matrix @ base.tail_local
    chain_end = arm_matrix @ end.tail_local
    pole_head = arm_matrix @ pole.head_local
    base_x_axis = arm_matrix.to_3x3() @ base.matrix_local.to_3x3() @ Vector((1.0, 0.0, 0.0))

    base_vector = base_tail - base_head
    if base_vector.length < 1e-9 or base_x_axis.length < 1e-9:
        return 0.0
    base_vector.normalize()
    base_x_axis.normalize()

    pole_normal = (chain_end - base_head).cross(pole_head - base_head)
    projected_pole_axis = pole_normal.cross(base_tail - base_head)

    return _angle_on_plane(base_vector, base_x_axis, projected_pole_axis)
