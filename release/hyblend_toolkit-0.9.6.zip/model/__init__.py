"""Modelos do Hytale (.blockymodel) no Blender, pra todos os addons Hyblend (pela api):
  props.py      constantes e propriedades gravadas (bone/Armature), lidas também pelo export e rig do Anim
  geometry.py   caixa/quad com UV, posição dos nós, malha única sem bones
  materials.py  textura chapada, tingida por gradiente e versões sem luz (miniatura), 4.5 e 5.x
  build.py      Armature nova ou anexo numa existente (bones + malhas)
  textures.py   textura de modelo solto no disco (File > Import)
  options.py    opções/blocos das janelas de import (o Anim usa no .bbmodel/Bedrock)
  catalog.py    personagens do jogo (Server/Models no Assets.zip: herança, anexos, ícone)
  character.py  import do personagem completo (corpo + anexos padrão)
  operators.py  File > Import > Hytale Model (.blockymodel) e hyblend.import_character

IMPORTANTE: o Anim 0.1.0 ainda registra o MESMO bl_idname (o Blender troca o nosso pelo dele). Quando ele sai,
check_operator_later() (chamado pela api ao tirar a tela do Anim) devolve o nosso.
"""

import bpy

from ..translations import register_localized_class, unregister_localized_class
from . import build, catalog, character, geometry, materials, options, props, textures  # noqa: F401
from .operators import HYBLEND_OT_import_character, IMPORT_OT_hytale_blockymodel, menu_import

_RNA_NAME = "IMPORT_SCENE_OT_hytale_blockymodel"


def _restore_operator():
    if getattr(bpy.types, _RNA_NAME, None) is None:
        register_localized_class(IMPORT_OT_hytale_blockymodel)
    return None


def check_operator_later():
    """Depois que um addon sai (timer: não registrar no meio do unregister dele)."""
    if not bpy.app.timers.is_registered(_restore_operator):
        bpy.app.timers.register(_restore_operator, first_interval=0.0)


def register():
    bpy.utils.register_class(HYBLEND_OT_import_character)
    register_localized_class(IMPORT_OT_hytale_blockymodel)
    bpy.types.TOPBAR_MT_file_import.append(menu_import)


def unregister():
    if bpy.app.timers.is_registered(_restore_operator):
        bpy.app.timers.unregister(_restore_operator)
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
    try:
        unregister_localized_class(IMPORT_OT_hytale_blockymodel)
    except RuntimeError:          # o do Anim 0.1.0 está por cima: o nosso já saiu
        from .. import translations
        if IMPORT_OT_hytale_blockymodel in translations._localized_classes:
            translations._localized_classes.remove(IMPORT_OT_hytale_blockymodel)
    bpy.utils.unregister_class(HYBLEND_OT_import_character)
    catalog.forget()
