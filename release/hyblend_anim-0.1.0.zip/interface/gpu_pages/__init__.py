"""Páginas do Anim na UI por GPU do núcleo (5.0+): tabs.py monta a tela (api.App)."""
