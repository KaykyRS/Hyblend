"""gradient_parser.py -- le GradientSets.json (Cosmetics/CharacterCreator/)
e devolve os conjuntos de cor/rampa usados pelos Items em coloring_mode ==
'gradient' (ver manifest_parser.py).

Achado de design importante (ver conversa): cada "cor" aqui NAO e um tint
plano -- e uma textura-rampa (gradient map). BaseColor e so o valor de
swatch pro picker da nossa UI; a cor de verdade, no shader, vem de
amostrar essa textura-rampa usando a luminancia da GreyscaleTexture do
Item como coordenada de busca. Ver material_setup.py (builder/) pra como
isso vira um Node Group no Blender.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class GradientColor:
    name: str  # chave dentro do set, ex. "Brown", "04" (skin tone)
    texture: str  # caminho da rampa, relativo a Assets/Common/ (mesma base do Model/GreyscaleTexture dos manifests)
    base_color: tuple = field(default_factory=tuple)  # hex(es) representativo(s) pro swatch da UI


@dataclass(frozen=True)
class GradientSet:
    id: str
    colors: tuple  # tuple[GradientColor, ...]

    def get(self, name: str) -> Optional[GradientColor]:
        for c in self.colors:
            if c.name == name:
                return c
        return None


def parse_gradient_sets(json_path: Path) -> dict:
    """Devolve {gradient_set_id: GradientSet}."""
    with json_path.open(encoding="utf-8") as f:
        raw_list = json.load(f)

    sets = {}
    for raw in raw_list:
        colors = tuple(
            GradientColor(
                name=name,
                texture=data["Texture"],
                base_color=tuple(data.get("BaseColor", [])),
            )
            for name, data in raw.get("Gradients", {}).items()
        )
        sets[raw["Id"]] = GradientSet(id=raw["Id"], colors=colors)
    return sets
