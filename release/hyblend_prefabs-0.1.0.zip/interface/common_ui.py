"""interface/common_ui.py -- o que o painel CLÁSSICO (interface/__init__.py)
e a UI por GPU (interface/gpu_ui/) mostram IGUAL: links do About, textos e
formatação de valores do inspetor, grupos de problema do relatório.

Só lê custom properties de Objects/dicts -- sem bpy.ops, sem bpy.data,
seguro dentro de draw() e de draw handler. Mudar um texto aqui muda nas
duas UIs ao mesmo tempo."""

from __future__ import annotations

import math

from ..builder.prefab_ops import OUTPUT_LABELS, texture_problem_items  # noqa: F401  (OUTPUT_LABELS: reexport)
from ..common import (
    PROP_BLOCK_NAME,
    PROP_BLOCK_ROTATION_RAW,
    PROP_BLOCK_STATE,
    PROP_ENTITY_ROTATION_PITCH_RAW,
    PROP_ENTITY_ROTATION_ROLL_RAW,
    PROP_ENTITY_ROTATION_YAW_RAW,
    PROP_ENTITY_SCALE_RAW,
)

# --- About -- créditos/links (mesmos do Hyblend Toolkit, aba Info) ---
# String vazia = botão correspondente fica desabilitado.
HYBLEND_NEXUSMODS_URL = "https://www.nexusmods.com/hytale/mods/164"
HYBLEND_GITHUB_URL = "https://github.com/KaykyRS/Hyblend"
HYBLEND_PATREON_URL = "https://www.patreon.com/cw/kaayky"
# Créditos: "Created by:" / estúdio (linha própria) / autor + redes sociais.
HYBLEND_STUDIO_NAME = "Trupe Forge"
HYBLEND_AUTHOR_NAME = "Kaayky (Ká)"
HYBLEND_AUTHOR_INSTAGRAM_URL = "https://www.instagram.com/kaayky_r.s/"
HYBLEND_AUTHOR_TWITTER_URL = "https://x.com/kaayky_anim"
HYBLEND_AUTHOR_YOUTUBE_URL = "https://www.youtube.com/@KaaykyModder"
HYBLEND_HYTALE_URL = "https://hytale.com"
# Redes do autor (linha "Kaayky (Ká)" dos créditos), na ordem dos botões:
# (url, logo em assets/icons/, ícone embutido do painel clássico, ícone da UI por GPU).
HYBLEND_SOCIAL_LINKS = (
    (HYBLEND_PATREON_URL, "patreon", "FUND", "heart"),
    (HYBLEND_AUTHOR_INSTAGRAM_URL, "instagram", "IMAGE_DATA", "image"),
    (HYBLEND_AUTHOR_TWITTER_URL, "twitter_x", "WORLD", "globe"),
    (HYBLEND_AUTHOR_YOUTUBE_URL, "youtube", "FILE_MOVIE", "play"),
)
# Textos do About = os da aba Info do Toolkit (translations/en.py, panel.info_*).
ABOUT_HYTALE_LABEL = "Hypixel Studios"
ABOUT_LINKS_LABEL = "Links"
ABOUT_CREDITS_LABEL = "Credits"
ABOUT_CREATED_BY_LABEL = "Created by:"
# Aviso de não-afiliação -- as duas UIs quebram em várias linhas conforme a largura.
HYBLEND_DISCLAIMER = "Fan-made, unofficial tool. Not affiliated with or endorsed by Hypixel Studios."

# Quantos ids mostrar por categoria de problema antes de "... and N more"
# (a lista completa sempre sai inteira no "Copy Report").
MAX_ISSUES_SHOWN = 8

# Categorias de problema do relatório, com título em linguagem simples.
# (chave do dict de load_report(), título, ícone do Blender, ícone da UI por GPU)
# "textures" é tratado à parte (ver prefab_ops.texture_problem_items).
ISSUE_GROUPS = (
    ("missing", "Not found in game files", "QUESTION", "search"),
    ("unresolved", "No 3D model", "GHOST_DISABLED", "cube"),
    ("errored", "Failed to build", "CANCEL", "error"),
    ("textures", "Missing texture", "TEXTURE", "image"),
)

# Tipo de entity -> (rótulo, ícone do Blender, ícone da UI por GPU)
ENTITY_KIND_LABELS = {
    "block": ("Block Entity", "MESH_CUBE", "cube"),
    "item": ("Item Entity", "TOOL_SETTINGS", "shape"),
    "model": ("Model Entity", "OUTLINER_OB_ARMATURE", "user"),
}
ENTITY_KIND_FALLBACK = ("Entity", "OBJECT_DATA", "cube")


def issue_items(report: dict, key: str) -> list:
    """Ids de UMA categoria de problema, já prontos pra listar."""
    if key == "textures":
        return texture_problem_items(report)
    if key == "errored":
        return sorted(report[key])
    return list(report[key])


def issue_label(item: str) -> str:
    """"id -- motivo": só o id cabe na Sidebar; o motivo completo sai no
    Copy Report (Developer Mode)."""
    return item.split(" -- ", 1)[0]


def problems_title(count: int) -> str:
    return f"{count} {'item' if count == 1 else 'items'} didn't load"


def fmt_vec(values, digits=2) -> str:
    try:
        return ", ".join(f"{float(v):.{digits}f}".rstrip("0").rstrip(".") if digits else str(int(v)) for v in values)
    except (TypeError, ValueError):
        return str(values)


def fmt_rotation(yaw_deg, pitch_deg, roll_deg) -> str:
    """Só os eixos que giraram ("Yaw 90°", "Yaw 90°  Roll 180°"); "None"
    quando nenhum -- mais fácil de ler que "Y 90° P 0° R 0°"."""
    parts = [
        f"{name} {deg:.0f}°"
        for name, deg in (("Yaw", yaw_deg), ("Pitch", pitch_deg), ("Roll", roll_deg))
        if round(deg) % 360 != 0
    ]
    return "  ".join(parts) if parts else "None"


def block_item_id(obj) -> tuple:
    """(item id sem o sufixo de estado, estado) de um Object de bloco."""
    raw_name = str(obj.get(PROP_BLOCK_NAME, ""))
    item_id = obj.name.split(".")[0] if not raw_name else raw_name.lstrip("*")
    state = str(obj.get(PROP_BLOCK_STATE, "") or "")
    if state:
        # O estado vai na linha própria.
        for marker in ("_State_Definitions_", "_State_"):
            if marker in item_id:
                item_id = item_id.split(marker, 1)[0]
                break
    return item_id, state


def block_rotation_text(obj) -> str:
    raw_rot = obj.get(PROP_BLOCK_ROTATION_RAW, 0) or 0
    try:
        raw_rot = int(raw_rot)
    except (TypeError, ValueError):
        raw_rot = 0
    return fmt_rotation((raw_rot % 4) * 90, ((raw_rot // 4) % 4) * 90, ((raw_rot // 16) % 4) * 90)


def entity_rotation_text(obj) -> str:
    angles = []
    for key in (PROP_ENTITY_ROTATION_YAW_RAW, PROP_ENTITY_ROTATION_PITCH_RAW, PROP_ENTITY_ROTATION_ROLL_RAW):
        try:
            angles.append(math.degrees(float(obj.get(key, 0.0) or 0.0)))
        except (TypeError, ValueError):
            angles.append(0.0)
    return fmt_rotation(*angles)


def entity_scale(obj) -> float:
    try:
        return float(obj.get(PROP_ENTITY_SCALE_RAW, 1.0))
    except (TypeError, ValueError):
        return 1.0


def raw_value_text(value) -> str:
    """Valor cru de custom property, formatado (Developer Mode)."""
    if hasattr(value, "to_list"):
        value = value.to_list()
    if isinstance(value, float):
        return f"{value:.5g}"
    if isinstance(value, (list, tuple)):
        return ", ".join(f"{v:.5g}" if isinstance(v, float) else str(v) for v in value)
    return str(value)


def layer_collection_for(view_layer, collection):
    """LayerCollection (a que tem o "olho") de uma Collection, procurando
    recursivamente -- o import linka na raiz da cena, mas o usuário pode
    ter movido a Collection pra dentro de outra."""
    def walk(lc):
        if lc.collection == collection:
            return lc
        for child in lc.children:
            found = walk(child)
            if found is not None:
                return found
        return None

    return walk(view_layer.layer_collection)
