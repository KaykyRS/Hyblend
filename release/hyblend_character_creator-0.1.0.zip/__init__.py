"""Hyblend Character Creator -- __init__.py

So orquestra: importa as classes de cada modulo, registra tudo em
_CLASSES, e cuida das WindowManager properties que nao pertencem a
nenhum modulo especifico (hyblendcc_slots e as outras vivem aqui porque
precisam ser registradas numa ordem especifica em relacao as classes).

MAPA DO PACOTE (ordem de dependencia, de baixo pra cima -- ver
DEVELOPER_NOTES.md pra detalhes de cada um):
  compat.py       -- camada de compatibilidade Blender 4.5 <-> 5.x (so bpy)
  common.py       -- constantes/utilitarios sem dependencia interna nenhuma
  preferences.py  -- Preferences do addon + resolucao da pasta Hytale
  picker.py       -- HYBLENDCC_ItemSlot, aplicar automatico, catalogo/thumbnail
  presets_ops.py  -- salvar/carregar/apagar preset
  player_ops.py   -- Create Player, Create Rig (Hyblend)
  interface/      -- TODA a UI (N-panel, operadores de clique, widgets de
                     layout, draw das Preferences) -- ver interface/__init__.py

  builder/        -- monta bones+mesh (character_assembly.py e o principal)
  scanner/        -- le os manifests JSON do jogo (Cosmetics/CharacterCreator) e
                     mapeia a pasta de instalacao (hytale_install.py)
  thumbnails/     -- renderiza miniatura isolada (sem Armature real)
  presets/        -- so a leitura/escrita em disco do preset (sem bpy)

Fluxo de uso:
  1. Importa Player.blockymodel usando o HYBLEND, OU usa o botao
     "Create Player" deste addon (nao depende do Hyblend pra isso).
  2. Preferences deste addon: aponta pra pasta Hytale (Automatico acha
     sozinho em %APPDATA%/Hytale). Assets.zip e icones vem de dentro dela.
  3. Sidebar (N) > aba "Hyblend" -- escolhe Categoria/Sub-
     categoria/Item/Cor pela grade (estilo character creator do
     Hytale), aplica sozinho ao clicar (sem botao de "Aplicar").
"""

from __future__ import annotations

import bpy
import bpy.utils.previews
from bpy.props import CollectionProperty, EnumProperty, StringProperty
from bpy.types import WindowManager

from .common import _precompute_all_icons, _preview_collections
from .interface import gpu_ui  # gpu_ui: UI experimental por GPU (5.0+), ver interface/gpu_ui/__init__.py
from .interface import panel as _interface_panel  # seletor dos addons Hyblend (hyblend_hub.py)
from .interface import OPERATOR_CLASSES as _UI_OPERATOR_CLASSES
from .interface import PANEL_CLASSES as _UI_PANEL_CLASSES
from .picker import (
    HYBLENDCC_ItemSlot,
    HYBLENDCC_OT_apply_slot,
    HYBLENDCC_OT_build_all_thumbnails,
    HYBLENDCC_OT_build_category_thumbnails,
    HYBLENDCC_OT_reload_catalog,
    _invalidate_item_enum_cache,
    cancel_pending_applies,
)
from .player_ops import HYBLENDCC_OT_create_player, HYBLENDCC_OT_create_rig
from .preferences import (
    HYBLENDCC_AddonPreferences,
    HYBLENDCC_OT_locate_game,
    HYBLENDCC_OT_clear_cache,
    _autodetect_hytale_on_startup,
    _restore_images_on_load,
)
from .presets_ops import (
    HYBLENDCC_OT_delete_preset,
    HYBLENDCC_OT_load_preset,
    HYBLENDCC_OT_save_preset,
    _preset_enum_items,
)


def _register_window_manager_props():
    WindowManager.hyblendcc_slots = CollectionProperty(type=HYBLENDCC_ItemSlot)

    # Estado da UI (uma Categoria/Sub-categoria ATIVA por vez -- so essa
    # e desenhada, nunca N grids grandes simultaneos, ver interface/panel.py).
    # StringProperty simples + os 2 Operators de clique
    # (HYBLENDCC_OT_select_section/_category, ver interface/operators.py).
    # `template_icon_view`+EnumProperty foi tentado DUAS vezes (ver
    # DEVELOPER_NOTES.md itens 14 e 15) e crashou o Blender do usuario
    # as duas -- a segunda mesmo depois de fechar a causa especifica
    # diagnosticada na primeira. NAO TENTAR DE NOVO sem um crash log de
    # verdade pra analisar (ver item 16) -- Operator/StringProperty e a
    # unica versao confirmada estavel apos varias rodadas de teste real.
    WindowManager.hyblendcc_active_section = StringProperty(default="")
    WindowManager.hyblendcc_active_category = StringProperty(default="")

    WindowManager.hyblendcc_preset_name = StringProperty(name="Preset Name", default="")
    WindowManager.hyblendcc_preset_selected = EnumProperty(name="Preset", items=_preset_enum_items)


def _unregister_window_manager_props():
    del WindowManager.hyblendcc_slots

    del WindowManager.hyblendcc_active_section
    del WindowManager.hyblendcc_active_category

    del WindowManager.hyblendcc_preset_name
    del WindowManager.hyblendcc_preset_selected

_CLASSES = (
    HYBLENDCC_AddonPreferences,
    HYBLENDCC_OT_locate_game,
    HYBLENDCC_OT_clear_cache,
    HYBLENDCC_ItemSlot,
    HYBLENDCC_OT_apply_slot,
    *_UI_OPERATOR_CLASSES,
    HYBLENDCC_OT_save_preset,
    HYBLENDCC_OT_load_preset,
    HYBLENDCC_OT_delete_preset,
    HYBLENDCC_OT_reload_catalog,
    HYBLENDCC_OT_build_all_thumbnails,
    HYBLENDCC_OT_build_category_thumbnails,
    HYBLENDCC_OT_create_player,
    HYBLENDCC_OT_create_rig,
    *_UI_PANEL_CLASSES,  # Panel por ultimo: desenha botao pra todos os Operators acima
)


def register():
    _interface_panel.hub_register()   # seletor dos addons Hyblend (painel bl_order 0) antes dos outros
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    _register_window_manager_props()
    # Preview collection NOVA -- qualquer icon_id cacheado de uma
    # collection anterior (ex. addon desabilitado/reabilitado na mesma
    # sessao do Blender) fica invalido a partir daqui. Limpa TODOS os
    # caches que guardam icon_id (nao so os de item) antes de qualquer
    # coisa tentar desenhar -- ver DEVELOPER_NOTES.md item 15 (crash
    # real relacionado a isso).
    _invalidate_item_enum_cache(category=None)
    _preview_collections["main"] = bpy.utils.previews.new()
    # Pre-carrega (corta/cacheia) todos os icones de Categoria/Sub-
    # categoria de uma vez, ANTES do primeiro draw() -- nunca de dentro
    # de draw() ou de um callback de RNA (items()/update()), onde mexer
    # em bpy.data (bpy.data.images.load/remove, usado no corte de
    # margem) e inseguro. bpy.app.timers roda fora desse contexto,
    # mesmo padrao ja usado em _defer_apply_slot.
    bpy.app.timers.register(_precompute_all_icons, first_interval=0.1)
    # Addon recem-instalado (modo Automatico, campo vazio): acha a pasta
    # Hytale sozinho, sem precisar clicar em Auto-Detect no N-Panel.
    # Timer porque escrever em property no draw() e proibido.
    bpy.app.timers.register(_autodetect_hytale_on_startup, first_interval=0.1, persistent=True)
    # .blend aberto: texturas de personagem que sumiram do assets_cache
    # (Clear Cache, outro PC) voltam do Assets.zip.
    bpy.app.handlers.load_post.append(_restore_images_on_load)
    gpu_ui.register()   # gpu_ui: nao faz nada abaixo do Blender 5.0


def unregister():
    if _restore_images_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_restore_images_on_load)
    for fn in (_autodetect_hytale_on_startup, _precompute_all_icons):
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    cancel_pending_applies()
    gpu_ui.unregister()   # gpu_ui: antes de tudo -- derruba hosts/handlers/timers da UI por GPU
    for pcoll in _preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    _preview_collections.clear()
    # Mesma razao do register(): nao deixar nenhum icon_id cacheado
    # sobrevivendo a destruicao da preview collection.
    _invalidate_item_enum_cache(category=None)

    _unregister_window_manager_props()
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
    _interface_panel.hub_unregister()
