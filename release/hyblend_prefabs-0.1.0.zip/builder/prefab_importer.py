"""prefab_importer.py -- IMPORT_OT_hytale_prefab, o operador principal do
addon.

"blocks" (grade voxel) sempre e importado. "entities" (props fora da grade,
posicao/rotacao/escala continuas) e importado por padrao, controlavel pela
property `import_entities`. "fluids" fora de escopo. Blocos/entities com
estado (porta/bau aberto-fechado) sempre usam o modelo/textura BASE, o
estado so e gravado como custom property.

Uma malha (bpy.types.Mesh) e construida UMA VEZ por item_id e REAPROVEITADA
(mesmo datablock, varios Objects) por todas as instancias daquele item no
prefab -- essencial pra performance, ja que um prefab real tem centenas de
blocos/entities repetidos. Ver DEVELOPER_NOTES.md pra visao geral do
pipeline (block_def -> mesh cache -> Object)."""

from __future__ import annotations

import gc
import json
from pathlib import Path
from typing import Optional

import math

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntVectorProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper
from mathutils import Matrix, Vector

from ..common import (
    BLOCK_GRID_UNIT_DEFAULT,
    PREFAB_COLLECTION_PREFIX,
    PROP_PREFAB_ADDON_VERSION,
    PROP_PREFAB_BLOCKS_PLACED,
    PROP_PREFAB_BLOCKS_TOTAL,
    PROP_PREFAB_ENTITIES_PLACED,
    PROP_PREFAB_ENTITIES_TOTAL,
    PROP_PREFAB_FILE,
    PROP_PREFAB_HIDDEN_BLOCKS,
    PROP_PREFAB_HIDDEN_FACES,
    PROP_PREFAB_OUTPUT_MODE,
    PROP_PREFAB_REGION_SKIPPED,
    PROP_PREFAB_REPORT_JSON,
    PROP_PREFAB_ROOT,
    PROP_PREFAB_UNIQUE_MESHES,
    PROP_ENTITY_ITEM_ID,
    PROP_ENTITY_ITEM_ID_RAW,
    PROP_ENTITY_KIND,
    PROP_ENTITY_MODEL_SCALE_RAW,
    PROP_ENTITY_POSITION_RAW,
    PROP_ENTITY_ROTATION_PITCH_RAW,
    PROP_ENTITY_ROTATION_ROLL_RAW,
    PROP_ENTITY_ROTATION_YAW_RAW,
    PROP_ENTITY_SCALE_RAW,
    PROP_ENTITY_STATE,
    PROP_ENTITY_UUID,
    UNIT_SCALE_DEFAULT,
    game_found,
)
from ..preferences import AssetsSourceError, get_assets_source, is_developer_mode
from ..scanner.item_index import ItemIndexError, load_item_json, load_model_json
from . import cube_mesh, materials, node_mesh
from .emitters import Placement, emit_instances, emit_objects, emit_single_mesh, remove_unused_meshes
from .block_def import BlockDef, build_block_def, parse_resolved_name, resolve_item_model_ref
from .entity_rotation import decode_block_entity_rotation, decode_item_or_model_entity_rotation
from .rotation import decode_block_rotation

# Item/model entities usam 64 unidades cruas por bloco (metade do que
# CustomModel de blocks[] usa). Ver DEVELOPER_NOTES.md ("Units").
_ITEM_ENTITY_UNIT_SCALE = UNIT_SCALE_DEFAULT * 0.5

# Componentes que marcam uma entity como "nao e prop de cenario de verdade"
# (spawner/patrulha/etc) -- ignorados mesmo com Item/Model/BlockEntity.
_ENTITY_IGNORE_COMPONENTS = ("SpawnMarkerComponent", "Intangible", "PatrolPathMarker", "SpawnSuppression")

_FALLBACK_ATLAS_SIZE = 64.0

# Opcoes do Optimizer que afetam a MONTAGEM das malhas compartilhadas,
# ligadas so durante o execute() (ver IMPORT_OT_hytale_prefab.execute).
_build_options = {"merge_by_distance": False, "need_opacity": False}

# BlockType.Opacity que conta como "opaco" pro culling do Optimizer.
# Ausente (None) = padrao do jogo pra bloco cheio.
_OPAQUE_OPACITY_VALUES = (None, "Solid")


def _merge_by_distance(mesh) -> None:
    """Merge by Distance (0.0001 bloco) numa malha compartilhada. UV e por
    canto de face, entao a textura nao muda; sombreamento continua flat."""
    import bmesh

    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-4)
    bm.to_mesh(mesh)
    bm.free()


def _finish_model_mesh(mesh) -> None:
    if _build_options["merge_by_distance"]:
        _merge_by_distance(mesh)

# Correcao extra de eixo, so pra CustomModel vindo de "Items/" -- NAO
# CONFIRMADA necessaria (analise atual sugere NONE esta certo, ver
# DEVELOPER_NOTES.md). Exposta como property pra testar sem reinstalar.
_ITEM_MODEL_AXIS_FIX_OPTIONS = {
    "NONE": None,
    "MINUS_90_X": Matrix.Rotation(-math.pi / 2.0, 4, "X"),
    "PLUS_90_X": Matrix.Rotation(math.pi / 2.0, 4, "X"),
    "180_X": Matrix.Rotation(math.pi, 4, "X"),
    "MINUS_90_Y": Matrix.Rotation(-math.pi / 2.0, 4, "Y"),
    "PLUS_90_Y": Matrix.Rotation(math.pi / 2.0, 4, "Y"),
    "MINUS_90_Z": Matrix.Rotation(-math.pi / 2.0, 4, "Z"),
    "PLUS_90_Z": Matrix.Rotation(math.pi / 2.0, 4, "Z"),
}


def _resolve_common_path(assets_source, relative: str) -> Path:
    """Caminhos do JSON do jogo sempre usam "/" (string de JSON, nao caminho de SO)."""
    return assets_source.resolve_common(*relative.split("/"))


def _build_mesh_entry(
    assets_source,
    block_def: BlockDef,
    block_grid_unit: float,
    item_model_axis_fix: str = "NONE",
    texture_warnings: Optional[list] = None,
    ignore_custom_model_scale: bool = False,
):
    """Constroi (mesh, ja com materiais) pra um BlockDef. None se o tipo
    nao tem gerador conhecido ou o .blockymodel nao existe -- quem chama
    registra como "item com problema" e segue o import.

    A malha e sempre construida em escala NATIVA (item_scale=1.0), mesmo
    pra "MODEL": e CACHEADA e reaproveitada entre blocks[] e entities[] (ver
    _get_or_build_entry), entao nenhum multiplicador CONTEXTUAL
    (model_scale_multiplier, EntityScale.Scale) e aplicado aqui -- so no
    Object (obj.scale/matrix_basis), ver execute()/_place_entities().

    `ignore_custom_model_scale` -- BlockType.CustomModelScale NAO se aplica
    quando o item e "block entity" (so vale pra blocks[] da grade); como a
    malha e cacheada por item_id, quem chama pra block entity passa True
    aqui e _get_or_build_entry usa uma chave de cache separada."""
    if block_def.draw_type == "MODEL":
        model_path = _resolve_common_path(assets_source, block_def.custom_model)
        if not model_path.is_file():
            return None
        with model_path.open("r", encoding="utf-8") as f:
            model_data = json.load(f)
        root_nodes = model_data.get("nodes", [])

        image = None
        if block_def.custom_model_textures:
            # Primeira variante de peso -- nao da pra saber qual o jogo escolheu.
            texture_rel = block_def.custom_model_textures[0].path
            image = materials.get_or_load_image(_resolve_common_path(assets_source, texture_rel))
            if image is None and texture_warnings is not None:
                texture_warnings.append(
                    f"{block_def.item_id}: CustomModelTexture aponta pra "
                    f"'{texture_rel}' mas o arquivo nao foi encontrado em "
                    f"{_resolve_common_path(assets_source, texture_rel)}"
                )
        elif texture_warnings is not None:
            texture_warnings.append(f"{block_def.item_id}: sem CustomModelTexture nenhuma no JSON (nem herdada de Parent)")

        atlas_w = float(image.size[0]) if image else _FALLBACK_ATLAS_SIZE
        atlas_h = float(image.size[1]) if image else _FALLBACK_ATLAS_SIZE

        # Correcao de eixo so pra CustomModel de "Items/" (nunca "Blocks/"),
        # e so se o usuario escolher algo != NONE. Ver DEVELOPER_NOTES.md.
        is_item_path = block_def.custom_model.replace("\\", "/").lstrip("/").lower().startswith("items/")
        root_correction = _ITEM_MODEL_AXIS_FIX_OPTIONS.get(item_model_axis_fix) if is_item_path else None
        # CustomModelScale e propriedade intrinseca do item (mora dentro do
        # BlockType), bake-ada na malha cacheada -- pivot = "bottom center"
        # do bloco, que ja bate com a origem local de build_item_mesh.
        mesh = node_mesh.build_item_mesh(
            block_def.item_id,
            root_nodes,
            UNIT_SCALE_DEFAULT,
            atlas_w,
            atlas_h,
            item_scale=1.0 if ignore_custom_model_scale else block_def.custom_model_scale,
            root_correction=root_correction,
        )
        _finish_model_mesh(mesh)
        mat = materials.get_or_create_flat_material(block_def.item_id, image, tint=block_def.tint)
        mesh.materials.append(mat)
        return {"mesh": mesh, "draw_type": "MODEL", "opaque": False}

    if block_def.draw_type == "CUBE":
        sides_img = (
            materials.get_or_load_image(_resolve_common_path(assets_source, block_def.cube_sides))
            if block_def.cube_sides
            else None
        )
        up_img = (
            materials.get_or_load_image(_resolve_common_path(assets_source, block_def.cube_up))
            if block_def.cube_up
            else None
        )
        down_img = (
            materials.get_or_load_image(_resolve_common_path(assets_source, block_def.cube_down))
            if block_def.cube_down
            else None
        )
        if texture_warnings is not None:
            if block_def.cube_sides and sides_img is None:
                texture_warnings.append(
                    f"{block_def.item_id}: Textures[].Sides aponta pra '{block_def.cube_sides}' "
                    f"mas o arquivo nao foi encontrado em {_resolve_common_path(assets_source, block_def.cube_sides)}"
                )
            if block_def.cube_up and up_img is None:
                texture_warnings.append(
                    f"{block_def.item_id}: Textures[].Up aponta pra '{block_def.cube_up}' "
                    f"mas o arquivo nao foi encontrado em {_resolve_common_path(assets_source, block_def.cube_up)}"
                )
            if block_def.cube_down and down_img is None:
                texture_warnings.append(
                    f"{block_def.item_id}: Textures[].Down aponta pra '{block_def.cube_down}' "
                    f"mas o arquivo nao foi encontrado em {_resolve_common_path(assets_source, block_def.cube_down)}"
                )
            if not block_def.cube_sides and not block_def.cube_up and not block_def.cube_down:
                texture_warnings.append(
                    f"{block_def.item_id}: Textures[0] sem chave All/Sides/Side/UpDown/Top/Bottom/Up/Down reconhecida"
                )
        mesh = cube_mesh.build_cube_mesh(block_def.item_id, size=block_grid_unit)
        mesh.materials[0] = materials.get_or_create_flat_material(
            block_def.item_id + "_Sides", sides_img, tint=block_def.tint_sides
        )
        mesh.materials[1] = materials.get_or_create_flat_material(
            block_def.item_id + "_Up", up_img, tint=block_def.tint_up
        )
        mesh.materials[2] = materials.get_or_create_flat_material(
            block_def.item_id + "_Down", down_img, tint=block_def.tint_down
        )
        # "Opaco" (so o Optimizer usa): Opacity Solid/ausente E nenhuma das
        # 3 texturas com pixel transparente. Um cubo opaco esconde a face
        # do vizinho encostado nele.
        # So calculado quando alguma opcao de culling esta ligada (le os
        # pixels da textura) -- sem Optimizer, custo zero.
        opaque = _build_options["need_opacity"] and block_def.opacity in _OPAQUE_OPACITY_VALUES and not any(
            materials.image_has_transparency(img) for img in (sides_img, up_img, down_img)
        )
        return {"mesh": mesh, "draw_type": "CUBE", "opaque": opaque}

    return None


def _get_or_build_entry(
    item_id,
    assets_source,
    loader,
    block_grid_unit,
    mesh_cache,
    missing_items,
    unresolved_kind,
    item_model_axis_fix: str = "NONE",
    errored_items: Optional[dict] = None,
    texture_warnings: Optional[list] = None,
    entity_context: bool = False,
):
    """Resolve a malha (cacheada, escala nativa) de um item_id -- usado pra
    blocks[] e pra "block entities" (armas/trofeus tem seu proprio caminho,
    ver _build_item_entity_mesh_entry/_build_model_entity_mesh_entry).
    Devolve {"mesh":..., "draw_type": "MODEL"|"CUBE"} ou None (motivo ja
    registrado em missing_items/unresolved_kind/errored_items).

    `entity_context=True` -- item e "block entity": CustomModelScale nao se
    aplica, entao a malha resultante e diferente da usada por blocks[] --
    precisa de chave de cache separada.

    Qualquer excecao ao construir UM item e capturada e registrada em
    `errored_items` -- o import continua pro resto de blocks[]/entities[]
    em vez de abortar no meio (ver DEVELOPER_NOTES.md)."""
    cache_key = (item_id, "entity") if entity_context else item_id
    entry = mesh_cache.get(cache_key)
    if entry is False:
        return None
    if entry is not None:
        return entry

    if load_item_json(assets_source, item_id) is None:
        missing_items.add(item_id)
        mesh_cache[cache_key] = False
        return None

    try:
        block_def = build_block_def(item_id, loader)
        built = _build_mesh_entry(
            assets_source,
            block_def,
            block_grid_unit,
            item_model_axis_fix,
            texture_warnings,
            ignore_custom_model_scale=entity_context,
        )
    except Exception as exc:  # noqa: BLE001 -- 1 item quebrado nao pode travar o prefab inteiro
        if errored_items is not None:
            errored_items[item_id] = f"{type(exc).__name__}: {exc}"
        mesh_cache[cache_key] = False
        return None

    if built is None:
        if block_def.draw_type == "MODEL":
            # _build_mesh_entry devolve None pra MODEL quando o arquivo nao existe.
            reason = f"model file not found: {block_def.custom_model}"
        else:
            reason = "no CustomModel/Textures/State model in BlockType (nor in Parent)"
        unresolved_kind.add(f"{item_id} -- {reason}")
        mesh_cache[cache_key] = False
        return None

    mesh_cache[cache_key] = built
    return built


def _item_ref_from_block_type(item_id: str, loader) -> Optional[dict]:
    """{"Model", "Texture"} tirado do BlockType (CustomModel + 1a
    CustomModelTexture, subindo Parent e State "default" igual blocks[]),
    ou None se o BlockType nao desenha um modelo proprio (bloco "cubo" ou
    sem BlockType). Usado so como fallback de item entity sem "Model"."""
    block_def = build_block_def(item_id, loader)
    if block_def.draw_type != "MODEL" or not block_def.custom_model:
        return None
    texture = block_def.custom_model_textures[0].path if block_def.custom_model_textures else None
    return {"Model": block_def.custom_model, "Texture": texture}


def _build_item_entity_mesh_entry(
    assets_source,
    item_id: str,
    loader,
    item_mesh_cache: dict,
    unresolved_kind: set,
    errored_items: Optional[dict] = None,
    texture_warnings: Optional[list] = None,
):
    """Resolve a malha de uma "item entity" (arma solta, ex.
    Weapon_Longsword_Iron): usa "Model"/"Texture" do NIVEL RAIZ do proprio
    item.json (subindo Parent). Cache proprio, chaveado por item_id -- nunca
    compartilhado com mesh_cache de blocks[] porque usa unit_scale diferente
    (ver _ITEM_ENTITY_UNIT_SCALE).

    Fallback (dev-0.2.0, NAO CONFIRMADO visualmente): item SEM "Model" na raiz
    mas com BlockType.CustomModel (ex. Tool_Watering_Can -- o modelo so
    existe no BlockType, com CustomModelScale 0.5) usa esse CustomModel +
    a 1a CustomModelTexture, na MESMA unidade de item entity (1/64) e SEM
    CustomModelScale. Por que bate: um .blockymodel de "Items/" usado como
    bloco precisa de CustomModelScale 0.5 justamente porque bloco usa 1/32
    -- 1/32 * 0.5 = 1/64, a unidade nativa de item. Ver
    _item_ref_from_block_type."""
    entry = item_mesh_cache.get(item_id)
    if entry is False:
        return None
    if entry is not None:
        return entry

    try:
        ref = resolve_item_model_ref(item_id, loader)
        if ref is None:
            ref = _item_ref_from_block_type(item_id, loader)
        if ref is None:
            unresolved_kind.add(
                f"[item] {item_id} -- no 'Model' field in the item JSON (nor in Parent), "
                "and no BlockType.CustomModel to fall back to"
            )
            item_mesh_cache[item_id] = False
            return None

        model_path = _resolve_common_path(assets_source, ref["Model"])
        if not model_path.is_file():
            unresolved_kind.add(f"[item] {item_id} -- model file not found: {ref['Model']}")
            item_mesh_cache[item_id] = False
            return None
        with model_path.open("r", encoding="utf-8") as f:
            model_data = json.load(f)
        root_nodes = model_data.get("nodes", [])

        image = None
        texture_rel = ref.get("Texture")
        if texture_rel:
            image = materials.get_or_load_image(_resolve_common_path(assets_source, texture_rel))
            if image is None and texture_warnings is not None:
                texture_warnings.append(
                    f"{item_id}: Texture (item entity) aponta pra '{texture_rel}' mas o arquivo nao "
                    f"foi encontrado em {_resolve_common_path(assets_source, texture_rel)}"
                )
        elif texture_warnings is not None:
            texture_warnings.append(f"{item_id}: sem campo 'Texture' nenhum no JSON do item (nem herdado de Parent)")

        atlas_w = float(image.size[0]) if image else _FALLBACK_ATLAS_SIZE
        atlas_h = float(image.size[1]) if image else _FALLBACK_ATLAS_SIZE

        # item_model_axis_fix nao se aplica aqui (correcao de eixo era um
        # falso positivo -- o problema real era a formula de rotacao).
        mesh = node_mesh.build_item_mesh(
            item_id,
            root_nodes,
            _ITEM_ENTITY_UNIT_SCALE,
            atlas_w,
            atlas_h,
            item_scale=1.0,
            root_correction=None,
        )
        _finish_model_mesh(mesh)
        mat = materials.get_or_create_flat_material(item_id + "_item_entity", image)
        mesh.materials.append(mat)
    except Exception as exc:  # noqa: BLE001 -- 1 arma quebrada nao pode travar o import
        if errored_items is not None:
            errored_items[f"[item] {item_id}"] = f"{type(exc).__name__}: {exc}"
        item_mesh_cache[item_id] = False
        return None

    built = {"mesh": mesh, "draw_type": "MODEL"}
    item_mesh_cache[item_id] = built
    return built


def _build_model_entity_mesh_entry(
    assets_source,
    model_id: str,
    model_mesh_cache: dict,
    unresolved_kind: set,
    errored_items: Optional[dict] = None,
    texture_warnings: Optional[list] = None,
):
    """Resolve a malha de uma "model entity" (trofeu de parede, NPC parado
    -- ex. Antelope, Klops_Gentleman): "Id" aponta pra um JSON em
    Server/Models/**/<Id>.json (NAO Server/Item/Items, ver
    scanner/item_index.py/load_model_json), com seu proprio "Model"/
    "Texture" no nivel raiz (sem cadeia Parent documentada pra esse caso).
    Mesmo unit_scale de item entities."""
    entry = model_mesh_cache.get(model_id)
    if entry is False:
        return None
    if entry is not None:
        return entry

    try:
        model_index_data = load_model_json(assets_source, model_id)
        if model_index_data is None or not model_index_data.get("Model"):
            unresolved_kind.add(f"[model] {model_id} -- not in Server/Models, or no 'Model' field")
            model_mesh_cache[model_id] = False
            return None

        model_path = _resolve_common_path(assets_source, model_index_data["Model"])
        if not model_path.is_file():
            unresolved_kind.add(f"[model] {model_id} -- model file not found: {model_index_data['Model']}")
            model_mesh_cache[model_id] = False
            return None
        with model_path.open("r", encoding="utf-8") as f:
            model_data = json.load(f)
        root_nodes = model_data.get("nodes", [])

        image = None
        texture_rel = model_index_data.get("Texture")
        if texture_rel:
            image = materials.get_or_load_image(_resolve_common_path(assets_source, texture_rel))
            if image is None and texture_warnings is not None:
                texture_warnings.append(
                    f"{model_id}: Texture (model entity) aponta pra '{texture_rel}' mas o arquivo nao "
                    f"foi encontrado em {_resolve_common_path(assets_source, texture_rel)}"
                )
        elif texture_warnings is not None:
            texture_warnings.append(f"{model_id}: sem campo 'Texture' nenhum no JSON de Server/Models")

        atlas_w = float(image.size[0]) if image else _FALLBACK_ATLAS_SIZE
        atlas_h = float(image.size[1]) if image else _FALLBACK_ATLAS_SIZE

        mesh = node_mesh.build_item_mesh(
            model_id,
            root_nodes,
            _ITEM_ENTITY_UNIT_SCALE,
            atlas_w,
            atlas_h,
            item_scale=1.0,
            root_correction=None,
        )
        _finish_model_mesh(mesh)
        mat = materials.get_or_create_flat_material(model_id + "_model_entity", image)
        mesh.materials.append(mat)
    except ItemIndexError as exc:
        # Pasta Server/Models nao existe nesse Assets (zip parcial/de teste)
        # -- nao trava o import, so marca esse tipo como nao resolvido.
        if errored_items is not None:
            errored_items[f"[model] {model_id}"] = f"ItemIndexError: {exc}"
        model_mesh_cache[model_id] = False
        return None
    except Exception as exc:  # noqa: BLE001 -- 1 model quebrado nao pode travar o import
        if errored_items is not None:
            errored_items[f"[model] {model_id}"] = f"{type(exc).__name__}: {exc}"
        model_mesh_cache[model_id] = False
        return None

    built = {"mesh": mesh, "draw_type": "MODEL"}
    model_mesh_cache[model_id] = built
    return built


def _is_ignored_entity(entity) -> bool:
    """Entity que _place_entities pula DE PROPOSITO (sem Components, ou com
    marcador de spawner/patrulha) -- nao conta no total do relatorio, senao
    "54/60 entities" parece falha quando na verdade 6 eram spawners."""
    components = entity.get("Components", {}) or {}
    return not components or any(marker in components for marker in _ENTITY_IGNORE_COMPONENTS)


def _prefab_display_stem(prefab_path: Path) -> str:
    """"Cozy_Tavern.prefab.json" -> "Cozy_Tavern" (Path.stem so tira o
    ultimo sufixo e deixaria "Cozy_Tavern.prefab")."""
    name = prefab_path.name
    for suffix in (".prefab.json", ".json"):
        if name.lower().endswith(suffix):
            return name[: -len(suffix)]
    return prefab_path.stem


def _addon_version() -> str:
    """Versao do blender_manifest.toml, so pra gravar no relatorio."""
    try:
        import tomllib

        manifest = Path(__file__).resolve().parent.parent / "blender_manifest.toml"
        with manifest.open("rb") as f:
            return str(tomllib.load(f).get("version", ""))
    except Exception:  # noqa: BLE001 -- so informativo, nunca pode travar o import
        return ""


def _store_report_on_collection(
    collection,
    *,
    prefab_path: Path,
    blocks_placed: int,
    blocks_total: int,
    entities_placed: int,
    entities_total: int,
    unique_meshes: int,
    missing_items: set,
    unresolved_kind: set,
    errored_items: dict,
    texture_warnings: list,
) -> None:
    """Grava o resultado do import como custom properties da Collection do
    prefab -- a secao "Prefabs in Scene" do painel le daqui (ver
    interface/__init__.py). Salvo junto com o .blend, entao o relatorio
    continua disponivel depois de fechar/reabrir o arquivo."""
    collection[PROP_PREFAB_FILE] = str(prefab_path)
    collection[PROP_PREFAB_BLOCKS_PLACED] = int(blocks_placed)
    collection[PROP_PREFAB_BLOCKS_TOTAL] = int(blocks_total)
    collection[PROP_PREFAB_ENTITIES_PLACED] = int(entities_placed)
    collection[PROP_PREFAB_ENTITIES_TOTAL] = int(entities_total)
    collection[PROP_PREFAB_UNIQUE_MESHES] = int(unique_meshes)
    collection[PROP_PREFAB_ADDON_VERSION] = _addon_version()
    collection[PROP_PREFAB_REPORT_JSON] = json.dumps(
        {
            "missing": sorted(missing_items),
            "unresolved": sorted(unresolved_kind),
            "errored": {k: errored_items[k] for k in sorted(errored_items)},
            "textures": list(texture_warnings),
        }
    )


class IMPORT_OT_hytale_prefab(Operator, ImportHelper):
    """Importa um .prefab.json do Hytale (grade de blocos + props soltos)
    pra dentro do Blender, resolvendo cada item contra a pasta/zip de
    Assets configurada nas Preferences do addon."""

    bl_idname = "import_scene.hytale_prefab"
    bl_label = "Import Prefab"
    bl_description = "Import a Hytale .prefab.json (block grid + loose props) into the scene"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.prefab.json;*.json", options={"HIDDEN"})

    block_grid_unit: FloatProperty(
        name="Grid Unit",
        description="Size of ONE grid cell, in Blender units. Also converts the continuous position of "
        "entities (same coordinate space as blocks). Adjust and re-import if something shows up "
        "overlapping or with gaps",
        default=BLOCK_GRID_UNIT_DEFAULT,
        min=0.001,
        soft_max=10.0,
        unit="LENGTH",
    )
    import_entities: BoolProperty(
        name="Import Entities",
        description="Import entities[] (off-grid props: mugs, candles, weapons, trophies, NPCs...), using "
        "the same item resolution as blocks. Turn off to import ONLY the block grid",
        default=True,
    )
    apply_rotation_heuristic: BoolProperty(
        name="Block Rotation",
        description="Decode each block's integer 'rotation' field (yaw/pitch/roll, base 4, 90 degree "
        "steps). Turn off to import everything unrotated (correct position, default orientation) "
        "while comparing with the game",
        default=True,
    )
    apply_entity_rotation_heuristic: BoolProperty(
        name="Entity Rotation",
        description="Unified rotation formula for block/item/model entities, validated number by number "
        "against the game. Turn off to import entities unrotated while comparing with the game",
        default=True,
    )
    model_scale_multiplier: FloatProperty(
        name="Block Model Scale",
        description="UNVERIFIED -- multiplier applied to blocks[] geometry that comes from its own "
        ".blockymodel (doors, branches, rope, etc.), separate from the plain 'cube' block size and "
        "WITHOUT affecting entities. Only change this when comparing a specific item against the game",
        default=1.0,
        min=0.001,
    )
    item_model_axis_fix: bpy.props.EnumProperty(
        name="Item Model Axis Fix",
        description="UNVERIFIED -- extra axis correction applied ONLY to a CustomModel coming from an "
        "'Items/' path (never to regular grid blocks from 'Blocks/'). Default 'None': current analysis "
        "suggests no correction is needed",
        items=[
            ("NONE", "None (default)", "Same convention as Blocks/, no extra correction"),
            ("MINUS_90_X", "-90° X", "Confirmed WRONG (front ends up facing up)"),
            ("PLUS_90_X", "+90° X", ""),
            ("180_X", "180° X", ""),
            ("MINUS_90_Y", "-90° Y", ""),
            ("PLUS_90_Y", "+90° Y", ""),
            ("MINUS_90_Z", "-90° Z", ""),
            ("PLUS_90_Z", "+90° Z", ""),
        ],
        default="NONE",
    )

    # ---- Optimizer (todas desligadas por padrao = import classico) ----
    optimizer_output: EnumProperty(
        name="Output",
        description="How the imported prefab is built in the scene",
        items=[
            (
                "OBJECTS", "Objects",
                "One object per block/entity (default). Every block can be selected and inspected, "
                "but very large prefabs get heavy (hundreds of thousands of objects)",
                "OBJECT_DATA", 0,
            ),
            (
                "INSTANCES", "Instances",
                "One object per unique item, with Geometry Nodes placing every copy. Much lighter viewport "
                "and render (great for renders); single blocks can no longer be selected/inspected",
                "OUTLINER_OB_POINTCLOUD", 1,
            ),
            (
                "SINGLE_MESH", "Single Mesh",
                "Everything merged into one mesh object (great for exporting to other engines or "
                "editing as a whole); single blocks can no longer be selected/inspected",
                "MESH_DATA", 2,
            ),
        ],
        default="OBJECTS",
    )
    opt_remove_hidden_blocks: BoolProperty(
        name="Remove Hidden Blocks",
        description="Skip cube blocks completely enclosed by opaque cube blocks on all 6 sides -- they can't be "
        "seen from any angle (e.g. the inside of solid walls and terrain)",
        default=False,
    )
    opt_remove_hidden_faces: BoolProperty(
        name="Remove Hidden Faces",
        description="Single Mesh only: delete cube faces touching an opaque cube (the faces between two "
        "stacked blocks). Big polygon savings on walls and terrain",
        default=False,
    )
    opt_merge_by_distance: BoolProperty(
        name="Merge by Distance",
        description="Weld overlapping vertices (0.0001 block). Fewer vertices, same look -- UVs are kept. "
        "In Single Mesh mode it also welds neighboring blocks together",
        default=False,
    )
    opt_smart_alpha: BoolProperty(
        name="Alpha Only When Needed",
        description="Textures with an alpha channel but no transparent pixel get an opaque material "
        "(cheaper to draw and render). Same look",
        default=False,
    )
    opt_limit_region: BoolProperty(
        name="Limit to Region",
        description="Only import blocks/entities inside a box of grid coordinates (the x/y/z of the prefab "
        "file). Useful to bring in just a piece of a huge prefab",
        default=False,
    )
    opt_region_min: IntVectorProperty(name="Min", size=3, default=(-32, -32, -32), description="Smallest x, y, z (inclusive)")
    opt_region_max: IntVectorProperty(name="Max", size=3, default=(32, 32, 32), description="Largest x, y, z (inclusive)")


    @classmethod
    def poll(cls, context):
        return game_found()          # sem a pasta do jogo o addon fica travado (common.game_found)

    def invoke(self, context, event):
        # Arrastar um .json pra Viewport (HYBLENDPREFABS_FH_prefab) ja chega
        # com filepath preenchido -- mostra so as opcoes num popup em vez de
        # abrir o file browser de novo. ImportHelper.invoke_popup existe
        # desde o Blender 4.2 (minimo do addon e 4.5).
        if self.properties.is_property_set("filepath"):
            return self.invoke_popup(context)
        return ImportHelper.invoke(self, context, event)

    def draw(self, context):
        """Opcoes do import (sidebar do file browser / popup do drag-and-
        drop), agrupadas em secoes recolhiveis. layout.panel() em draw()
        de operador e suportado desde o Blender 4.2."""
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        # (sem a pasta do jogo o import nem abre: poll/common.game_found)
        header, body = layout.panel("HYBLENDPREFABS_import_general", default_closed=False)
        header.label(text="General", icon="SETTINGS")
        if body:
            body.prop(self, "block_grid_unit")
            body.prop(self, "import_entities")

        header, body = layout.panel("HYBLENDPREFABS_import_rotation", default_closed=False)
        header.label(text="Rotation", icon="ORIENTATION_GIMBAL")
        if body:
            body.prop(self, "apply_rotation_heuristic")
            sub = body.row()
            sub.active = self.import_entities
            sub.prop(self, "apply_entity_rotation_heuristic")

        self._draw_optimizer(layout)

        if not is_developer_mode(context):
            return
        header, body = layout.panel("HYBLENDPREFABS_import_experimental", default_closed=True)
        header.label(text="Experimental", icon="EXPERIMENTAL")
        if body:
            col = body.column()
            col.label(text="Unverified -- for comparing against the game", icon="INFO")
            col.prop(self, "model_scale_multiplier")
            col.prop(self, "item_model_axis_fix")

    def _draw_optimizer(self, layout):
        """Secao Optimizer (fechada por padrao). Tudo desligado = import
        classico, sem nenhuma diferenca de resultado."""
        header, body = layout.panel("HYBLENDPREFABS_import_optimizer", default_closed=True)
        header.label(text="Optimizer", icon="MODIFIER")
        active = (
            self.optimizer_output != "OBJECTS"
            or self.opt_remove_hidden_blocks
            or (self.optimizer_output == "SINGLE_MESH" and self.opt_remove_hidden_faces)
            or self.opt_merge_by_distance
            or self.opt_smart_alpha
            or self.opt_limit_region
        )
        if active:
            badge = header.row()
            badge.alignment = "RIGHT"
            badge.label(text="", icon="CHECKMARK")
        if not body:
            return

        col = body.column()
        col.use_property_split = False
        col.label(text="Output")
        col.row().prop(self, "optimizer_output", expand=True)
        hint = col.column(align=True)
        hint.scale_y = 0.8
        if self.optimizer_output == "OBJECTS":
            hint.label(text="One object per block (every block selectable).", icon="INFO")
        elif self.optimizer_output == "INSTANCES":
            hint.label(text="Lightest viewport and render.", icon="INFO")
            hint.label(text="Single blocks can't be selected.", icon="BLANK1")
        else:
            hint.label(text="One mesh -- best for exporting.", icon="INFO")
            hint.label(text="Single blocks can't be selected.", icon="BLANK1")

        col.separator()
        col.label(text="Geometry")
        col.prop(self, "opt_remove_hidden_blocks")
        faces = col.row()
        faces.active = self.optimizer_output == "SINGLE_MESH"
        faces.prop(self, "opt_remove_hidden_faces")
        col.prop(self, "opt_merge_by_distance")

        col.separator()
        col.label(text="Materials")
        col.prop(self, "opt_smart_alpha")

        col.separator()
        col.label(text="Scope")
        col.prop(self, "opt_limit_region")
        if self.opt_limit_region:
            box = col.column(align=True)
            box.prop(self, "opt_region_min", text="Min")
            box.prop(self, "opt_region_max", text="Max")

    def execute(self, context):
        if not is_developer_mode(context):
            # Opcoes Experimental so aparecem em Developer Mode -- sem ele,
            # um valor antigo lembrado pelo operador (o Blender guarda o
            # ultimo usado) nao pode ficar agindo escondido.
            self.model_scale_multiplier = 1.0
            self.item_model_axis_fix = "NONE"
        try:
            assets_source = get_assets_source(context)
        except AssetsSourceError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        wm = context.window_manager
        wm.progress_begin(0.0, 100.0)
        # Opcoes do Optimizer que moram fora do operador (montagem de malha,
        # material) -- ligadas so durante este import, sempre desligadas no fim.
        materials.set_import_options(smart_alpha=self.opt_smart_alpha)
        _build_options["merge_by_distance"] = self.opt_merge_by_distance
        _build_options["need_opacity"] = self.opt_remove_hidden_blocks or (
            self.optimizer_output == "SINGLE_MESH" and self.opt_remove_hidden_faces
        )
        try:
            return self._execute(context, assets_source)
        except ItemIndexError as exc:            # Assets.zip sem Server/Item/Items (instalação quebrada)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        finally:
            materials.set_import_options()
            _build_options["merge_by_distance"] = False
            _build_options["need_opacity"] = False
            wm.progress_end()

    def _in_region(self, x, y, z) -> bool:
        lo, hi = self.opt_region_min, self.opt_region_max
        return (
            min(lo[0], hi[0]) <= x <= max(lo[0], hi[0])
            and min(lo[1], hi[1]) <= y <= max(lo[1], hi[1])
            and min(lo[2], hi[2]) <= z <= max(lo[2], hi[2])
        )

    def _execute(self, context, assets_source):
        wm = context.window_manager
        prefab_path = Path(self.filepath)
        try:
            with prefab_path.open("r", encoding="utf-8") as f:
                prefab_data = json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            self.report({"ERROR"}, f"Could not read '{prefab_path}': {exc}")
            return {"CANCELLED"}

        blocks = prefab_data.get("blocks", []) or []
        entities = (prefab_data.get("entities", []) or []) if self.import_entities else []
        # Libera ja o resto do JSON (fluids[] etc. nunca sao usados -- num
        # prefab com muita agua isso e boa parte do arquivo). blocks/entities
        # sao liberados logo depois de virarem Placements/Objects.
        prefab_data = None  # noqa: F841
        if not blocks and not entities:
            self.report({"WARNING"}, "This file has no entries in 'blocks' or 'entities' -- nothing to import.")
            return {"CANCELLED"}

        display_name = _prefab_display_stem(prefab_path)
        collection = bpy.data.collections.new(f"{PREFAB_COLLECTION_PREFIX}{display_name}")
        context.scene.collection.children.link(collection)

        root_empty = bpy.data.objects.new(f"Prefab - {display_name}", None)
        root_empty.empty_display_type = "PLAIN_AXES"
        root_empty[PROP_PREFAB_ROOT] = True
        # Unica correcao de eixo do import: tudo e construido em espaco de
        # arquivo (Y-up); +90 em X no Object raiz converte pra Z-up do Blender.
        root_empty.rotation_euler = (1.5707963267948966, 0.0, 0.0)  # 90 graus em X
        collection.objects.link(root_empty)

        def loader(iid: str):
            return load_item_json(assets_source, iid)

        mesh_cache: dict = {}
        # Caches proprios pra item/model entities (unit_scale diferente de
        # blocks[]/block entities, nao pode compartilhar mesh_cache).
        item_mesh_cache: dict = {}
        model_mesh_cache: dict = {}
        missing_items: set = set()
        unresolved_kind: set = set()
        errored_items: dict = {}
        texture_warnings: list = []
        placements: list = []
        placed = 0
        skipped_secondary_cells = 0
        skipped_empty = 0
        skipped_region_blocks = 0
        limit_region = self.opt_limit_region

        # ---- Fase 1: resolver (malhas + matrizes), sem criar Object ----
        grid_unit = self.block_grid_unit
        pivot = Vector((0.5, 0.5, 0.5)) * grid_unit
        shift_model = Vector((0.5, 0.0, 0.5)) * grid_unit
        pivot_in = Matrix.Translation(pivot)
        pivot_out = Matrix.Translation(-pivot)
        progress_step = max(len(blocks) // 200, 1)
        for index, block in enumerate(blocks):
            if index % progress_step == 0:
                wm.progress_update(35.0 * index / max(len(blocks), 1))
            raw_name = block.get("name")
            if not raw_name:
                continue

            if raw_name == "Empty":
                # Marcador de "celula de ar" do proprio formato -- blocks[]
                # cobre a caixa delimitadora inteira, entao toda celula
                # vazia aparece como {"x":,"y":,"z":,"name":"Empty"}. Nao
                # conta como item desconhecido nem afeta "blocks placed".
                skipped_empty += 1
                continue

            if "filler" in block:
                # Celula "secundaria" de um bloco que ocupa mais de 1x1x1
                # (porta, mesa, lustre...) -- o modelo ja e desenhado
                # inteiro a partir da celula PRINCIPAL (a UNICA sem a chave
                # "filler"); desenhar de novo aqui duplicaria a peca.
                # "filler" e um inteiro com 3 campos de bits (offset por
                # eixo dentro da caixa multi-celula) -- qualquer valor
                # presente, nao so um bit especifico, marca "secundaria".
                skipped_secondary_cells += 1
                continue

            grid_pos = (block.get("x", 0), block.get("y", 0), block.get("z", 0))
            if limit_region and not self._in_region(*grid_pos):
                skipped_region_blocks += 1
                continue

            item_id, state_name = parse_resolved_name(raw_name)
            entry = _get_or_build_entry(
                item_id,
                assets_source,
                loader,
                grid_unit,
                mesh_cache,
                missing_items,
                unresolved_kind,
                self.item_model_axis_fix,
                errored_items,
                texture_warnings,
            )
            if entry is None:
                continue

            # Rotacao pivota no CENTRO do bloco. Cada tipo de malha nasce
            # numa origem diferente e precisa do seu proprio "shift" pra
            # alinhar com a celula ANTES de rotacionar:
            #   - MODEL: centrada em X/Z, Y=0 no fundo -> shift so em X/Z.
            #   - CUBE: centrada nos 3 eixos -> shift == pivot.
            # Composto como UMA matriz local (matrix_basis) porque o pivo
            # nao coincide com a origem do Object.
            rot_matrix = decode_block_rotation(block.get("rotation"), self.apply_rotation_heuristic)
            is_model = entry.get("draw_type") == "MODEL"
            shift = shift_model if is_model else pivot
            matrix = (
                Matrix.Translation(Vector(grid_pos) * grid_unit)
                @ pivot_in
                @ rot_matrix
                @ pivot_out
                @ Matrix.Translation(shift)
            )
            # model_scale_multiplier so se aplica a blocks[] tipo "MODEL"
            # (nunca entities, que tem seu proprio EntityScale.Scale, nem
            # blocos "cubo"). Aplicado na matriz do Object, nunca na malha
            # compartilhada -- mesmo resultado de `obj.scale = (s,s,s)`
            # depois de `obj.matrix_basis = ...` (versoes anteriores).
            if is_model and self.model_scale_multiplier != 1.0:
                s = self.model_scale_multiplier
                loc, rot, _scale = matrix.decompose()
                matrix = Matrix.LocRotScale(loc, rot, (s, s, s))

            placements.append(Placement(item_id, entry, matrix, block=block, state=state_name, grid=grid_pos))
            placed += 1

        entities_placed = 0
        skipped_region_entities = 0
        if entities:
            entities_placed, entities_missing, entities_unresolved, skipped_region_entities = self._place_entities(
                entities,
                assets_source,
                loader,
                mesh_cache,
                item_mesh_cache,
                model_mesh_cache,
                placements,
                errored_items,
                texture_warnings,
            )
            missing_items |= entities_missing
            unresolved_kind |= entities_unresolved
        wm.progress_update(50.0)

        # Contagens que dependem do JSON cru -- calculadas antes de liberar.
        real_block_count = len(blocks) - skipped_empty - skipped_secondary_cells - skipped_region_blocks
        entities_real_total = sum(1 for e in entities if not _is_ignored_entity(e)) - skipped_region_entities
        blocks = entities = None  # noqa: F841 -- JSON nao e mais necessario

        # ---- Optimizer: remover blocos escondidos ----
        hidden_blocks_removed = 0
        opaque_keys = None
        if _build_options["need_opacity"]:
            placements, hidden_blocks_removed, opaque_keys = _cull_hidden_blocks(
                placements, remove_blocks=self.opt_remove_hidden_blocks
            )

        # ---- Fase 2: emitir ----
        output = self.optimizer_output
        hidden_faces_removed = 0
        shared_meshes = {id(p.entry["mesh"]): p.entry["mesh"] for p in placements}
        if output == "INSTANCES":
            emit_instances(context, placements, collection, root_empty, display_name)
        elif output == "SINGLE_MESH":
            result = emit_single_mesh(
                context,
                placements,
                collection,
                root_empty,
                display_name,
                opaque_cells=opaque_keys,
                remove_hidden_faces=self.opt_remove_hidden_faces,
                weld=self.opt_merge_by_distance,
            )
            hidden_faces_removed = result["faces_removed"]
        else:
            emit_objects(context, placements, collection, root_empty)
        placements = None  # noqa: F841
        if output != "OBJECTS":
            # Single Mesh copia a geometria -- as malhas compartilhadas ficam
            # sem uso. Instances usa elas nos Objects de origem (continuam).
            remove_unused_meshes(shared_meshes.values())
        shared_meshes = None  # noqa: F841
        gc.collect()

        # Malhas unicas = entradas resolvidas (!= False) nos 3 caches. A conta
        # antiga (len(mesh_cache) - missing - unresolved) misturava ids de
        # entity que nunca entram em mesh_cache e podia dar negativo.
        unique_meshes = sum(1 for cache in (mesh_cache, item_mesh_cache, model_mesh_cache) for v in cache.values() if v)

        _store_report_on_collection(
            collection,
            prefab_path=prefab_path,
            blocks_placed=placed,
            blocks_total=real_block_count,
            entities_placed=entities_placed,
            entities_total=entities_real_total if self.import_entities else -1,
            unique_meshes=unique_meshes,
            missing_items=missing_items,
            unresolved_kind=unresolved_kind,
            errored_items=errored_items,
            texture_warnings=texture_warnings,
        )
        collection[PROP_PREFAB_OUTPUT_MODE] = output
        collection[PROP_PREFAB_HIDDEN_BLOCKS] = int(hidden_blocks_removed)
        collection[PROP_PREFAB_HIDDEN_FACES] = int(hidden_faces_removed)
        collection[PROP_PREFAB_REGION_SKIPPED] = int(skipped_region_blocks + skipped_region_entities)

        # Deixa o prefab recem-importado selecionado (raiz ativa) -- mover a
        # raiz move o prefab inteiro, e o painel ja mostra ele em "Selection".
        for obj in context.selected_objects:
            obj.select_set(False)
        root_empty.select_set(True)
        context.view_layer.objects.active = root_empty

        msg = f"Hyblend Prefab: {placed}/{real_block_count} blocks placed, {unique_meshes} unique meshes."
        if output != "OBJECTS":
            msg += f" | Output: {output.replace('_', ' ').title()}"
        if hidden_blocks_removed:
            msg += f" | {hidden_blocks_removed} hidden block(s) removed"
        if hidden_faces_removed:
            msg += f" | {hidden_faces_removed} hidden face(s) removed"
        if skipped_region_blocks or skipped_region_entities:
            msg += f" | {skipped_region_blocks + skipped_region_entities} outside the region skipped"
        if skipped_empty:
            msg += f" | {skipped_empty} empty cell(s) skipped (air, not a bug -- see README.md)"
        if skipped_secondary_cells:
            msg += f" | {skipped_secondary_cells} secondary cell(s) skipped ('filler' key present, e.g. tall doors, tables, benches -- see README.md)"
        if self.import_entities:
            msg += f" | {entities_placed}/{entities_real_total} entities placed"
        if missing_items:
            # "[item] "/"[model] " no comeco = id nao veio de Server/Item/Items
            # (item/model entities tem busca propria, ver DEVELOPER_NOTES.md).
            sample = ", ".join(sorted(missing_items)[:8])
            msg += f" | {len(missing_items)} unknown item id(s): {sample}"
        if unresolved_kind:
            sample = ", ".join(sorted(unresolved_kind)[:8])
            msg += f" | {len(unresolved_kind)} item(s) with no known model/shape (BlockType, item Model/Texture, or Server/Models entry): {sample}"
        if errored_items:
            sample = ", ".join(sorted(errored_items)[:8])
            msg += f" | {len(errored_items)} item(s) skipped due to an error while building their mesh (see System Console for details): {sample}"
        if texture_warnings:
            # Cada item com problema de textura entra uma vez (cacheado por item_id).
            names = sorted({w.split(":", 1)[0] for w in texture_warnings})
            sample = ", ".join(names[:8])
            msg += f" | {len(names)} item(s) with a texture problem, drawn with a gray placeholder (see System Console for details): {sample}"

        level = "WARNING" if (missing_items or unresolved_kind or errored_items or texture_warnings) else "INFO"
        self.report({level}, msg)
        if errored_items:
            print("Hyblend Prefab -- itens pulados por erro ao construir a malha:")
            for iid, err in sorted(errored_items.items()):
                print(f"  {iid}: {err}")
        if texture_warnings:
            print("Hyblend Prefab -- itens com problema de textura (material placeholder cinza):")
            for w in texture_warnings:
                print(f"  {w}")
        return {"FINISHED"}

    def _place_entities(
        self,
        entities,
        assets_source,
        loader,
        mesh_cache,
        item_mesh_cache,
        model_mesh_cache,
        placements,
        errored_items=None,
        texture_warnings=None,
    ):
        """Resolve entities[] (props fora da grade) em Placements (o Object
        so e criado na fase 2, ver emitters.py). Existem TRES tipos de
        entity, cada um com seu proprio jeito de achar malha/escala/rotacao.
        Classificacao (nesta ordem, ver DEVELOPER_NOTES.md "Entities"):

        1. `Components.BlockEntity` presente -> "block entity" (caneca,
           vela, prato, barril, quadro...). Malha = BlockType do item
           (BlockEntity.BlockTypeKey), mesma resolucao de blocks[] mas SEM
           CustomModelScale. Rotacao de HeadRotation (nao Transform.Rotation,
           que e lixo nesse caso). Escala final = 0.5 * EntityScale.Scale.
           Pivo = centro do bloco (celula 1x1x1).
        2. `Components.Model` presente -> "model entity" (trofeu de parede,
           NPC parado). Malha de Server/Models/**/<Model.Model.Id>.json.
           Rotacao sempre de Transform.Rotation. Escala final =
           Model.Model.Scale * EntityScale.Scale (sem 0.5 extra -- ja esta
           embutido em _ITEM_ENTITY_UNIT_SCALE). Pivo = origem nativa do modelo.
        3. `Components.Item` presente (sem BlockEntity) -> "item entity"
           (arma solta). Malha do "Model"/"Texture" do nivel raiz do proprio
           item.json (nao do BlockType). Rotacao sempre de Transform.Rotation.
           Escala final = EntityScale.Scale (sem 0.5 extra). Pivo = origem
           nativa do modelo.

        Entities sem nenhum dos 3 componentes, ou com qualquer marcador de
        _ENTITY_IGNORE_COMPONENTS, sao ignoradas.

        Devolve (colocadas, ids desconhecidos, ids sem modelo, fora da regiao)."""
        placed = 0
        skipped_region = 0
        missing: set = set()
        unresolved: set = set()
        if errored_items is None:
            errored_items = {}
        wm = bpy.context.window_manager
        progress_step = max(len(entities) // 100, 1)

        for index, entity in enumerate(entities):
            if index % progress_step == 0:
                wm.progress_update(35.0 + 15.0 * index / max(len(entities), 1))
            if _is_ignored_entity(entity):
                continue
            components = entity.get("Components", {}) or {}

            transform = components.get("Transform", {}) or {}
            pos = transform.get("Position", {}) or {}
            position_raw = (pos.get("X", 0.0), pos.get("Y", 0.0), pos.get("Z", 0.0))
            if self.opt_limit_region:
                try:
                    cell = tuple(math.floor(float(v)) for v in position_raw)
                except (TypeError, ValueError):
                    cell = (0, 0, 0)
                if not self._in_region(*cell):
                    skipped_region += 1
                    continue
            pos_vec = Vector(position_raw)
            uuid_hex = ((components.get("UUID", {}) or {}).get("UUID", {}) or {}).get("$binary")

            block_entity_comp = components.get("BlockEntity")
            model_comp = ((components.get("Model", {}) or {}).get("Model", {}) or {}) if "Model" in components else None
            item_comp = ((components.get("Item", {}) or {}).get("Item", {}) or {}) if "Item" in components else None

            entity_scale_raw = (components.get("EntityScale", {}) or {}).get("Scale", 1.0)
            try:
                entity_scale_raw = float(entity_scale_raw)
            except (TypeError, ValueError):
                entity_scale_raw = 1.0

            if block_entity_comp is not None:
                # ---- 1. Block entity ------------------------------------
                kind = "block"
                raw_item_id = block_entity_comp.get("BlockTypeKey") or (item_comp or {}).get("Id") or ""
                if not raw_item_id:
                    continue
                item_id, entity_state_name = parse_resolved_name(raw_item_id)

                entry = _get_or_build_entry(
                    item_id,
                    assets_source,
                    loader,
                    self.block_grid_unit,
                    mesh_cache,
                    missing,
                    unresolved,
                    self.item_model_axis_fix,
                    errored_items,
                    texture_warnings,
                    entity_context=True,
                )
                if entry is None:
                    continue

                # HeadRotation e a rotacao visivel de uma block entity
                # (Transform.Rotation dela e lixo). Cai pra Transform.Rotation
                # so se HeadRotation nao existir (nao deveria com dado real).
                head_rot = (components.get("HeadRotation", {}) or {}).get("Rotation")
                rot = head_rot if head_rot else transform.get("Rotation", {}) or {}
                pitch_raw = rot.get("Pitch", 0.0)
                yaw_raw = rot.get("Yaw", 0.0)
                roll_raw = rot.get("Roll", 0.0)

                rot_quat = decode_block_entity_rotation(
                    pitch_raw, yaw_raw, roll_raw, self.apply_entity_rotation_heuristic
                )
                s = 0.5 * entity_scale_raw
                # draw_type "MODEL" nasce em unidades nativas "1 = 1 bloco"
                # (sem block_grid_unit embutido) -- precisa multiplicar
                # aqui. "CUBE" ja nasce em unidades Blender reais
                # (size=block_grid_unit direto), multiplicar de novo dobraria
                # o tamanho. unit_factor cobre os dois casos com a mesma formula.
                is_model = entry.get("draw_type") == "MODEL"
                unit_factor = self.block_grid_unit if is_model else 1.0
                mesh_origin_offset = Vector((0.0, 0.5, 0.0)) if is_model else Vector((0.0, 0.0, 0.0))
                geom_scale = s * unit_factor
                center_blender = pos_vec * self.block_grid_unit + Vector((0.0, 0.5 * geom_scale, 0.0))
                matrix = (
                    Matrix.Translation(center_blender)
                    @ Matrix.Scale(geom_scale, 4)
                    @ rot_quat.to_matrix().to_4x4()
                    @ Matrix.Translation(-mesh_origin_offset)
                )
                props = {
                    PROP_ENTITY_ITEM_ID: item_id,
                    PROP_ENTITY_ITEM_ID_RAW: raw_item_id,
                    PROP_ENTITY_STATE: entity_state_name or "",
                    PROP_ENTITY_KIND: kind,
                    PROP_ENTITY_UUID: uuid_hex or "",
                    PROP_ENTITY_SCALE_RAW: entity_scale_raw,
                    PROP_ENTITY_ROTATION_PITCH_RAW: pitch_raw,
                    PROP_ENTITY_ROTATION_YAW_RAW: yaw_raw,
                    PROP_ENTITY_ROTATION_ROLL_RAW: roll_raw,
                    PROP_ENTITY_POSITION_RAW: position_raw,
                }
                placements.append(Placement(item_id, entry, matrix, props=props))
                placed += 1
                continue

            if model_comp is not None:
                # ---- 2. Model entity -------------------------------------
                kind = "model"
                model_id = model_comp.get("Id")
                if not model_id:
                    continue
                model_scale_raw = model_comp.get("Scale", 1.0)
                try:
                    model_scale_raw = float(model_scale_raw)
                except (TypeError, ValueError):
                    model_scale_raw = 1.0

                entry = _build_model_entity_mesh_entry(
                    assets_source, model_id, model_mesh_cache, unresolved, errored_items, texture_warnings
                )
                if entry is None:
                    continue

                rot = transform.get("Rotation", {}) or {}
                pitch_raw = rot.get("Pitch", 0.0)
                yaw_raw = rot.get("Yaw", 0.0)
                roll_raw = rot.get("Roll", 0.0)
                rot_quat = decode_item_or_model_entity_rotation(
                    pitch_raw, yaw_raw, roll_raw, self.apply_entity_rotation_heuristic
                )
                # Sem 0.5 extra aqui -- ja esta embutido em
                # _ITEM_ENTITY_UNIT_SCALE. S = Model.Scale * EntityScale.
                s = model_scale_raw * entity_scale_raw
                matrix = (
                    Matrix.Scale(self.block_grid_unit, 4)
                    @ Matrix.Translation(pos_vec)
                    @ Matrix.Scale(s, 4)
                    @ rot_quat.to_matrix().to_4x4()
                )
                props = {
                    PROP_ENTITY_ITEM_ID: model_id,
                    PROP_ENTITY_ITEM_ID_RAW: model_id,
                    PROP_ENTITY_STATE: "",
                    PROP_ENTITY_KIND: kind,
                    PROP_ENTITY_UUID: uuid_hex or "",
                    PROP_ENTITY_SCALE_RAW: entity_scale_raw,
                    PROP_ENTITY_MODEL_SCALE_RAW: model_scale_raw,
                    PROP_ENTITY_ROTATION_PITCH_RAW: pitch_raw,
                    PROP_ENTITY_ROTATION_YAW_RAW: yaw_raw,
                    PROP_ENTITY_ROTATION_ROLL_RAW: roll_raw,
                    PROP_ENTITY_POSITION_RAW: position_raw,
                }
                placements.append(Placement(model_id, entry, matrix, props=props))
                placed += 1
                continue

            if item_comp is not None:
                # ---- 3. Item entity ---------------------------------------
                kind = "item"
                raw_item_id = item_comp.get("Id")
                if not raw_item_id:
                    continue
                item_id, entity_state_name = parse_resolved_name(raw_item_id)

                entry = _build_item_entity_mesh_entry(
                    assets_source, item_id, loader, item_mesh_cache, unresolved, errored_items, texture_warnings
                )
                if entry is None:
                    continue

                rot = transform.get("Rotation", {}) or {}
                pitch_raw = rot.get("Pitch", 0.0)
                yaw_raw = rot.get("Yaw", 0.0)
                roll_raw = rot.get("Roll", 0.0)
                rot_quat = decode_item_or_model_entity_rotation(
                    pitch_raw, yaw_raw, roll_raw, self.apply_entity_rotation_heuristic
                )
                # Mesmo ajuste do model entity acima -- sem 0.5 extra.
                s = entity_scale_raw
                matrix = (
                    Matrix.Scale(self.block_grid_unit, 4)
                    @ Matrix.Translation(pos_vec)
                    @ Matrix.Scale(s, 4)
                    @ rot_quat.to_matrix().to_4x4()
                )
                props = {
                    PROP_ENTITY_ITEM_ID: item_id,
                    PROP_ENTITY_ITEM_ID_RAW: raw_item_id,
                    PROP_ENTITY_STATE: entity_state_name or "",
                    PROP_ENTITY_KIND: kind,
                    PROP_ENTITY_UUID: uuid_hex or "",
                    PROP_ENTITY_SCALE_RAW: entity_scale_raw,
                    PROP_ENTITY_ROTATION_PITCH_RAW: pitch_raw,
                    PROP_ENTITY_ROTATION_YAW_RAW: yaw_raw,
                    PROP_ENTITY_ROTATION_ROLL_RAW: roll_raw,
                    PROP_ENTITY_POSITION_RAW: position_raw,
                }
                placements.append(Placement(item_id, entry, matrix, props=props))
                placed += 1
                continue

            # Nenhum dos 3 componentes conhecidos -- pula sem travar o import.

        return placed, missing, unresolved, skipped_region


def _cull_hidden_blocks(placements, remove_blocks: bool):
    """Optimizer: acha as celulas ocupadas por cubo OPACO (entry["opaque"],
    ver _build_mesh_entry) e, com `remove_blocks`, descarta todo bloco CUBO
    cujas 6 celulas vizinhas sao cubos opacos (nunca aparece de nenhum
    angulo). Devolve (placements filtradas, quantos removidos, chaves das
    celulas opacas pro culling de face do Single Mesh).

    Considera so o que foi IMPORTADO: com "Limit to Region", a borda da
    regiao conta como ar (faces da borda continuam visiveis)."""
    import numpy as np

    from .emitters import _grid_key

    opaque_cells = [p.grid for p in placements if p.grid is not None and p.entry.get("opaque")]
    if not opaque_cells:
        return placements, 0, None
    opaque_keys = np.unique(_grid_key(opaque_cells))
    if not remove_blocks:
        return placements, 0, opaque_keys

    cube_idx = [i for i, p in enumerate(placements) if p.grid is not None and p.entry.get("draw_type") == "CUBE"]
    if not cube_idx:
        return placements, 0, opaque_keys
    grid = np.array([placements[i].grid for i in cube_idx], dtype=np.int64)
    enclosed = np.ones(len(cube_idx), dtype=bool)
    for offset in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
        keys = _grid_key(grid + np.array(offset, dtype=np.int64))
        idx = np.clip(np.searchsorted(opaque_keys, keys), 0, len(opaque_keys) - 1)
        enclosed &= opaque_keys[idx] == keys
    drop = {cube_idx[i] for i in np.nonzero(enclosed)[0]}
    if not drop:
        return placements, 0, opaque_keys
    kept = [p for i, p in enumerate(placements) if i not in drop]
    return kept, len(drop), opaque_keys


class HYBLENDPREFABS_FH_prefab(bpy.types.FileHandler):
    """Arrastar um .prefab.json do explorador de arquivos pra Viewport 3D
    abre o popup de opcoes do import (ver IMPORT_OT_hytale_prefab.invoke).
    A extensao registrada e ".json" (o Blender compara so a extensao final)
    -- qualquer .json solto na Viewport oferece este import; um .json que
    nao e prefab so gera o aviso "no entries in 'blocks' or 'entities'"."""

    bl_idname = "HYBLENDPREFABS_FH_prefab"
    bl_label = "Hytale Prefab"
    bl_import_operator = "import_scene.hytale_prefab"
    bl_file_extensions = ".json"

    @classmethod
    def poll_drop(cls, context):
        # sem a pasta do jogo o addon fica travado (common.game_found)
        return game_found() and context.area is not None and context.area.type == "VIEW_3D"


def menu_func_import(self, context):
    if not game_found():          # sem a pasta do jogo: nada do addon nos menus
        return
    self.layout.operator(IMPORT_OT_hytale_prefab.bl_idname, text="Hytale Prefab (.prefab.json)")


_CLASSES = (IMPORT_OT_hytale_prefab, HYBLENDPREFABS_FH_prefab)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
    materials.clear_caches()
