"""catalog.py -- cache em memoria (por sessao do Blender) dos catalogos
de item (Gloves/Overtops/Pants/BodyCharacteristics/...) e do
GradientSets, pra alimentar os dropdowns da UI sem reler/reparsear os
.json toda vez que o Blender redesenha o painel (EnumProperty com items
via callback e chamado MUITO frequentemente -- reparsear JSON nesse
caminho travaria a interface).

So guarda estado, nao sabe nada de bpy/UI -- quem decide QUANDO invalidar
(pasta Assets mudou, botao "Recarregar") e o __init__.py.
"""

from __future__ import annotations

from pathlib import Path

from .gradient_parser import parse_gradient_sets
from .lang_parser import load_avatar_customization_lang
from .manifest_parser import parse_character_creator_folder


class CatalogCache:
    def __init__(self):
        self.character_creator_dir: "Path | None" = None
        self.catalogs: dict = {}
        self.gradient_sets: dict = {}
        self._item_index: dict = {}

        self.languages_dir: "Path | None" = None
        self.language: "str | None" = None
        self.lang: dict = {}

    def ensure_loaded(self, character_creator_dir: Path) -> None:
        """Reparseia so se a pasta mudou desde a ultima vez (ex: usuario
        trocou a pasta Assets nas Preferences) ou se ainda nao carregou
        nada nesta sessao."""
        if self.character_creator_dir == character_creator_dir and self.catalogs:
            return

        self.catalogs = parse_character_creator_folder(character_creator_dir)
        # Indice (categoria, id) -> Item, construido UMA VEZ aqui --
        # BUG DE PERFORMANCE REAL corrigido: find_item() antes fazia uma
        # busca linear na lista toda vez que era chamada, e e chamada
        # MUITAS vezes por redraw do painel (uma vez por linha visivel,
        # de dentro de varias funcoes diferentes). Com um catalogo grande
        # (Haircuts, 112 itens) isso somava rapido.
        self._item_index = {
            (category, item.id): item
            for category, items in self.catalogs.items()
            for item in items
        }

        gradient_sets_path = character_creator_dir / "GradientSets.json"
        self.gradient_sets = parse_gradient_sets(gradient_sets_path) if gradient_sets_path.is_file() else {}

        self.character_creator_dir = character_creator_dir

    def ensure_lang_loaded(self, languages_dir: Path, language: str) -> None:
        """Idem, mas pro dict de textos localizados -- fonte (pasta) E
        idioma juntos decidem se precisa reparsear."""
        if self.languages_dir == languages_dir and self.language == language and self.lang:
            return
        self.lang = load_avatar_customization_lang(languages_dir, language)
        self.languages_dir = languages_dir
        self.language = language

    def display_name(self, name_key: str) -> str:
        """Resolve um name_key (ex.
        "avatarCustomization.gloves.BasicGloves_Basic.name") pro texto
        localizado -- devolve o proprio name_key sem alteracao se a
        chave nao for encontrada (idioma nao carregado, .lang nao tem
        essa entrada, etc.) -- nunca falha, so degrada pro texto tecnico."""
        return self.lang.get(name_key, name_key)

    def invalidate(self) -> None:
        self.character_creator_dir = None
        self.catalogs = {}
        self.gradient_sets = {}
        self._item_index = {}
        self.languages_dir = None
        self.language = None
        self.lang = {}

    def find_item(self, category: str, item_id: str):
        return self._item_index.get((category, item_id))


# Uma unica instancia por sessao do Blender -- modulo Python so e importado
# uma vez, entao isso se comporta como um singleton natural enquanto o
# addon estiver habilitado (unregister() nao limpa isso de proposito --
# reabilitar o addon na mesma sessao reaproveita o cache, evitando
# reparsear tudo de novo à toa).
_CACHE = CatalogCache()


def get_cache() -> CatalogCache:
    return _CACHE
