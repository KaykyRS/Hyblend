"""Janela flutuante (tipo splash) desenhada por cima de uma 3D Viewport.

Irmã do PanelHost (runtime.py), mas sem sidebar: a janela fica
centralizada na região WINDOW de uma View3D e some ao clicar fora (ou
Esc). Mesma árvore de widgets, mesmo Renderer, mesma cache em textura.

Como entra na tela:
  * `open_overlay(window, area, build, ...)` roda o operador modal
    `<namespace>.gpu_ui_overlay` (framework.configure) com override nessa janela/área;
  * o operador cria um `OverlayHost`, que registra um draw handler
    POST_PIXEL por tipo de região da View3D (WINDOW, UI, TOOLS, HEADER...).

Regiões por cima da viewport (Region Overlap: sidebar, toolbar, header
transparente) são desenhadas DEPOIS da viewport. Onde elas cruzam a
janela, escrevemos pixels transparentes (sem mistura) no retângulo da
janela -- o que a viewport desenhou (a janela) aparece por baixo, sem
desenhar duas vezes. Região opaca (sem overlap) recebe o pedaço da
textura direto.

Eventos (o modal é da JANELA inteira do Blender):
  * dentro da janela flutuante: hover/clique/tooltip nos widgets;
  * clique (qualquer botão do mouse) FORA dela: fecha e o clique é
    "comido" (inclusive o RELEASE), como o splash do Blender;
  * Esc fecha; outras teclas não vazam pra cena (G/X/Tab...), exceto
    atalhos com Ctrl/Alt/Cmd e F1-F24.

Custo: renderiza a textura só quando algo muda (hover, animação, clique);
o resto é um blit por região.
"""

import math
import time
import traceback
from types import SimpleNamespace

import bpy
from bpy.app.handlers import persistent

from . import CONFIG, ops_namespace
from .core import Frame, Rect, Theme, draw_tooltip, find_by_key
from .motion import animate, prune
from .renderer import Renderer, render_to_texture
from .runtime import FKEY, is_keyboard

CACHE_PAD = 24.0           # folga da textura para a sombra
MARGIN = 20.0              # distância mínima da janela às bordas da viewport
ENTER_DURATION = 0.28
READY_TIMEOUT = 0.6        # espera a arte (PNGs) decodificar antes de aparecer, no máximo isto
EXIT_DURATION = 0.14
SAFETY_REFRESH = 1.0
TICK_FAST, TICK_IDLE = 1 / 60, 0.25
TOOLTIP_DELAY = 0.6

_REGION_TYPES = ("WINDOW", "UI", "TOOLS", "HEADER", "TOOL_HEADER", "ASSET_SHELF", "ASSET_SHELF_HEADER",
                 "FOOTER")
_EAT = {"RUNNING_MODAL"}
_PASS = {"PASS_THROUGH"}
_MOUSE_BUTTONS = {"LEFTMOUSE", "RIGHTMOUSE", "MIDDLEMOUSE", "BUTTON4MOUSE", "BUTTON5MOUSE",
                  "BUTTON6MOUSE", "BUTTON7MOUSE"}

_HOSTS = {}                # nome -> OverlayHost (uma janela de cada tipo por vez)
_PENDING = {}              # nome -> parâmetros do próximo invoke (build, tema...)


def _viewport_of(area):
    return next((r for r in area.regions if r.type == "WINDOW"), None)


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------

def is_open(name):
    host = _HOSTS.get(name)
    return host is not None and not host.closed and host.closing is None


def open_overlay(name, window, area, build, *, theme=None, text=None, scale=None, width=520.0, on_close=None):
    """Abre a janela `name` centralizada na View3D `area` da `window`.
    build(frame) -> Widget (raiz); scale(context) -> escala extra;
    text(key) -> texto traduzido; on_close() ao fechar de vez (ex.: liberar
    imagens). Já aberta: não abre outra (True)."""
    if is_open(name):
        return True
    viewport = _viewport_of(area)
    if viewport is None:
        return False
    _PENDING[name] = SimpleNamespace(build=build, theme=theme, text=text, scale=scale, width=width,
                                     on_close=on_close)
    try:
        with bpy.context.temp_override(window=window, screen=window.screen, area=area, region=viewport):
            ops_namespace().gpu_ui_overlay("INVOKE_DEFAULT", name=name)
    except Exception:
        traceback.print_exc()
        _PENDING.pop(name, None)
        return False
    if not is_open(name):
        _PENDING.pop(name, None)
        print("[%s] window '%s' did not open (operator cancelled)" % (CONFIG.label, name))
        return False
    return True


def close(name):
    """Fecha a janela `name` NA HORA (sem a animação de saída) -- ex.: o
    Welcome dando lugar à Home em tela cheia, que troca o layout da tela."""
    host = _HOSTS.get(name)
    if host is not None:
        host.close()


def refresh_all():
    """Algo de fora mudou (ex.: tamanho nas Preferences): redesenhar."""
    for host in list(_HOSTS.values()):
        host.request()


def shutdown_all():
    for host in list(_HOSTS.values()):
        host.close()
    _PENDING.clear()


# --------------------------------------------------------------------------
# Host
# --------------------------------------------------------------------------

class OverlayHost:
    def __init__(self, context, name, params):
        self.name = name
        self.ptrs = (context.window.as_pointer(), context.area.as_pointer())
        self.window = context.window
        self.params = params
        self.state = {}
        self.theme = params.theme or Theme()
        self.renderer = Renderer()
        self.tree = None
        self.closed = False
        self.closing = None                 # instante em que começou a sair
        self.panel = Rect(0, 0, 0, 0)       # retângulo lógico (coords da viewport / escala)
        self.scale = 1.0
        self._offscreen = None
        self._placement = None               # (x0, y0, w, h) em pixels da viewport
        self._dirty = True
        self._animating = True
        self._revealing = True               # entrada/saída em andamento (só recompõe, não re-renderiza)
        self._opened = time.monotonic()
        self._ready = False                  # arte pronta: só então começa a entrada (sem peças surgindo)
        self._tooltip_waiting = False
        self._built_at = 0.0
        self._size_key = None
        self._eat_release = set()            # botões apertados fora: come o RELEASE também
        self._timer = None
        self._tick = None
        self._handles = []
        for region_type in _REGION_TYPES:
            try:
                handle = bpy.types.SpaceView3D.draw_handler_add(self.on_draw, (), region_type, "POST_PIXEL")
            except (TypeError, ValueError):
                continue                      # tipo de região inexistente nesta versão
            self._handles.append((handle, region_type))
        self._set_tick(TICK_FAST)
        _HOSTS[name] = self
        self.request()

    # ---------------------------------------------------------------- estado
    def lookup(self):
        """(janela, área, viewport, viewport) -- mesmo formato do PanelHost
        (bind.UI.override usa [0], [1], [2]), ou None se sumiu."""
        wm = bpy.context.window_manager
        for window in (wm.windows if wm else ()):
            if window.as_pointer() != self.ptrs[0]:
                continue
            for area in window.screen.areas:
                if area.as_pointer() == self.ptrs[1]:
                    viewport = _viewport_of(area)
                    return (window, area, viewport, viewport) if viewport else None
        return None

    def request(self, content=True):
        """Pede redesenho só das regiões que cruzam a janela (viewport +
        sidebar/toolbar/header por cima dela). Redesenhar a área inteira
        a cada hover redesenhava também o N-Panel clássico (Python)."""
        if content:
            self._dirty = True
        found = self.lookup()
        if found is None:
            return
        viewport = found[2]
        viewport.tag_redraw()
        if self._placement is None:
            return
        x0, y0, w, h = self._placement
        wx, wy = viewport.x + x0, viewport.y + y0 - round(16 * self.scale)   # folga da animação
        h += round(32 * self.scale)
        for region in found[1].regions:
            if region != viewport and (wx < region.x + region.width and region.x < wx + w
                                       and wy < region.y + region.height and region.y < wy + h):
                region.tag_redraw()

    def _set_tick(self, interval):
        if self.closed or interval == self._tick:
            return
        wm = bpy.context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
        self._timer = wm.event_timer_add(interval, window=self.window)
        self._tick = interval

    def begin_close(self):
        if self.closed or self.closing is not None:
            return
        self.closing = time.monotonic()
        self.state.pop("_hover", None)
        self._set_tick(TICK_FAST)
        self.request()

    def close(self):
        if self.closed:
            return
        self.closed = True
        for handle, kind in self._handles:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, kind)
            except (ValueError, ReferenceError):
                pass
        self._handles = []
        if self._timer is not None:
            try:
                bpy.context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        if _HOSTS.get(self.name) is self:
            del _HOSTS[self.name]
        self.request(content=False)          # último quadro: limpa o que foi desenhado
        self.tree = self._offscreen = None
        self._placement = None
        if self.params.on_close is not None:
            try:
                self.params.on_close()
            except Exception:
                traceback.print_exc()

    # ------------------------------------------------------------- animação
    def _visibility(self, now):
        """(opacidade, deslocamento Y lógico) da entrada/saída."""
        if self.closing is not None:
            t = min(1.0, (now - self.closing) / EXIT_DURATION)
            ease = 1.0 - (1.0 - t) ** 2
            return 1.0 - ease, -8.0 * ease
        reveal = animate(self.state, "overlay.reveal", 1.0, ENTER_DURATION, initial=0.0, now=now)
        return reveal, -12.0 * (1.0 - reveal)

    # ----------------------------------------------------------------- desenho
    def on_draw(self):
        context = bpy.context
        region, area = context.region, context.area
        if self.closed or region is None or area is None or area.as_pointer() != self.ptrs[1]:
            return
        try:
            found = self.lookup()
            if found is None:
                return
            viewport = found[2]
            in_viewport = region.as_pointer() == viewport.as_pointer()
            now = time.monotonic()
            if in_viewport and self.closing is None:
                self._render(context, viewport, now)
            if self._placement is None:
                if not in_viewport:
                    viewport.tag_redraw()
                return
            if not self._ready:
                return                        # ainda decodificando a arte (o timer segue rápido)
            alpha, dy = self._visibility(now)
            self._revealing = self.closing is not None or alpha < 0.999
            if alpha <= 0.001:
                return
            x0, y0, w, h = self._placement
            rise = round(dy * self.scale)
            # Retângulo da textura em coordenadas da JANELA do Blender.
            wx, wy = viewport.x + x0, viewport.y + y0 + rise
            if in_viewport:
                self.renderer.blit(self._offscreen.texture_color, x0, y0 + rise, self._offscreen.width,
                                   self._offscreen.height, opacity=alpha, linear=True)
                self._schedule()
                return
            # Outra região da mesma área (sidebar, toolbar, header...).
            if not (wx < region.x + region.width and region.x < wx + w
                    and wy < region.y + region.height and region.y < wy + h):
                return
            overlapped = (viewport.x <= region.x and viewport.y <= region.y
                          and region.x + region.width <= viewport.x + viewport.width
                          and region.y + region.height <= viewport.y + viewport.height)
            if overlapped:
                # Região transparente por cima da viewport: fura o retângulo
                # da JANELA (sem a sombra) -- a viewport já mostra a janela.
                p = self.panel
                s = self.scale
                px = viewport.x + round(p.x * s) - region.x
                py = viewport.y + round(p.y * s) + rise - region.y
                self.renderer.cover(px, py, round(p.w * s), round(p.h * s), (0.0, 0.0, 0.0, 0.0), replace=True)
            else:
                self.renderer.blit(self._offscreen.texture_color, wx - region.x, wy - region.y,
                                   self._offscreen.width, self._offscreen.height, opacity=alpha, linear=False)
        except Exception:
            traceback.print_exc()
            bpy.app.timers.register(self._fail, first_interval=0.0)   # nunca remover handler no draw

    def _schedule(self):
        """Ritmo do timer conforme o que está acontecendo AGORA. Chamado no
        desenho (como o PanelHost): sem isso, o hover animava no ritmo
        lento (4x/s) até o próximo tique -- a "demora" ao passar o mouse."""
        busy = self._animating or self._revealing or self._tooltip_waiting
        self._set_tick(TICK_FAST if busy else TICK_IDLE)

    def _fail(self):
        self.close()
        return None

    def _measure(self, context, viewport):
        extra = self.params.scale(context) if self.params.scale else 1.0
        s = max(0.1, context.preferences.system.ui_scale * extra)
        vw, vh = viewport.width / s, viewport.height / s
        width = max(200.0, min(self.params.width, vw - 2 * MARGIN))
        return s, vw, vh, width

    def _render(self, context, viewport, now):
        s, vw, vh, width = self._measure(context, viewport)
        size_key = (s, round(vw), round(vh))
        stale = now - self._built_at >= SAFETY_REFRESH
        if not (self._dirty or self._animating or stale or size_key != self._size_key):
            return False
        self.scale = s
        st = self.state
        st["_motion_active"] = False
        st["_mouse_rects"] = []
        st["_overlay_width"] = width
        st.pop("_wake_at", None)
        f = Frame(self.renderer, st, self.theme, context, now, host=self)
        self.tree = self.params.build(f)
        self._built_at = now
        _, preferred, _ = self.tree.extent(f, width)
        height = min(preferred, max(120.0, vh - 2 * MARGIN))
        self.panel = Rect(round((vw - width) / 2), round((vh - height) / 2), width, height)
        self.tree.layout(f, self.panel)

        area = self.panel.expand(CACHE_PAD)
        x0, y0 = math.floor(area.x * s), math.floor(area.y * s)
        w = max(1, math.ceil(area.right * s) - x0)
        h = max(1, math.ceil(area.top * s) - y0)

        def draw():
            self.tree.draw(f)
            self._tooltip_waiting = self._draw_tooltip(f)
        r = self.renderer
        self._offscreen = render_to_texture(self._offscreen, r, s, x0, y0, w, h, draw)
        self._placement = (x0, y0, w, h)
        self._size_key = size_key
        self._dirty = False
        self._animating = bool(st.get("_motion_active")) or r.pending_images
        if not self._ready and (not r.pending_images or now - self._opened >= READY_TIMEOUT):
            self._ready = True
        prune(st, now)
        return True

    def _draw_tooltip(self, f):
        st = self.state
        key = st.get("_hover")
        if not key or st.get("_pressed") or st.get("_tooltip_off"):
            return False
        widget = find_by_key(self.tree, key)
        if widget is None or not widget.tooltip:
            return False
        if f.now - st.get("_hover_since", f.now) < TOOLTIP_DELAY:
            return True
        text = widget.tooltip() if callable(widget.tooltip) else widget.tooltip
        if text:
            draw_tooltip(f, key, text, st.get("_hover_pos", f.mouse), self.panel)
        return False

    # ----------------------------------------------------------------- eventos
    def _frame(self, context, now):
        return Frame(self.renderer, self.state, self.theme, context, now, host=self)

    def on_event(self, context, event):
        st = self.state
        now = time.monotonic()
        if self.closing is not None:
            if now - self.closing >= EXIT_DURATION:
                self.close()
                return {"FINISHED"}
            if event.type == "TIMER":
                self.request(content=False)
                return _PASS
            # Saindo: só termina de comer o RELEASE do clique que fechou.
            if event.type in self._eat_release and event.value == "RELEASE":
                self._eat_release.discard(event.type)
                return _EAT
            return _PASS

        found = self.lookup()
        if found is None:
            self.close()
            return {"CANCELLED"}

        if event.type == "TIMER":
            return self._on_tick(now)
        if not self._ready:
            return _PASS          # ainda invisível (arte decodificando): não pega clique nem tecla

        viewport = found[2]
        s = self.scale
        x = (event.mouse_x - viewport.x) / s
        y = (event.mouse_y - viewport.y) / s
        inside = self._placement is not None and self.panel.contains(x, y)
        st["_mouse"] = (x, y)

        if event.type in self._eat_release and event.value == "RELEASE":
            self._eat_release.discard(event.type)
            return _EAT

        # Esc fecha; outras teclas não caem na cena (exceto atalhos globais).
        if event.type == "ESC" and event.value == "PRESS":
            self.begin_close()
            return _EAT
        if is_keyboard(event.type):
            if event.ctrl or event.alt or event.oskey or FKEY.match(event.type):
                return _PASS
            return _EAT

        f = self._frame(context, now)

        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            hit = self.tree.hit(x, y) if (inside and self.tree) else None
            key = hit.key if hit else None
            if key != st.get("_hover"):
                st["_hover"], st["_hover_since"], st["_hover_pos"] = key, now, (x, y)
                st.pop("_tooltip_off", None)
                self.request()
            elif any(r.contains(x, y) for r in st.get("_mouse_rects", ())):
                self.request()
            return _EAT if inside else _PASS

        if event.type in _MOUSE_BUTTONS and event.value in {"PRESS", "DOUBLE_CLICK"} and not inside:
            self._eat_release.add(event.type)
            self.begin_close()
            return _EAT

        if not inside:
            return _PASS

        if event.type == "LEFTMOUSE":
            hit = self.tree.hit(x, y) if self.tree else None
            if event.value in {"PRESS", "DOUBLE_CLICK"}:
                st["_tooltip_off"] = True
                if hit is not None and hit.interactive:
                    st["_pressed"] = hit.key
                self.request()
            elif event.value == "RELEASE":
                pressed = st.pop("_pressed", None)
                if hit is not None and pressed == hit.key:
                    try:
                        hit.on_click(f, x, y)
                    except Exception as error:
                        traceback.print_exc()
                        f.toast("%s %s" % (self._t("gpu_ui.error_prefix", "Error:"), error), error=True)
                self.request()
            return _EAT
        return _EAT          # roda do mouse, botão direito/meio etc. em cima da janela

    def _t(self, key, fallback):
        if self.params.text is not None:
            try:
                return self.params.text(key)
            except Exception:
                pass
        return fallback

    def _on_tick(self, now):
        st = self.state
        wants = self._animating
        if self._tooltip_waiting and now - st.get("_hover_since", now) >= TOOLTIP_DELAY:
            wants = True
        if st.get("_wake_at") is not None and now >= st["_wake_at"]:
            wants = True
        if wants:
            self.request()
        elif self._revealing:
            self.request(content=False)      # entrada: só o blit muda (opacidade/posição)
        self._schedule()
        return _PASS


# --------------------------------------------------------------------------
# Operador modal
# --------------------------------------------------------------------------

class _OverlayOperator:
    """Corpo do operador modal; a classe registrada (bl_idname com o
    namespace do app) é criada em register()."""
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        params = _PENDING.pop(self.name, None)
        if params is None or is_open(self.name) or context.area is None or context.area.type != "VIEW_3D":
            return {"CANCELLED"}
        old = _HOSTS.get(self.name)
        if old is not None:
            old.close()                      # ainda saindo: troca pela nova
        self._host = OverlayHost(context, self.name, params)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        host = self._host
        if host.closed:
            return {"CANCELLED"}
        try:
            return host.on_event(context, event)
        except Exception:
            traceback.print_exc()
            host.close()
            return {"CANCELLED"}

    def cancel(self, context):
        self._host.close()


@persistent
def _before_load(*_):
    shutdown_all()          # abrir .blend derruba os modais


_OPERATOR = []


def register():
    ns = CONFIG.namespace
    cls = type("%s_OT_gpu_ui_overlay" % ns.upper(), (_OverlayOperator, bpy.types.Operator),
               {"bl_idname": ns + ".gpu_ui_overlay", "bl_label": CONFIG.label + " Window",
                "__annotations__": {"name": bpy.props.StringProperty(options={"SKIP_SAVE", "HIDDEN"})}})
    _OPERATOR[:] = [cls]
    bpy.utils.register_class(cls)
    if _before_load not in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.append(_before_load)


def unregister():
    shutdown_all()
    if _before_load in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.remove(_before_load)
    for cls in _OPERATOR:
        bpy.utils.unregister_class(cls)
    _OPERATOR.clear()
