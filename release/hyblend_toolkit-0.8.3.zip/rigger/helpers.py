"""Auto-Rigger -- helpers genéricos de bone/collection/hierarquia, sem estado próprio."""

import math
from collections import deque

from mathutils import Matrix

from .constants import (
    ARM_COLLECTION_ROOTS,
    ARM_COLLECTION_ROOTS_NO_SHOULDER,
    ATTACHMENT_NAME_HINT,
    COLL_MAIN_ARM_L,
    COLL_MAIN_ARM_R,
    COLL_MAIN_LEG_L,
    COLL_MAIN_LEG_R,
    LEG_COLLECTION_ROOTS,
    PARENT_OVERRIDE_ALIASES,
    PROP_RIG_LAYER,
    SUFFIX_CTRL,
    SUFFIX_IK,
)


def _resolve_parent_override(edit_bones, override_name):
    """Resolve item.parent_override pro edit bone final: tenta
    PARENT_OVERRIDE_ALIASES primeiro, senão o nome literal.

    Alias tem que vir ANTES do nome literal -- um ORG chamado igual ao
    alias (ex. o próprio "Pelvis") rouba a resolução senão. Sufixo
    "_CTRL" digitado por engano é removido antes de resolver, pra
    "L-Shoulder" e "L-Shoulder_CTRL" sempre caírem no mesmo lugar."""
    if not override_name:
        return None
    if override_name.endswith(SUFFIX_CTRL):
        override_name = override_name[: -len(SUFFIX_CTRL)]
    alias = PARENT_OVERRIDE_ALIASES.get(override_name)
    if alias:
        return edit_bones.get(alias)
    return edit_bones.get(override_name)


def _classify_chain_limb(item):
    """'ARM'/'LEG'/None a partir de item.chain_type."""
    return item.chain_type if item.chain_type in ("ARM", "LEG") else None


_LIMB_SIDE_TO_COLLECTION = {
    ("ARM", "LEFT"): COLL_MAIN_ARM_L,
    ("ARM", "RIGHT"): COLL_MAIN_ARM_R,
    ("LEG", "LEFT"): COLL_MAIN_LEG_L,
    ("LEG", "RIGHT"): COLL_MAIN_LEG_R,
}


def _resolve_main_limb_roots(armature, edit_bones):
    """Raízes de Arm L/R e Leg L/R pra este Armature: parte dos nomes
    fixos (ARM/LEG_COLLECTION_ROOTS), troca pra variante sem ombro se o
    personagem não tiver esse bone, e acrescenta a raiz real de
    qualquer cadeia ARM/LEG customizada em hytale_ik_chains."""
    roots = {name: list(bones) for name, bones in {**ARM_COLLECTION_ROOTS, **LEG_COLLECTION_ROOTS}.items()}

    for coll_name, shoulder_roots in ARM_COLLECTION_ROOTS.items():
        shoulder_name = shoulder_roots[0]
        if edit_bones.get(shoulder_name) is None:
            for candidate in ARM_COLLECTION_ROOTS_NO_SHOULDER[coll_name]:
                if candidate not in roots[coll_name]:
                    roots[coll_name].append(candidate)

    for item in getattr(armature, "hytale_ik_chains", []):
        if not item.root_bone or item.side not in ("LEFT", "RIGHT"):
            continue
        limb = _classify_chain_limb(item)
        if limb is None:
            continue
        coll_name = _LIMB_SIDE_TO_COLLECTION.get((limb, item.side))
        if coll_name is None:
            continue
        for candidate in (item.root_bone + SUFFIX_CTRL, item.root_bone + SUFFIX_IK):
            if candidate not in roots[coll_name]:
                roots[coll_name].append(candidate)
    return roots


# --- Edit Mode: collections e edit bones ---


def _find_bone_collection_anywhere(armature, name):
    """Procura uma bone collection em qualquer nível de aninhamento --
    armature.collections só enxerga o nível raiz."""
    all_colls = getattr(armature, "collections_all", None)
    if all_colls is not None:
        return all_colls.get(name)

    def search(colls):
        for c in colls:
            if c.name == name:
                return c
            found = search(c.children)
            if found is not None:
                return found
        return None

    return search([c for c in armature.collections if c.parent is None])


def _iter_all_collections(armature):
    all_colls = getattr(armature, "collections_all", None)
    if all_colls is not None:
        return list(all_colls)

    result = []

    def gather(colls):
        for c in colls:
            result.append(c)
            gather(c.children)

    gather([c for c in armature.collections if c.parent is None])
    return result


def set_bone_collection_visibility(armature, visible_names):
    """Deixa visível só as collections cujo nome está em visible_names."""
    for coll in _iter_all_collections(armature):
        coll.is_visible = coll.name in visible_names


def ensure_bone_collection(armature, name, parent=None):
    existing = _find_bone_collection_anywhere(armature, name)
    if existing is not None:
        return existing
    return armature.collections.new(name=name, parent=parent)


def _redraw_all_areas(context):
    """Força redraw de toda área/janela -- operadores chamados a partir
    de um popup menu (ex. RIG_MT_hytale_ik_chain_add_menu) não fazem a
    UIList redesenhar sozinha, limitação conhecida do Blender."""
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()


def create_bone_like(edit_bones, source, new_name):
    """Cria (ou reaproveita) um edit bone com a mesma transform de
    source. Retorna (bone, foi_criado_agora)."""
    existing = edit_bones.get(new_name)
    if existing is not None:
        return existing, False
    new_bone = edit_bones.new(new_name)
    new_bone.head = source.head.copy()
    new_bone.tail = source.tail.copy()
    new_bone.roll = source.roll
    new_bone.use_connect = False
    new_bone.use_deform = False  # só ORG deforma a malha
    return new_bone, True


def rotate_edit_bone_local_axis(edit_bone, axis_letter, degrees):
    """Rotaciona um edit bone em torno de um dos próprios eixos locais.
    Usado pelo ajuste manual da ponta de uma cadeia Tail, que não tem
    próximo segmento pra apontar sozinha."""
    if abs(degrees) < 1e-6:
        return
    axis = {"X": edit_bone.x_axis, "Y": edit_bone.y_axis, "Z": edit_bone.z_axis}.get(axis_letter)
    if axis is None or axis.length < 1e-9:
        return
    axis = axis.normalized()
    old_z = edit_bone.z_axis
    rot = Matrix.Rotation(math.radians(degrees), 4, axis)
    direction = edit_bone.tail - edit_bone.head
    edit_bone.tail = edit_bone.head + (rot @ direction)
    edit_bone.align_roll(rot @ old_z)


def find_layer_bone(edit_bones, org_name, suffix):
    if org_name is None:
        return None
    return edit_bones.get(org_name + suffix)


def is_attachment_bone(bone):
    return ATTACHMENT_NAME_HINT in bone.name.lower()


def bone_side_prefix(name):
    """Detecta prefixo de lado ("L"/"R"/None). Aceita "L-"/"R-" (padrão
    oficial) e "L_"/"R_" (visto em mods com nome inconsistente) -- só
    usado por cosmético (cor de bone), nunca por parenting/nomenclatura
    de verdade, que continuam exigindo o padrão oficial."""
    if name.startswith("L-") or name.startswith("L_"):
        return "L"
    if name.startswith("R-") or name.startswith("R_"):
        return "R"
    return None


def is_excluded_from_main_collections(bone):
    """Bones que não entram nas collections Head/Spine/Body/Arm/Leg/Root
    dentro de Main: attachments e as camadas internas MCH/MCH-IK/
    MCH-TRANSFER."""
    if is_attachment_bone(bone):
        return True
    return bone.get(PROP_RIG_LAYER) in ("MCH", "MCH-IK", "MCH-TRANSFER")


def find_attachment_child(org_bone):
    """Primeiro filho ORG cujo nome contém ATTACHMENT_NAME_HINT, ou None."""
    for child in org_bone.children:
        if is_attachment_bone(child):
            return child
    return None


def find_non_attachment_children(org_bone):
    """Irmã de find_attachment_child: todos os filhos ORG que NÃO são attachment."""
    return [child for child in org_bone.children if not is_attachment_bone(child)]


def find_org_path(root_bone, tip_name):
    """Caminho (root->tip) descendo pela hierarquia ORG, ignorando bones
    já gerados. None se tip_name não for descendente de root_bone."""
    if root_bone.name == tip_name:
        return None
    queue = deque([[root_bone]])
    visited = {root_bone.name}
    while queue:
        path = queue.popleft()
        node = path[-1]
        for child in node.children:
            if PROP_RIG_LAYER in child.keys():
                continue  # só anda por bones ORG
            if child.name in visited:
                continue
            new_path = path + [child]
            if child.name == tip_name:
                return new_path
            visited.add(child.name)
            queue.append(new_path)
    return None


def collect_descendants_inclusive(edit_bones, root_name, exclude_predicate=None):
    """[root] + todos os descendentes, pulando bones pros quais
    exclude_predicate(bone) seja True."""
    root = edit_bones.get(root_name)
    if root is None:
        return []
    result = []
    stack = [root]
    while stack:
        bone = stack.pop()
        stack.extend(bone.children)
        if exclude_predicate is not None and exclude_predicate(bone):
            continue
        result.append(bone)
    return result
