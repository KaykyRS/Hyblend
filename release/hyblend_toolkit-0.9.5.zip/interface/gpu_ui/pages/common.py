"""Peças compartilhadas pelas páginas da UI por GPU."""

from ..framework.core import Button, Column, Label, Rect, Style, fit_text
from ..framework.motion import mix
from ..widgets import OptionRow, labeled, option_list

MAX_SUGGESTIONS = 7


class ImageButton(Button):
    """Botão cujo ícone pode ser um PNG do disco (logos da aba Info, de
    assets/icons/); sem o PNG, cai no ícone procedural."""

    def __init__(self, key, text, on_click, icon=None, image=None, **kw):
        super().__init__(key, text, on_click, icon=icon, **kw)
        self.image = image

    def measure(self, f, max_w):
        w, h = super().measure(f, max_w)
        if self.image and not self.icon:
            w += 16 + (6 if self.text else 0)
        return (w, h)

    def draw(self, f):
        th, r = f.theme, f.renderer
        hovered = f.hover == self.key and self.enabled
        pressed = hovered and f.pressed == self.key
        h = f.animate(self.key + ".hover", 1.0 if hovered else 0.0, 0.12)
        p = f.animate(self.key + ".press", 1.0 if pressed else 0.0, 0.06)
        rect = self.rect.expand(-0.75 * p)
        # Fundo: a arte do botão do tema (Hytale) ou o procedural.
        if not self._draw_skin(f, self.rect, h, p, 0.0):
            color = mix(mix(th.surface_raised, th.surface_hover, h), th.surface_pressed, p)
            r.rect(rect, color, radius=self.style.radius * th.radius_scale, border=th.border)
        label, weight, tracking, size = self._label(th)
        gap = 6.0 if self.text else 0.0
        if self.text:     # estreito: sem tracking, fonte menor, e só então "…"
            size, tracking = fit_text(r, label, rect.w - 18 - 16 - gap, size, weight, tracking)
        text_w = r.text_width(label, size, weight, tracking) if self.text else 0.0
        total = 16 + gap + text_w     # (só ícone: centro exato)
        x = rect.x + (max(6.0, (rect.w - total) / 2) if self.text else (rect.w - total) / 2)
        box = Rect(x, rect.y + (rect.h - 16) / 2, 16, 16)
        old = r.opacity
        if not self.enabled:
            r.opacity = old * 0.45
        # Logo do addon (assets/icons, cores próprias); sem ele, o ícone genérico.
        if not (self.image and r.image(box, self.image)):
            r.icon(box, self.icon or "globe", th.text if self.enabled else th.text_muted)
        r.opacity = old
        if self.text:
            r.text(Rect(box.right + gap, rect.y, rect.right - box.right - gap - 6, rect.h), label,
                   th.text if self.enabled else th.text_muted, size=size, weight=weight, tracking=tracking)


def suggestions(ui, field_key, candidates, apply, icon="bone"):
    """Lista de sugestões embaixo de um campo de texto EM EDIÇÃO (nomes de
    bone, de collection...). Filtra pelo que já foi digitado. Os itens
    têm keeps_focus: clicar neles não "confirma" o texto parcial antes."""
    f = ui.f
    if f.focus != field_key or field_key + ".edit" not in f.state:
        return None
    typed = f.state.get(field_key + ".edit", "").strip().lower()
    if f.state.get(field_key + ".select_all"):
        typed = ""
    if typed:
        starts = [c for c in candidates if c.lower().startswith(typed)]
        contains = [c for c in candidates if typed in c.lower() and c not in starts]
        matches = starts + contains
    else:
        matches = list(candidates)
    if not matches or (len(matches) == 1 and matches[0].lower() == typed):
        return None

    def pick(name):
        def run(f):
            for suffix in (".edit", ".caret", ".blink", ".select_all"):
                f.state.pop(field_key + suffix, None)
            if f.state.get("_focus") == field_key:
                f.state.pop("_focus", None)
            apply(f, name)
        return run

    rows = [OptionRow("%s.sug.%d" % (field_key, i), name, pick(name), icon=icon,
                      keeps_focus=True)
            for i, name in enumerate(matches[:MAX_SUGGESTIONS])]
    if len(matches) > MAX_SUGGESTIONS:
        rows.append(Label("+%d" % (len(matches) - MAX_SUGGESTIONS), size=11,
                          color=ui.theme.text_muted, style=Style(height=18, padding=(10, 0, 0, 0))))
    return option_list(rows, key=field_key + ".sug")


def bone_names(obj):
    if obj is None or obj.type != "ARMATURE":
        return []
    return [b.name for b in obj.data.bones]


def bone_field(ui, owner, prop, label, *, picker=None, extra=(), candidates=None, icon="bone"):
    """Campo de nome de bone: texto + conta-gotas (pega o bone ativo) +
    extras (ex.: caixinha do Rename). Enquanto digita, sugere bones do
    Armature ativo. `picker` = (classe/idname do operador, props)."""
    field = ui.text(owner, prop, icon=icon)
    controls = [field]
    if picker is not None:
        op, props = picker
        controls.append(ui.op("pick.%s.%s" % (field.key, prop), op, "", icon="eyedropper", props=props))
    controls.extend(c for c in extra if c is not None)
    row = labeled(label, *controls)
    if candidates is None:
        candidates = bone_names(ui.context.active_object)
    sug = suggestions(ui, field.key, candidates, lambda f, name: ui.set(f, owner, prop, name))
    if sug is None:
        return row
    return Column(row, sug, style=Style(gap=4))


def text_field(ui, owner, prop, label, candidates=(), icon=None):
    """Texto com sugestões (o prop_search do painel clássico)."""
    field = ui.text(owner, prop, icon=icon)
    row = labeled(label, field)
    sug = suggestions(ui, field.key, list(candidates), lambda f, name: ui.set(f, owner, prop, name),
                      icon="collection")
    return row if sug is None else Column(row, sug, style=Style(gap=4))


def active_armature(context):
    obj = context.active_object
    return obj if obj is not None and obj.type == "ARMATURE" else None
