"""Carregador de idiomas: cada translations/*.py define LANGUAGE_CODE, LANGUAGE_NAME e TRANSLATIONS (key -> texto),
descobertos em tempo de execução (_discover). Keys com prefixo do arquivo dono ("importer.", "panel."...).
O idioma é UM só pra todos os addons Hyblend (Preferences do núcleo). Cada dependente registra a própria tabela
(register_table) e lê pelo tr_for(dono, ...): tabela dele primeiro, depois a do núcleo. O tr() do núcleo (usado
pela UI por GPU) procura no núcleo e depois nas tabelas dos dependentes.

Tooltips traduzidos, dois mecanismos:
1. Botão (Operator): `description = tooltip("arquivo.tooltip.foo")` (o Blender chama a cada hover).
2. Campo (bpy.props): o Blender lê description= só no register_class. As properties da classe ficam numa função
   `_props(lang)` + @localized_props(_props), registrada com register_localized_class; trocar o idioma re-registra.
   Classe usada como type= numa atribuição direta (ex.: Armature.x = PointerProperty(type=X)) precisa refazer
   essa atribuição num register_refresh_hook (ex.: exporter._redo_armature_property_assignments, no Anim).
"""
import importlib
import os

import bpy

from ..common import ADDON_PACKAGE

_PACKAGE = __package__
_DIR = os.path.dirname(__file__)

# Idioma de fallback quando uma key não existe no idioma escolhido.
# Único arquivo obrigatório (en.py) -- os outros são opcionais/plugáveis.
_FALLBACK_CODE = "EN"

# {code: {"name": .., "labels": {...}, "filename": ..}}
_languages = {}

# Tabelas dos addons dependentes: dono -> {"loader": fn() -> {code: labels}, "tables": {code: labels}}.
_owners = {}
_merged = {}      # code -> {key: texto} (núcleo por cima dos dependentes); refeito ao mudar uma tabela


# Lista de items já pronta pro EnumProperty -- cacheada num objeto
# estável (não reconstruída a cada chamada, ver get_language_items()).
_items_cache = []


def _rebuild_items_cache():
    global _items_cache
    codes = sorted(_languages.keys(), key=lambda c: (c != _FALLBACK_CODE, _languages[c]["name"]))
    _items_cache = [(code, _languages[code]["name"], "") for code in codes] or [("EN", "English", "")]


def _discover():
    """Escaneia translations/*.py e refaz o registro (na importação e no Reload Translations)."""
    global _languages
    _languages = {}

    if os.path.isdir(_DIR):
        for filename in sorted(os.listdir(_DIR)):
            if not filename.endswith(".py") or filename.startswith("_"):
                continue
            modname = filename[:-3]
            try:
                module = importlib.import_module(f".{modname}", _PACKAGE)
                module = importlib.reload(module)
            except Exception as exc:
                print(f"[HyblendToolkit] Falha ao carregar '{filename}' em translations/: {exc}")
                continue

            code = getattr(module, "LANGUAGE_CODE", None)
            name = getattr(module, "LANGUAGE_NAME", None)
            labels = getattr(module, "TRANSLATIONS", None)
            if not code or not name or not isinstance(labels, dict):
                print(
                    f"[HyblendToolkit] '{filename}' em translations/ não define "
                    "LANGUAGE_CODE/LANGUAGE_NAME/TRANSLATIONS válidos -- ignorado."
                )
                continue

            _languages[code] = {"name": name, "labels": labels, "filename": filename}

    if _FALLBACK_CODE not in _languages:
        print(
            f"[HyblendToolkit] Aviso: nenhum arquivo com LANGUAGE_CODE = "
            f"'{_FALLBACK_CODE}' encontrado em translations/ -- keys ausentes "
            "em outros idiomas vão aparecer cruas em vez de cair pro Inglês."
        )

    _rebuild_items_cache()
    for owner in _owners.values():          # Reload Translations recarrega também os dependentes
        try:
            owner["tables"] = owner["loader"]()
        except Exception as exc:
            print(f"[HyblendToolkit] Falha ao recarregar traduções de um addon: {exc}")
    _rebuild_merged()


def _rebuild_merged():
    _merged.clear()
    codes = set(_languages) | {code for owner in _owners.values() for code in owner["tables"]}
    for code in codes:
        merged = {}
        for owner in _owners.values():
            merged.update(owner["tables"].get(code, {}))
        entry = _languages.get(code)
        if entry:
            merged.update(entry["labels"])
        _merged[code] = merged


def load_tables(package, directory):
    """{LANGUAGE_CODE: TRANSLATIONS} dos <directory>/*.py de um dependente (módulos <package>.<arquivo>)."""
    tables = {}
    for filename in sorted(os.listdir(directory)) if os.path.isdir(directory) else ():
        if not filename.endswith(".py") or filename.startswith("_"):
            continue
        try:
            module = importlib.reload(importlib.import_module(f".{filename[:-3]}", package))
        except Exception as exc:
            print(f"[HyblendToolkit] Falha ao carregar '{filename}' de {package}: {exc}")
            continue
        code = getattr(module, "LANGUAGE_CODE", None)
        labels = getattr(module, "TRANSLATIONS", None)
        if code and isinstance(labels, dict):
            tables[code] = labels
    return tables


def register_table(owner, loader):
    """Dependente entra com as próprias traduções; `loader()` -> {code: labels} (chamado de novo no Reload)."""
    _owners[owner] = {"loader": loader, "tables": loader()}
    _rebuild_merged()


def unregister_table(owner):
    if _owners.pop(owner, None) is not None:
        _rebuild_merged()


def tr_for(owner, key, lang):
    """tr() de um dependente: tabela dele no idioma, depois o idioma no geral, depois inglês, depois a key."""
    if not _languages:
        _discover()
    entry = _owners.get(owner)
    if entry is not None:
        labels = entry["tables"].get(lang)
        if labels and key in labels:
            return labels[key]
    merged = _merged.get(lang)
    if merged and key in merged:
        return merged[key]
    if entry is not None:
        labels = entry["tables"].get(_FALLBACK_CODE)
        if labels and key in labels:
            return labels[key]
    merged = _merged.get(_FALLBACK_CODE)
    if merged and key in merged:
        return merged[key]
    return key


def tooltip_for(owner, key):
    """tooltip() de um dependente (descrição pelo tr_for dele)."""

    def _description(cls, context, properties):
        return tr_for(owner, key, get_language(context))

    return classmethod(_description)


def get_language_items(self, context):
    """items do Enum de idioma: sempre a mesma lista em cache (lista coletada pelo GC pode crashar o Blender)."""
    if not _languages:
        _discover()
    return _items_cache


def get_language(context):
    """Lê a preference de idioma do addon, com fallback pro Inglês se
    não existir ainda ou apontar pra um código que não existe mais."""
    if not _languages:
        _discover()
    try:
        prefs = context.preferences.addons[ADDON_PACKAGE].preferences
        lang = prefs.language
    except Exception:
        return _FALLBACK_CODE
    return lang if lang in _languages else _FALLBACK_CODE


def tr(key, lang):
    """Texto de `key` em `lang`; senão inglês; senão a própria key (fica óbvio o que falta traduzir)."""
    if not _languages:
        _discover()

    merged = _merged.get(lang)
    if merged and key in merged:
        return merged[key]

    fallback = _merged.get(_FALLBACK_CODE)
    if fallback and key in fallback:
        return fallback[key]

    return key


def tooltip(key):
    """classmethod description(cls, context, properties) pra `description = tooltip(...)` num Operator."""

    def _description(cls, context, properties):
        return tr(key, get_language(context))

    return classmethod(_description)


# Classes decoradas com @localized_props, na ordem em que foram
# registradas -- refresh_localized_properties() percorre esta lista.
_localized_classes = []


def localized_props(builder):
    """Marca a classe: `builder(lang)` devolve todas as properties dela (trocadas a cada (re)registro)."""

    def _decorator(cls):
        cls._i18n_props_builder = staticmethod(builder)
        return cls

    return _decorator


def register_localized_class(cls):
    """Substitui bpy.utils.register_class(cls) -- funciona também numa
    classe sem @localized_props (vira um register_class puro)."""
    builder = getattr(cls, "_i18n_props_builder", None)
    if builder is not None:
        cls.__annotations__ = dict(builder(get_language(bpy.context)))
        if cls not in _localized_classes:
            _localized_classes.append(cls)
    bpy.utils.register_class(cls)


def unregister_localized_class(cls):
    bpy.utils.unregister_class(cls)
    if cls in _localized_classes:
        _localized_classes.remove(cls)


def refresh_localized_properties(context):
    """Troca de idioma: re-registra as classes @localized_props (sem perder dado salvo) e roda os refresh hooks."""
    lang = get_language(context)
    for cls in list(_localized_classes):
        builder = getattr(cls, "_i18n_props_builder", None)
        if builder is None:
            continue
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass  # já desregistrada (ex.: addon sendo desligado no meio de um refresh)
        cls.__annotations__ = dict(builder(lang))
        bpy.utils.register_class(cls)

    for hook in list(_post_refresh_hooks):
        try:
            hook()
        except Exception as exc:
            print(f"[HyblendToolkit] Erro num refresh hook de tradução ({hook}): {exc}")


# Callables sem argumento, chamados no fim de refresh_localized_properties().
_post_refresh_hooks = []


def register_refresh_hook(fn):
    """`fn` roda depois de cada refresh de idioma (atribuições diretas com type= de classe @localized_props)."""
    if fn not in _post_refresh_hooks:
        _post_refresh_hooks.append(fn)


def unregister_refresh_hook(fn):
    if fn in _post_refresh_hooks:
        _post_refresh_hooks.remove(fn)


def available_languages():
    """{code: nome_de_exibição} de todo idioma carregado."""
    if not _languages:
        _discover()
    return {code: info["name"] for code, info in _languages.items()}


class TRANSLATIONS_OT_reload(bpy.types.Operator):
    """Reescaneia a pasta translations/ sem precisar reiniciar o Blender."""

    bl_idname = "hytale.reload_translations"
    bl_label = "Reload Translations"
    bl_options = {"REGISTER"}
    description = tooltip("translations.tooltip.reload")

    def execute(self, context):
        _discover()                     # também recarrega as tabelas dos dependentes
        # Re-registra também as @localized_props (tooltips de campo).
        refresh_localized_properties(context)
        names = ", ".join(sorted(info["name"] for info in _languages.values())) or "-"
        self.report({"INFO"}, f"HyblendToolkit: {len(_languages)} idioma(s) carregado(s) -- {names}")
        return {"FINISHED"}


_CLASSES = (TRANSLATIONS_OT_reload,)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)


# Escaneia já na importação -- get_language_items() precisa ter algo
# pra mostrar assim que o painel de Preferences desenhar, sem esperar register().
_discover()
