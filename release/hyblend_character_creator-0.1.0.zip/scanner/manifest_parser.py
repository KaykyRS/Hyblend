"""manifest_parser.py -- le os arquivos .json de Cosmetics/CharacterCreator/
do Hytale (Assets extraido pelo usuario) e converte cada entrada num objeto
Item comum, reaproveitado por toda categoria (Gloves, Overtops, Pants,
BodyCharacteristics, ...).

Contrato de arquivo (confirmado empiricamente contra Gloves.json/
Overtops.json/Pants.json/BodyCharacteristics.json reais -- ver notas de
design da conversa que originou este arquivo):

Cada entrada da lista JSON tem sempre "Id"/"Name"/"Model", e entao ZERO OU
MAIS dos seguintes blocos de cor (na pratica, quase sempre exatamente um
dos dois principais):

  Modo A (tingivel via rampa):  GreyscaleTexture + GradientSet
      -> a "cor" real vem de uma textura-rampa (ver gradient_parser.py),
         nao de um tint plano. A GreyscaleTexture guarda luminancia
         (sombra/dobra/brilho), o GradientSet resolve o nome da cor pra
         uma imagem de rampa que e amostrada por essa luminancia.

  Modo B (variantes discretas): Textures: {nome: {Texture, BaseColor}}
      -> texturas ja prontas/coloridas, sem rampa. BaseColor aqui e so
         metadado pro swatch da UI, nao e aplicado em nenhum shader.

  Caso raro, os dois juntos (ex. "Scarf" em Overtops.json): o item tem um
  GreyscaleTexture+GradientSet "principal" E uma entrada extra em
  Textures pra uma variante especifica (ex. "Colorful", padrao
  multicolorido que nao cabe numa rampa de 1 cor). O parser preserva
  ambos sem tentar decidir qual e "o" modo do item -- ver
  Item.coloring_mode, que reporta 'gradient' quando o modo A esta
  presente (prioridade visual: e o caminho mais comum).

Campos ignorados de proposito no v1 (sistema de monetizacao do jogo, sem
sentido numa ferramenta offline de Blender que ja tem o asset extraido):
Entitlements, FallbackPartIds. Eles sao lidos e guardados (caso vire util
no futuro, ex. pra marcar visualmente "isso era conteudo pago"), mas
nenhuma logica do addon deve depender deles pra decidir o que mostrar.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class TextureVariant:
    """Uma variante de cor "pronta" (Modo B) -- textura ja colorida, sem
    passar por rampa de gradiente. base_color e so o valor pra desenhar o
    swatch no picker, nao e aplicado no shader."""

    name: str
    texture: str  # caminho relativo a raiz do Assets, ex. "Cosmetics/Gloves/MiningGloves_Black.png"
    base_color: tuple = field(default_factory=tuple)  # hex string(s); pode ter mais de 1 (ver "Scarf"/"Colorful")


@dataclass(frozen=True)
class ItemVariant:
    """Sub-variante posicional/estrutural de um Item (raro -- ex.
    Spiked_Bracelets Left/Right/Default, Scavenger_Poncho
    ShortDungareesRegular/Slacks). Tem seu proprio Model + opcionalmente
    sua propria GreyscaleTexture, mas vive sob o mesmo Id do Item pai
    (o GradientSet, quando existe, e herdado do Item pai)."""

    key: str
    name_key: Optional[str]
    model: str
    greyscale_texture: Optional[str] = None


@dataclass(frozen=True)
class Item:
    id: str
    name_key: str
    model: str
    category: str  # nome do arquivo .json de origem (ex. "Gloves"), usado pra agrupar na UI

    greyscale_texture: Optional[str] = None
    gradient_set: Optional[str] = None

    textures: tuple = field(default_factory=tuple)  # tuple[TextureVariant, ...]
    variants: tuple = field(default_factory=tuple)  # tuple[ItemVariant, ...]

    is_default_asset: bool = False

    # guardados mas nao usados pra decisao nenhuma no v1 -- ver docstring do modulo
    entitlements: tuple = field(default_factory=tuple)
    fallback_part_ids: tuple = field(default_factory=tuple)

    # Qualquer campo do JSON que NAO seja um dos conhecidos acima cai
    # aqui, cru (ex.: "HairType"/"RequiresGenericHaircut" em
    # Haircuts.json -- confirmado contra o arquivo real: sao a peca de
    # dado que decide "None" quando um personagem customizado nao suporta
    # aquela categoria, ver conceito original do addon). Nao processamos
    # isso ainda no v1, mas guardar cru agora evita perder a informacao
    # e ter que re-parsear tudo de novo quando essa feature for construida.
    extra: dict = field(default_factory=dict)

    @property
    def coloring_mode(self) -> str:
        """'gradient' (Modo A presente -- prioridade visual, e o caminho
        mais comum), 'discrete' (so Modo B), ou 'none' (nenhum dos dois --
        nao deveria acontecer nos dados reais, mas o parser nao assume,
        so reporta pra quem for desenhar a UI decidir o que fazer).

        Caso de borda confirmado nos dados reais (ex. "Scavenger_Poncho",
        "Dungarees", "LongDungarees" em Overtops.json/Pants.json): quando
        o Item tem Variants, a GreyscaleTexture pode morar em CADA
        variante em vez de no Item -- o GradientSet continua no Item,
        compartilhado por todas as variantes. Por isso checamos tambem
        `self.variants` antes de decidir 'none'."""
        greyscale_somewhere = self.greyscale_texture or any(
            v.greyscale_texture for v in self.variants
        )
        if self.gradient_set and greyscale_somewhere:
            return "gradient"
        if self.textures:
            return "discrete"
        return "none"

    def greyscale_for_variant(self, variant_key: Optional[str] = None) -> Optional[str]:
        """Resolve a GreyscaleTexture a usar: a do Item, ou -- se o Item
        nao tiver uma propria e existir uma variante com esse key -- a da
        variante. `variant_key=None` usa a primeira variante disponivel
        (equivalente a "variante padrao") quando o Item nao tem
        GreyscaleTexture propria."""
        if self.greyscale_texture:
            return self.greyscale_texture
        if not self.variants:
            return None
        if variant_key is not None:
            match = next((v for v in self.variants if v.key == variant_key), None)
            if match is not None:
                return match.greyscale_texture
        return self.variants[0].greyscale_texture

    def model_for_variant(self, variant_key: Optional[str] = None) -> Optional[str]:
        """Mesmo padrao de greyscale_for_variant, pro Model -- BUG REAL
        encontrado no teste: alguns itens (ex. "Slickback"/"Dreadlocks"
        em Haircuts.json) tem `Model` vazio no nivel do Item, so definido
        DENTRO de cada Variante (mesmo padrao ja confirmado pra
        GreyscaleTexture, so que eu tinha esquecido de replicar aqui).
        Sem isso, qualquer codigo que usasse `item.model` direto (geracao
        de thumbnail, aplicar item) resolvia pra string vazia -> caminho
        quebrado -> "Model nao encontrado em disco" apontando pra pasta
        Common sozinha (sem nome de arquivo nenhum depois)."""
        if self.model:
            return self.model
        if not self.variants:
            return None
        if variant_key is not None:
            match = next((v for v in self.variants if v.key == variant_key), None)
            if match is not None and match.model:
                return match.model
        return self.variants[0].model or None


def _parse_texture_variants(raw: dict) -> tuple:
    return tuple(
        TextureVariant(
            name=name,
            texture=data["Texture"],
            base_color=tuple(data.get("BaseColor", [])),
        )
        for name, data in raw.items()
    )


def _parse_item_variants(raw: dict) -> tuple:
    return tuple(
        ItemVariant(
            key=key,
            name_key=data.get("NameKey"),
            model=data.get("Model", ""),
            greyscale_texture=data.get("GreyscaleTexture"),
        )
        for key, data in raw.items()
    )


_KNOWN_ITEM_KEYS = frozenset({
    "Id", "Name", "Model", "GreyscaleTexture", "GradientSet", "Textures", "Variants",
    "IsDefaultAsset", "Entitlements", "FallbackPartIds",
})


def parse_items(json_path: Path, category: Optional[str] = None) -> list:
    """Le um .json de Cosmetics/CharacterCreator/ (ex. Gloves.json) e
    devolve a lista de Item. `category` default = nome do arquivo sem
    extensao (ex. "Gloves.json" -> "Gloves")."""
    category = category or json_path.stem

    with json_path.open(encoding="utf-8") as f:
        raw_list = json.load(f)

    items = []
    for raw in raw_list:
        items.append(
            Item(
                id=raw["Id"],
                name_key=raw.get("Name", ""),
                model=raw.get("Model", ""),
                category=category,
                greyscale_texture=raw.get("GreyscaleTexture"),
                gradient_set=raw.get("GradientSet"),
                textures=_parse_texture_variants(raw.get("Textures", {})),
                variants=_parse_item_variants(raw.get("Variants", {})),
                is_default_asset=raw.get("IsDefaultAsset", False),
                entitlements=tuple(raw.get("Entitlements", [])),
                fallback_part_ids=tuple(raw.get("FallbackPartIds", [])),
                extra={k: v for k, v in raw.items() if k not in _KNOWN_ITEM_KEYS},
            )
        )
    return items


# Arquivos de Cosmetics/CharacterCreator/ que SAO listas JSON validas mas
# NAO sao catalogo de Item pro picker. Dois motivos possiveis:
#   - Paleta/dado de apoio, nao catalogo (Id/BaseColor ou Id/Gradients em
#     vez de Id/Model): GenericColors/HairColors/EyeColors/GradientSets.
#   - Sistema de EMOTES/animacao, fora do escopo deste addon (foco e
#     aparencia -- import de animacao e outra ferramenta inteira, pedido
#     explicito pra excluir): Emotes/EmotesFace/EmotesInGame.
# Tags ainda nao analisado, fica de fora por seguranca ate confirmar o
# schema dele.
_NON_ITEM_CATALOG_FILES = frozenset({
    "GradientSets", "GenericColors", "HairColors", "EyeColors", "Tags",
    "Emotes", "EmotesFace", "EmotesInGame",
})


def parse_character_creator_folder(character_creator_dir: Path) -> dict:
    """Escaneia Cosmetics/CharacterCreator/ inteiro, devolve
    {nome_da_categoria: [Item, ...]}. Ignora arquivos que nao sao lista de
    itens no formato esperado (ex. HaircutFallbacks.json e um dict simples
    de fallback, nao um catalogo -- tem parser proprio, nao entra aqui) e
    os listados em _NON_ITEM_CATALOG_FILES (mesmo sendo lista JSON, tem
    schema diferente de Item)."""
    result = {}
    for json_path in sorted(character_creator_dir.glob("*.json")):
        if json_path.stem in _NON_ITEM_CATALOG_FILES:
            continue

        try:
            with json_path.open(encoding="utf-8") as f:
                raw = json.load(f)
        except (json.JSONDecodeError, OSError) as exc:
            print(f"[HyblendCharacterCreator] Aviso: nao consegui ler {json_path.name}: {exc}")
            continue

        if not isinstance(raw, list):
            # dicts simples (HaircutFallbacks.json) nao sao catalogo de
            # Item -- pulados silenciosamente aqui
            continue

        try:
            result[json_path.stem] = parse_items(json_path, category=json_path.stem)
        except (KeyError, TypeError) as exc:
            # uma entrada mal-formada nao pode travar o scan inteiro --
            # ha centenas de itens, e melhor avisar e seguir
            print(f"[HyblendCharacterCreator] Aviso: entrada invalida em {json_path.name}: {exc}")
    return result
