"""Avaliação dos canais de um .blockyanim do mesmo jeito que o jogo.

Regras (spec de engenharia reversa do player do jogo -- zimokernel/
HytaleModel, docs/blockyanim-spec.md §10), tempo em frames a 60 FPS:
  - before = último key com tempo < t; after = primeiro com tempo >= t.
    Em loop (holdLastKeyframe false, com duration e 2+ keys) os dois dão a
    volta: antes do 1º key vale o último key - duration; depois do último,
    o 1º + duration. Sem loop: antes do 1º / depois do último = constante.
  - Posição e shapeStretch: Catmull-Rom UNIFORME (vizinhos por índice, não
    por tempo) se qualquer ponta for "smooth", senão linear. Vizinho que não
    existe repete a ponta; em loop com 3+ keys dá a volta.
  - Rotação: slerp do delta (arco curto), nunca spline; com as duas pontas
    "smooth" o alpha passa por uma curva de ease (Bézier racional) -- a
    "pausinha" em cada key de rotação no jogo.
  - Canal com um key só: constante."""

import bisect
import math

from mathutils import Quaternion, Vector

KIND_POSITION = "position"
KIND_ORIENTATION = "orientation"
KIND_STRETCH = "shapeStretch"

_KEY_TOLERANCE = 0.05  # frames -- key a essa distância de t vale direto
_EASE_POINTS = (0.0, 0.05, 0.95, 1.0)
_EASE_WEIGHTS = (2.0, 1.0, 2.0, 1.0)


def ease(t):
    """Ease da rotação "smooth" (Bézier cúbica racional)."""
    u = 1.0 - t
    basis = (u * u * u, 3.0 * u * u * t, 3.0 * u * t * t, t * t * t)
    num = sum(b * w * p for b, w, p in zip(basis, _EASE_WEIGHTS, _EASE_POINTS))
    den = sum(b * w for b, w in zip(basis, _EASE_WEIGHTS))
    return num / den


def _catmull_rom(p0, p1, p2, p3, a):
    return 0.5 * (
        2.0 * p1 + (p2 - p0) * a + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * (a * a)
        + (3.0 * p1 - p0 - 3.0 * p2 + p3) * (a * a * a)
    )


def _key_value(key, kind):
    delta = key.get("delta") or {}
    if kind == KIND_ORIENTATION:
        return Quaternion((delta.get("w", 1.0), delta.get("x", 0.0), delta.get("y", 0.0), delta.get("z", 0.0)))
    default = 1.0 if kind == KIND_STRETCH else 0.0
    return Vector((delta.get("x", default), delta.get("y", default), delta.get("z", default)))


class Channel:
    """Um canal (position/orientation/shapeStretch) de um bone, avaliável
    em qualquer tempo `t` (frames a 60 FPS, float)."""

    def __init__(self, keys, kind, duration, looping):
        self.kind = kind
        self.keys = sorted(keys, key=lambda k: k["time"])
        self.times = [k["time"] for k in self.keys]
        self.values = [_key_value(k, kind) for k in self.keys]
        self.smooth = [k.get("interpolationType", "smooth") == "smooth" for k in self.keys]
        self.duration = duration
        self.looping = bool(looping and duration and len(self.keys) >= 2)

    def __bool__(self):
        return bool(self.keys)

    def _bracket(self, t):
        """(índice before, índice after, tempo before, tempo after), ou
        (índice, None, ...) quando `t` cai fora e o canal não dá a volta."""
        n = len(self.keys)
        first_at_or_after = bisect.bisect_left(self.times, t)
        before = first_at_or_after - 1 if first_at_or_after > 0 else None
        after = first_at_or_after if first_at_or_after < n else None
        if before is None:
            if not self.looping:
                return 0, None, None, None
            before, b_time = n - 1, self.times[-1] - self.duration
        else:
            b_time = self.times[before]
        if after is None:
            if not self.looping:
                return n - 1, None, None, None
            after, a_time = 0, self.times[0] + self.duration
        else:
            a_time = self.times[after]
        return before, after, b_time, a_time

    def evaluate(self, t):
        n = len(self.keys)
        if n == 0:
            return None
        if n == 1:
            return self.values[0].copy()
        if self.looping:
            t = t % self.duration
        bi, ai, b_time, a_time = self._bracket(t)
        if ai is None:
            return self.values[bi].copy()
        if abs(a_time - t) <= _KEY_TOLERANCE:
            return self.values[ai].copy()
        span = a_time - b_time
        alpha = 0.0 if span <= 0 else (t - b_time) / span
        if self.kind == KIND_ORIENTATION:
            q0, q1 = self.values[bi], self.values[ai]
            if q0.dot(q1) < 0.0:
                q1 = -q1
            if self.smooth[bi] and self.smooth[ai]:
                alpha = ease(alpha)
            return q0.slerp(q1, alpha)
        p1, p2 = self.values[bi], self.values[ai]
        if not (self.smooth[bi] or self.smooth[ai]):
            return p1.lerp(p2, alpha)
        wrap = self.looping and n >= 3
        p0 = self.values[bi - 1] if bi >= 1 else (self.values[n - 2] if wrap else p1)
        p3 = self.values[bi + 2] if bi + 2 < n else (self.values[1] if wrap else p2)
        return _catmull_rom(p0, p1, p2, p3, alpha)

    def key_times(self):
        """Tempos dos keys que reproduzem o canal no Blender: os do arquivo e, em loop, também 0 e `duration`."""
        times = sorted(set(self.times))
        if self.looping:
            times = sorted({t for t in times if 0 <= t <= self.duration} | {0, self.duration})
        return times


# ease() como Bézier 2D (0,0) (x1,y1) (x2,y2) (1,1), que o Blender desenha; erro máximo 0,05% do trecho.
_EASE_BEZIER = ((0.29729, 0.01811), (0.474, 0.82938))


def _bezier1d(p0, p1, p2, p3, s):
    u = 1.0 - s
    return u * u * u * p0 + 3.0 * u * u * s * p1 + 3.0 * u * s * s * p2 + s * s * s * p3


def _ease_param(alpha):
    """s em que o x da Bézier do ease vale `alpha` (x é monótono)."""
    (x1, _y1), (x2, _y2) = _EASE_BEZIER
    lo, hi = 0.0, 1.0
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        if _bezier1d(0.0, x1, x2, 1.0, mid) < alpha:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def _sub_bezier(points, s0, s1):
    """Pontos de controle do pedaço [s0, s1] de uma Bézier cúbica (de
    Casteljau: corta em s1, depois o pedaço da esquerda em s0/s1)."""
    def split(pts, s):
        a = [p0.lerp(p1, s) for p0, p1 in zip(pts, pts[1:])]
        b = [p0.lerp(p1, s) for p0, p1 in zip(a, a[1:])]
        c = b[0].lerp(b[1], s)
        return [pts[0], a[0], b[0], c], [c, b[1], a[2], pts[3]]
    left, _right = split(points, s1)
    _left, piece = split(left, s0 / s1)
    return piece


def bezier_segments(channel, times):
    """Curva do jogo como Bézier 2D por trecho de `times`: [((t, v), alça de saída, alça de chegada, (t, v))] e os valores.
    Posição/stretch: cúbica, exata. Rotação: lerp dos componentes com o ease e _nlerp_weights (~1° num trecho de 150°),
    com o sinal do quaternion contínuo."""
    values = []
    segments = []
    previous = None
    for i in range(len(times) - 1):
        t0, t1 = times[i], times[i + 1]
        if channel.kind != KIND_ORIENTATION:
            c0, c3 = channel.evaluate(t0), channel.evaluate(t1)
            c1 = channel.evaluate(t0 + (t1 - t0) / 3.0)
            c2 = channel.evaluate(t0 + 2.0 * (t1 - t0) / 3.0)
            # Cúbica pelos 4 pontos (s = 0, 1/3, 2/3, 1) -> pontos de controle.
            h1 = (-5.0 * c0 + 18.0 * c1 - 9.0 * c2 + 2.0 * c3) / 6.0
            h2 = (2.0 * c0 - 9.0 * c1 + 18.0 * c2 - 5.0 * c3) / 6.0
            segment = [(t0, c0), (t0 + (t1 - t0) / 3.0, h1), (t1 - (t1 - t0) / 3.0, h2), (t1, c3)]
        else:
            segment = _rotation_segment(channel, t0, t1, previous)
            previous = segment[3][1]
        if not values:
            values.append(segment[0][1])
        values.append(segment[3][1])
        segments.append(segment)
    if not segments:
        values = [channel.evaluate(t) for t in times]
    return values, segments


def _rotation_segment(channel, t0, t1, previous):
    # O trecho do jogo é o que contém o meio de [t0, t1] (nunca atravessam um key).
    bi, ai, b_time, a_time = channel._bracket(0.5 * (t0 + t1))
    q0, q1 = channel.values[bi], channel.values[ai]
    if previous is not None and q0.dot(previous) < 0.0:
        q0 = -q0
    if q1.dot(q0) < 0.0:
        q1 = -q1
    v0, v1 = Vector(q0), Vector(q1)
    span = a_time - b_time
    a0 = (t0 - b_time) / span
    a1 = (t1 - b_time) / span
    eased = channel.smooth[bi] and channel.smooth[ai]
    if eased:
        (x1, y1), (x2, y2) = _EASE_BEZIER
        curve = [Vector((0.0, 0.0)), Vector((x1, y1)), Vector((x2, y2)), Vector((1.0, 1.0))]
        piece = _sub_bezier(curve, _ease_param(a0), _ease_param(a1))
    else:
        piece = [Vector((a, a)) for a in (a0, a0 + (a1 - a0) / 3.0, a1 - (a1 - a0) / 3.0, a1)]
    ys = _nlerp_weights(piece, eased, math.acos(min(1.0, max(-1.0, q0.dot(q1)))))
    return [(b_time + p.x * span, v0.lerp(v1, y)) for p, y in zip(piece, ys)]


def _nlerp_weights(piece, eased, theta):
    """y das alças pra o lerp normalizado do Blender cair no slerp do jogo (g(e) = sin(eθ) / (sin(eθ) + sin((1-e)θ)));
    alças por mínimos quadrados (sem isso, ~4,5° de erro num trecho de 150°)."""
    if theta < 1e-4:
        return [p.y for p in piece]

    def g(e):
        a, b = math.sin(e * theta), math.sin((1.0 - e) * theta)
        return a / (a + b)

    def target(x):
        return g(ease(x) if eased else x)

    xs = [p.x for p in piece]
    y0, y3 = target(xs[0]), target(xs[3])
    m11 = m12 = m22 = r1 = r2 = 0.0
    for k in range(1, 20):
        sk = k / 20.0
        u = 1.0 - sk
        b0, b1, b2, b3 = u * u * u, 3.0 * u * u * sk, 3.0 * u * sk * sk, sk * sk * sk
        rest = target(b0 * xs[0] + b1 * xs[1] + b2 * xs[2] + b3 * xs[3]) - b0 * y0 - b3 * y3
        m11 += b1 * b1
        m12 += b1 * b2
        m22 += b2 * b2
        r1 += b1 * rest
        r2 += b2 * rest
    det = m11 * m22 - m12 * m12
    return [y0, (r1 * m22 - r2 * m12) / det, (r2 * m11 - r1 * m12) / det, y3]
