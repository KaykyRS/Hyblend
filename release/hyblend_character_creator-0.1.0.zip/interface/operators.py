"""interface/operators.py -- Operators de CLIQUE da UI (selecionar
Categoria/Sub-categoria/Variante/Cor, ligar/desligar links de cor).
Nenhum deles aplica nada na cena diretamente: so escrevem no estado da
UI (`wm.hyblendcc_active_*`) ou nas EnumProperty/BoolProperty do slot
-- o update() normal do slot (picker.py) e quem agenda a aplicacao de
verdade via `_defer_apply_slot`. Movidos de picker.py sem mudar logica
(ver DEVELOPER_NOTES item 56); `bl_idname` IDENTICOS aos de antes, entao
nada que chama por string (`layout.operator("hyblendcc....")`) muda."""

from __future__ import annotations

from bpy.props import StringProperty
from bpy.types import Operator

from ..common import _SLOT_NONE_VALUE, _prettify_key
from ..picker import _find_slot
from ..scanner.catalog import get_cache
from .ui_data import _group_categories


# ---------------------------------------------------------------------------
# REVERTIDO DE VEZ -- template_icon_view crashou DUAS VEZES (ver
# DEVELOPER_NOTES.md itens 14 e 15), a segunda mesmo depois de fechar a
# causa especifica que foi diagnosticada na primeira (bpy.data dentro do
# items()). Ou seja, o diagnostico anterior nao era a causa completa (ou
# nao era a causa nenhuma) -- SEM um crash log de verdade pra analisar,
# continuar tentando variacoes dessa abordagem e chute, nao correcao. NAO
# TENTAR template_icon_view DE NOVO pra Categoria/Sub-categoria sem um
# dado novo de verdade (crash log, ou reproduzir num Blender de teste
# com sintomas isolados) -- ver DEVELOPER_NOTES.md item 16.
# ---------------------------------------------------------------------------

class HYBLENDCC_OT_select_section(Operator):
    """Clique num icone de Categoria (grupo grande, ex. 'Head') na grade
    -- troca o grupo ativo e reseta pra primeira sub-categoria dele."""

    bl_idname = "hyblendcc.select_section"
    bl_label = "Select Category"
    bl_description = "Select this category group and switch to its first sub-category"
    bl_options = {"INTERNAL"}

    section: StringProperty()

    @classmethod
    def description(cls, context, properties):
        # Tooltip dinamico -- esses botoes sao SO icone (sem texto
        # nenhum na propria grade), entao o nome legivel da categoria
        # SO aparece passando o mouse. Pedido explicito do usuario.
        return _prettify_key(properties.section)

    def execute(self, context):
        wm = context.window_manager
        wm.hyblendcc_active_section = self.section
        subcats = _group_categories(get_cache()).get(self.section, [])
        wm.hyblendcc_active_category = subcats[0] if subcats else ""
        return {"FINISHED"}


class HYBLENDCC_OT_select_category(Operator):
    """Clique num icone de Sub-categoria (ex. 'Haircuts') na grade."""

    bl_idname = "hyblendcc.select_category"
    bl_label = "Select Sub-category"
    bl_description = "Select this sub-category"
    bl_options = {"INTERNAL"}

    category: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return _prettify_key(properties.category)

    def execute(self, context):
        wm = context.window_manager
        wm.hyblendcc_active_category = self.category
        return {"FINISHED"}


class HYBLENDCC_OT_select_variant(Operator):
    """Clique num botao de Variante (ex. Left/Right) dentro de Colors."""

    bl_idname = "hyblendcc.select_variant"
    bl_label = "Select Variant"
    bl_description = "Select this variant for the current item"
    bl_options = {"INTERNAL", "UNDO"}

    category: StringProperty()
    variant: StringProperty()

    def execute(self, context):
        slot = _find_slot(context.window_manager, self.category)
        if slot is None:
            return {"CANCELLED"}
        if slot.variant != self.variant:
            slot.variant = self.variant
        return {"FINISHED"}


class HYBLENDCC_OT_select_color(Operator):
    """Clique num swatch circular dentro de Colors -- escreve direto em
    `slot.color` (o proprio update, `_slot_on_color_update`, cuida de
    propagar pras outras categorias linkadas quando aplicavel, ver
    `_propagate_linked_skin_color`). Sem mais o caso especial de
    escrever numa property compartilhada (`wm.hyblendcc_skintone`,
    removida) -- cada slot tem sua PROPRIA `color` sempre."""

    bl_idname = "hyblendcc.select_color"
    bl_label = "Select Color"
    bl_description = "Select this color for the current item"
    bl_options = {"INTERNAL", "UNDO"}

    category: StringProperty()
    color: StringProperty()

    @classmethod
    def description(cls, context, properties):
        # Tooltip dinamico: nome da cor + GradientSet (ex. "23 (Skin)")
        # -- pedido explicito do usuario (swatches sao so um circulo de
        # cor, sem texto nenhum, entao o nome so aparece no hover).
        slot = _find_slot(context.window_manager, properties.category)
        gset = slot.gradient_set if slot is not None else ""
        if gset and gset != _SLOT_NONE_VALUE:
            return f"{properties.color} ({gset})"
        return properties.color

    def execute(self, context):
        slot = _find_slot(context.window_manager, self.category)
        if slot is None:
            return {"CANCELLED"}
        if slot.color != self.color:
            slot.color = self.color
        return {"FINISHED"}


class HYBLENDCC_OT_select_background_color(Operator):
    """Clique num swatch da grade de cor do '*Background*' (ex.
    Eye-Background) -- SEPARADA da cor principal do item. So relevante
    quando `slot.background_linked` esta desligado (ligado, o fundo usa
    `slot.color` direto, essa grade nem aparece -- ver interface/panel.py)."""

    bl_idname = "hyblendcc.select_background_color"
    bl_label = "Select Background Color"
    bl_description = "Select this color for the item's background part"
    bl_options = {"INTERNAL", "UNDO"}

    category: StringProperty()
    color: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return f"Background: {properties.color}"

    def execute(self, context):
        slot = _find_slot(context.window_manager, self.category)
        if slot is None:
            return {"CANCELLED"}
        if slot.background_color != self.color:
            slot.background_color = self.color
        return {"FINISHED"}


class HYBLENDCC_OT_toggle_background_link(Operator):
    """Liga/desliga o link entre a cor principal do item e a cor do
    '*Background*' -- ligado, o fundo usa `slot.color` (mesma cor do
    item); desligado, usa `slot.background_color` (independente, ver
    HYBLENDCC_OT_select_background_color). So aparece na UI pra itens
    que de fato tem esse no separado na malha (ver
    _item_model_has_background_node, interface/panel.py)."""

    bl_idname = "hyblendcc.toggle_background_link"
    bl_label = "Link Background Color"
    bl_description = "Toggle whether the background part follows this item's main color or uses its own"
    bl_options = {"INTERNAL", "UNDO"}

    category: StringProperty()

    @classmethod
    def description(cls, context, properties):
        slot = _find_slot(context.window_manager, properties.category)
        linked = slot.background_linked if slot is not None else False
        return "Linked: click to give background its own color" if linked else "Independent: click to match item color"

    def execute(self, context):
        slot = _find_slot(context.window_manager, self.category)
        if slot is None:
            return {"CANCELLED"}
        slot.background_linked = not slot.background_linked
        return {"FINISHED"}


class HYBLENDCC_OT_toggle_skin_link(Operator):
    """Liga/desliga o link de cor compartilhada entre
    BodyCharacteristics/Faces/Mouths/Ears -- ligado, escolher uma cor
    aqui propaga pras outras categorias do grupo TAMBEM linkadas
    (`_propagate_linked_skin_color`); desligado, essa categoria fica
    com paleta independente (nao propaga nem recebe mudanca das
    outras). Cada categoria mantem a PROPRIA grade de cor sempre
    visivel -- diferente do link de Eye-Background, aqui NAO aparece
    uma segunda paleta, so muda se a escolha se propaga ou nao."""

    bl_idname = "hyblendcc.toggle_skin_link"
    bl_label = "Link Skin Color"
    bl_description = "Toggle whether this category's color propagates to other linked skin categories"
    bl_options = {"INTERNAL", "UNDO"}

    category: StringProperty()

    @classmethod
    def description(cls, context, properties):
        slot = _find_slot(context.window_manager, properties.category)
        linked = slot.skin_linked if slot is not None else False
        name = _prettify_key(properties.category)
        return f"{name}: linked, click to make independent" if linked else f"{name}: independent, click to link"

    def execute(self, context):
        slot = _find_slot(context.window_manager, self.category)
        if slot is None:
            return {"CANCELLED"}
        slot.skin_linked = not slot.skin_linked
        return {"FINISHED"}
