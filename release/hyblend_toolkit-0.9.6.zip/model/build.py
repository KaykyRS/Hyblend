"""Monta um .blockymodel numa Armature: um bone por nó (rest certa) e as malhas presas aos bones
(parent + modifier Armature + vertex group com peso 1: visual rígido, mas dá pra repintar os pesos).

Dois jeitos: Armature nova, ou anexar numa existente (attachment: roupa, cabelo, arma...). No anexo, a raiz do
arquivo e os nós com isPiece ancoram no bone de mesmo nome que já existe (como o plugin do Blockbench); os filhos
vão num bone "wrapper" "{arquivo}:{nó}" dentro dele.
Não mexe no texto de nada: avisos voltam como (nível, key, campos) pra quem chama traduzir.
"""

import json
import math
import os
import re
from dataclasses import dataclass, field

import bpy
from mathutils import Euler, Matrix, Vector

from . import geometry
from .props import (
    ARMATURE_MODEL_FORMAT_PROP,
    ATTACHMENTS_COLLECTION_PROP,
    BONE_DISPLAY_LENGTH,
    BONE_ORIGINAL_NAME_PROP,
    BONE_SHAPE_JSON_PROP,
    BONE_SHAPE_OFFSET_PROP,
    MAIN_COLLECTION_PROP,
    MODEL_FORMAT_CHARACTER,
    MODEL_FORMAT_PROP,
    armature_model_format,
    bone_file_name,
    normalize_model_format,
    store_import_rest,
)

# No objeto de malha: "{arquivo}:{nó}" de onde veio (reimportar o mesmo anexo não duplica, mesmo com ".001").
SOURCE_PROP = "hytale_source"


@dataclass
class Result:
    armature: object
    objects: list = field(default_factory=list)       # malhas criadas
    bones: list = field(default_factory=list)         # bones criados (pai antes do filho), nunca os reaproveitados
    warnings: list = field(default_factory=list)      # (nível, key, campos)
    nodes: int = 0


def model_name(filepath):
    """Nome do modelo = arquivo sem extensão (o .blockymodel não guarda nome)."""
    base = os.path.basename(filepath or "")
    if base.lower().endswith(".blockymodel"):
        base = base[:-len(".blockymodel")]
    return base or "Hytale_Model"


def resolve_format(choice, data, filepath="", attach_armature=None):
    """Character/Prop (ordem do plugin): escolha manual, "format" no arquivo, [anexo] o da Armature, pasta
    "Blocks" -> prop, senão character."""
    if choice in ("CHARACTER", "PROP"):
        return MODEL_FORMAT_PROP if choice == "PROP" else MODEL_FORMAT_CHARACTER
    if data.get("format"):
        return normalize_model_format(data["format"])
    if attach_armature is not None and ARMATURE_MODEL_FORMAT_PROP in attach_armature:
        return armature_model_format(attach_armature)
    if "Blocks" in re.split(r"[\\/]", os.path.normpath(filepath or ""))[:-1]:
        return MODEL_FORMAT_PROP
    return MODEL_FORMAT_CHARACTER


# --- Collections ---

def child_collection(parent, name):
    for child in parent.children:
        if child.name == name:
            return child
    coll = bpy.data.collections.new(name)
    parent.children.link(coll)
    return coll


def new_armature(context, name, model_format=MODEL_FORMAT_CHARACTER):
    """Armature nova nas collections do personagem: <nome> > Rig - <nome> e Meshes - <nome> > Main / Mesh
    Attachments (o sufixo evita ".001" com vários personagens). Devolve (objeto, collection Main)."""
    data = bpy.data.armatures.new(name)
    obj = bpy.data.objects.new(name, data)
    top = bpy.data.collections.new(obj.name)
    context.scene.collection.children.link(top)
    name = obj.name
    rig = child_collection(top, f"Rig - {name}")
    meshes = child_collection(top, f"Meshes - {name}")
    main = child_collection(meshes, f"Main - {name}")
    attachments = child_collection(meshes, f"Mesh Attachments - {name}")
    rig.objects.link(obj)
    obj[MAIN_COLLECTION_PROP] = main.name
    obj[ATTACHMENTS_COLLECTION_PROP] = attachments.name
    obj[ARMATURE_MODEL_FORMAT_PROP] = model_format
    return obj, main


def attachments_collection(context, armature_obj):
    """(collection "Mesh Attachments" da Armature, criada agora?). Sem a propriedade (import antigo ou feito à
    mão) cria uma ao lado da Armature e grava."""
    existing = bpy.data.collections.get(armature_obj.get(ATTACHMENTS_COLLECTION_PROP) or "")
    if existing is not None:
        return existing, False
    parent = armature_obj.users_collection[0] if armature_obj.users_collection else context.scene.collection
    coll = child_collection(parent, f"Mesh Attachments - {armature_obj.name}")
    armature_obj[ATTACHMENTS_COLLECTION_PROP] = coll.name
    return coll, True


def bone_collection(cache, top, armature_name, bone_name, ancestor_of):
    """Collection das malhas de um bone ("{bone} - {armature}"), dentro da do ancestral com malha (aninhado) ou
    direto em `top`. `ancestor_of(bone)` = bone ancestral com malha ou None; `cache` = dict da chamada."""
    key = (top.name, bone_name)
    if key in cache:
        return cache[key]
    ancestor = ancestor_of(bone_name)
    parent = (bone_collection(cache, top, armature_name, ancestor, ancestor_of)
              if ancestor is not None and ancestor != bone_name else top)
    cache[key] = child_collection(parent, f"{bone_name} - {armature_name}")
    return cache[key]


def _collection_sources(coll, out):
    """Origem ("{arquivo}:{nó}") e nome de todo objeto da collection e sub-collections."""
    for obj in coll.objects:
        out.add(obj.get(SOURCE_PROP, ""))
        out.add(obj.name)
    for child in coll.children:
        _collection_sources(child, out)


# --- Bones ---

def unique_bone_name(name, edit_bones):
    """Nome livre com sufixo ".dupNN" (não o ".001" do Blender); o original vai em BONE_ORIGINAL_NAME_PROP."""
    if name not in edit_bones:
        return name
    n = 1
    while f"{name}.dup{n:02d}" in edit_bones:
        n += 1
    return f"{name}.dup{n:02d}"


class _Builder:
    def __init__(self, armature_obj, unit_scale, attach, stem, result):
        self.edit_bones = armature_obj.data.edit_bones
        self.unit_scale = unit_scale
        self.attach = attach
        self.stem = stem
        self.result = result
        # Só bones de ANTES deste import podem ser reaproveitados (nome repetido no arquivo vira bone novo).
        self.reusable = set(armature_obj.data.bones.keys()) if attach else set()
        self.world = {}           # id(nó) -> matriz do bone (espaço da Armature)
        self.bone_of = {}         # id(nó) -> nome do bone
        self.own_offset = {}      # id(nó) -> shape.offset resolvido (escalado)

    def _anchor(self, name):
        """Bone existente pra ancorar: nome exato; senão ignorando maiúsculas/espaços; senão pelo nome do arquivo
        (bone renomeado no Blender). Só com UM candidato. Devolve (bone, nome do nó pro wrapper) ou (None, None)."""
        bones = self.edit_bones
        if name in self.reusable and name in bones:
            return bones[name], name
        needle = name.strip().lower()
        same = [n for n in self.reusable if n.strip().lower() == needle and n in bones]
        if len(same) == 1:
            return bones[same[0]], same[0]
        renamed = [n for n in self.reusable if n in bones and (bone_file_name(bones[n]) or "").strip().lower() == needle]
        if len(renamed) == 1:
            return bones[renamed[0]], name        # wrapper segue o nome do ARQUIVO, como o plugin
        return None, None

    def _new_bone(self, name, matrix, parent_name):
        bone = self.edit_bones.new(name)
        bone.head = (0.0, 0.0, 0.0)
        bone.tail = (0.0, BONE_DISPLAY_LENGTH * self.unit_scale, 0.0)
        bone.matrix = matrix
        if parent_name is not None and parent_name in self.edit_bones:
            bone.parent = self.edit_bones[parent_name]
            bone.use_connect = False
        self.result.bones.append(bone.name)
        return bone

    def visit(self, node, parent_name, parent_world, parent_offset):
        name = node.get("name") or "Bone"
        is_root = parent_name is None
        anchor_candidate = bool((node.get("shape") or {}).get("settings", {}).get("isPiece")) or is_root
        bone, wrapper_node = self._anchor(name) if (self.attach and anchor_candidate) else (None, None)

        if bone is not None:
            world = bone.matrix.copy()
            children_parent = bone.name
            if self.stem:
                children_parent = self._new_bone(f"{self.stem}:{wrapper_node}", world, bone.name).name
            stored = bone.get(BONE_SHAPE_OFFSET_PROP)
            # Filhos ancoram no centro da caixa do bone do modelo principal (gravado no 1º import), não no offset
            # que o anexo traz (plugin: parseNode + getMainShape).
            offset = Vector(stored) if stored is not None else Vector((0.0, 0.0, 0.0))
        else:
            if self.attach and is_root:
                self.result.warnings.append(("WARNING", "model.warn.anchor_missing", {"name": name}))
            world = parent_world @ geometry.local_matrix(node, parent_offset, self.unit_scale)
            final = unique_bone_name(name, self.edit_bones)
            if final != name:
                self.result.warnings.append(("WARNING", "model.warn.duplicate_bone", {"name": name, "new": final}))
            bone = self._new_bone(final, world, parent_name)
            store_import_rest(bone)
            if final != name:
                bone[BONE_ORIGINAL_NAME_PROP] = name
            offset = geometry.shape_offset(node, self.unit_scale)
            bone[BONE_SHAPE_OFFSET_PROP] = tuple(offset)
            bone[BONE_SHAPE_JSON_PROP] = json.dumps([node.get("shape", {})])   # lista: mesmo formato do .bbmodel
            children_parent = bone.name

        self.world[id(node)] = world.copy()
        self.bone_of[id(node)] = bone.name
        self.own_offset[id(node)] = offset
        self.result.nodes += 1
        for child in node.get("children") or []:
            self.visit(child, children_parent, world, offset)


def _reattach(edit_bones, children, warnings):
    """Religa por nome bones de fora que eram filhos de bones recriados (apagar um bone sobe os filhos pro avô)."""
    missing = []
    for child_name, parent_name in children.items():
        child = edit_bones.get(child_name)
        if child is None:
            continue
        parent = edit_bones.get(parent_name)
        if parent is None:
            missing.append(child_name)
            continue
        child.parent = parent
        child.use_connect = False
    if missing:
        warnings.append(("WARNING", "model.warn.reattach_missing", {"names": ", ".join(missing)}))


def build(context, data, armature_obj, *, unit_scale, attach=False, stem="", collection=None, meshes=True,
          generate_uvs=True, missing_face_mode="SKIP", flat_collections=False, bone_collections=True, atlas=None,
          material=None, reattach_children=None):
    """Bones (e malhas, com `meshes`) do .blockymodel `data` na `armature_obj`, que fica ativa em Object Mode.
    `attach`: ancora nos bones que já existem. `stem`: nome do arquivo (bone wrapper e o reimport não duplicar).
    `collection`: onde as malhas vão; com `bone_collections` cada bone ganha a sua dentro dela ("{bone} - {arm}",
    aninhadas ou, com `flat_collections`, lado a lado); sem, todas direto nela (CC: peça trocada sem sobrar
    collection vazia). `atlas`: (w, h) da textura; sem ele, estimado pelo arquivo. `material`: posto em todas as
    malhas. `reattach_children`: {bone de fora: pai} a religar por nome. Devolve Result."""
    result = Result(armature_obj)
    roots = data.get("nodes") or []
    builder = _Builder(armature_obj, unit_scale, attach, stem, result)
    view_layer = context.view_layer
    if context.object is not None and context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    view_layer.objects.active = armature_obj
    armature_obj.select_set(True)

    # IMPORTANTE: X-Axis Mirror ligado reseta o bone R criado antes do par L. Desligado durante o import.
    arm = armature_obj.data
    mirror = arm.use_mirror_x
    arm.use_mirror_x = False
    bpy.ops.object.mode_set(mode="EDIT")
    try:
        for root in roots:
            builder.visit(root, None, Matrix.Identity(4), Vector((0.0, 0.0, 0.0)))
        if reattach_children:
            _reattach(arm.edit_bones, reattach_children, result.warnings)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        arm.use_mirror_x = mirror

    if meshes and collection is not None:
        _add_meshes(armature_obj, roots, builder, result, collection, stem, generate_uvs, missing_face_mode,
                    flat_collections, bone_collections, atlas or geometry.atlas_size(roots), material)
    return result


def _add_meshes(armature_obj, roots, builder, result, top, stem, generate_uvs, missing_face_mode, flat,
                per_bone, atlas, material):
    nodes = [n for n in geometry.walk(roots) if geometry.is_visual(n)]
    before = set()
    _collection_sources(top, before)
    cache = {}
    bones = armature_obj.data.bones
    with_mesh = {builder.bone_of[id(n)] for n in nodes}

    def ancestor_of(bone_name):
        if flat:
            return None
        bone = bones.get(bone_name)
        parent = bone.parent if bone is not None else None
        while parent is not None:
            if parent.name in with_mesh:
                return parent.name
            parent = parent.parent
        return None

    atlas_w, atlas_h = atlas
    for node in nodes:
        name = node.get("name") or "Mesh"
        source = f"{stem}:{name}"
        # O mesmo anexo já importado (por este import ou o "_ref" do Anim 0.1.0): não duplica.
        if builder.attach and (source in before or f"{name}_ref" in before):
            continue
        bone_name = builder.bone_of[id(node)]
        mesh = geometry.shape_mesh(name, node["shape"], builder.unit_scale, atlas_w, atlas_h, generate_uvs,
                                   missing_face_mode)
        obj = bpy.data.objects.new(name, mesh)
        if stem:
            obj[SOURCE_PROP] = source
        target = bone_collection(cache, top, armature_obj.name, bone_name, ancestor_of) if per_bone else top
        target.objects.link(obj)
        if material is not None:
            mesh.materials.append(material)
        # IMPORTANTE: × matrix_world (no anexo a Armature já pode estar girada/movida).
        obj.parent = armature_obj
        obj.matrix_world = (armature_obj.matrix_world @ builder.world[id(node)]
                            @ Matrix.Translation(builder.own_offset[id(node)]))
        group = obj.vertex_groups.new(name=bone_name)
        group.add(range(len(mesh.vertices)), 1.0, "REPLACE")
        obj.modifiers.new(name="Armature", type="ARMATURE").object = armature_obj
        result.objects.append(obj)


def orient_z_up(armature_obj):
    """Y-up do jogo -> Z-up do Blender (só visual: rotação no objeto)."""
    armature_obj.rotation_euler = Euler((math.radians(90.0), 0.0, 0.0), "XYZ")
