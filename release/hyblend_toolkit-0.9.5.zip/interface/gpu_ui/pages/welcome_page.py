"""Janela de boas-vindas -- versão GPU (a nativa e a lógica de quando
abrir moram em interface/welcome.py; os textos, links e o banner também
vêm de lá).

Mesmo visual do N-Panel: @DecoratedContainer do jogo (ornamentos, faixa
do título, moldura ContainerPatch), botões/cartões com a arte do jogo,
fontes do jogo. Desenhada pela janela flutuante (framework/overlay.py).
"""

from ... import welcome
from .. import game
from ..app import toast, window
from ..bind import UI
from ..framework import renderer
from ..framework.core import Column, Icon, Label, Rect, Row, Spacer, Style, Widget
from ..widgets import CheckBox, CheckLabel, Paragraph, RuneDivider, TitleBand, _with, card

WIDTH = 580.0              # largura lógica da janela (encolhe em viewport pequena)
TWO_COLUMNS_MIN = 430.0    # abaixo disso, descrição e botões ficam um embaixo do outro
BUTTON_H = 38.0


class Banner(Widget):
    """Arte do addon (assets/) com o título desenhado por cima (texto de
    verdade, trocável em welcome.BANNER_TITLE/SUBTITLE). Base escurecida
    em degradê pra o título ler bem em qualquer parte da arte."""

    RATIO = 390.0 / 1280.0      # proporção do welcome_banner.jpg

    def __init__(self, path, title, subtitle):
        super().__init__(style=Style())
        self.path, self.title, self.subtitle = path, title, subtitle

    def _extent(self, f, width):
        h = round(width * self.RATIO)
        return (h, h, h)

    def measure(self, f, max_w):
        return (max_w, self.extent(f, max_w)[1])

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        if not (self.path and r.image(rect, self.path, fit="cover")):
            r.rect(rect, th.surface, radius=0)

        # Título (Lexend = fonte "Title" do tema) com o subtítulo centralizado
        # embaixo; o CONJUNTO fica centralizado na altura do banner.
        size = max(24.0, min(48.0, rect.w * 0.088))
        sub_size = max(9.0, size * 0.25)
        sub_tracking = sub_size * 0.12
        cap, sub_cap, gap = size * renderer.CAP_RATIO, sub_size * renderer.CAP_RATIO, size * 0.24
        title_w = r.text_width(self.title, size, "Title")
        sub_w = r.text_width(self.subtitle, sub_size, "Title", sub_tracking)
        group_w = max(title_w, sub_w)
        x = rect.x + max(16.0, rect.w * 0.06)
        bottom = rect.y + (rect.h - (cap + gap + sub_cap)) / 2

        # Escurece o lado esquerdo em faixas verticais: forte atrás do texto,
        # sumindo logo depois dele (a arte continua visível à direita).
        text_end = x - rect.x + group_w
        fade = rect.w * 0.22
        steps = 20
        band = min(rect.w, text_end + fade)
        for i in range(steps):
            mid = band * (i + 0.5) / steps
            # 0..1 sempre (texto mais largo que o banner não pode gerar
            # potência de número negativo -> cor "complexa" e erro no shader)
            t = min(1.0, max(0.0, (mid - text_end * 0.75) / max(1e-3, band - text_end * 0.75)))
            r.rect(Rect(rect.x + band * i / steps, rect.y, band / steps + 0.5, rect.h),
                   th.canvas[:3] + (0.72 * (1.0 - t) ** 1.6,))
        r.rect(rect, (0.0, 0.0, 0.0, 0.0), border=th.border)

        title_x = x + (group_w - title_w) / 2
        title_y = bottom + sub_cap + gap
        # Renderer.text centraliza pela altura da maiúscula: retângulo com
        # altura = cap põe a base da letra exatamente em `y`.
        r.text(Rect(title_x, title_y, title_w + 4, cap), self.title, th.text, size=size, weight="Title",
               truncate=False, shadow=((0.0, 0.0, 0.0, 0.55), 1.5, -2.0))
        r.text(Rect(x + (group_w - sub_w) / 2, bottom, sub_w + 4, sub_cap), self.subtitle, th.accent,
               size=sub_size, weight="Title", tracking=sub_tracking, truncate=False,
               shadow=((0.0, 0.0, 0.0, 0.6), 1.0, -1.0))


def release():
    """Ao fechar a janela: tira o banner (1280x390) do cache da GPU."""
    path = welcome.banner_path()
    if path:
        renderer.drop_image(path)


def build(f):
    game.sync()                                   # fontes/arte do jogo (O(1) com a pasta igual)
    ui = UI(f)
    t = ui.t
    th = f.theme
    wm = ui.wm
    width = f.state.get("_overlay_width", WIDTH)

    banner = Banner(welcome.banner_path(), welcome.BANNER_TITLE, welcome.BANNER_SUBTITLE)

    description = card(
        Paragraph(t("welcome.description"), size=11.5, color=th.text),
        Row(Paragraph(t("welcome.experimental"), size=10.5, style=Style(flex=1)),
            Icon("experimental", size=26, style=Style(width=28, height=28)),
            style=Style(gap=6, align="end")),
        gap=6,
    )

    found = welcome.game_dir()
    if found is not None:
        game_button = ui.op("welcome.game", "hyblend.welcome_open_game_folder", t("welcome.game_found"),
                            icon="check", height=BUTTON_H)
        game_button.icon_color = th.success
    else:
        game_button = ui.op("welcome.locate", "hyblend.welcome_locate_game", t("welcome.locate_game"),
                            icon="search", height=BUTTON_H)
    support_url = welcome.support_url()
    # Abre a Home já na aba Changelog (sem a Home: a página de releases no
    # navegador) -- welcome.HYBLEND_OT_welcome_changelog decide.
    changelog = ui.op("welcome.changelog", "hyblend.welcome_changelog", t("welcome.changelog"), height=BUTTON_H)
    # Destaque dourado (contorno Tertiary_Active do jogo), como na referência.
    support = ui.op("welcome.support", "wm.url_open", t("welcome.support"), props={"url": support_url},
                    height=BUTTON_H, enabled=bool(support_url), tooltip=support_url or None, selected=True)
    buttons = [game_button, changelog, support]

    if width >= TWO_COLUMNS_MIN:
        description.style = _with(description.style, flex=1.15)
        column = Column([Spacer()] + buttons + [Spacer()], style=Style(gap=8, flex=1.0))
        content = Row(description, column, style=Style(gap=10))
    else:
        content = Column([description] + buttons, style=Style(gap=8))

    dont_show = bool(getattr(wm, "hytale_welcome_dont_show", False))
    footer = Row(
        # final=False nos dois: preferência da janela, não dado do .blend (sem passo de undo)
        CheckBox("welcome.dont_show", dont_show,
                 lambda f, v: ui.set(f, wm, "hytale_welcome_dont_show", v, final=False),
                 tooltip=lambda: t("welcome.tooltip.dont_show")),
        CheckLabel("welcome.dont_show.label", t("welcome.dont_show"), style=Style(height=26)),   # só a caixinha clica
        Spacer(),
        Label(t("welcome.close_hint"), size=10.5, color=th.text_muted, align="RIGHT"),
        style=Style(gap=2, align="center", height=28),
    )

    # Janela de boas-vindas OPACA (pedido do autor): base sólida por baixo da
    # arte do jogo, que tem transparência própria. O N-Panel continua translúcido.
    header = TitleBand(t("welcome.title"), [], header=game.frame_style("header"),
                       version="v%s" % welcome.addon_version(), key="welcome.header", base=th.canvas)
    # Mesma moldura do N-Panel (app.window); sombra: a janela flutua na viewport.
    return window(f, header, [banner, content, RuneDivider(), footer, toast(f)], key="welcome.root",
                  padding=(14, 12, 14, 14), gap=10, shadow=True, opaque=True)
