"""Páginas da UI por GPU."""
