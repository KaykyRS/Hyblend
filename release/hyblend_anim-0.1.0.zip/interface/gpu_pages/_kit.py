"""Peças da UI por GPU do núcleo usadas pelas páginas do Anim (só importado no Blender 5.0+ com o núcleo ativo).
Página nova que precisar de outra peça: acrescentar aqui (pelo api.gpu_module do núcleo)."""

from ...toolkit import api

_core = api.gpu_module("framework.core")
_widgets = api.gpu_module("widgets")
_common = api.gpu_module("pages.common")

Column, Icon, Label, Row, Style = _core.Column, _core.Icon, _core.Label, _core.Row, _core.Style
CONTROL_H, Hint, ListRow, SwipeButton = _widgets.CONTROL_H, _widgets.Hint, _widgets.ListRow, _widgets.SwipeButton
card, labeled = _widgets.card, _widgets.labeled
list_box, list_with_buttons = _widgets.list_box, _widgets.list_with_buttons
active_armature, bone_field, text_field = _common.active_armature, _common.bone_field, _common.text_field

info_build = api.gpu_module("pages.info_page").build     # aba Info = a do núcleo
