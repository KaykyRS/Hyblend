"""common.py -- constantes/utilitarios sem dependencia interna (camada 0,
tudo no addon pode importar daqui)."""

from __future__ import annotations

from mathutils import Quaternion, Vector

# AddonPreferences.bl_idname precisa ser o nome do pacote raiz.
ADDON_PACKAGE = __package__
# Id deste addon no hyblend_hub (seletor da aba "Hyblend").
HUB_ID = "prefabs"


def game_found():
    """Pasta do Hytale localizada (Preferences > Hytale Folder)? Igual ao
    Hyblend Toolkit (common.game_found): sem ela o addon fica TRAVADO --
    somem o N-Panel (clássico e GPU), a entrada de File > Import e o
    arrastar-e-soltar, e o import não roda (poll). Continuam as
    Preferences e o "Locate Game".

    Barato (pode ir em poll/draw): interface/gpu_ui/game.hytale_dir() é
    cacheado pela (modo, caminho) das Preferences. Import tardio -- este
    arquivo é a camada 0 (todo mundo importa daqui)."""
    game = _game_module()
    return game is not None and game.hytale_dir() is not None


_GAME = []      # interface/gpu_ui/game, importado 1x (game_found roda em todo poll)


def _game_module():
    if not _GAME:
        try:
            from .interface.gpu_ui import game
        except ImportError:          # register() no meio: interface/ ainda não carregou
            return None
        _GAME.append(game)
    return _GAME[0]

# Unidades-cru por bloco de um .blockymodel usado como CustomModel de block/item.
# Ver DEVELOPER_NOTES.md ("Units").
UNIT_SCALE_DEFAULT = 1.0 / 32.0

# Tamanho de uma celula do grid, em unidades Blender. Exposto como property do
# operator (nao e constante fixa) caso um prefab futuro use outra escala.
BLOCK_GRID_UNIT_DEFAULT = 1.0

# Custom properties gravadas nos Objects gerados a partir de blocks[].
PROP_BLOCK_NAME = "hytale_block_name"
PROP_BLOCK_ROTATION_RAW = "hytale_block_rotation_raw"
PROP_BLOCK_SUPPORT_RAW = "hytale_block_support_raw"
PROP_BLOCK_FILLER_RAW = "hytale_block_filler_raw"
PROP_BLOCK_STATE = "hytale_block_state"
PROP_BLOCK_GRID_POS = "hytale_block_grid_pos"

# Custom properties gravadas nos Objects gerados a partir de entities[]. Ver
# DEVELOPER_NOTES.md ("Entities") para o que cada tipo de entity significa.
PROP_ENTITY_ITEM_ID = "hytale_entity_item_id"
PROP_ENTITY_ITEM_ID_RAW = "hytale_entity_item_id_raw"  # Item.Item.Id cru, antes do parse de state
PROP_ENTITY_STATE = "hytale_entity_state"
PROP_ENTITY_UUID = "hytale_entity_uuid"
PROP_ENTITY_SCALE_RAW = "hytale_entity_scale_raw"  # EntityScale.Scale, 1.0 se ausente
PROP_ENTITY_ROTATION_PITCH_RAW = "hytale_entity_rotation_pitch_raw"
PROP_ENTITY_ROTATION_YAW_RAW = "hytale_entity_rotation_yaw_raw"
PROP_ENTITY_ROTATION_ROLL_RAW = "hytale_entity_rotation_roll_raw"
PROP_ENTITY_POSITION_RAW = "hytale_entity_position_raw"
PROP_ENTITY_KIND = "hytale_entity_kind"  # "block" | "item" | "model"
PROP_ENTITY_MODEL_SCALE_RAW = "hytale_entity_model_scale_raw"  # so model entities: Model.Model.Scale

# Nome da Collection criada por import (debug_export.py e a UI acham os
# prefabs da cena por esse prefixo).
PREFAB_COLLECTION_PREFIX = "Hyblend Prefab - "

# Marcador no Empty raiz de cada prefab importado (a UI usa pra achar a raiz
# dentro da Collection sem depender do nome do Object, que o usuario pode
# renomear).
PROP_PREFAB_ROOT = "hyblend_prefab_root"

# Relatorio do import gravado como custom property na PROPRIA Collection do
# prefab (a UI mostra isso na secao "Prefabs in Scene"). Prefabs importados
# por versoes antigas (< dev-0.2.0) nao tem essas chaves -- a UI trata isso.
PROP_PREFAB_FILE = "hyblend_prefab_file"
PROP_PREFAB_BLOCKS_PLACED = "hyblend_blocks_placed"
PROP_PREFAB_BLOCKS_TOTAL = "hyblend_blocks_total"
PROP_PREFAB_ENTITIES_PLACED = "hyblend_entities_placed"
PROP_PREFAB_ENTITIES_TOTAL = "hyblend_entities_total"  # -1 = entities nao foram importadas
PROP_PREFAB_UNIQUE_MESHES = "hyblend_unique_meshes"
PROP_PREFAB_REPORT_JSON = "hyblend_report_json"  # {"missing": [...], "unresolved": [...], "errored": {...}, "textures": [...]}
PROP_PREFAB_ADDON_VERSION = "hyblend_addon_version"
# Optimizer (dev-0.2.0+): modo de saida e o que foi removido/pulado.
PROP_PREFAB_OUTPUT_MODE = "hyblend_output_mode"  # "OBJECTS" | "INSTANCES" | "SINGLE_MESH"
PROP_PREFAB_HIDDEN_BLOCKS = "hyblend_hidden_blocks_removed"
PROP_PREFAB_HIDDEN_FACES = "hyblend_hidden_faces_removed"
PROP_PREFAB_REGION_SKIPPED = "hyblend_region_skipped"


def vec3(d, default=0.0) -> Vector:
    """{'x':,'y':,'z':} (.blockymodel) -> Vector, sem troca de eixo (espaco do arquivo, Y-up)."""
    return Vector((d.get("x", default), d.get("y", default), d.get("z", default)))


def quat_xyzw(d) -> Quaternion:
    """{'x':,'y':,'z':,'w':} (ordem .blockymodel) -> Quaternion (interno w,x,y,z)."""
    return Quaternion((d.get("w", 1.0), d.get("x", 0.0), d.get("y", 0.0), d.get("z", 0.0)))
