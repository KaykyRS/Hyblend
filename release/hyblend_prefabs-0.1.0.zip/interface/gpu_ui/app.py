"""A tela da UI por GPU: moldura do jogo + cabeçalho + página + toast.

`build(f)` roda quando algo muda e devolve uma árvore NOVA de widgets
(estilo React, ver framework/runtime.py). O Prefabs tem UMA página
(pages/prefabs_page.py), na mesma ordem do painel clássico.

THEME, window() e toast() são os mesmos do Hyblend Toolkit (app.py) --
a família Hyblend tem um visual só.
"""

import tomllib
from functools import lru_cache
from pathlib import Path

import bpy

from ...builder.prefab_ops import iter_prefab_collections
from ...common import ADDON_PACKAGE
from . import game
from .bind import UI
from .framework.core import Column, Fade, Icon, Label, ScrollView, Spacer, Style, Theme, pad
from .pages import prefabs_page
from .widgets import DecoratedContainer, Ornament, SkinRow, TitleBand


def _rgb(hex_color, a=1.0):
    value = hex_color.lstrip("#")
    return tuple(int(value[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (a,)


# Paleta da interface do Hytale (cópia do Toolkit: Common.ui do jogo + cores
# medidas nos PNGs). Vale com ou sem a pasta do jogo.
THEME = Theme(
    canvas=_rgb("#151f2c"),                 # miolo do ContainerPatch
    surface=_rgb("#1f2c44"),                # cartão (OptionBackgroundPatch sobre o canvas)
    surface_raised=_rgb("#21344b"),         # Buttons/Secondary
    surface_hover=_rgb("#2b3a55"),
    surface_pressed=_rgb("#253f60"),        # Secondary_Pressed
    input=_rgb("#263047"),                  # InputBox
    border=_rgb("#42526d", 0.9),            # borda do Secondary/InputBox
    text=_rgb("#dfe7ee"),
    text_muted=_rgb("#96a9be"),             # @ColorDefaultLabel
    accent=_rgb("#e6c279"),                 # dourado (seleção, títulos)
    accent_hover=_rgb("#f1ba50"),
    accent_pressed=_rgb("#c09953"),
    accent_soft=_rgb("#e6c279", 0.14),
    accent_text=_rgb("#151f2c"),
    track_off=_rgb("#0d1217"),
    shadow=(0.0, 0.0, 0.02, 0.6),
    dots=_rgb("#7a9cc6", 0.10),
    danger=_rgb("#e0526f"),                 # Buttons/Destructive (clareado p/ texto)
    danger_soft=_rgb("#c83a5f", 0.16),
    warning=_rgb("#f1ba50"),
    warning_soft=_rgb("#f1ba50", 0.12),
    success=_rgb("#57d9af"),
    primary=_rgb("#4470a4"),                # Buttons/Primary
    primary_hover=_rgb("#3858a2"),
    primary_pressed=_rgb("#2f6db0"),
    primary_text=_rgb("#ffffff"),
    heading_weight="Title",                 # Lexend (fonte "Secondary" do jogo)
    heading_upper=True,
    heading_tracking=0.5,
    radius_scale=0.45,                      # cantos mais retos, como a arte do jogo
)


@lru_cache(maxsize=1)
def addon_version():
    """Versão do blender_manifest.toml (a única que conta)."""
    try:
        manifest = Path(__file__).resolve().parents[2] / "blender_manifest.toml"
        with open(manifest, "rb") as fh:
            return str(tomllib.load(fh).get("version", ""))
    except (OSError, ValueError):
        return ""


def signature(context):
    """Resumo BARATO do que a tela mostra; se mudar, o runtime reconstrói.

    Roda a cada redesenho do viewport. Mudança de dado "de verdade"
    (prefab importado/removido, olho da collection...) já chega pelo
    depsgraph_update_post do runtime; aqui fica o que o depsgraph não avisa
    (troca de objeto ativo, Preferences)."""
    obj = context.view_layer.objects.active
    try:
        prefs = context.preferences.addons[ADDON_PACKAGE].preferences
        settings = (prefs.hytale_path_mode, prefs.hytale_path, prefs.developer_mode)
    except Exception:
        settings = None
    return (
        context.scene.as_pointer(),
        obj.name if obj else None,
        context.mode,
        settings,
        len(bpy.data.collections),
    )


def build(f):
    game.sync()                           # pasta do jogo mudou -> arte e fontes (O(1) se igual)
    ui = UI(f)
    th = f.theme
    try:
        content = prefabs_page.build(ui, iter_prefab_collections())
    except Exception as error:            # página quebrada não derruba a UI inteira
        import traceback
        traceback.print_exc()
        content = [Label("Error: %s" % error, color=th.danger, size=11)]
    page = Column([c for c in content if c is not None], style=Style(gap=8))
    body = [
        # A página é a parte que cresce: rola quando não cabe na sidebar.
        ScrollView("page.scroll", page, style=Style(min_height=120.0)),
        toast(f),
    ]
    return window(f, _header(ui), body, key="root", padding=(14, 10, 14, 14))


def window(f, header, content, *, key, padding, gap=8.0, shadow=False, opaque=False):
    """Moldura do jogo (@DecoratedContainer com a arte do jogo); sem a
    pasta, caixa procedural com fundo, borda e sombra do tema."""
    th = f.theme
    frame = game.frame_style("frame")
    base = th.canvas if opaque else None
    if frame:
        body = Column(content, key=key + ".body",
                      style=Style(padding=padding, gap=gap, frame=frame, frame_base=base, shadow=shadow, radius=6))
        return DecoratedContainer(
            Ornament(game.art("ornament")[0], base=base), header, body,
            Ornament(game.art("ornament_bottom")[0], bottom=True, base=base),
            key=key, style=Style(gap=0, clip=not shadow),
        )
    left, top, right, bottom = padding
    body = Column(content, key=key + ".body", style=Style(padding=(left - 2, top, right - 2, bottom - 2), gap=gap))
    return Column(header, body, key=key,
                  style=Style(gap=0, background=th.canvas, border=th.border, radius=12 * th.radius_scale,
                              shadow=True, clip=True))


def _header(ui):
    """Faixa do título: versão à esquerda, título no meio, engrenagem
    (Preferences do addon) à direita."""
    version = addon_version()
    prefs = ui.op("header.prefs", "preferences.addon_show", "", icon="gear", props={"module": ADDON_PACKAGE},
                  tooltip="Addon preferences", style=Style(width=26, height=26))
    return TitleBand("Hyblend Prefabs", [Spacer(), prefs], header=game.frame_style("header"),
                     version=("v%s" % version) if version else "", key="header")


def toast(f):
    data = f.state.get("_toast")
    if not data:
        return None
    text, born, error = data
    age = f.now - born
    if age > 2.6:
        f.state.pop("_toast", None)
        return None
    if age < 0.2 or age > 2.2:
        f.state["_motion_active"] = True    # animando entrada/saída: quadro a quadro
    else:
        f.wake_at(born + 2.2)               # parado no meio: só acordar na hora de sumir
    alpha = max(0.0, min(1.0, age / 0.15, (2.6 - age) / 0.4))
    th = f.theme
    body = SkinRow(
        [Icon("check" if not error else "error", size=14, color=th.danger if error else th.success),
         Label(text, size=11, weight="SemiBold", color=th.danger if error else th.accent,
               style=Style(flex=1))],
        "inset_light",
        style=Style(height=30, padding=pad(x=10, y=0), gap=8, align="center",
                    background=th.surface_raised, border=th.border, radius=8 * th.radius_scale),
    )
    return Fade(body, alpha=alpha, dy=-6.0 * (1.0 - min(1.0, age / 0.2)))
