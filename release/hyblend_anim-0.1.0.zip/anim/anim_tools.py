"""Operadores da aba Animation: switch FK/IK, Snap FK/IK, Head Free/Lock e key dos switches."""

from bpy.props import EnumProperty, IntProperty
from bpy.types import Operator
from mathutils import Matrix, Vector

from .anim_importer import IK_FIT_PASSES, ik_pieces, matrix_change, _rest_local_matrix, fit_fk_ctrl, fit_ik_piece, transfer_offset
from .stretch_fit import export_delta, lengths

from ..common import UNIT_SCALE_DEFAULT, armature_model_format, effective_unit_scale, is_active_armature
from ..translations import localized_props, register_localized_class, tooltip, tr, unregister_localized_class
from ..rigger import (
    BONE_PROPERTIES,
    CONSTRAINT_CHILD_OF_GLOBAL,
    CONSTRAINT_CHILD_OF_LOCAL,
    PROP_HEAD_FOLLOW_SWITCH,
    SUFFIX_CTRL,
    SUFFIX_IK,
    SUFFIX_MCH,
    SUFFIX_MCH_IK_TRANSFER,
    SUFFIX_MCH_TRANSFER,
    SUFFIX_POLE,
    SUFFIX_TWEAK,
    control_name,
    find_org_path,
    ik_solver_target_index,
    pole_position_for_root,
    switch_property_name,
    tweak_basis,
)


def _redraw_all_areas(context):
    """Redesenha todas as áreas (mudar a custom property não redesenha a viewport sozinho)."""
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()


# --- FK/IK Switch + Snap, por cadeia (armature.hytale_ik_chains) ---


def get_fk_ik_state(obj, item):
    """Switch FK/IK da cadeia: 0 (FK), 1 (IK) ou None se não existe (pra destacar o botão)."""
    if item.chain_type == "CHAIN":
        return None
    pose = obj.pose
    if pose is None:
        return None
    props_bone = pose.bones.get(BONE_PROPERTIES)
    if props_bone is None:
        return None
    prop_name = switch_property_name(item.tip_bone, item.side)
    value = props_bone.get(prop_name)
    if value is None:
        return None
    return 1 if value else 0


def get_head_follow_state(obj):
    """Head Free/Lock: 1 (Lock), 0 (Free) ou None se não existe."""
    pose = obj.pose
    if pose is None:
        return None
    props_bone = pose.bones.get(BONE_PROPERTIES)
    if props_bone is None:
        return None
    value = props_bone.get(PROP_HEAD_FOLLOW_SWITCH)
    if value is None:
        return None
    return 1 if value else 0


def _snap_matrix_through_constraints(context, pose_bone, target_matrix, constraint_names):
    """Põe o bone em `target_matrix` compensando a 1ª Child Of ativa da lista (o valor já sai descontado)."""
    active_con = None
    for name in constraint_names:
        con = pose_bone.constraints.get(name)
        if con is not None and con.type == "CHILD_OF" and not con.mute and con.influence > 0.0 and con.subtarget:
            active_con = con
            break  # as duas (Local/Global) nunca deveriam estar ativas ao mesmo tempo

    if active_con is None:
        pose_bone.matrix = target_matrix
        return

    target_pb = pose_bone.id_data.pose.bones.get(active_con.subtarget)
    if target_pb is None:
        pose_bone.matrix = target_matrix
        return

    pose_bone.matrix = (target_pb.matrix @ active_con.inverse_matrix).inverted() @ target_matrix
    context.view_layer.update()


def _stretch_snapshot(pose_bones, path):
    """Se a cadeia (ou o pai dela) tem escala: (alvo do export por peça, mundo do ORG pai ou None); senão None."""
    parent = pose_bones[path[0].name].parent
    checked = [pose_bones[bone.name] for bone in path] + ([parent] if parent is not None else [])
    if all(abs(length - 1.0) < 1e-5 for pb in checked for length in lengths(pb.matrix)):
        return None
    goals = {}
    for bone in path:
        pb = pose_bones[bone.name]
        rest_local = _rest_local_matrix(pb)
        goals[bone.name] = export_delta(pb.parent.matrix if pb.parent else None, rest_local, pb.matrix)
    return goals, (parent.matrix.copy() if parent is not None else None)


def _fit_stretched_ik(context, obj, path, target_index, stretch, unit_scale):
    """Snap FK->IK com escala: Tweaks, jarretes e ponta pelo ajuste, até a ponta parar."""
    goals, root_parent = stretch
    pieces = ik_pieces(obj, {"org_names": [bone.name for bone in path], "target_index": target_index})
    for _pass in range(IK_FIT_PASSES):
        context.view_layer.update()
        parent, moved = root_parent if root_parent is not None else Matrix.Identity(4), False
        for org_name, holder, bridge, is_tweak in pieces:
            rest_local = _rest_local_matrix(obj.pose.bones[org_name])
            basis, parent = fit_ik_piece(
                holder, bridge, rest_local, parent, goals[org_name], unit_scale, [holder.matrix_basis.copy()],
            )
            if not is_tweak and matrix_change(holder.matrix_basis, basis) > 1e-5:
                moved = True
            holder.matrix_basis = basis
        if not moved:
            break
    context.view_layer.update()


def _fit_stretched_fk(context, obj, path, stretch):
    """Snap IK->FK com escala: cada `_CTRL` pelo ajuste, de cima pra baixo."""
    goals, org_parent = stretch
    pose_bones = obj.pose.bones
    unit_scale = effective_unit_scale(UNIT_SCALE_DEFAULT, armature_model_format(obj))
    fitted = {}  # `_CTRL` -> pose ajustada, pros de baixo
    for org_bone in path:
        ctrl_pb = pose_bones.get(control_name(obj.data, org_bone.name, SUFFIX_CTRL))
        transfer_pb = pose_bones.get(org_bone.name + SUFFIX_MCH_TRANSFER)
        if ctrl_pb is None or transfer_pb is None:
            continue
        parent = ctrl_pb.parent
        ctrl_parent = fitted.get(parent.name) if parent is not None else None
        if ctrl_parent is None:
            ctrl_parent = parent.matrix.copy() if parent is not None else Matrix.Identity(4)
        rest_local = _rest_local_matrix(pose_bones[org_bone.name])
        basis, fitted[ctrl_pb.name], org_parent = fit_fk_ctrl(
            ctrl_parent, _rest_local_matrix(ctrl_pb), transfer_offset(ctrl_pb, transfer_pb), rest_local, org_parent,
            org_bone.use_connect, goals[org_bone.name], unit_scale, [ctrl_pb.matrix_basis.copy()],
        )
        ctrl_pb.matrix_basis = basis
    context.view_layer.update()


def snap_chain_pose(context, obj, item, target_mode):
    """Iguala os controles de `target_mode` à pose visível (os `_MCH`), sem mexer no switch; (True, None) ou (False, motivo)."""
    pose_bones = obj.pose.bones
    bones = obj.data.bones
    context.view_layer.update()  # a pose lida abaixo tem que estar em dia (o Tweak mexe no FK)

    root_bone = bones.get(item.root_bone)
    if root_bone is None:
        return False, f"root bone '{item.root_bone}' not found"
    path = find_org_path(root_bone, item.tip_bone)
    if not path:
        return False, f"no bone path from '{item.root_bone}' to '{item.tip_bone}'"

    if target_mode == "FK":
        stretch = _stretch_snapshot(pose_bones, path)
        if stretch is not None:
            _fit_stretched_fk(context, obj, path, stretch)
            return True, None
        for org_bone in path:
            mch_pb = pose_bones.get(org_bone.name + SUFFIX_MCH)
            ctrl_pb = pose_bones.get(control_name(obj.data, org_bone.name, SUFFIX_CTRL))
            if mch_pb is None or ctrl_pb is None:
                continue  # bone sem MCH/CTRL (ex. attachment) -- pula, não é erro
            transfer_pb = pose_bones.get(org_bone.name + SUFFIX_MCH_TRANSFER)
            if transfer_pb is not None:
                # transfer = ctrl @ offset (rest + Tweak do FK); queremos transfer == mch.
                ctrl_pb.matrix = mch_pb.matrix @ transfer_offset(ctrl_pb, transfer_pb).inverted()
            else:
                ctrl_pb.matrix = mch_pb.matrix.copy()
            context.view_layer.update()
        return True, None

    if target_mode == "IK":
        if len(path) < 2:
            return False, f"'{item.root_bone}' -> '{item.tip_bone}' has no bone to bend"
        tip_org = path[-1]
        tip_mch_pb = pose_bones.get(tip_org.name + SUFFIX_MCH)
        ik_tip_name = control_name(obj.data, tip_org.name, SUFFIX_IK)
        ik_tip_pb = pose_bones.get(ik_tip_name)
        ik_tip_bone = bones.get(ik_tip_name)
        bridge_bone = bones.get(tip_org.name + SUFFIX_MCH_IK_TRANSFER)
        if tip_mch_pb is None or ik_tip_pb is None or ik_tip_bone is None or bridge_bone is None:
            return False, f"'{tip_org.name}{SUFFIX_MCH}'/'{ik_tip_name}' bones not found"

        # Raiz: o solver decide a rotação, a posição vem da pose (o `_CTRL`
        # da raiz pode ter location no FK).
        root_mch_pb = pose_bones.get(path[0].name + SUFFIX_MCH)
        root_ik_pb = pose_bones.get(control_name(obj.data, path[0].name, SUFFIX_IK))
        target_index = ik_solver_target_index(len(path))
        stretch = _stretch_snapshot(pose_bones, path)  # lido antes de mexer em qualquer coisa
        tweaks = []  # (tweak, pose atual da peça, bridge): lida antes, o Tweak também mexe no FK
        for org_bone in path[:target_index]:
            tweak_pb = pose_bones.get(control_name(obj.data, org_bone.name, SUFFIX_TWEAK))
            mch_pb = pose_bones.get(org_bone.name + SUFFIX_MCH)
            bridge = bones.get(org_bone.name + SUFFIX_MCH_IK_TRANSFER)
            if tweak_pb is not None and mch_pb is not None and bridge is not None and bridge.parent == tweak_pb.bone:
                tweaks.append((tweak_pb, mch_pb.matrix.copy(), bridge))
        root_target = None  # orientação que o `_IK` raiz precisa ter (a do FK)
        if root_mch_pb is not None and root_ik_pb is not None:
            root_target = root_mch_pb.matrix @ path[0].matrix_local.inverted() @ root_ik_pb.bone.matrix_local
            root_ik_pb.matrix = root_target
            context.view_layer.update()

        # A ponta `_IK` tem rest própria: o bridge (rest do ORG) é que tem que cair no `_MCH`.
        offset = ik_tip_bone.matrix_local.inverted() @ bridge_bone.matrix_local
        _snap_matrix_through_constraints(
            context, ik_tip_pb, tip_mch_pb.matrix @ offset.inverted(), [CONSTRAINT_CHILD_OF_GLOBAL]
        )

        # Necessário antes de mexer no pole: ele tem Child Of mirando
        # neste mesmo ik_tip, senão resolveria com o valor pré-snap.
        context.view_layer.update()

        # Jarretes, de baixo pra cima (cada um é filho do de baixo). O
        # bridge é filho real com a rest do ORG: bridge = jarrete @ offset.
        for org_bone in reversed(path[target_index:-1]):
            hock_pb = pose_bones.get(control_name(obj.data, org_bone.name, SUFFIX_IK))
            hock_mch_pb = pose_bones.get(org_bone.name + SUFFIX_MCH)
            if hock_pb is None or hock_mch_pb is None:
                continue
            hock_pb.matrix = hock_mch_pb.matrix @ org_bone.matrix_local.inverted() @ hock_pb.bone.matrix_local
            context.view_layer.update()
        target_mch_pb = pose_bones.get(path[target_index].name + SUFFIX_MCH) or tip_mch_pb

        pole_ref_name = item.pole_bone or path[len(path) // 2].name
        pole_ref_mch_pb = pose_bones.get(pole_ref_name + SUFFIX_MCH)
        pole_pb = pose_bones.get(control_name(obj.data, path[0].name, SUFFIX_POLE))
        solver_end_pb = pose_bones.get(control_name(obj.data, path[target_index - 1].name, SUFFIX_IK))
        ik_con = next((c for c in solver_end_pb.constraints if c.type == "IK"), None) if solver_end_pb else None
        if pole_ref_mch_pb is not None and pole_pb is not None:
            # Pole que reproduz a orientação da raiz do FK; sem a raiz ou a
            # constraint IK, o método antigo (eixo Z do bone do meio).
            target_head = None
            if root_target is not None and ik_con is not None:
                target_head = pole_position_for_root(
                    root_target, target_mch_pb.matrix.translation, ik_con.pole_angle, item.pole_distance
                )
            if target_head is None:
                ref_matrix = pole_ref_mch_pb.matrix
                z_axis = ref_matrix.to_3x3() @ Vector((0.0, 0.0, 1.0))
                z_axis = z_axis.normalized() if z_axis.length > 1e-9 else Vector((0.0, 0.0, 1.0))
                sign = 1.0 if item.pole_invert else -1.0
                target_head = ref_matrix.translation + z_axis * (item.pole_distance * sign)

            new_matrix = pole_pb.matrix.copy()
            new_matrix.translation = target_head
            _snap_matrix_through_constraints(
                context, pole_pb, new_matrix, [CONSTRAINT_CHILD_OF_LOCAL, CONSTRAINT_CHILD_OF_GLOBAL]
            )
        # Sem pole_ref/pole bone -- não é fatal (o alvo IK já foi
        # posicionado); só o ângulo do cotovelo/joelho pode não bater perfeitamente.

        context.view_layer.update()
        unit_scale = effective_unit_scale(UNIT_SCALE_DEFAULT, armature_model_format(obj))
        for tweak_pb, _pose, _bridge in tweaks:
            tweak_pb.matrix_basis = Matrix()
        if stretch is not None:
            _fit_stretched_ik(context, obj, path, target_index, stretch, unit_scale)
            return True, None
        for tweak_pb, pose, bridge in tweaks:
            basis, negligible = tweak_basis(tweak_pb, bridge, pose, unit_scale)
            if not negligible:
                tweak_pb.matrix_basis = basis
        context.view_layer.update()
        return True, None

    return False, f"unknown target_mode '{target_mode}'"


def _resolve_switch_prop(obj, item):
    """(props_bone, prop_name, None) do switch FK/IK da cadeia, ou (None, None, motivo)."""
    props_bone = obj.pose.bones.get(BONE_PROPERTIES)
    if props_bone is None:
        return None, None, "rig not generated yet -- there's no FK/IK switch to set"
    prop_name = switch_property_name(item.tip_bone, item.side)
    if prop_name not in props_bone.keys():
        return None, None, (
            f"'{prop_name}' not found on the {BONE_PROPERTIES} bone -- generate/regenerate the rig first "
            "(this chain may have been added to the list after the last 'Create Rig')"
        )
    return props_bone, prop_name, None


def _write_fk_ik_switch(context, obj, props_bone, prop_name, mode):
    """Escreve 0/1 na custom property já resolvida e força o
    recálculo/redraw."""
    props_bone[prop_name] = 1 if mode == "IK" else 0
    obj.update_tag()
    context.view_layer.update()
    _redraw_all_areas(context)


def _set_fk_ik_props(lang):
    return {
        "chain_index": IntProperty(description=tr("anim_tools.prop.set_fk_ik_chain_index", lang)),
        "mode": EnumProperty(items=[("FK", "FK", ""), ("IK", "IK", "")]),
    }


@localized_props(_set_fk_ik_props)
class ANIM_OT_hytale_set_fk_ik(Operator):
    """Troca a cadeia (por índice) pra FK ou IK, só a influência; igualar a pose é o Snap."""

    bl_idname = "pose.hytale_set_fk_ik"
    bl_label = "Set FK/IK"
    description = tooltip("anim_tools.tooltip.set_fk_ik")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return is_active_armature(context) and obj.pose is not None

    def execute(self, context):
        obj = context.active_object
        armature = obj.data
        chains = armature.hytale_ik_chains
        if not (0 <= self.chain_index < len(chains)):
            self.report({"WARNING"}, "Invalid chain index.")
            return {"CANCELLED"}

        item = chains[self.chain_index]
        if item.chain_type == "CHAIN":
            self.report({"WARNING"}, "Chain entries don't have an FK/IK switch.")
            return {"CANCELLED"}

        props_bone, prop_name, reason = _resolve_switch_prop(obj, item)
        if props_bone is None:
            self.report({"WARNING"}, reason)
            return {"CANCELLED"}

        _write_fk_ik_switch(context, obj, props_bone, prop_name, self.mode)
        return {"FINISHED"}


class ANIM_OT_hytale_set_head_follow(Operator):
    """Troca o switch único "Head Free/Lock" -- só a custom property,
    mesmo espírito cru de ANIM_OT_hytale_set_fk_ik."""

    bl_idname = "pose.hytale_set_head_follow"
    bl_label = "Set Head Free/Lock"
    description = tooltip("anim_tools.tooltip.set_head_follow")
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(items=[("FREE", "Free", ""), ("LOCK", "Lock", "")])

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return is_active_armature(context) and obj.pose is not None

    def execute(self, context):
        obj = context.active_object
        props_bone = obj.pose.bones.get(BONE_PROPERTIES)
        if props_bone is None or PROP_HEAD_FOLLOW_SWITCH not in props_bone.keys():
            self.report(
                {"WARNING"},
                f"'{PROP_HEAD_FOLLOW_SWITCH}' not found on the {BONE_PROPERTIES} bone -- enable 'Head "
                "Free/Lock' on the HEAD entry (Bone Settings) and run 'Create Rig' first.",
            )
            return {"CANCELLED"}

        props_bone[PROP_HEAD_FOLLOW_SWITCH] = 1 if self.mode == "LOCK" else 0
        obj.update_tag()
        context.view_layer.update()
        _redraw_all_areas(context)
        return {"FINISHED"}


def _keyframe_switch_props(lang):
    return {
        "switch": EnumProperty(items=[("FK_IK", "FK/IK", ""), ("HEAD_FOLLOW", "Head Follow", "")]),
        "chain_index": IntProperty(
            default=-1, description=tr("anim_tools.prop.keyframe_switch_chain_index", lang)
        ),
    }


@localized_props(_keyframe_switch_props)
class ANIM_OT_hytale_keyframe_switch(Operator):
    """Key no frame atual do valor cru (0/1) de um switch FK/IK ou do Head Free/Lock."""

    bl_idname = "pose.hytale_keyframe_switch"
    bl_label = "Insert Switch Keyframe"
    description = tooltip("anim_tools.tooltip.keyframe_switch")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return is_active_armature(context) and obj.pose is not None

    def execute(self, context):
        obj = context.active_object

        if self.switch == "FK_IK":
            chains = obj.data.hytale_ik_chains
            if not (0 <= self.chain_index < len(chains)):
                self.report({"WARNING"}, "Invalid chain index.")
                return {"CANCELLED"}
            props_bone, prop_name, reason = _resolve_switch_prop(obj, chains[self.chain_index])
            if props_bone is None:
                self.report({"WARNING"}, reason)
                return {"CANCELLED"}
        else:
            props_bone = obj.pose.bones.get(BONE_PROPERTIES)
            prop_name = PROP_HEAD_FOLLOW_SWITCH
            if props_bone is None or prop_name not in props_bone.keys():
                self.report(
                    {"WARNING"},
                    f"'{prop_name}' not found on the {BONE_PROPERTIES} bone -- enable 'Head Free/Lock' "
                    "on the HEAD entry (Bone Settings) and run 'Create Rig' first.",
                )
                return {"CANCELLED"}

        # Sintaxe padrão do Blender pra apontar uma custom (ID)
        # property (mesma de "Copy Data Path" no painel Item).
        try:
            props_bone.keyframe_insert(data_path=f'["{prop_name}"]', frame=context.scene.frame_current)
        except TypeError as exc:
            self.report({"ERROR"}, f"Couldn't insert keyframe for '{prop_name}': {exc}")
            return {"CANCELLED"}

        _redraw_all_areas(context)
        self.report({"INFO"}, f"Keyframed '{prop_name}' at frame {context.scene.frame_current}.")
        return {"FINISHED"}


def identify_chain_from_bone(obj, bone_name):
    """(index, item, lado) da cadeia ARM/LEG do bone; lado None no Tweak (vale nos dois); (None, None, None) fora de cadeia."""
    armature = obj.data
    bones = armature.bones
    for index, item in enumerate(armature.hytale_ik_chains):
        if item.chain_type == "CHAIN" or not item.root_bone or not item.tip_bone:
            continue
        root_bone = bones.get(item.root_bone)
        if root_bone is None:
            continue
        path = find_org_path(root_bone, item.tip_bone)
        if not path:
            continue

        if bone_name == control_name(armature, path[0].name, SUFFIX_POLE):
            return index, item, "IK"
        for org_bone in path:
            if bone_name == control_name(armature, org_bone.name, SUFFIX_CTRL):
                return index, item, "FK"
            if bone_name == control_name(armature, org_bone.name, SUFFIX_IK):
                return index, item, "IK"
            if bone_name == control_name(armature, org_bone.name, SUFFIX_TWEAK):
                return index, item, None  # Tweak vale nos dois lados: quem decide é o switch
    return None, None, None


class ANIM_OT_hytale_snap_selected(Operator):
    """Snap + Switch pelo bone selecionado: iguala o lado oposto e troca o switch pra ele."""

    bl_idname = "pose.hytale_snap_fk_ik_selected"
    bl_label = "Snap FK/IK"
    description = tooltip("anim_tools.tooltip.snap_selected")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            obj is not None
            and obj.type == "ARMATURE"
            and obj.pose is not None
            and context.active_pose_bone is not None
        )

    def execute(self, context):
        obj = context.active_object
        active_bone = context.active_pose_bone
        index, item, side = identify_chain_from_bone(obj, active_bone.name)
        if item is None:
            self.report(
                {"WARNING"},
                f"'{active_bone.name}' doesn't belong to any Arm/Leg chain -- select a chain's FK "
                "control, IK target, or Pole Target first.",
            )
            return {"CANCELLED"}

        props_bone, prop_name, reason = _resolve_switch_prop(obj, item)
        if props_bone is None:
            self.report({"WARNING"}, reason)
            return {"CANCELLED"}

        if side is None:
            side = "IK" if props_bone[prop_name] >= 0.5 else "FK"
        target_mode = "FK" if side == "IK" else "IK"
        ok, reason = snap_chain_pose(context, obj, item, target_mode)
        if not ok:
            self.report({"WARNING"}, f"Snap failed ({reason}) -- switching without matching the pose.")

        _write_fk_ik_switch(context, obj, props_bone, prop_name, target_mode)
        self.report({"INFO"}, f"Snapped and switched '{item.label or item.root_bone}' to {target_mode}.")
        return {"FINISHED"}


_CLASSES = (
    ANIM_OT_hytale_set_fk_ik,
    ANIM_OT_hytale_set_head_follow,
    ANIM_OT_hytale_snap_selected,
    ANIM_OT_hytale_keyframe_switch,
)


def register():
    for cls in _CLASSES:
        register_localized_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        unregister_localized_class(cls)
