"""Import com stretch: acha o controle que faz o export devolver o arquivo (o Blender passa a escala do pai pro filho, o jogo não)."""

import itertools
import math
import random

from mathutils import Euler, Matrix, Quaternion, Vector

from ..rigger.helpers import stable_rotation

# Erro aceito (px / graus / escala), bem abaixo da tolerância do export.
_TOL_PX = 0.002
_TOL_DEG = 0.002
_TOL_SCALE = 0.00002
_MAX_ITERATIONS = 20
_RESTARTS = 200


def lengths(matrix):
    """Comprimento de cada eixo (o que Copy Scale copia)."""
    m = matrix.to_3x3()
    return Vector([m.col[i].length for i in range(3)])


def clean(matrix, extra_scale=None):
    """O que Copy Location/Rotation/Scale deixam no dono (× `extra_scale` = use_offset do IK_CopyScale)."""
    size = lengths(matrix)
    if extra_scale is not None:
        size = Vector([size[i] * extra_scale[i] for i in range(3)])
    return (
        Matrix.Translation(matrix.translation)
        @ stable_rotation(matrix).to_4x4()
        @ Matrix.Diagonal((*size, 1.0))
    )


def decompose(matrix):
    """(posição, quaternion, escala) com a rotação estável -- a do decompose() pula com cisalhamento."""
    return matrix.to_translation(), stable_rotation(matrix).to_quaternion(), lengths(matrix)


def shape_shift(scale, offset):
    """Quanto o centro da caixa anda com essa escala (o Blender estica pela cabeça do bone, o jogo pelo centro)."""
    if offset is None:
        return Vector((0.0, 0.0, 0.0))
    return Vector([(scale[i] - 1.0) * offset[i] for i in range(3)])


def file_position(rest_local, pos):
    """Posição do delta como o arquivo grava (espaço do pai: o jogo soma na do bind), a partir da do bone."""
    return rest_local.to_quaternion() @ pos


def bone_position(rest_local, pos):
    """Inverso de file_position."""
    return rest_local.to_quaternion().inverted() @ pos


def export_delta(parent_world, rest_local, world, offset=None, parent_offset=None):
    """(posição, quaternion, escala) que o export grava (exporter.compute_deltas), em unidades do Blender e com a
    posição no espaço do bone. `offset`/`parent_offset`: centro da caixa do bone/pai (o jogo estica por ele)."""
    parent_scale = Vector((1.0, 1.0, 1.0))
    if parent_world is not None:
        loc, rot, parent_scale = decompose(parent_world)
        world = (Matrix.Translation(loc) @ rot.to_matrix().to_4x4()).inverted() @ world
    pos, quat, scale = decompose(rest_local.inverted() @ world)
    pos = pos + quat @ shape_shift(scale, offset) - bone_position(rest_local, shape_shift(parent_scale, parent_offset))
    return pos, quat, scale


def inverse_start(before, target_world, after=None):
    """Partida pela conta direta (before @ basis @ after == target_world), sem o cisalhamento."""
    basis = before.inverted() @ target_world
    if after is not None:
        basis = basis @ after.inverted()
    loc, quat, scale = basis.decompose()
    return Matrix.Translation(loc) @ quat.to_matrix().to_4x4() @ Matrix.Diagonal((*scale, 1.0))


def target_from_delta(parent_world, rest_local, pos, quat, scale, offset=None, parent_offset=None):
    """Inverso de export_delta: o mundo do bone com esse delta."""
    unscaled = Matrix()
    parent_scale = Vector((1.0, 1.0, 1.0))
    if parent_world is not None:
        loc, rot, parent_scale = decompose(parent_world)
        unscaled = Matrix.Translation(loc) @ rot.to_matrix().to_4x4()
    pos = pos - quat @ shape_shift(scale, offset) + bone_position(rest_local, shape_shift(parent_scale, parent_offset))
    return unscaled @ rest_local @ Matrix.Translation(pos) @ quat.to_matrix().to_4x4() @ Matrix.Diagonal((*scale, 1.0))


def _residual(result, target, unit_scale):
    """Erro em px, graus e log da escala (×100) -- pesos parecidos."""
    pos, quat, scale = result
    tpos, tquat, tscale = target
    diff = tquat.rotation_difference(quat)
    if diff.w < 0.0:
        diff.negate()
    # Pela parte vetorial: acos(w) perde ângulo pequeno em float32.
    vec = Vector((diff.x, diff.y, diff.z))
    rot = vec * (math.degrees(2.0 * math.atan2(vec.length, diff.w)) / vec.length) if vec.length > 1e-12 else Vector()
    out = [(pos[i] - tpos[i]) / unit_scale for i in range(3)]
    out += [rot[i] for i in range(3)]
    out += [math.log(max(scale[i], 1e-9) / max(tscale[i], 1e-9)) * 100.0 for i in range(3)]
    return out


def _within_tolerance(res):
    """Erro abaixo de _TOL_* nos 9 componentes."""
    return (
        max(abs(v) for v in res[0:3]) < _TOL_PX
        and max(abs(v) for v in res[3:6]) < _TOL_DEG
        and max(abs(v) for v in res[6:9]) < _TOL_SCALE * 100.0
    )


def _basis(x, start):
    """basis = partida + x (deslocamento, rotação em vetor, log da escala)."""
    loc, quat, scale = start
    w = Vector(x[3:6])
    turn = Quaternion(w.normalized(), w.length) if w.length > 1e-12 else Quaternion()
    size = [scale[i] * math.exp(x[6 + i]) for i in range(3)]
    return (
        Matrix.Translation(loc + Vector(x[0:3]))
        @ (quat @ turn).to_matrix().to_4x4()
        @ Matrix.Diagonal((*size, 1.0))
    )


def _solve_linear(a, b):
    """a x = b (Gauss com pivô parcial); None se singular."""
    n = len(b)
    m = [row[:] + [b[i]] for i, row in enumerate(a)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(m[r][col]))
        if abs(m[pivot][col]) < 1e-12:
            return None
        m[col], m[pivot] = m[pivot], m[col]
        for r in range(col + 1, n):
            f = m[r][col] / m[col][col]
            for c in range(col, n + 1):
                m[r][c] -= f * m[col][c]
    x = [0.0] * n
    for r in reversed(range(n)):
        x[r] = (m[r][n] - sum(m[r][c] * x[c] for c in range(r + 1, n))) / m[r][r]
    return x


def solve_basis(forward, target, starts, unit_scale):
    """(basis, chegou?) com forward(basis) == target; tenta as `starts` em ordem e devolve a melhor."""
    starts = [start for start in starts if start is not None]
    best = None
    for start_basis in itertools.chain(starts, _restarts(starts[0])):
        basis, ok, cost = _solve_from(forward, target, start_basis, unit_scale)
        if ok:
            return basis, True
        if best is None or cost < best[1]:
            best = (basis, cost)
    return best[0], False


def _restarts(around):
    """Partidas extras, sempre as mesmas, pra quando as dadas param num mínimo local."""
    generator = random.Random(0)
    loc = around.to_translation()
    for _ in range(_RESTARTS):
        turn = Euler([generator.uniform(-math.pi, math.pi) for _ in range(3)]).to_matrix().to_4x4()
        size = [generator.uniform(0.6, 1.6) for _ in range(3)]
        yield Matrix.Translation(loc) @ turn @ Matrix.Diagonal((*size, 1.0))


def _solve_from(forward, target, start_basis, unit_scale):
    """Levenberg-Marquardt a partir de uma partida: (basis, chegou?, custo)."""
    start = start_basis.decompose()
    x = [0.0] * 9

    def evaluate(params):
        res = _residual(forward(_basis(params, start)), target, unit_scale)
        return res, sum(v * v for v in res)

    res, cost = evaluate(x)
    damping = 1e-3
    eps = 1e-4
    for _ in range(_MAX_ITERATIONS):
        if _within_tolerance(res):
            break
        columns = []  # columns[k][i] = d res[i] / d x[k]
        for k in range(9):
            xs = x[:]
            xs[k] += eps
            r2, _cost = evaluate(xs)
            columns.append([(r2[i] - res[i]) / eps for i in range(9)])
        jtj = [[sum(columns[a][r] * columns[b][r] for r in range(9)) for b in range(9)] for a in range(9)]
        jtr = [-sum(columns[a][r] * res[r] for r in range(9)) for a in range(9)]
        improved = False
        for _attempt in range(8):
            system = [row[:] for row in jtj]
            for a in range(9):
                system[a][a] += damping * (jtj[a][a] + 1e-9)
            step = _solve_linear(system, jtr)
            if step is None:
                damping *= 10.0
                continue
            trial = [x[k] + step[k] for k in range(9)]
            r2, c2 = evaluate(trial)
            if c2 < cost:
                x, res, cost = trial, r2, c2
                damping = max(damping * 0.3, 1e-7)
                improved = True
                break
            damping *= 10.0
        if not improved:
            break
    return _basis(x, start), _within_tolerance(res), cost
