"""Tela do Anim na UI por GPU do núcleo: abas, grade e assinatura (api.App). No Blender < 5.0 (sem UI por GPU)
vai sem abas e as páginas nem são importadas (dependem das peças por GPU do núcleo)."""

from ...toolkit import api


def _version():
    """Versão do blender_manifest.toml do Anim (a única que conta)."""
    import os
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                        "blender_manifest.toml")
    try:
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                key, _, value = line.partition("=")
                if key.strip() == "version":
                    return value.strip().strip('"')
    except OSError:
        pass
    return ""


def signature(context):
    """O que o depsgraph não avisa e só o Anim lê (aba e sub-aba do Rig)."""
    wm = context.window_manager
    return (getattr(wm, "hytale_active_tab", None), getattr(wm, "hytale_rig_subtab", None))


def app():
    tabs = ()
    if api.gpu_supported():
        from . import _kit, animation_page, export_page, import_page, rig_page
        # (id do enum hytale_active_tab, rótulo, ícone, key do tooltip, página)
        tabs = (
            ("IMPORT", "Import", "import", "panel.tab_import_tooltip", import_page.build),
            ("EXPORT", "Export", "export", "panel.tab_export_tooltip", export_page.build),
            ("RIG", "Rig", "rig", "panel.tab_rig_tooltip", rig_page.build),
            ("ANIMATION", "Animation", "anim", "panel.tab_animation_tooltip", animation_page.build),
            ("INFO", "Info", "info", "panel.tab_info_tooltip", _kit.info_build),
        )
    return api.App(
        title="Hyblend Anim", version=_version(), hub_label="Anim", tab_prop="hytale_active_tab", tabs=tabs,
        # Mesma grade do painel clássico: duplas + Info fino ocupando a linha toda.
        tab_rows=((("IMPORT", "EXPORT"), 32.0), (("RIG", "ANIMATION"), 32.0), (("INFO",), 22.0)),
        signature=signature,
    )
