"""Preferences do núcleo, valem pra todos os addons Hyblend (idioma, Home, boas-vindas, UI por GPU, pasta do Hytale);
bl_idname = pacote raiz."""


import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import AddonPreferences

from . import hyblend_hub
from .common import (
    ADDON_PACKAGE,
    HUB_ID,
)
from .translations import (
    get_language,
    get_language_items,
    localized_props,
    refresh_localized_properties,
    register_localized_class,
    tooltip,
    tr,
    unregister_localized_class,
)


class HYTALE_OT_open_addon_preferences(bpy.types.Operator):
    """Engrenagem do N-Panel: abre as Preferences na página deste addon (addon_show)."""

    bl_idname = "hytale.open_addon_preferences"
    bl_label = "Hyblend Toolkit Preferences"
    description = tooltip("importer.tooltip.open_addon_preferences")
    bl_options = {"REGISTER"}

    def execute(self, context):
        try:
            bpy.ops.preferences.addon_show(module=ADDON_PACKAGE)
        except Exception:
            # Sem o addon na lista ou sem janela: abre o que der e só avisa.
            try:
                bpy.ops.screen.userpref_show("INVOKE_DEFAULT")
                context.preferences.active_section = "ADDONS"
            except Exception as exc:
                self.report({"WARNING"}, "Could not open Preferences: %s" % exc)
                return {"CANCELLED"}
        return {"FINISHED"}


def _on_language_update(self, context):
    """Troca de idioma: re-registra as classes @localized_props no próximo tick (dentro do update seria reentrante)."""

    def _do_refresh():
        refresh_localized_properties(bpy.context)
        return None  # não repete (timer de disparo único)

    bpy.app.timers.register(_do_refresh, first_interval=0.0)


def _on_hytale_path_changed(self, context):
    """Pasta do Hytale mudou: avisa a UI por GPU (a pasta é uma só pra todos os addons Hyblend, via hub)."""
    from .interface import gpu_ui
    gpu_ui.on_hytale_path_changed(context)
    hyblend_hub.share_hytale(HUB_ID, self.hytale_path_mode, self.hytale_path)


def _welcome_startup_get(self):
    """Enum sem armazenamento próprio: o estado mora no welcome.json
    (interface/welcome.py) -- o mesmo do "Não mostrar novamente"."""
    from .interface import welcome
    return welcome.STARTUP_MODES.index(welcome.startup_mode())


def _welcome_startup_set(self, value):
    from .interface import welcome
    welcome.set_startup_mode(welcome.STARTUP_MODES[value])


def _on_welcome_size_changed(self, context):
    from .interface import welcome
    welcome.on_size_changed(context)


def _home_startup_get(self):
    """Sem armazenamento próprio: mora no welcome.json (interface/home)."""
    from .interface import home
    return home.show_on_startup()


def _home_startup_set(self, value):
    from .interface import home
    home.set_show_on_startup(value)


def _on_home_look_changed(self, context):
    from .interface import home
    home.on_look_changed(context)


def _on_home_thumbs_changed(self, context):
    from .interface import home
    home.on_thumbs_changed(self, context)


def _importer_preferences_props(lang):
    return {
        # items é callback (idioma novo em translations/ aparece sozinho), por isso sem default=; inválido cai pro inglês.
        "language": EnumProperty(
            name="Language / Idioma",
            description=tr("importer.prefs_language_tooltip", lang),
            items=get_language_items,
            update=_on_language_update,
        ),
        # UI por GPU (Blender 5.0+, ligada por padrão): a escolha é uma só pra todos os addons Hyblend (get/set no hub).
        "use_gpu_ui": BoolProperty(
            name="Experimental GPU Interface",
            description=tr("importer.prefs_gpu_ui_tooltip", lang),
            get=hyblend_hub.prop_get_gpu,
            set=hyblend_hub.prop_set_gpu, default=True,
        ),
        # Tamanho do painel: compartilhado pelos addons Hyblend (get/set no hub).
        "gpu_ui_scale": FloatProperty(
            name="Panel Size",
            description=tr("importer.prefs_gpu_ui_scale_tooltip", lang),
            min=0.75, max=1.5, subtype="FACTOR",
            get=hyblend_hub.prop_get("panel_size"), set=hyblend_hub.prop_set("panel_size"),
            default=hyblend_hub.SETTINGS["panel_size"],
        ),
        "gpu_ui_panel_width": FloatProperty(
            name="Panel Width",
            description=tr("importer.prefs_gpu_ui_width_tooltip", lang),
            min=0.0,
            get=hyblend_hub.prop_get("panel_width"), set=hyblend_hub.prop_set("panel_width"), default=0.0,
        ),
        "gpu_ui_panel_height": FloatProperty(
            name="Panel Height",
            description=tr("importer.prefs_gpu_ui_height_tooltip", lang),
            min=0.0,
            get=hyblend_hub.prop_get("panel_height"), set=hyblend_hub.prop_set("panel_height"), default=0.0,
        ),
        # --- Janela de boas-vindas (interface/welcome.py). Ordem dos itens =
        # welcome.STARTUP_MODES (o get/set usa o índice).
        "welcome_startup": EnumProperty(
            name="Show at Startup",
            description=tr("importer.prefs_welcome_startup_tooltip", lang),
            items=[
                ("ALWAYS", tr("importer.prefs_welcome_always", lang),
                 tr("importer.prefs_welcome_always_tooltip", lang)),
                ("NEW_VERSION", tr("importer.prefs_welcome_new_version", lang),
                 tr("importer.prefs_welcome_new_version_tooltip", lang)),
                ("NEVER", tr("importer.prefs_welcome_never", lang),
                 tr("importer.prefs_welcome_never_tooltip", lang)),
            ],
            get=_welcome_startup_get,
            set=_welcome_startup_set,
        ),
        "welcome_size": FloatProperty(
            name="Welcome Window Size",
            description=tr("importer.prefs_welcome_size_tooltip", lang),
            default=100.0, min=50.0, max=200.0, soft_min=75.0, soft_max=150.0,
            subtype="PERCENTAGE", precision=0,
            update=_on_welcome_size_changed,
        ),
        # --- Home (interface/home/, 5.0+ com a pasta do jogo). Ordem dos itens
        # dos enums: novos SEMPRE no fim (o .blend/userpref guarda o índice).
        "home_startup": BoolProperty(
            name="Show Home on Startup",
            description=tr("importer.prefs_home_startup_tooltip", lang),
            get=_home_startup_get,
            set=_home_startup_set,
        ),
        "home_background_mode": EnumProperty(
            name="Home Background",
            description=tr("importer.prefs_home_background_mode_tooltip", lang),
            items=[
                ("FIXED", tr("importer.prefs_home_background_fixed", lang),
                 tr("importer.prefs_home_background_fixed_tooltip", lang)),
                ("RANDOM", tr("importer.prefs_home_background_random", lang),
                 tr("importer.prefs_home_background_random_tooltip", lang)),
            ],
            default="FIXED",
            update=_on_home_look_changed,
        ),
        "home_background": EnumProperty(
            name="Home Background Image",
            description=tr("importer.prefs_home_background_tooltip", lang),
            items=[
                ("ZONE1", tr("importer.prefs_home_zone1", lang), ""),
                ("ZONE2", tr("importer.prefs_home_zone2", lang), ""),
                ("ZONE3", tr("importer.prefs_home_zone3", lang), ""),
            ],
            default="ZONE3",
            update=_on_home_look_changed,
        ),
        "home_background_blur": BoolProperty(
            name="Blurred Background",
            description=tr("importer.prefs_home_blur_tooltip", lang),
            default=True,
            update=_on_home_look_changed,
        ),
        "home_scale": FloatProperty(
            name="Home Scale",
            description=tr("importer.prefs_home_scale_tooltip", lang),
            default=1.0, min=0.6, max=1.6,
            update=_on_home_look_changed,
        ),
        "home_hires_thumbs": BoolProperty(
            name="High Quality Thumbnails",
            description=tr("importer.prefs_home_hires_thumbs_tooltip", lang),
            default=True,
            update=_on_home_thumbs_changed,
        ),
        # Pasta do Hytale: a UI por GPU lê dela a arte e as fontes do jogo
        # (nada disso vem no zip). Automático = %APPDATA%/Hytale.
        "hytale_path_mode": EnumProperty(
            name="Hytale Folder",
            description=tr("importer.prefs_hytale_mode_tooltip", lang),
            items=[
                ("AUTO", tr("importer.prefs_hytale_mode_auto", lang),
                 tr("importer.prefs_hytale_mode_auto_tooltip", lang)),
                ("MANUAL", tr("importer.prefs_hytale_mode_manual", lang),
                 tr("importer.prefs_hytale_mode_manual_tooltip", lang)),
            ],
            default="AUTO",
            update=_on_hytale_path_changed,
        ),
        "hytale_path": StringProperty(
            name="Hytale Folder",
            description=tr("importer.prefs_hytale_path_tooltip", lang),
            subtype="DIR_PATH",
            update=_on_hytale_path_changed,
        ),
    }


@localized_props(_importer_preferences_props)
class HytaleImporterPreferences(AddonPreferences):
    # Nome do pacote raiz, senão o Blender não acha as preferences.
    bl_idname = ADDON_PACKAGE

    def draw(self, context):
        lang = get_language(context)
        row = self.layout.row(align=True)
        row.prop(self, "language", text=tr("importer.prefs_language", lang))
        row.operator(
            "hytale.reload_translations",
            text=tr("importer.prefs_reload_translations", lang),
            icon="FILE_REFRESH",
        )

        from .interface import gpu_ui, home, welcome
        self._draw_hytale_folder(self.layout, lang)

        # Experimental: o desenho do hub (IGUAL no CC e no Prefabs) -- aba
        # colapsável com uma sub-aba por recurso (ids hyblend_prefs_*).
        sections = [(ident, tr(key, lang), icon, lambda layout, d=draw: d(self, layout, context, lang))
                    for ident, key, icon, draw in (
                        ("home", "importer.prefs_home_box", "HOME", home.draw_preferences),
                        ("welcome", "importer.prefs_welcome_box", "INFO", welcome.draw_preferences),
                        ("gpu_ui", "importer.prefs_gpu_ui_panel", "WINDOW", gpu_ui.draw_preferences))]
        hyblend_hub.draw_experimental(self.layout, "hyblend", sections, title=tr("importer.prefs_experimental_box", lang))

    def _draw_hytale_folder(self, layout, lang):
        """Pasta do Hytale (obrigatória desde a 0.9.5), sempre à vista; desenho igual ao do hub."""
        from .interface.gpu_ui import game
        # hytale_dir() é cacheado pela configuração: seguro a cada redesenho.
        hyblend_hub.draw_hytale_folder(
            layout, self, game.hytale_dir(), "hyblend.welcome_locate_game", "Hyblend Toolkit",
            texts={"box": tr("importer.prefs_hytale_box", lang), "required": tr("importer.prefs_hytale_required", lang),
                   "locate": tr("welcome.locate_game", lang), "found": tr("importer.prefs_hytale_found", lang),
                   "invalid": tr("importer.prefs_hytale_invalid", lang), "missing": tr("importer.prefs_hytale_missing", lang)},
            locate_props={"reopen": False})


_CLASSES = (
    HytaleImporterPreferences,
    HYTALE_OT_open_addon_preferences,
)


def register():
    for cls in _CLASSES:
        register_localized_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        unregister_localized_class(cls)
