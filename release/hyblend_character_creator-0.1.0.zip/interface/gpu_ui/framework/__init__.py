"""Mini framework de UI via GPU (portado do protótipo "Mini GPU UI").

Nada aqui conhece o Hyblend: widgets, layout, renderer e runtime genéricos.
O que é do Hyblend mora em ../widgets.py, ../bind.py e ../pages/.

FRAMEWORK UNIFICADO (Toolkit 0.9.5): esta pasta é IDÊNTICA, byte a byte,
no Hyblend Toolkit, no Character Creator e no Prefabs. Correção feita
aqui = copiar a pasta inteira pros outros dois, sem trocar nada. O que
muda de um addon pro outro entra por `configure()` (chamado pelo app no
register, ANTES de runtime/overlay/renderer serem usados):

  namespace         prefixo dos operadores internos (bpy.ops.<ns>.gpu_ui_host,
                    <ns>.gpu_ui_overlay) -- tem que ser único por addon
  label             nome nos avisos do console ("[<label>] ...")
  font_copy_dir     pasta em %TEMP% com a cópia das fontes (renderer._font_copy)
  builtin_fonts     {peso: arquivo em ../fonts} por cima do padrão (Geist)
  text_tracking     "prefix" (padrão: posição pela largura do prefixo, em
                    pixels inteiros) ou "sum" (soma das letras soltas,
                    espaço fracionário -- o desenho antigo do CC)
  image_samples     máx. de amostras por eixo ao REDUZIR imagem (8 padrão;
                    4 = o desenho antigo do CC)

Do CC vieram (core.py): Divider, Image, TextField, VirtualColumn,
VirtualGrid, Wrap, tooltip_text, wrap_text(max_lines, break_words) e a âncora de
rolagem por item (ScrollView._keep_anchor); runtime: largura padrão e
mínima do app (register) e tooltip do app (register(tooltip=)).
O seletor dos addons Hyblend (topo da aba, UI por GPU) é switcher.py.
"""

from types import SimpleNamespace

CONFIG = SimpleNamespace(
    namespace="hyblend",
    label="Hyblend GPU UI",
    font_copy_dir="hyblend_toolkit_fonts",
    builtin_fonts={},
    text_tracking="prefix",
    image_samples=8,
)


def configure(**options):
    """Ajustes por addon (ver docstring do módulo). Chave desconhecida = erro
    na hora (erro de digitação não passa calado)."""
    for key, value in options.items():
        if not hasattr(CONFIG, key):
            raise KeyError("framework.configure: unknown option %r" % key)
        setattr(CONFIG, key, value)
    if "builtin_fonts" in options or "text_tracking" in options:
        from . import renderer
        renderer.forget_fonts()


def ops_namespace():
    """bpy.ops.<namespace> (ex.: bpy.ops.hyblendcc)."""
    import bpy
    return getattr(bpy.ops, CONFIG.namespace)
