"""Hyblend Character Creator: monta/customiza personagens do Hytale a partir dos Assets do jogo.
Depende do Hyblend Toolkit (núcleo: pasta do Hytale, interface, seletor). Aqui só a ligação (hyblend_link):
sem o núcleo, só o aviso (painel + Preferences); com ele, main.register().
IMPORTANTE: nenhum submódulo além de hyblend_link é importado aqui em cima -- eles importam o núcleo e só podem
carregar com ele pronto (e são recarregados se o núcleo for atualizado, ver _deactivate)."""

import sys

import bpy
from bpy.types import AddonPreferences, Panel

from . import hyblend_link

# Versão da API do núcleo exigida (api.py do Toolkit, HYBLEND_CORE_API).
REQUIRES_CORE_API = 2     # 2: montagem dos modelos no núcleo (api.model)
TOOLKIT_URL = "https://www.nexusmods.com/hytale/mods/164"

_TEXTS = {
    "EN": {
        hyblend_link.MISSING: "Hyblend Character Creator needs the Hyblend Toolkit add-on. Install and enable it.",
        hyblend_link.DISABLED: "Waiting for the Hyblend Toolkit add-on to start.",
        hyblend_link.OUTDATED: "Your Hyblend Toolkit is too old for this Character Creator. Update it.",
        hyblend_link.ERROR: "Hyblend Character Creator failed to start (see the console):",
        "button": "Get Hyblend Toolkit",
    },
    "PT_BR": {
        hyblend_link.MISSING: "O Hyblend Character Creator precisa do addon Hyblend Toolkit. Instale e ative.",
        hyblend_link.DISABLED: "Esperando o addon Hyblend Toolkit iniciar.",
        hyblend_link.OUTDATED: "Seu Hyblend Toolkit é antigo demais pra este Character Creator. Atualize.",
        hyblend_link.ERROR: "O Hyblend Character Creator falhou ao iniciar (veja o console):",
        "button": "Baixar o Hyblend Toolkit",
    },
}


def _text(key):
    """Aviso sem o núcleo (sem o tradutor dele): idioma do núcleo se ativo, senão o da interface do Blender."""
    core = hyblend_link.core()
    lang = None
    if core is not None:
        try:
            lang = core.api.get_language(bpy.context)
        except Exception:
            lang = None
    if lang not in _TEXTS:
        locale = getattr(bpy.app.translations, "locale", "") or ""
        lang = "PT_BR" if locale.lower().startswith("pt") else "EN"
    return _TEXTS[lang].get(key, _TEXTS["EN"].get(key, key))


def _draw_status(layout):
    state = hyblend_link.status(__package__)
    box = layout.box()
    col = box.column(align=True)
    col.label(text=_text(state), icon="ERROR" if state == hyblend_link.ERROR else "INFO")
    if state == hyblend_link.ERROR:
        col.label(text=hyblend_link.error(__package__) or "")
    elif state in (hyblend_link.MISSING, hyblend_link.OUTDATED):
        box.operator("wm.url_open", text=_text("button"), icon="URL").url = TOOLKIT_URL


class HYBLENDCC_PT_waiting(Panel):
    """Aba "Hyblend" sem o núcleo: só o aviso."""

    bl_label = "Hyblend Character Creator"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Hyblend"
    bl_order = 11

    @classmethod
    def poll(cls, context):
        return not hyblend_link.is_active(__package__)

    def draw(self, context):
        _draw_status(self.layout)


class HYBLENDCC_WaitingPreferences(AddonPreferences):
    """Preferences enquanto o CC espera o núcleo (as de verdade, preferences.py, entram no main.register()).
    Os valores salvos (idioma, miniaturas) ficam guardados no meio-tempo (testado no 4.5 e no 5.2)."""
    bl_idname = __package__

    def draw(self, context):
        _draw_status(self.layout)


def _activate():
    _set_waiting_prefs(False)
    from . import main
    main.register()


def _deactivate():
    main = sys.modules.get(__package__ + ".main")
    try:
        if main is not None:
            main.unregister()
    finally:
        # Esquece os submódulos: guardam referências ao núcleo, que pode estar sendo atualizado (o próximo
        # _activate importa tudo de novo).
        keep = __package__ + ".hyblend_link"
        for name in [n for n in sys.modules if n.startswith(__package__ + ".") and n != keep]:
            del sys.modules[name]
            attr = name[len(__package__) + 1:]
            if "." not in attr and attr in globals():
                del globals()[attr]
        _set_waiting_prefs(True)


def _set_waiting_prefs(on):
    if on != HYBLENDCC_WaitingPreferences.is_registered:
        (bpy.utils.register_class if on else bpy.utils.unregister_class)(HYBLENDCC_WaitingPreferences)


def register():
    bpy.utils.register_class(HYBLENDCC_PT_waiting)
    _set_waiting_prefs(True)
    hyblend_link.attach(__package__, requires=REQUIRES_CORE_API, activate=_activate, deactivate=_deactivate)


def unregister():
    hyblend_link.detach(__package__)
    _set_waiting_prefs(False)
    bpy.utils.unregister_class(HYBLENDCC_PT_waiting)
