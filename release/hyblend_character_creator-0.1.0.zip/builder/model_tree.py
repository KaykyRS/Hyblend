"""model_tree.py -- utilidades puras-Python (sem bpy) compartilhadas.

A resolucao de arvore "de verdade" (criar bone por no, reaproveitando
bones existentes, ver o bug de itens de Head com caixa-dentro-de-caixa)
foi MOVIDA pra character_assembly.py -- ela precisa mexer no Armature de
verdade (Edit Mode), entao nao pode ficar num modulo sem bpy. Este
arquivo ficou so com o que continua sendo puro-Python e reutilizado:
a constante de escala de unidade e a estimativa de tamanho de atlas
(fallback pra quando a textura real nao esta disponivel).
"""

from __future__ import annotations

from pathlib import Path

# 1 unidade Blender = 1/64 unidade do jogo -- mesmo valor documentado em
# common.py do Hyblend (UNIT_SCALE_DEFAULT). Duplicado aqui de proposito:
# este addon e standalone (ver decisao de design), nao importa do Hyblend.
UNIT_SCALE_DEFAULT = 1.0 / 64.0


def _vec3(d: dict, default: float = 0.0) -> tuple:
    return (d.get("x", default), d.get("y", default), d.get("z", default))


# ---------------------------------------------------------------------------
# Fallback pra tamanho do atlas de textura -- usar SO quando a textura de
# verdade nao pode ser carregada. Quando a textura existe, e SEMPRE
# melhor ler o tamanho real dela (bpy.data.images.load(path).size) em vez
# de inferir -- essa funcao so existe pra nao travar o teste quando a
# textura falta. Adaptada de compute_atlas_size do importer/__init__.py
# do Hyblend (pura leitura de dict, sem bpy).
# ---------------------------------------------------------------------------

_BOX_FACE_FIXED_AXIS = {
    "front": "z", "back": "z", "top": "y", "bottom": "y", "left": "x", "right": "x",
}
_FACE_AXES_BY_FIXED_AXIS = {"z": (0, 1), "y": (0, 2), "x": (2, 1)}


def _blockbench_uv_corner(fw, fh, angle, mirror, offset):
    """Versao minima de _blockbench_uv_rect (ver box_mesh.py) que so
    devolve os dois cantos, pra achar o maior X/Y usado -- nao precisamos
    da matematica completa de rotacao aqui, so um limite superior."""
    ux, uy = offset.get("x", 0.0), offset.get("y", 0.0)
    w, h = (fh, fw) if angle in (90, 270) else (fw, fh)
    mx = -1.0 if mirror.get("x") else 1.0
    my = -1.0 if mirror.get("y") else 1.0
    return ux, uy, ux + w * mx, uy + h * my


def estimate_atlas_size(blockymodel_path: Path) -> tuple:
    """Le o .blockymodel e infere (largura, altura) minimas do atlas de
    textura a partir do maior canto usado por qualquer face. E uma
    HEURISTICA -- prefira sempre o tamanho real da textura quando ela
    estiver disponivel."""
    import json

    with blockymodel_path.open(encoding="utf-8") as f:
        data = json.load(f)

    max_x, max_y = 1.0, 1.0

    def visit(node):
        nonlocal max_x, max_y
        shape = node.get("shape", {})
        size = shape.get("settings", {}).get("size", {})
        size_raw = _vec3(size, default=1.0)
        for face_key, info in shape.get("textureLayout", {}).items():
            fixed_axis = _BOX_FACE_FIXED_AXIS.get(face_key)
            if fixed_axis is None:
                continue
            au, av = _FACE_AXES_BY_FIXED_AXIS[fixed_axis]
            fw, fh = size_raw[au], size_raw[av]
            x1, y1, x2, y2 = _blockbench_uv_corner(
                fw, fh, info.get("angle", 0), info.get("mirror", {}), info.get("offset", {})
            )
            max_x = max(max_x, x1, x2)
            max_y = max(max_y, y1, y2)
        for child in node.get("children", []):
            visit(child)

    for root_node in data.get("nodes", []):
        visit(root_node)
    return max_x, max_y
