"""Português (Brasil). Key de en.py ainda não traduzida aqui cai pro inglês."""

LANGUAGE_CODE = "PT_BR"
LANGUAGE_NAME = "Português (Brasil)"

TRANSLATIONS = {
}
