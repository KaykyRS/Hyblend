"""interface/gpu_ui/app.py -- a tela "Character Creator" desenhada por GPU.

`build(f)` roda quando algo muda e devolve uma árvore NOVA de widgets
(estilo React, ver framework/runtime.py). Layout do protótipo (título +
coluna de Categoria + coluna de Sub-categoria + área principal), mais a
barra de RODAPÉ pedida pelo usuário (Create Player / Create Rig /
Presets / Settings, cada um abrindo uma "gaveta" inline acima dele).

MESMAS FUNÇÕES DA UI CLÁSSICA -- mesmo estado e mesmos operadores:
  * Categoria/Sub-categoria ativas = `wm.hyblendcc_active_section/
    _category` (as MESMAS da UI clássica: trocar de UI mantém a tela);
    clique -> `hyblendcc.select_section/_category`.
  * Item -> escreve `slot.item_id` (o que o template_icon_view clássico
    faz); o update() do slot agenda a aplicação (_defer_apply_slot).
  * Variante/Cor/Cor do fundo/links -> `hyblendcc.select_variant`,
    `select_color`, `select_background_color`, `toggle_skin_link`,
    `toggle_background_link`. Materials -> `slot.gradient_set`.
  * Rodapé -> create_player, create_rig, save/load/delete_preset,
    build_category_thumbnails, build_all_thumbnails, reload_catalog,
    locate_game, clear_cache.

SÓ DESTA UI (sem equivalente clássico, pedido do usuário -- ganham
função de verdade depois): busca por nome na grade, cadeado por
sub-categoria (hoje só guarda estado), moldura/título ornamentados.

Build é SÓ LEITURA: sincronizar/carregar catálogo vai pro timer
(bind.maybe_sync), nunca aqui dentro do draw handler.
"""

from __future__ import annotations

from dataclasses import replace

from ...common import _LINKED_SKIN_CATEGORIES, _SLOT_NONE_VALUE
from ...scanner.catalog import get_cache
from . import bind, data
from .framework.core import (Column, Divider, Fade, Label, Row, ScrollView, Style, TextField, Theme,
                             VirtualGrid, Wrap)
from .widgets import (C, Breadcrumb, FrameOrnament, Chip, DropdownHeader, EmptyState, FooterButton, ItemTile,
                      LinkButton, NavIcon, OptionRow, SectionTitle, SquareButton, Swatch, TextButton,
                      TitleBar, option_list)

TITLE = "CHARACTER CREATOR"
CELL_W, CELL_ASPECT, CELL_GAP = 84.0, 136 / 84, 9.0          # grade medida na referência
NAV_W, SUB_W = 64.0, 66.0
MAIN_PAD = (20.0, 14.0, 10.0, 18.0)                           # esquerda, topo, direita, baixo
PREFERRED_ROWS = 3

# Tema do framework ajustado às cores do jogo (campo de busca, rolagem, foco...)
THEME = replace(
    Theme(),
    canvas=C.panel, surface=C.nav_tile, surface_raised=C.button, input=C.search, border=(0, 0, 0, 0),
    text=C.title_text, text_muted=C.placeholder, accent=C.gold, focus=C.gold,
    scroll_thumb=(0.769, 0.620, 0.361, 1.0), scroll_thumb_hot=(0.84, 0.69, 0.42, 1.0),
    scroll_track=(0.071, 0.086, 0.114, 1.0), danger=C.danger,
)

DEFAULT_WIDTH = 560.0     # largura inicial do painel (passa da sidebar, como no jogo)
MIN_WIDTH = 420.0


def signature(context):
    """Resumo BARATO do que a tela mostra; se mudar, o runtime reconstrói.
    Roda a cada redesenho do viewport -> só O(1). Mudança de dado "de
    verdade" (item aplicado, undo...) já chega pelo depsgraph_update_post
    do runtime; aqui fica o que o depsgraph não avisa."""
    wm = context.window_manager
    obj = context.active_object
    p = bind.prefs(context)
    return (
        obj.name if obj else None,
        obj.type if obj else None,
        getattr(wm, "hyblendcc_active_section", None),
        getattr(wm, "hyblendcc_active_category", None),
        wm.get("hyblendcc_synced_for"),
        len(wm.hyblendcc_slots),
        getattr(wm, "hyblendcc_preset_selected", None),
        p.hytale_path if p else None,
        p.language if p else None,
        data.catalog_loaded(),
    )


# --------------------------------------------------------------------------
# Ações
# --------------------------------------------------------------------------

def _op(idname, props=None, toast=None, after=None):
    def run(f):
        result = bind.run_op(f, idname, props, invoke=False, toast=toast)
        if after is not None and result is not None:
            after(f)
    return run


def _invoke(idname, props=None, toast=None):
    def run(f):
        bind.run_op(f, idname, props, invoke=True, toast=toast)
    return run


def _after_thumbnails(f):
    from .framework import renderer
    data.invalidate()
    renderer.forget_images()


def _after_reload(f):
    data.invalidate()
    bind.forget_sync_attempt()


def _toggle_state(key, default=False):
    def run(f):
        f.state[key] = not f.state.get(key, default)
    return run


def _toggle_drawer(name):
    def run(f):
        f.state["drawer"] = None if f.state.get("drawer") == name else name
        f.state.pop("_open_menu", None)
    return run


def _use_classic(f):
    p = bind.prefs()
    if p is not None:
        p.use_gpu_ui = False      # o update da preference derruba esta UI


# --------------------------------------------------------------------------
# Tela
# --------------------------------------------------------------------------

def build(f):
    context = f.context
    data.sync()      # pasta Hytale 1x por build (+ fontes/pré-carga se mudou)
    p = bind.prefs(context)
    has_assets = bool(p and p.hytale_path)
    if has_assets:
        bind.maybe_sync(context)

    catalog = data.load() if (has_assets and bind.catalog_ready(context)) else []
    cat, sub = _current(context, catalog)

    if cat is not None:
        body = Row(
            _nav_column(catalog, cat),
            Divider(vertical=True, color=C.divider_a),
            _sub_column(cat, sub),
            Divider(vertical=True, color=C.divider_b),
            _safe_main(f, cat, sub, has_assets),
        )
    else:
        body = _safe_main(f, None, None, has_assets)

    # Igual ao @DecoratedContainer do Common/Container.ui: título e conteúdo
    # são IRMÃOS (a moldura não passa por trás da faixa do título), com o
    # ornamento de baixo saindo da moldura. Sem arte do jogo: o layout
    # provisório de antes (moldura em volta de tudo).
    title = TitleBar(TITLE, **data.title_assets())
    parts = (body, _drawer(f, sub), _footer(f), _toast(f))
    bottom = data.bottom_ornament()
    if data.decorated():
        return Column(
            title,
            Column(*parts, style=Style(frame=data.frame_style(), padding=(2, 2, 2, 2), flex=1, clip=True)),
            FrameOrnament(bottom) if bottom else None,
            key="root",
            style=Style(radius=4, shadow=True),
        )
    return Column(
        title, *parts,
        key="root",
        style=Style(frame=data.frame_style(), padding=(2, 2, 2, 2), radius=4, shadow=True, clip=True),
    )


def _current(context, catalog):
    """(Category, Sub) ativos -- lidos de wm (mesmo estado da UI
    clássica). Valor inválido (catálogo trocou) cai no primeiro
    disponível SÓ pra desenhar; quem grava é o clique (operador)."""
    if not catalog:
        return None, None
    wm = context.window_manager
    cats = {c.id: c for c in catalog}
    cat = cats.get(wm.hyblendcc_active_section) or catalog[0]
    subs = {s.id: s for s in cat.subs}
    sub = subs.get(wm.hyblendcc_active_category) or cat.subs[0]
    return cat, sub


def _nav_column(catalog, cat):
    icons = [NavIcon("cat." + c.id, c.icon, c.icon_selected, c.id == cat.id,
                     _op("hyblendcc.select_section", {"section": c.id}), tooltip=c.label)
             for c in catalog]
    return Column(icons, style=Style(width=NAV_W, padding=(8, 10, 6, 10), gap=0))


def _sub_column(cat, sub):
    icons = [NavIcon("sub." + s.id, s.icon, s.icon_selected, s.id == sub.id,
                     _op("hyblendcc.select_category", {"category": s.id}), tooltip=s.label)
             for s in cat.subs]
    return Column(icons, style=Style(width=SUB_W, padding=(10, 10, 6, 10), gap=0))


def _safe_main(f, cat, sub, has_assets):
    """Erro ao montar a área principal (dado estranho no catálogo...) vira
    um aviso NO LUGAR dela -- as colunas da esquerda e o rodapé continuam
    funcionando. Sem isso, a exceção caía no except do on_draw, o host era
    marcado quebrado e a UI inteira fechava (item 62)."""
    try:
        return _main(f, cat, sub, has_assets)
    except Exception as error:
        import traceback
        traceback.print_exc()
        return Column(EmptyState("Something went wrong here", str(error)[:120], icon="error"),
                      style=Style(flex=1, padding=MAIN_PAD, gap=12))


def _main(f, cat, sub, has_assets):
    context = f.context
    style = Style(flex=1, padding=MAIN_PAD, gap=12)
    if not has_assets:
        return Column(
            EmptyState("Hytale folder not found",
                       "Locate the game folder to use the add-on.", icon="folder"),
            TextButton("empty.autodetect", "Locate Game", _invoke("hyblendcc.locate_game"),
                       icon="refresh", primary=True, style=Style(height=34)),
            style=style,
        )
    if cat is None:
        if bind.catalog_failed(context):
            return Column(
                EmptyState("Could not load the catalog",
                           "Check the Assets path in the addon Preferences.", icon="error"),
                TextButton("empty.autodetect", "Locate Game", _invoke("hyblendcc.locate_game"),
                           icon="refresh", primary=True, style=Style(height=34)),
                style=style,
            )
        return Column(EmptyState("Loading catalog…", icon="refresh"), style=style)
    obj = context.active_object
    if obj is None or obj.type != "ARMATURE":
        return Column(
            EmptyState("No Armature selected",
                       "Create a Player from scratch, or select an existing Armature.", icon="rig"),
            TextButton("empty.create_player", "Create Player", _invoke("hyblendcc.create_player"),
                       icon="user", primary=True, style=Style(height=34)),
            style=style,
        )

    from ...picker import _find_slot
    slot = _find_slot(context.window_manager, sub.id)
    if slot is None:
        return Column(EmptyState("Syncing with the Armature…", icon="refresh"), style=style)

    st = f.state
    if st.get("search.for") != sub.id:          # busca limpa ao trocar de sub-categoria
        st["search.for"] = sub.id
        st["search"], st["search.caret"] = "", 0
        if st.get("_focus") == "search":
            st.pop("_focus", None)
        st.pop("_open_menu", None)

    locked = st.get("lock." + sub.id, False)
    header = Row(
        Breadcrumb([cat.label, sub.label], size=16),
        SquareButton("lock." + sub.id, "lock" if locked else "unlock", _toggle_state("lock." + sub.id),
                     active=locked, tooltip="Lock this part (reserved for a future Randomize feature)",
                     images=data.lock_images()),
        style=Style(height=24, align="center"),
    )
    children = [header,
                TextField("search", "Search", icon="search", style=Style(height=30)),
                _grid(f, sub, slot)]
    children += _details(f, sub, slot)
    return Column(children, style=style)


def _grid(f, sub, slot):
    st = f.state
    query = st.get("search", "").strip().lower()
    entries = [e for e in data.items_for(sub.id) if query in e.name.lower()]
    show_none = sub.optional and not query
    count = len(entries) + (1 if show_none else 0)
    from ...picker import _slot_item_value
    current = _slot_item_value(slot)          # espelho barato (item 58), nao le a enum
    chosen = None if current in ("", _SLOT_NONE_VALUE) else current

    def choose(item_id):
        def run(f):
            value = item_id if item_id is not None else _SLOT_NONE_VALUE
            if _slot_item_value(slot) != value:
                bind.set_prop(f, slot, "item_id", value)
        return run

    badge = data.equipped_icon()

    def cell(i):
        if show_none:
            if i == 0:
                return ItemTile("tile.%s.none" % sub.id, None, chosen is None, choose(None),
                                none=True, tooltip="None", none_icon=data.empty_part_icon(),
                                badge_icon=badge)
            i -= 1
        e = entries[i]
        return ItemTile("tile.%s.%s" % (sub.id, e.id), e.thumb, chosen == e.id, choose(e.id),
                        tooltip=e.name, name=e.name, badge_icon=badge)

    if count == 0:
        return EmptyState("No items match \"%s\"" % query if query else "No items", icon="search", height=80)
    grid = VirtualGrid("grid." + sub.id, count, cell, cell_width=CELL_W, aspect=CELL_ASPECT, gap=CELL_GAP)
    return ScrollView("scroll." + sub.id, grid, style=Style(height=_rows_height(f, PREFERRED_ROWS),
                                                         min_height=_rows_height(f, 1)))


def _rows_height(f, rows):
    """Altura de N linhas da grade na largura atual do painel."""
    panel_w = f.host.geo.frame.w if f.host is not None else DEFAULT_WIDTH
    width = panel_w - 4 - NAV_W - SUB_W - 2 - MAIN_PAD[0] - MAIN_PAD[2] - ScrollView.BAR
    grid = VirtualGrid("", 0, None, cell_width=CELL_W, aspect=CELL_ASPECT, gap=CELL_GAP)
    _, _, cell_h = grid._geometry(max(width, CELL_W))
    return rows * (cell_h + CELL_GAP) - CELL_GAP


# --------------------------------------------------------------------------
# Variante / Materials / Cor / Fundo (mesmas regras de _draw_colors clássico)
# --------------------------------------------------------------------------

def _details(f, sub, slot):
    """PERFORMANCE (item 58): cada valor do slot e lido UMA vez aqui e
    reaproveitado -- ler uma EnumProperty dinamica dispara o items() dela
    (e a versao anterior lia `slot.color` uma vez POR BOLINHA). O
    item_id/gradient_set vem dos espelhos baratos do picker."""
    from ...picker import _slot_gradient_value, _slot_item_value
    item_id = _slot_item_value(slot)
    if item_id in ("", _SLOT_NONE_VALUE):
        return []
    context = f.context
    cache = get_cache()
    item = cache.find_item(sub.id, item_id)
    if item is None:
        return [Label("Invalid item (catalog reloaded?)", size=12, color=C.danger)]

    out = []
    variant = slot.variant
    if item.variants:
        chips = [Chip("variant.%s.%s" % (sub.id, v.key),
                      cache.display_name(v.name_key) if v.name_key else v.key,
                      variant == v.key,
                      _op("hyblendcc.select_variant", {"category": sub.id, "variant": v.key}))
                 for v in item.variants]
        out.append(Row(SectionTitle("Variant"), style=Style(height=24, align="center")))
        out.append(Row(chips, style=Style(gap=6, height=26)))

    if item.coloring_mode not in ("gradient", "discrete"):
        out.append(Label("This item has no color options.", size=12, color=C.text_dim))
        return out

    from ..ui_data import _grid_color_entries
    entries = _grid_color_entries(context, slot)

    if item.coloring_mode == "gradient" and len(cache.gradient_sets) > 1:
        out += _materials(f, sub, slot, item)

    skin_link = None
    if sub.id in _LINKED_SKIN_CATEGORIES:
        linked = slot.skin_linked
        skin_link = LinkButton("link.skin." + sub.id, linked, data.link_icons(),
                               _op("hyblendcc.toggle_skin_link", {"category": sub.id}),
                               tooltip=("Linked with Body/Face/Mouth/Ears: click to make independent" if linked
                                        else "Independent: click to link with Body/Face/Mouth/Ears"))
    out.append(Row(SectionTitle("Color"), skin_link, style=Style(height=24, align="center")))
    gradient_set = _slot_gradient_value(slot)
    gset = gradient_set if gradient_set not in ("", _SLOT_NONE_VALUE) else ""
    color = slot.color
    out.append(Wrap([Swatch("sw.%s.%s" % (sub.id, name), data.hex_to_rgba(hex_),
                            color == name,
                            _op("hyblendcc.select_color", {"category": sub.id, "color": name}),
                            tooltip="%s (%s)" % (name, gset) if gset else name)
                     for name, hex_ in entries],
                    item_width=24, item_height=24, gap=10, row_gap=10.5))

    from ...picker import _item_model_has_background_node
    has_variant = variant and variant != _SLOT_NONE_VALUE
    if item.coloring_mode == "gradient" and _item_model_has_background_node(
            context, sub.id, item, variant_key=(variant if has_variant else None)):
        linked = slot.background_linked
        out.append(Row(
            SectionTitle("Background"),
            LinkButton("link.bg." + sub.id, linked, data.link_icons(),
                       _op("hyblendcc.toggle_background_link", {"category": sub.id}),
                       tooltip=("Linked: click to give the background its own color" if linked
                                else "Independent: click to match the item color")),
            style=Style(height=24, align="center")))
        if not linked:
            background_color = slot.background_color
            out.append(Wrap([Swatch("bg.%s.%s" % (sub.id, name), data.hex_to_rgba(hex_),
                                    background_color == name,
                                    _op("hyblendcc.select_background_color", {"category": sub.id, "color": name}),
                                    tooltip="Background: %s" % name)
                             for name, hex_ in entries],
                            item_width=24, item_height=24, gap=10, row_gap=10.5))
    return out


def _materials(f, sub, slot, item):
    """Dropdown "Materials" (GradientSet) -- mesma property que o
    `prop(slot, "gradient_set")` clássico, mesma lista de opções."""
    from ...picker import _slot_effective_gradient_set, _slot_gradient_set_enum_items, _slot_gradient_value
    key = "materials." + sub.id
    is_open = f.state.get("_open_menu") == key
    current = _slot_effective_gradient_set(slot)

    def toggle(f):
        f.state["_open_menu"] = None if is_open else key

    header = Row(Label("Materials", size=12, weight="Medium", color=C.text, style=Style(width=76)),
                 DropdownHeader(key, current or "—", toggle, is_open=is_open,
                                tooltip="Color palette (GradientSet) used by this item"),
                 style=Style(height=26, align="center", gap=8))
    if not is_open:
        return [header]

    def pick(value):
        def run(f):
            f.state["_open_menu"] = None
            if _slot_gradient_value(slot) != value:
                bind.set_prop(f, slot, "gradient_set", value)
        return run
    options = [OptionRow("%s.opt.%s" % (key, ident), name, pick(ident), selected=(ident == current))
               for ident, name, *_ in _slot_gradient_set_enum_items(slot, f.context)
               if ident != _SLOT_NONE_VALUE]
    return [header, option_list(options, key=key + ".list")]


# --------------------------------------------------------------------------
# Rodapé + gaveta
# --------------------------------------------------------------------------

def _footer(f):
    from ...player_ops import _hyblend_generate_rig_available
    drawer = f.state.get("drawer")
    rig_ok = _hyblend_generate_rig_available()
    return Row(
        FooterButton("foot.player", "Create Player", "user", _invoke("hyblendcc.create_player"),
                     tooltip=bind.op_description("hyblendcc.create_player") or "Create a Player from scratch"),
        FooterButton("foot.rig", "Create Rig", "rig", _invoke("hyblendcc.create_rig"),
                     enabled=rig_ok and bind.op_poll("hyblendcc.create_rig"),
                     tooltip=("Generate the rig using the Hyblend Toolkit" if rig_ok
                              else "Requires the Hyblend Toolkit addon")),
        FooterButton("foot.presets", "Presets", "bookmark", _toggle_drawer("presets"),
                     selected=(drawer == "presets"), tooltip="Save / load / delete presets"),
        FooterButton("foot.settings", "Settings", "gear", _toggle_drawer("settings"),
                     selected=(drawer == "settings"), tooltip="Assets, thumbnails and catalog"),
        key="footer",
        style=Style(padding=(10, 8, 10, 10), gap=6, background=C.footer, radius=0),
    )


def _drawer(f, sub):
    drawer = f.state.get("drawer")
    if drawer == "presets":
        content = _presets_drawer(f)
    elif drawer == "settings":
        content = _settings_drawer(f, sub)
    else:
        return None
    enter = f.animate("drawer.enter." + drawer, 1.0, 0.22, initial=0.0)
    return Fade(Column(content, key="drawer." + drawer,
                       style=Style(padding=(12, 10, 12, 8), gap=6, background=C.footer, radius=0)),
                alpha=enter, dy=-6.0 * (1.0 - enter))


def _presets_drawer(f):
    from ...presets_ops import _preset_enum_items
    context = f.context
    wm = context.window_manager
    st = f.state
    # Nome do preset: o campo guarda texto no estado da UI; espelha a
    # MESMA property da UI clássica (wm.hyblendcc_preset_name).
    if st.get("_focus") != "preset.name":
        st["preset.name"] = wm.hyblendcc_preset_name

    def on_name(f, text):
        bind.set_prop(f, wm, "hyblendcc_preset_name", text, undo=False)

    name_row = Row(
        TextField("preset.name", "Preset name", on_change=on_name, icon="bookmark", style=Style(height=28, flex=1)),
        TextButton("preset.save", "Save", _op("hyblendcc.save_preset", toast="Preset saved"), icon="save",
                   enabled=bind.op_poll("hyblendcc.save_preset"), style=Style(height=28)),
        style=Style(gap=6, height=28, align="center"),
    )

    items = [i for i in _preset_enum_items(wm, context) if i[0]]
    current = wm.hyblendcc_preset_selected
    key = "preset.pick"
    is_open = st.get("_open_menu") == key
    names = {i[0]: i[1] for i in items}

    def toggle(f):
        f.state["_open_menu"] = None if is_open else key

    load_row = Row(
        DropdownHeader(key, names.get(current, "(no saved presets)"), toggle, is_open=is_open,
                       placeholder=current not in names),
        TextButton("preset.load", "Load", _op("hyblendcc.load_preset", toast="Preset loaded"), icon="load",
                   enabled=bind.op_poll("hyblendcc.load_preset"), style=Style(height=28)),
        TextButton("preset.delete", "", _op("hyblendcc.delete_preset", toast="Preset deleted"), icon="trash",
                   enabled=bind.op_poll("hyblendcc.delete_preset"), tooltip="Delete the selected preset",
                   style=Style(height=28, width=32)),
        style=Style(gap=6, height=28, align="center"),
    )
    out = [name_row, load_row]
    if is_open:
        def pick(value):
            def run(f):
                f.state["_open_menu"] = None
                bind.set_prop(f, wm, "hyblendcc_preset_selected", value, undo=False)
            return run
        out.append(option_list([OptionRow("%s.opt.%s" % (key, ident), name, pick(ident),
                                          selected=(ident == current))
                                for ident, name, *_ in items], key=key + ".list"))
    return out


def _settings_drawer(f, sub):
    rows = []
    if sub is not None:
        rows.append(TextButton("set.thumbs", "Generate Thumbnails: %s" % sub.label,
                               _op("hyblendcc.build_category_thumbnails", {"category": sub.id},
                                   toast="Thumbnails generated", after=_after_thumbnails),
                               icon="refresh", style=Style(height=28)))
    rows += [
        TextButton("set.thumbs_all", "Generate All Thumbnails",
                   _op("hyblendcc.build_all_thumbnails", toast="Thumbnails generated", after=_after_thumbnails),
                   icon="refresh", style=Style(height=28)),
        Row(
            TextButton("set.reload", "Reload Catalog", _op("hyblendcc.reload_catalog", after=_after_reload),
                       icon="refresh", style=Style(height=28, flex=1)),
            TextButton("set.autodetect", "Locate Game", _invoke("hyblendcc.locate_game"),
                       icon="folder", style=Style(height=28, flex=1)),
            style=Style(gap=6, height=28),
        ),
        Row(
            TextButton("set.clear_cache", "Clear Cache", _invoke("hyblendcc.clear_cache"),
                       icon="trash", style=Style(height=28, flex=1)),
            TextButton("set.classic", "Use Classic Interface", _use_classic,
                       icon="exit", style=Style(height=28, flex=1)),
            style=Style(gap=6, height=28),
        ),
    ]
    return rows


def _toast(f):
    """Mensagem curta (preset salvo, erro de operador...) -- do Toolkit."""
    msg = f.state.get("_toast")
    if not msg:
        return None
    text, born, error = msg
    age = f.now - born
    if age > 2.6:
        f.state.pop("_toast", None)
        return None
    if age < 0.2 or age > 2.2:
        f.state["_motion_active"] = True    # animando entrada/saída
    else:
        f.wake_at(born + 2.2)               # parado no meio: só acordar na hora de sumir
    alpha = max(0.0, min(1.0, age / 0.15, (2.6 - age) / 0.4))
    body = Row(
        Label(text, size=11, weight="Medium", color=C.danger if error else C.gold, style=Style(flex=1)),
        style=Style(height=28, padding=(12, 0, 12, 0), align="center", background=C.button, radius=0),
    )
    return Fade(body, alpha=alpha, dy=-6.0 * (1.0 - min(1.0, age / 0.2)))
