"""Dados da Home: arquivos recentes (+ miniaturas lidas de dentro do .blend)
e o conteúdo PLACEHOLDER de Personagens (página desligada) / Aprender (o Changelog vem do GitHub: releases.py).

Regra da UI por GPU: nada aqui roda dentro do desenho. `refresh()` é chamado
ao abrir a Home (fora do draw) e as miniaturas são lidas por um timer, uma
por rodada (`_thumb_tick`), e entregues ao renderer com `put_pixels`.
"""

import gzip
import os
import struct
import time

import bpy

from ...common import HYBLEND_AUTHOR_YOUTUBE_URL

# --------------------------------------------------------------------------
# Conteúdo placeholder (trocar pelos dados reais depois)
# --------------------------------------------------------------------------

YOUTUBE_CHANNEL = HYBLEND_AUTHOR_YOUTUBE_URL      # o mesmo dos créditos (common.py)

# (id, nome, tipo) -- imagens ainda não existem: card mostra o [X] placeholder.
CHARACTERS = (
    ("player", "Player", "player"),
    ("dog", "Dog", "creature"),
    ("goblin", "Goblin", "creature"),
    ("kweebec", "Kweebec", "creature"),
    ("raptor", "Raptor", "creature"),
    ("yeti", "Yeti", "creature"),
    ("dragon", "Frost Dragon", "creature"),
    ("wolf", "Wolf", "creature"),
    ("scarecrow", "Scarecrow", "creature"),
)

# Vídeos placeholder: todos abrem o canal até os links reais chegarem.
VIDEOS = (
    {"title": {"EN": "Importing a .blockymodel", "PT_BR": "Importando um .blockymodel"},
     "desc": {"EN": "From the game files to a rigged model in Blender.",
              "PT_BR": "Dos arquivos do jogo até um modelo com rig no Blender."},
     "duration": "12:40", "url": YOUTUBE_CHANNEL},
    {"title": {"EN": "Creating the rig", "PT_BR": "Criando o rig"},
     "desc": {"EN": "Bone Settings, IK chains and Create Rig step by step.",
              "PT_BR": "Bone Settings, cadeias de IK e Create Rig passo a passo."},
     "duration": "18:05", "url": YOUTUBE_CHANNEL},
    {"title": {"EN": "Animating and exporting .blockyanim", "PT_BR": "Animando e exportando .blockyanim"},
     "desc": {"EN": "FK/IK switch, keyframes and batch export of Actions.",
              "PT_BR": "Troca FK/IK, keyframes e exportação em lote das Actions."},
     "duration": "15:22", "url": YOUTUBE_CHANNEL},
    {"title": {"EN": "Texture Picker", "PT_BR": "Texture Picker"},
     "desc": {"EN": "Swap faces and textures with a control in the viewport.",
              "PT_BR": "Troque rostos e texturas com um controle na viewport."},
     "duration": "09:48", "url": YOUTUBE_CHANNEL},
    {"title": {"EN": "Bedrock models in Hytale", "PT_BR": "Modelos Bedrock no Hytale"},
     "desc": {"EN": "Converting Minecraft Bedrock geometry to the Hytale standard.",
              "PT_BR": "Convertendo geometria do Minecraft Bedrock para o padrão do Hytale."},
     "duration": "11:16", "url": YOUTUBE_CHANNEL},
    {"title": {"EN": "First person camera", "PT_BR": "Câmera em primeira pessoa"},
     "desc": {"EN": "Camera on the head bone, ready to preview animations.",
              "PT_BR": "Câmera no bone da cabeça, pronta pra conferir animações."},
     "duration": "07:31", "url": YOUTUBE_CHANNEL},
)

# --------------------------------------------------------------------------
# Arquivos recentes
# --------------------------------------------------------------------------

MAX_RECENT = 16
THUMB_PREFIX = "mem:thumb:"     # chave da miniatura no renderer (put_pixels)

_recent = []                    # [dict(path, name, folder, mtime, size, exists, thumb)]
_thumb_queue = []               # caminhos esperando leitura da miniatura
_thumb_done = {}                # caminho -> mtime já lido (arquivo salvo de novo = relê)
_png_seen = {}                  # PNG em alta (thumbs.py) -> mtime já entregue ao renderer


def recent_files():
    return _recent


def refresh():
    """Relê recent-files.txt + stat de cada arquivo (barato) e agenda as
    miniaturas. FORA do desenho (chamado ao abrir a Home)."""
    from . import thumbs
    from ..gpu_ui.framework import renderer
    paths = thumbs.recent_blends()
    items = []
    for path in paths[:MAX_RECENT]:
        try:
            st = os.stat(path)
            exists, mtime, size = True, st.st_mtime, st.st_size
        except OSError:
            exists, mtime, size = False, 0.0, 0
        # Miniatura em alta (salva pela Home, thumbs.py) > a de 128 px de dentro do .blend.
        png = thumbs.fresh_cache(path, mtime) if exists else ""
        if png:
            png_mtime = os.path.getmtime(png)
            if _png_seen.get(png) not in (None, png_mtime):
                renderer.drop_image(png)          # regravado: o renderer relê
            _png_seen[png] = png_mtime
        items.append({"path": path, "name": os.path.splitext(os.path.basename(path))[0],
                      "folder": os.path.dirname(path), "mtime": mtime, "size": size, "exists": exists,
                      "thumb": png or (THUMB_PREFIX + path), "hires": bool(png)})
    _recent[:] = items
    if thumbs.enabled():
        thumbs.prune(paths)
    _thumb_queue[:] = [i["path"] for i in items
                       if i["exists"] and not i["hires"] and _thumb_done.get(i["path"]) != i["mtime"]]
    if _thumb_queue and not bpy.app.timers.is_registered(_thumb_tick):
        bpy.app.timers.register(_thumb_tick, first_interval=0.0)


def _thumb_tick():
    """Uma miniatura por rodada (cada uma lê ~poucas centenas de KB)."""
    if not _thumb_queue:
        return None
    path = _thumb_queue.pop(0)
    try:
        _thumb_done[path] = os.stat(path).st_mtime
    except OSError:
        return 0.0 if _thumb_queue else None
    try:
        found = read_blend_thumbnail(path)
    except Exception as error:          # arquivo estranho: fica o NoPreview
        print("[Hyblend] Home: thumbnail:", path, error)
        found = None
    from ..gpu_ui.framework import renderer
    if found is None:
        renderer.drop_image(THUMB_PREFIX + path)     # salvo de novo sem miniatura: some a antiga
    else:
        import numpy as np
        width, height, rgba = found
        # ImBuf de bytes do Blender = alpha "reto" (não pré-multiplicado): usa direto.
        # Fica em 128 px: o shader amplia com bilinear (image(..., smooth=True)).
        pixels = np.frombuffer(rgba, dtype=np.uint8).astype(np.float32) / 255.0
        renderer.put_pixels(THUMB_PREFIX + path, width, height, pixels)
        from ..gpu_ui import home_host as host
        host.refresh_all()
    return 0.0 if _thumb_queue else None


def cancel_timers():
    if bpy.app.timers.is_registered(_thumb_tick):
        bpy.app.timers.unregister(_thumb_tick)


# --------------------------------------------------------------------------
# Miniatura de dentro do .blend (bloco TEST), Python puro
# --------------------------------------------------------------------------

READ_LIMIT = 4 * 1024 * 1024     # o TEST vem logo no começo; nunca ler o arquivo inteiro


def _open_blend(path):
    """Bytes do começo do .blend, descomprimindo gzip (antigos) ou zstd."""
    with open(path, "rb") as raw:
        magic = raw.read(4)
        raw.seek(0)
        if magic[:2] == b"\x1f\x8b":
            with gzip.GzipFile(fileobj=raw) as gz:
                return gz.read(READ_LIMIT)
        if magic == b"\x28\xb5\x2f\xfd":
            import zstandard          # vem com o Python do Blender
            with zstandard.ZstdDecompressor().stream_reader(raw) as reader:
                chunks, total = [], 0
                while total < READ_LIMIT:
                    chunk = reader.read(min(262144, READ_LIMIT - total))
                    if not chunk:
                        break
                    chunks.append(chunk)
                    total += len(chunk)
                return b"".join(chunks)
        return raw.read(READ_LIMIT)


def read_blend_thumbnail(path):
    """(largura, altura, bytes RGBA linha 0 = base) ou None.

    Dois formatos de cabeçalho:
      * antigo  "BLENDER" + '_'|'-' (ponteiro 4/8) + 'v'|'V' + "405"  (12 bytes)
        BHead = code(4) len(4) old(ptr) SDNAnr(4) nr(4)
      * 5.0+    "BLENDER17-01v0501"  (17 bytes)
        BHead = code(4) SDNAnr(4) old(8) len(8) nr(8)   (32 bytes)
    O TEST guarda int largura, int altura e os pixels RGBA."""
    data = _open_blend(path)
    if not data.startswith(b"BLENDER"):
        return None
    if data[7:8] in (b"_", b"-"):
        pointer = 8 if data[7:8] == b"-" else 4
        endian = "<" if data[8:9] == b"v" else ">"
        pos = 12
        head = struct.Struct(endian + "4si" + ("Q" if pointer == 8 else "I") + "ii")

        def block(at):
            code, length, _old, _sdna, _nr = head.unpack_from(data, at)
            return code, length
    else:
        size = int(data[7:9])                      # "17" = tamanho do cabeçalho
        endian = "<" if data[size - 5:size - 4] == b"v" else ">"
        pos = size
        head = struct.Struct(endian + "4siQqq")

        def block(at):
            code, _sdna, _old, length, _nr = head.unpack_from(data, at)
            return code, length

    for _ in range(64):              # Blender grava REND, TEST, GLOB... logo no começo
        if pos + head.size > len(data):
            return None
        code, length = block(pos)
        body = pos + head.size
        if code == b"TEST":
            if length < 8 or body + length > len(data):
                return None
            width, height = struct.unpack_from(endian + "ii", data, body)
            if not (0 < width <= 2048 and 0 < height <= 2048) or 8 + width * height * 4 > length:
                return None
            rgba = data[body + 8:body + 8 + width * height * 4]
            if not any(rgba[3::4]):          # toda transparente (salvo sem tela): sem miniatura
                return None
            return width, height, rgba
        if code in (b"ENDB", b"DNA1") or length < 0:
            return None
        pos = body + length
    return None


# --------------------------------------------------------------------------
# Formatação
# --------------------------------------------------------------------------

def relative_time(mtime, t, now=None):
    """'há 2 dias' etc. t(key) = função de tradução."""
    if not mtime:
        return ""
    delta = max(0.0, (now or time.time()) - mtime)
    minutes = delta / 60
    if minutes < 2:
        return t("home.time.now")
    if minutes < 60:
        return t("home.time.minutes").format(n=int(minutes))
    hours = minutes / 60
    if hours < 24:
        return t("home.time.hours").format(n=int(hours))
    days = hours / 24
    if days < 2:
        return t("home.time.yesterday")
    if days < 31:
        return t("home.time.days").format(n=int(days))
    if days < 365:
        months = max(1, int(days / 30))
        return t("home.time.month") if months == 1 else t("home.time.months").format(n=months)
    years = int(days / 365)
    return t("home.time.year") if years == 1 else t("home.time.years").format(n=years)


def human_size(size):
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return ("%d %s" % (value, unit)) if unit == "B" else ("%.1f %s" % (value, unit))
        value /= 1024
    return ""
