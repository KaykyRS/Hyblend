"""Auto-Rigger -- Bone Settings: HytaleIKChainItem e operadores de lista (add/remove/move/auto-detect/load defaults)."""

import re

from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import Menu, Operator, PropertyGroup, UIList

from ..common import is_active_armature
from ..templates import get_rig_template
from ..translations import localized_props, tooltip, tr

from .constants import (
    ATTACHMENTS_MAX_COUNT,
    ATTACHMENT_NAME_HINT,
    ROOT_MAX_COUNT,
    SUFFIX_CTRL,
    SUFFIX_IK,
    SUFFIX_MCH,
    TEXTURE_PICKER_EXTRA_BONES_MAX_COUNT,
    _TEMPLATE_NONE,
)

from .helpers import _redraw_all_areas, normalize_org_name, split_side_token
from .rename import BONE_NAME_FIELDS, RENAME_MIDDLE_PROP, RENAME_TOGGLE_PROPS, map_bone_name, renamed_bone_names
from .bone_collections import COLLECTION_OVERRIDE_AUTO, _bone_collection_enum_items, _collection_override_get, _collection_override_set


# Campos de HytaleIKChainItem que vão pro Rig Template. IMPORTANTE: campo novo tem que entrar aqui,
# senão o Save/Load Rig Template descarta o valor em silêncio (já aconteceu várias vezes).
_IK_CHAIN_JSON_FIELDS = (
    "chain_type", "label", "root_bone", "tip_bone", "pole_bone", "parent_override", "side",
    "pole_invert", "pole_distance", "pole_angle_mode",
    "pole_angle_manual", "pole_angle_fine_tune", "tail_tip_rotation_axis", "tail_tip_rotation_deg",
    "tail_use_connect",  # exclusivo de CHAIN -- estava faltando aqui (Save/Load descartava em silêncio)
    "neck_count", "neck_bone_1", "neck_bone_2", "neck_bone_3", "neck_bone_4", "neck_bone_5",
    "head_is_main", "head_bone", "head_end_bone",
    "spine_count", "spine_ctrl_enabled", "pelvis_bone", "spine_bone_1", "spine_bone_2", "spine_bone_3", "spine_bone_4",
    "head_follow_enabled",  # exclusivo de HEAD
    "head_camera_enabled", "head_camera_parent_bone",
    "head_camera_offset_x", "head_camera_offset_y", "head_camera_offset_z",
    "head_camera_rotation_x", "head_camera_rotation_y", "head_camera_rotation_z",
    "head_camera_fov",
    "attachments_count", *(f"attachment_bone_{i}" for i in range(1, ATTACHMENTS_MAX_COUNT + 1)),
    "root_count",
    *(f"root_bone_{i}" for i in range(1, ROOT_MAX_COUNT + 1)),
    *(f"root_create_{i}" for i in range(1, ROOT_MAX_COUNT + 1)),
    # Parte 4 -- caixinhas de "Rename Bones" (uma por campo renomeável +
    # rename_chain_middle), ver rigger/rename.py.
    *RENAME_TOGGLE_PROPS,
    "texture_picker_bone", "texture_picker_ui_parent_bone", "texture_picker_plane_scale", "texture_picker_plane_offset_x", "texture_picker_plane_offset_y",
    "texture_picker_grid_cols", "texture_picker_grid_rows",
    "texture_picker_grid_cell_width", "texture_picker_grid_cell_height",
    "texture_picker_extra_bone_count", *(f"texture_picker_extra_bone_{i}" for i in range(1, TEXTURE_PICKER_EXTRA_BONES_MAX_COUNT + 1)),
    # Salva o nome cru da collection (o Enum dinâmico daria erro com nome que não existe no destino).
    "collection_override_name",
)


def _head_is_main_update(self, context):
    """Main Head é radio button entre as entradas HEAD: marcar desmarca as outras; sem nenhuma marcada,
    resolve_head_chain_item usa a primeira HEAD da lista."""
    if not self.head_is_main or self.chain_type != "HEAD":
        return  # toda entrada nasce com o campo ligado; só HEAD disputa
    obj = context.active_object
    if obj is None or obj.type != "ARMATURE":
        return
    self_ptr = self.as_pointer()
    for other in obj.data.hytale_ik_chains:
        if other.as_pointer() != self_ptr and other.chain_type == "HEAD" and other.head_is_main:
            other.head_is_main = False


def _ik_chain_item_props(lang):
    props = {
        # ARM/LEG/CHAIN criam bones; HEAD/SPINE/ATTACHMENTS/TEXTURE_PICKER só organizam ou referenciam `_CTRL` existentes.
        "chain_type": EnumProperty(
            name="Type",
            description=tr("rigger.prop.ik_chain_chain_type", lang),
            items=[
                ("ARM", "Arm", tr("rigger.prop.ik_chain_chain_type_item_arm", lang)),
                ("LEG", "Leg", tr("rigger.prop.ik_chain_chain_type_item_leg", lang)),
                ("CHAIN", "Chain", tr("rigger.prop.ik_chain_chain_type_item_chain", lang)),
                ("HEAD", "Head", tr("rigger.prop.ik_chain_chain_type_item_head", lang)),
                ("SPINE", "Spine", tr("rigger.prop.ik_chain_chain_type_item_spine", lang)),
                ("ATTACHMENTS", "Attachments", tr("rigger.prop.ik_chain_chain_type_item_attachments", lang)),
                ("TEXTURE_PICKER", "Texture Picker", tr("rigger.prop.ik_chain_chain_type_item_texture_picker", lang)),
                # IMPORTANTE: tipo novo sempre no fim (o .blend guarda o Enum pelo índice).
                ("ROOT", "Root", tr("rigger.prop.ik_chain_chain_type_item_root", lang)),
            ],
            default="ARM",
        ),
        "label": StringProperty(
            name="Label",
            description=tr("rigger.prop.ik_chain_label", lang),
            default="",
        ),
        "root_bone": StringProperty(
            name="Root Bone",
            description=tr("rigger.prop.ik_chain_root_bone", lang),
            default="",
        ),
        "tip_bone": StringProperty(
            name="Tip Bone",
            description=tr("rigger.prop.ik_chain_tip_bone", lang),
            default="",
        ),
        "pole_bone": StringProperty(
            name="Pole Reference",
            description=tr("rigger.prop.ik_chain_pole_bone", lang),
            default="",
        ),
        "parent_override": StringProperty(
            name="Root Parent",
            description=tr("rigger.prop.ik_chain_parent_override", lang),
            default="",
        ),
        "tail_tip_rotation_axis": EnumProperty(
            name="Tip Rotation Axis",
            description=tr("rigger.prop.ik_chain_tail_tip_rotation_axis", lang),
            items=[
                ("X", "X (Local)", tr("rigger.prop.ik_chain_tail_tip_rotation_axis_item_x", lang)),
                ("Y", "Y (Local)", tr("rigger.prop.ik_chain_tail_tip_rotation_axis_item_y", lang)),
                ("Z", "Z (Local)", tr("rigger.prop.ik_chain_tail_tip_rotation_axis_item_z", lang)),
            ],
            default="Z",
        ),
        "tail_tip_rotation_deg": FloatProperty(
            name="Tip Rotation (deg)",
            description=tr("rigger.prop.ik_chain_tail_tip_rotation_deg", lang),
            default=0.0,
        ),
        "tail_use_connect": BoolProperty(
            name="Connected",
            description=tr("rigger.prop.ik_chain_tail_use_connect", lang),
            default=False,
        ),
        "side": EnumProperty(
            name="Side",
            description=tr("rigger.prop.ik_chain_side", lang),
            items=[
                ("LEFT", "Left", ""),
                ("RIGHT", "Right", ""),
                ("CENTER", "Center", ""),
            ],
            default="CENTER",
        ),
        "pole_invert": BoolProperty(
            name="Pole in Front (+Z)",
            description=tr("rigger.prop.ik_chain_pole_invert", lang),
            default=False,
        ),
        "pole_distance": FloatProperty(
            name="Pole Distance",
            description=tr("rigger.prop.ik_chain_pole_distance", lang),
            default=0.35,
            min=0.001,
        ),
        "pole_angle_mode": EnumProperty(
            name="Pole Angle Mode",
            # Números fixos (o .blend guarda o índice): o "PRESET" (1) saiu na
            # 0.9.6 e vira Auto no Create Rig.
            items=[
                ("AUTO", "Auto", tr("rigger.prop.ik_chain_pole_angle_mode_item_auto", lang), 0),
                ("MANUAL", "Manual", tr("rigger.prop.ik_chain_pole_angle_mode_item_manual", lang), 2),
            ],
            default="AUTO",
        ),
        "pole_angle_manual": FloatProperty(
            name="Pole Angle (deg)",
            description=tr("rigger.prop.ik_chain_pole_angle_manual", lang),
            default=90.0,
        ),
        "pole_angle_fine_tune": FloatProperty(
            name="Pole Angle Fine-Tune (deg)",
            description=tr("rigger.prop.ik_chain_pole_angle_fine_tune", lang),
            default=0.0,
        ),
        "neck_count": IntProperty(
            name="Neck Bones Amount",
            description=tr("rigger.prop.ik_chain_neck_count", lang),
            default=1, min=0, max=5,
        ),
        "neck_bone_1": StringProperty(
            name="Neck", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        "neck_bone_2": StringProperty(
            name="Neck 2", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        "neck_bone_3": StringProperty(
            name="Neck 3", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        "neck_bone_4": StringProperty(
            name="Neck 4", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        "neck_bone_5": StringProperty(
            name="Neck 5", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        "head_bone": StringProperty(
            name="Head",
            description=tr("rigger.prop.ik_chain_head_bone", lang),
            default="",
        ),
        "head_end_bone": StringProperty(
            name="Head End",
            description=tr("rigger.prop.ik_chain_head_end_bone", lang),
            default="",
        ),
        "spine_count": IntProperty(
            name="Spine Amount",
            description=tr("rigger.prop.ik_chain_spine_count", lang),
            default=3, min=1, max=5,
        ),
        # Liga/desliga root.spine_CTRL e o Spine Follow (padrão True).
        "spine_ctrl_enabled": BoolProperty(
            name="Create root.spine_CTRL",
            description=tr("rigger.prop.ik_chain_spine_ctrl_enabled", lang),
            default=True,
        ),
        "pelvis_bone": StringProperty(
            name="Pelvis", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        "spine_bone_1": StringProperty(
            name="Spine1", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        "spine_bone_2": StringProperty(
            name="Spine2", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        "spine_bone_3": StringProperty(
            name="Spine3", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        "spine_bone_4": StringProperty(
            name="Spine4", description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang), default=""
        ),
        # Main Head (radio entre HEADs): True só na 1ª HEAD adicionada (os operadores de adicionar forçam isso).
        "head_is_main": BoolProperty(
            name="Main Head",
            description=tr("rigger.prop.ik_chain_head_is_main", lang),
            default=True,
            update=_head_is_main_update,
        ),
        # TODO (documentado a pedido do usuário, não implementado): Head Free/Lock só funciona na Main Head;
        # numa HEAD secundária o checkbox não faz nada (o switch é uma só custom property no PROPERTIES).
        # Plano pra várias cabeças: 1) _apply_head_follow_parent itera toda HEAD com head_bone;
        # 2) switch por cabeça (ex.: f"{PROP_HEAD_FOLLOW_SWITCH}__{head_bone}"); 3) _build_head_follow e
        # _apply_pole_childof_inverses recebem uma lista por cabeça; 4) anim_tools acha o switch pelo Head_CTRL selecionado.
        "head_follow_enabled": BoolProperty(
            name="Head Free/Lock",
            description=tr("rigger.prop.ik_chain_head_follow_enabled", lang),
            default=False,
        ),
        "head_camera_enabled": BoolProperty(
            name="Create First Person Camera",
            description=tr("rigger.prop.ik_chain_head_camera_enabled", lang),
            default=False,
        ),
        "head_camera_parent_bone": StringProperty(
            name="Camera Parent Bone",
            description=tr("rigger.prop.ik_chain_head_camera_parent_bone", lang),
            default="",
        ),
        "head_camera_offset_x": FloatProperty(
            name="Camera Offset X", default=0.0,
            description=tr("rigger.prop.ik_chain_head_camera_offset_x", lang),
        ),
        "head_camera_offset_y": FloatProperty(
            name="Camera Offset Y", default=0.0,
            description=tr("rigger.prop.ik_chain_head_camera_offset_y", lang),
        ),
        "head_camera_offset_z": FloatProperty(
            name="Camera Offset Z", default=0.0,
            description=tr("rigger.prop.ik_chain_head_camera_offset_z", lang),
        ),
        "head_camera_rotation_x": FloatProperty(
            name="Camera Rotation X (deg)", default=0.0,
            description=tr("rigger.prop.ik_chain_head_camera_rotation_x", lang),
        ),
        "head_camera_rotation_y": FloatProperty(
            name="Camera Rotation Y (deg)", default=180.0,
            description=tr("rigger.prop.ik_chain_head_camera_rotation_y", lang),
        ),
        "head_camera_rotation_z": FloatProperty(
            name="Camera Rotation Z (deg)", default=0.0,
            description=tr("rigger.prop.ik_chain_head_camera_rotation_z", lang),
        ),
        "head_camera_fov": FloatProperty(
            name="Camera FOV (deg)", default=90.0, min=1.0, max=179.0,
            description=tr("rigger.prop.ik_chain_head_camera_fov", lang),
        ),
        "attachments_count": IntProperty(
            name="Attachments Bones Amount",
            description=tr("rigger.prop.ik_chain_attachments_count", lang).format(max=ATTACHMENTS_MAX_COUNT),
            default=1, min=0, max=ATTACHMENTS_MAX_COUNT,
        ),
    }
    for _i in range(1, ATTACHMENTS_MAX_COUNT + 1):
        props[f"attachment_bone_{_i}"] = StringProperty(
            name="Attachment" if _i == 1 else f"Attachment {_i}",
            description=tr("rigger.prop.ik_chain_org_bone_name_hint", lang),
            default="",
        )
    # ROOT: Root 1 = Origin principal; Root 2 vira pai do Root 1... (só na camada `_CTRL`); "New Bone" cria o bone.
    props["root_count"] = IntProperty(
        name="Root Bones Amount",
        description=tr("rigger.prop.ik_chain_root_count", lang).format(max=ROOT_MAX_COUNT),
        default=1, min=1, max=ROOT_MAX_COUNT,
    )
    for _i in range(1, ROOT_MAX_COUNT + 1):
        props[f"root_bone_{_i}"] = StringProperty(
            name="Origin" if _i == 1 else f"Root {_i}",
            description=tr("rigger.prop.ik_chain_root_slot_bone", lang),
            default="",
        )
        props[f"root_create_{_i}"] = BoolProperty(
            name="New Bone",
            description=tr("rigger.prop.ik_chain_root_create", lang),
            default=False,
        )
    # "Rename Bones" -- caixinha por campo renomeável (ligada = o bone
    # ganha o nome padrão do Hytale; desligada = mantém o original).
    for _toggle in RENAME_TOGGLE_PROPS:
        props[_toggle] = BoolProperty(
            name="Rename",
            description=tr(
                "rigger.prop.ik_chain_rename_middle" if _toggle == RENAME_MIDDLE_PROP
                else "rigger.prop.ik_chain_rename_field",
                lang,
            ),
            default=True,
        )
    props.update({
        "texture_picker_bone": StringProperty(
            name="Target Bone",
            description=tr("rigger.prop.ik_chain_texture_picker_bone", lang),
            default="",
        ),
        "texture_picker_ui_parent_bone": StringProperty(
            name="Root Bone",
            description=tr("rigger.prop.ik_chain_texture_picker_ui_parent_bone", lang),
            default="",
        ),
        "texture_picker_plane_scale": FloatProperty(
            name="Atlas Plane Scale",
            description=tr("rigger.prop.ik_chain_texture_picker_plane_scale", lang),
            default=1.0, min=0.001,
        ),
        "texture_picker_plane_offset_x": FloatProperty(
            name="Atlas Plane Offset X", default=0.0,
            description=tr("rigger.prop.ik_chain_texture_picker_plane_offset_x", lang),
        ),
        "texture_picker_plane_offset_y": FloatProperty(
            name="Atlas Plane Offset Y", default=0.0,
            description=tr("rigger.prop.ik_chain_texture_picker_plane_offset_y", lang),
        ),
        "texture_picker_grid_cols": IntProperty(
            name="Grid Columns",
            description=tr("rigger.prop.ik_chain_texture_picker_grid_cols", lang),
            default=1, min=1,
        ),
        "texture_picker_grid_rows": IntProperty(
            name="Grid Rows",
            description=tr("rigger.prop.ik_chain_texture_picker_grid_rows", lang),
            default=1, min=1,
        ),
        "texture_picker_grid_cell_width": IntProperty(
            name="Cell Width",
            description=tr("rigger.prop.ik_chain_texture_picker_grid_cell_width", lang),
            default=16, min=1,
        ),
        "texture_picker_grid_cell_height": IntProperty(
            name="Cell Height",
            description=tr("rigger.prop.ik_chain_texture_picker_grid_cell_height", lang),
            default=16, min=1,
        ),
        "texture_picker_extra_bone_count": IntProperty(
            name="Companion Bones Amount",
            description=tr("rigger.prop.ik_chain_texture_picker_extra_bone_count", lang).format(
                max=TEXTURE_PICKER_EXTRA_BONES_MAX_COUNT
            ),
            default=0, min=0, max=TEXTURE_PICKER_EXTRA_BONES_MAX_COUNT,
        ),
    })
    for _i in range(1, TEXTURE_PICKER_EXTRA_BONES_MAX_COUNT + 1):
        props[f"texture_picker_extra_bone_{_i}"] = StringProperty(
            name="Companion Bone" if _i == 1 else f"Companion Bone {_i}",
            description=tr("rigger.prop.ik_chain_texture_picker_extra_bone", lang),
            default="",
        )
    # Valor de verdade (nome, imune a reordenar o Collection Settings); nunca desenhado.
    props["collection_override_name"] = StringProperty(
        name="Collection (internal)",
        description="Internal storage for the Collection override -- not shown in the UI.",
        default=COLLECTION_OVERRIDE_AUTO,
        options={"HIDDEN"},
    )
    props["collection_override"] = EnumProperty(
        name="Collection",
        description=tr("rigger.prop.ik_chain_collection_override", lang),
        items=_bone_collection_enum_items,
        get=_collection_override_get,
        set=_collection_override_set,
    )
    return props


@localized_props(_ik_chain_item_props)
class HytaleIKChainItem(PropertyGroup):
    pass


# --- Operadores: gerenciar a lista de Bone Settings ---


def _unique_bone_setting_label(chains, base_label, ignore_index=None):
    """`base_label`, ou com sufixo ".001"... só se já existir na lista (fora `ignore_index`)."""
    existing = {
        item.label
        for i, item in enumerate(chains)
        if item.label and i != ignore_index
    }
    if base_label not in existing:
        return base_label
    n = 1
    while True:
        candidate = f"{base_label}.{n:03d}"
        if candidate not in existing:
            return candidate
        n += 1


def _init_head_is_main(item, chains):
    """head_is_main inicial de uma HEAD nova: True só se for a única HEAD da lista."""
    item_ptr = item.as_pointer()
    has_other_head = any(
        c.as_pointer() != item_ptr and c.chain_type == "HEAD" for c in chains
    )
    item.head_is_main = not has_other_head


class RIG_OT_hytale_ik_chain_add(Operator):
    """Adiciona uma entrada vazia do `chain_type` escolhido no menu do "+"."""

    bl_idname = "armature.hytale_ik_chain_add"
    bl_label = "Add Hytale Bone Setting"
    description = tooltip("rigger.tooltip.ik_chain_add")
    bl_options = {"REGISTER", "UNDO"}

    chain_type: StringProperty(default="ARM")

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def execute(self, context):
        armature = context.active_object.data
        chains = armature.hytale_ik_chains
        item = chains.add()
        # Valida contra os tipos conhecidos -- o menu popup manda uma
        # string crua, nunca deixa a entrada num estado inválido.
        item.chain_type = self.chain_type if self.chain_type in {"ROOT", "ARM", "LEG", "CHAIN", "HEAD", "SPINE", "ATTACHMENTS", "TEXTURE_PICKER"} else "ARM"
        if item.chain_type == "HEAD":
            _init_head_is_main(item, chains)
        prefix = {"ROOT": "Root", "ARM": "Arm", "LEG": "Leg", "CHAIN": "Chain", "HEAD": "Head", "SPINE": "Spine", "ATTACHMENTS": "Attachments", "TEXTURE_PICKER": "Texture Picker"}.get(item.chain_type, "Chain")
        item.label = _unique_bone_setting_label(chains, prefix)
        armature.hytale_ik_chains_index = len(chains) - 1
        _redraw_all_areas(context)
        return {"FINISHED"}


class RIG_MT_hytale_ik_chain_add_menu(Menu):
    """Menu do "+" da lista: escolhe o tipo antes de adicionar."""

    bl_idname = "RIG_MT_hytale_ik_chain_add_menu"
    bl_label = "Add Bone Setting"
    description = tooltip("rigger.tooltip.ik_chain_add_menu")

    def draw(self, context):
        layout = self.layout
        # Ordem pedida explicitamente: Head -> Spine -> Arm -> Leg ->
        # Chain -> Root -> Attachments -> Texture Picker.
        layout.operator(
            RIG_OT_hytale_ik_chain_add.bl_idname, text="Head", icon="USER"
        ).chain_type = "HEAD"
        layout.operator(
            RIG_OT_hytale_ik_chain_add.bl_idname, text="Spine", icon="BONE_DATA"
        ).chain_type = "SPINE"
        layout.operator(
            RIG_OT_hytale_ik_chain_add.bl_idname, text="Arm", icon="CON_KINEMATIC"
        ).chain_type = "ARM"
        layout.operator(
            RIG_OT_hytale_ik_chain_add.bl_idname, text="Leg", icon="CON_KINEMATIC"
        ).chain_type = "LEG"
        layout.operator(
            RIG_OT_hytale_ik_chain_add.bl_idname, text="Chain", icon="PHYSICS"
        ).chain_type = "CHAIN"
        layout.operator(
            RIG_OT_hytale_ik_chain_add.bl_idname, text="Root", icon="OBJECT_ORIGIN"
        ).chain_type = "ROOT"
        layout.operator(
            RIG_OT_hytale_ik_chain_add.bl_idname, text="Attachments", icon="LINKED"
        ).chain_type = "ATTACHMENTS"
        layout.operator(
            RIG_OT_hytale_ik_chain_add.bl_idname, text="Texture Picker", icon="IMAGE_DATA"
        ).chain_type = "TEXTURE_PICKER"


class RIG_OT_hytale_ik_chain_remove(Operator):
    """Remove uma cadeia da lista pelo índice (padrão: a ativa)."""

    bl_idname = "armature.hytale_ik_chain_remove"
    bl_label = "Remove Hytale IK Chain"
    description = tooltip("rigger.tooltip.ik_chain_remove")
    bl_options = {"REGISTER", "UNDO"}

    index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return is_active_armature(context) and len(obj.data.hytale_ik_chains) > 0

    def execute(self, context):
        armature = context.active_object.data
        chains = armature.hytale_ik_chains
        index = self.index if self.index >= 0 else armature.hytale_ik_chains_index
        if 0 <= index < len(chains):
            chains.remove(index)
            armature.hytale_ik_chains_index = max(0, min(armature.hytale_ik_chains_index, len(chains) - 1))
        _redraw_all_areas(context)
        return {"FINISHED"}


def _ik_chain_move_props(lang):
    return {
        "direction": EnumProperty(
            items=(
                ("UP", "Up", tr("rigger.prop.ik_chain_move_direction_item_up", lang)),
                ("DOWN", "Down", tr("rigger.prop.ik_chain_move_direction_item_down", lang)),
            ),
            default="UP",
        ),
    }


@localized_props(_ik_chain_move_props)
class RIG_OT_hytale_ik_chain_move(Operator):
    """Move uma entrada pra cima/baixo (só a ordem na lista; não muda a geração)."""

    bl_idname = "armature.hytale_ik_chain_move"
    bl_label = "Move Hytale Bone Setting"
    description = tooltip("rigger.tooltip.ik_chain_move")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return is_active_armature(context) and len(obj.data.hytale_ik_chains) > 1

    def execute(self, context):
        armature = context.active_object.data
        chains = armature.hytale_ik_chains
        index = armature.hytale_ik_chains_index
        target = index - 1 if self.direction == "UP" else index + 1
        if not (0 <= target < len(chains)):
            return {"CANCELLED"}
        chains.move(index, target)
        armature.hytale_ik_chains_index = target
        _redraw_all_areas(context)
        return {"FINISHED"}


class RIG_OT_hytale_ik_chain_set_count(Operator):
    """Deixa a lista com `count` itens (adiciona/remove no fim), do `chain_type` dado; pra uso por script."""

    bl_idname = "armature.hytale_ik_chain_set_count"
    bl_label = "Set Hytale IK Chain Count"
    description = tooltip("rigger.tooltip.ik_chain_set_count")
    bl_options = {"REGISTER", "UNDO"}

    count: IntProperty(name="Amount", default=1, min=0)
    chain_type: StringProperty(default="ARM")

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def execute(self, context):
        armature = context.active_object.data
        chains = armature.hytale_ik_chains
        chain_type = self.chain_type if self.chain_type in {"ROOT", "ARM", "LEG", "CHAIN", "HEAD", "SPINE", "ATTACHMENTS", "TEXTURE_PICKER"} else "ARM"
        prefix = {"ROOT": "Root", "ARM": "Arm", "LEG": "Leg", "CHAIN": "Chain", "HEAD": "Head", "SPINE": "Spine", "ATTACHMENTS": "Attachments", "TEXTURE_PICKER": "Texture Picker"}.get(chain_type, "Chain")
        while len(chains) < self.count:
            item = chains.add()
            item.chain_type = chain_type
            if chain_type == "HEAD":
                _init_head_is_main(item, chains)
            # v0.13 -- mesmo fix de RIG_OT_hytale_ik_chain_add: sufixo só
            # quando já existe outro item com esse label exato.
            item.label = _unique_bone_setting_label(chains, prefix)
        while len(chains) > self.count:
            chains.remove(len(chains) - 1)
        _redraw_all_areas(context)
        return {"FINISHED"}


class RIG_OT_hytale_ik_chain_pick_bone(Operator):
    """Copia o bone ativo pro campo (`field`) da entrada `chain_index` (botão de conta-gotas)."""

    bl_idname = "armature.hytale_ik_chain_pick_bone"
    bl_label = "Pick Bone From Selection"
    description = tooltip("rigger.tooltip.ik_chain_pick_bone")
    bl_options = {"REGISTER", "UNDO"}

    chain_index: IntProperty(default=-1)
    field: StringProperty(default="root_bone")

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def execute(self, context):
        obj = context.active_object
        bone_name = None
        if context.mode == "EDIT_ARMATURE" and context.active_bone is not None:
            bone_name = context.active_bone.name
        elif context.mode == "POSE" and context.active_pose_bone is not None:
            bone_name = context.active_pose_bone.name
        elif obj.data.bones.active is not None:
            bone_name = obj.data.bones.active.name

        if not bone_name:
            self.report({"WARNING"}, "No active bone to pick -- select one in Edit or Pose Mode first.")
            return {"CANCELLED"}

        chains = obj.data.hytale_ik_chains
        index = self.chain_index if self.chain_index >= 0 else obj.data.hytale_ik_chains_index
        if not (0 <= index < len(chains)):
            self.report({"WARNING"}, "Invalid IK chain index.")
            return {"CANCELLED"}
        allowed_fields = {
            "root_bone", "tip_bone", "pole_bone", "parent_override",
            "neck_bone_1", "neck_bone_2", "neck_bone_3", "neck_bone_4", "neck_bone_5",
            "head_bone", "head_end_bone",
            "pelvis_bone", "spine_bone_1", "spine_bone_2", "spine_bone_3", "spine_bone_4",
            *{f"attachment_bone_{i}" for i in range(1, ATTACHMENTS_MAX_COUNT + 1)},
            *{f"root_bone_{i}" for i in range(1, ROOT_MAX_COUNT + 1)},
            "texture_picker_bone",
            "texture_picker_ui_parent_bone",
            "head_camera_parent_bone",
            *{f"texture_picker_extra_bone_{i}" for i in range(1, TEXTURE_PICKER_EXTRA_BONES_MAX_COUNT + 1)},
        }
        if self.field not in allowed_fields:
            self.report({"WARNING"}, f"Unknown field '{self.field}'.")
            return {"CANCELLED"}

        # Pose Mode: o ativo costuma ser o `_CTRL`; o campo guarda o ORG dele (no Root Parent o `_CTRL` vale).
        if self.field != "parent_override":
            bone_name = normalize_org_name(obj.data.bones, bone_name)
        setattr(chains[index], self.field, bone_name)
        self.report({"INFO"}, f"{self.field} = '{bone_name}'.")
        return {"FINISHED"}


# --- Auto-Detect Bones: palpite por nome pros 6 slots previsíveis (Head, Spine, Arm L/R, Leg L/R) ---

# "L-"/"R-" é a convenção oficial; os outros tokens são fallback pra
# mods que não seguem essa convenção. Ordem importa (mais específico primeiro).
def _auto_detect_split_side(bone_name):
    """(lado, base em minúsculo sem o token de lado); ex.: "L-Forearm" -> ("LEFT", "forearm")."""
    return split_side_token(bone_name)


def _auto_detect_is_excluded_bone(name):
    """Bone que nunca é candidato: gerado pelo rig (_CTRL/_MCH/_IK) ou attachment; vale também nas varreduras de hierarquia."""
    lower = name.lower()
    if name.endswith(SUFFIX_CTRL) or name.endswith(SUFFIX_MCH) or name.endswith(SUFFIX_IK):
        return True
    return ATTACHMENT_NAME_HINT in lower


def _auto_detect_candidates(armature_data):
    """[(bone, lado, base)] dos ORG candidatos."""
    out = []
    for bone in armature_data.bones:
        name = bone.name
        if _auto_detect_is_excluded_bone(name):
            continue
        side, base = _auto_detect_split_side(name)
        out.append((name, side, base))
    return out


def _auto_detect_pick(candidates, keywords, exclude_keywords=(), side=None):
    """1º candidato com alguma de `keywords` (e nenhuma de `exclude_keywords`) no base; o igual à keyword vence
    substring. side=None aceita qualquer lado."""
    exact = None
    loose = None
    for name, cand_side, base in candidates:
        if side is not None and cand_side != side:
            continue
        if any(bad in base for bad in exclude_keywords):
            continue
        for kw in keywords:
            if base == kw:
                if exact is None:
                    exact = name
                break
            if kw in base:
                if loose is None:
                    loose = name
                break
    return exact or loose


def _auto_detect_pick_multi(candidates, keywords, exclude_keywords=(), side=None):
    """Todos os candidatos que batem (fallback de Neck/Spine sem hierarquia esperada)."""
    found = []
    seen = set()
    for name, cand_side, base in candidates:
        if side is not None and cand_side != side:
            continue
        if any(bad in base for bad in exclude_keywords):
            continue
        if any(kw in base for kw in keywords) and name not in seen:
            found.append(name)
            seen.add(name)
    return found


def _auto_detect_natural_sort_key(name):
    """Ordem natural ("Spine2" antes de "Spine10")."""
    return [int(tok) if tok.isdigit() else tok.lower() for tok in re.split(r"(\d+)", name)]


def _auto_detect_walk_down(bone, keywords, exclude_keywords=()):
    """Desce de `bone` (não incluso) pelo 1º filho que bate com `keywords` (ex.: Pelvis -> Belly -> Chest); raiz -> ponta."""
    out = []
    node = bone
    while node is not None:
        nxt = None
        for child in node.children:
            if _auto_detect_is_excluded_bone(child.name):
                continue
            child_base = child.name.lower()
            if any(bad in child_base for bad in exclude_keywords):
                continue
            if any(kw in child_base for kw in keywords):
                nxt = child
                break
        if nxt is None:
            break
        out.append(nxt.name)
        node = nxt
    return out


def _auto_detect_walk_up(bone, keywords, exclude_keywords=()):
    """Sobe do pai de `bone` enquanto bater com `keywords` (Neck a partir do Head); raiz -> ponta."""
    out = []
    node = bone.parent if bone is not None else None
    while node is not None:
        if _auto_detect_is_excluded_bone(node.name):
            break
        base = node.name.lower()
        if any(bad in base for bad in exclude_keywords):
            break
        if not any(kw in base for kw in keywords):
            break
        out.append(node.name)
        node = node.parent
    out.reverse()
    return out


def _auto_detect_bone_settings(armature_data):
    """Palpite por slot: {"HEAD"/"SPINE" ou ("ARM"/"LEG", lado): {campo: valor}}, só com o bone principal achado."""
    candidates = _auto_detect_candidates(armature_data)
    bones = armature_data.bones
    results = {}

    # --- Head / Neck --------------------------------------------------
    head_name = _auto_detect_pick(candidates, ("head",), exclude_keywords=("forehead",))
    if head_name:
        entry = {"head_bone": head_name}
        head_bone_obj = bones.get(head_name)
        neck_names = _auto_detect_walk_up(head_bone_obj, ("neck",)) if head_bone_obj else []
        if not neck_names:
            neck_names = sorted(
                _auto_detect_pick_multi(candidates, ("neck",)),
                key=_auto_detect_natural_sort_key,
            )
        for i, n in enumerate(neck_names[:5], start=1):
            entry[f"neck_bone_{i}"] = n
        if neck_names:
            entry["neck_count"] = min(len(neck_names), 5)
        results["HEAD"] = entry

    # --- Spine ----------------------------------------------------------
    pelvis_name = _auto_detect_pick(candidates, ("pelvis", "hips", "hip"))
    spine_names = []
    if pelvis_name:
        pelvis_obj = bones.get(pelvis_name)
        if pelvis_obj is not None:
            spine_names = _auto_detect_walk_down(pelvis_obj, ("spine", "belly", "chest", "torso"))
    if not spine_names:
        spine_names = sorted(
            _auto_detect_pick_multi(candidates, ("spine", "belly", "chest", "torso")),
            key=_auto_detect_natural_sort_key,
        )
    if pelvis_name or spine_names:
        entry = {}
        if pelvis_name:
            entry["pelvis_bone"] = pelvis_name
        for i, n in enumerate(spine_names[:4], start=1):
            entry[f"spine_bone_{i}"] = n
        if pelvis_name or spine_names:
            # Conta o Pelvis junto: 1 (se achado) + segmentos, teto 5.
            entry["spine_count"] = max(1, (1 if pelvis_name else 0) + min(len(spine_names), 4))
        results["SPINE"] = entry

    # --- Arm / Leg, por lado (exclude_keywords evita equipamento, ex.: "L-Handle") ---
    for side in ("LEFT", "RIGHT"):
        forearm = _auto_detect_pick(candidates, ("forearm", "lowerarm"), side=side)
        hand = _auto_detect_pick(candidates, ("hand",), exclude_keywords=("handle",), side=side)
        arm = _auto_detect_pick(
            candidates, ("upperarm", "arm"),
            exclude_keywords=("forearm", "lowerarm", "armor", "armour"), side=side,
        )
        if arm and hand:
            entry = {"root_bone": arm, "tip_bone": hand, "side": side}
            if forearm:
                entry["pole_bone"] = forearm
            shoulder = _auto_detect_pick(candidates, ("shoulder", "clavicle"), side=side)
            if shoulder:
                entry["parent_override"] = shoulder
            results[("ARM", side)] = entry

        calf = _auto_detect_pick(candidates, ("calf", "shin", "lowerleg", "knee"), side=side)
        foot = _auto_detect_pick(candidates, ("foot", "feet"), side=side)
        thigh = _auto_detect_pick(
            candidates, ("thigh", "upperleg", "leg"),
            exclude_keywords=("calf", "shin", "lowerleg"), side=side,
        )
        if thigh and foot:
            entry = {"root_bone": thigh, "tip_bone": foot, "side": side}
            if calf:
                entry["pole_bone"] = calf
            if pelvis_name:
                entry["parent_override"] = pelvis_name  # nome ORG puro, sem "_CTRL"
            results[("LEG", side)] = entry

    return results


class RIG_OT_hytale_ik_chain_auto_detect(Operator):
    """Preenche o Bone Settings por nome (Head, Spine, Arm L/R, Leg L/R); heurístico, confira antes do Create Rig.
    Nunca sobrescreve entrada existente do mesmo tipo/lado."""

    bl_idname = "armature.hytale_ik_chain_auto_detect"
    bl_label = "Auto-Detect Bone Settings"
    description = tooltip("rigger.tooltip.ik_chain_auto_detect")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def execute(self, context):
        armature = context.active_object.data
        chains = armature.hytale_ik_chains
        detected = _auto_detect_bone_settings(armature)

        existing_head = any(c.chain_type == "HEAD" for c in chains)
        existing_spine = any(c.chain_type == "SPINE" for c in chains)
        existing_sides = {
            (c.chain_type, c.side) for c in chains if c.chain_type in ("ARM", "LEG")
        }

        added = []
        skipped = []

        def _add_entry(chain_type, label_prefix, fields):
            item = chains.add()
            item.chain_type = chain_type
            if chain_type == "HEAD":
                _init_head_is_main(item, chains)
            item.label = _unique_bone_setting_label(chains, label_prefix)
            for key, value in fields.items():
                setattr(item, key, value)
            armature.hytale_ik_chains_index = len(chains) - 1
            added.append(item.label)

        if "HEAD" in detected:
            if existing_head:
                skipped.append("Head")
            else:
                _add_entry("HEAD", "Head", detected["HEAD"])

        if "SPINE" in detected:
            if existing_spine:
                skipped.append("Spine")
            else:
                _add_entry("SPINE", "Spine", detected["SPINE"])

        side_suffix = {"LEFT": "L", "RIGHT": "R"}
        for chain_type, limb_label in (("ARM", "Arm"), ("LEG", "Leg")):
            for side in ("LEFT", "RIGHT"):
                key = (chain_type, side)
                if key not in detected:
                    continue
                if (chain_type, side) in existing_sides:
                    skipped.append(f"{limb_label} {side_suffix[side]}")
                    continue
                _add_entry(chain_type, f"{limb_label} {side_suffix[side]}", detected[key])

        _redraw_all_areas(context)

        if not added and not skipped:
            self.report(
                {"WARNING"},
                "Could not recognize any Head/Spine/Arm/Leg bones on this armature -- "
                "the bone names may not follow a supported naming convention.",
            )
            return {"CANCELLED"}

        msg_parts = []
        if added:
            msg_parts.append(f"added {', '.join(added)}")
        if skipped:
            msg_parts.append(f"already had {', '.join(skipped)} (skipped)")
        self.report({"INFO"}, "Auto-Detect Bone Settings: " + "; ".join(msg_parts) + ".")
        return {"FINISHED"}


def _ik_chain_load_defaults_props(lang):
    return {
        "preset": StringProperty(
            name="Preset",
            default="",
            description=tr("rigger.prop.ik_chain_load_defaults_preset", lang),
            options={"HIDDEN", "SKIP_SAVE"},
        ),
    }


_UNCHECKED_FIELDS = {"parent_override", "texture_picker_bone"}
_NUMBERED_FIELD_COUNTS = {
    "neck_bone": "neck_count", "spine_bone": "spine_count", "attachment_bone": "attachments_count",
    "root_bone": "root_count",
}


def _missing_template_bones(armature):
    """Bones do Bone Settings que não existem nesta Armature (fora os criados pelo Create Rig e os alvos do Texture Picker)."""
    bones = armature.bones
    missing = []
    for item in armature.hytale_ik_chains:
        for field in BONE_NAME_FIELDS:
            name = (getattr(item, field, "") or "").strip()
            if (not name or name in missing or name.endswith("_CTRL") or field in _UNCHECKED_FIELDS
                    or field.startswith("texture_picker_extra_bone_")):
                continue
            prefix, _sep, index = field.rpartition("_")
            if index.isdigit():
                count_prop = _NUMBERED_FIELD_COUNTS.get(prefix)
                if count_prop and int(index) > getattr(item, count_prop, 0):
                    continue  # campo acima da quantidade em uso -- resto antigo
                if prefix == "root_bone" and getattr(item, f"root_create_{index}", False):
                    continue
            if bones.get(name) is None:
                missing.append(name)
    return missing


@localized_props(_ik_chain_load_defaults_props)
class RIG_OT_hytale_ik_chain_load_defaults(Operator):
    """Carrega um Rig Template (templates/rig/*.json, builtin + Documentos/Hyblend) substituindo a lista.
    "(none)" limpa a lista e o rig template ativo. Não mexe no Shape Template."""

    bl_idname = "armature.hytale_ik_chain_load_defaults"
    bl_label = "Load Hytale IK Chain Preset"
    description = tooltip("rigger.tooltip.ik_chain_load_defaults")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def execute(self, context):
        preset_name = self.preset or context.window_manager.hytale_rig_template_selected
        if not preset_name:
            self.report({"WARNING"}, "No rig template selected.")
            return {"CANCELLED"}
        if preset_name == _TEMPLATE_NONE:
            # "(none)": limpa a lista e o rig template ativo.
            armature = context.active_object.data
            chain_count = len(armature.hytale_ik_chains)
            armature.hytale_ik_chains.clear()
            armature.hytale_active_rig_template = ""
            self.report(
                {"INFO"},
                f"Rig template cleared -- removed {chain_count} IK chain(s). "
                f"Add chains manually or load a template to start again.",
            )
            return {"FINISHED"}

        template = get_rig_template(preset_name)
        entries = template.get("ik_chains") if template else None
        if not entries:
            self.report({"WARNING"}, f"Unknown or empty rig template '{preset_name}'.")
            return {"CANCELLED"}

        armature = context.active_object.data
        chains = armature.hytale_ik_chains
        chains.clear()
        # Referencia a mesma tupla que Save usa -- só um lugar pra
        # atualizar quando um chain_type novo ganhar campos próprios.
        chain_fields = set(_IK_CHAIN_JSON_FIELDS)
        # O template guarda o nome do MODELO; numa Armature que já passou
        # pelo Rename Bones, troca pelo nome atual.
        to_current_names = {original: current for current, original in renamed_bone_names(armature).items()}
        for entry in entries:
            entry = dict(entry)
            for field in BONE_NAME_FIELDS:
                current = map_bone_name(entry.get(field), to_current_names)
                if current is not None:
                    entry[field] = current
            item = chains.add()
            for key, value in entry.items():
                if key not in chain_fields:
                    continue  # campo desconhecido no .json (typo, versão futura) -- ignora em vez de quebrar
                # Modos removidos na 0.9.6 ("PRESET", e o "ARM" cru de
                # templates ainda mais antigos) viram Auto.
                if key == "pole_angle_mode" and value not in ("AUTO", "MANUAL"):
                    value = "AUTO"
                setattr(item, key, value)
            if "chain_type" not in entry:
                # Template antigo sem chain_type: adivinha pelo label/root_bone.
                guess = (item.label or item.root_bone or "").lower().replace("ç", "c").replace("ã", "a")
                if "leg" in guess or "perna" in guess or "thigh" in guess:
                    item.chain_type = "LEG"
                elif "tail" in guess or "cauda" in guess:
                    item.chain_type = "CHAIN"

        # No máximo uma HEAD com head_is_main (templates antigos não têm o campo): fica a primeira.
        seen_main_head = False
        for item in chains:
            if item.chain_type != "HEAD":
                continue
            if item.head_is_main and not seen_main_head:
                seen_main_head = True
            elif item.head_is_main:
                item.head_is_main = False

        # Ausente no .json (template antigo) = ligado, o padrão da opção.
        armature.hytale_ctrl_tail_to_child = bool(template.get("ctrl_tail_to_child", True))
        if "rename_enabled" in template:
            armature.hytale_rename_enabled = bool(template["rename_enabled"])
        if template.get("rename_mode") in ("ALL_BONES", "ONLY_CTRL"):
            armature.hytale_rename_mode = template["rename_mode"]
        missing = _missing_template_bones(armature)
        if missing:
            self.report(
                {"WARNING"},
                f"{len(missing)} bone(s) from this template don't exist on this armature: "
                f"{', '.join(missing[:6])}{'...' if len(missing) > 6 else ''} -- fix them in Bone Settings "
                f"(different character?).",
            )
        armature.hytale_active_rig_template = preset_name

        self.report({"INFO"}, f"Loaded rig template '{preset_name}' ({len(entries)} chain(s)).")
        return {"FINISHED"}


_CHAIN_TYPE_ICON = {
    "ROOT": "OBJECT_ORIGIN",
    "ARM": "CON_KINEMATIC", "LEG": "CON_KINEMATIC", "CHAIN": "PHYSICS",
    "HEAD": "USER", "SPINE": "BONE_DATA", "ATTACHMENTS": "LINKED",
    "TEXTURE_PICKER": "IMAGE_DATA",
}


class RIG_UL_hytale_ik_chains(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(
            item, "label", text="", emboss=False,
            icon=_CHAIN_TYPE_ICON.get(item.chain_type, "BONE_DATA"),
        )
