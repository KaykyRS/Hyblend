"""common.py -- constantes e utilitarios de baixo nivel compartilhados por
todo o resto do addon (preferences.py, picker.py, presets_ops.py,
player_ops.py, interface/). Fica no topo da hierarquia de import de
proposito: os UNICOS imports internos sao compat.py (camada 0, que so
depende de bpy) e scanner/hytale_install.py (Python puro, mapa da pasta
do jogo) -- nada mais deste pacote, pra nao criar dependencia circular (mesma razao do common.py do Hyblend
existir separado do resto).

ADDON_PACKAGE precisa ficar aqui (nao em __init__.py) por um motivo
tecnico especifico: se ficasse dentro de __init__.py, qualquer submodulo
que precisasse dele criaria um import circular (__init__.py importa dos
submodulos, os submodulos importariam de volta de __init__.py). Como
modulo comum (pkg/common.py), `__package__` AINDA resolve certo pro nome
do pacote raiz (nao "pkg.common") -- e exatamente o mesmo truque que o
common.py do Hyblend usa."""

from __future__ import annotations

import re
import struct
import time
import zlib
from pathlib import Path

import bpy
import bpy.utils.previews

from .compat import native_icon
from .paths import TEMP_CROPPED_ICONS, TEMP_SWATCH_ICONS, temp_dir
from .scanner import hytale_install

# Precisa ser o nome do PACOTE raiz, nao __name__ deste submodulo -- mesma
# razao documentada no common.py do Hyblend (AddonPreferences.bl_idname).
ADDON_PACKAGE = __package__
# Id deste addon no hyblend_hub (seletor da aba "Hyblend").
HUB_ID = "character_creator"


# Reestruturado pra casar com a organizacao real do character creator do
# Hytale (pedido explicito do usuario, ver DEVELOPER_NOTES.md -- nao e
# mais um agrupamento "logico" nosso, e a divisao que o proprio jogo usa).
# Nomenclatura nova: isto aqui e "Categoria" (grupo grande, ex. "Head"),
# cada entrada da lista e uma "Sub-categoria" (a chave real do catalogo,
# ex. "Haircuts"). O nome da variavel Python ficou o mesmo por
# compatibilidade com quem ja importa daqui (picker.py/interface/
# __init__.py) -- so o CONCEITO/rotulo mudou de "Secao/Categoria" pra
# "Categoria/Sub-categoria".
#
# DECISAO DE IDIOMA (pedido explicito do usuario): a UI mostra as chaves
# em INGLES (a UI antiga ja fazia isso; a nova continua). O nome em
# PORTUGUES (como aparece no jogo Hytale, usado pra alinhar a
# organizacao com o usuario) fica documentado abaixo como comentario, nao
# como dicionario de traducao carregado em runtime:
#
#   Head            -> Cabeça
#     Haircuts          Cabelo
#     Eyebrows          Sobrancelha
#     Eyes              Olhos
#     FacialHair        Pelos Faciais
#     HeadAccessory     Acessório de Cabeça
#     FaceAccessory     Acessório de Rosto
#     EarAccessory      Acessório de Orelha
#   General         -> Geral
#     Underwear         Roupa Íntima
#     BodyCharacteristics  Características do Corpo
#     Faces             Rosto
#     Mouths            Boca
#     Ears              Orelhas
#   Torso           -> Torso
#     Undertops         Roupa de Baixo
#     Overtops          Roupa de Cima
#     Gloves            Luvas
#   Legs            -> Pernas
#     Pants             Calças
#     Overpants         Acessório de Perna
#     Shoes             Calçados
#   Cape            -> Capas
#     Capes             Capas
#
# `SkinFeatures` existe no scanner mas fica ESCONDIDA da UI (ver
# _HIDDEN_CATEGORIES) -- sem correspondente confirmado no jogo e
# aparecia vazia (sem item nenhum) pro usuario, so ocupando espaco.
#
# O rotulo exibido na UI pra cada chave e gerado automaticamente por
# _prettify_key() (CamelCase -> "Camel Case"), sem dicionario manual --
# ver essa funcao mais abaixo.
_SECTION_CATEGORIES = {
    "Head": ["Haircuts", "Eyebrows", "Eyes", "FacialHair", "HeadAccessory", "FaceAccessory", "EarAccessory"],
    "General": ["Underwear", "BodyCharacteristics", "Faces", "Mouths", "Ears"],
    "Torso": ["Undertops", "Overtops", "Gloves"],
    "Legs": ["Pants", "Overpants", "Shoes"],
    "Cape": ["Capes"],
}

# Grupo sintetico (nao faz parte de _SECTION_CATEGORIES) pra sub-categorias
# do catalogo carregado que nao batem com nenhum grupo mapeado acima.
# Hoje nunca aparece de fato (ver _HIDDEN_CATEGORIES logo abaixo), mas o
# mecanismo fica pronto pra uma sub-categoria nova que o jogo venha a ter
# e que ainda nao tenha sido encaixada em nenhum grupo -- so aparece na UI
# se houver pelo menos uma de verdade no catalogo (ver _group_categories em
# picker.py).
_OUTROS_KEY = "Other"

# Sub-categorias que EXISTEM no scanner (o jogo tem o dado) mas ficam
# escondidas da UI -- confirmado pelo usuario com o catalogo real
# carregado que essas aparecem vazias (sem item nenhum de verdade dentro,
# so ocupando espaco). Diferente de uma sub-categoria so "nao mapeada"
# (que cairia em _OUTROS_KEY): essas aqui sao IGNORADAS de proposito em
# _group_categories, nunca aparecem nem na Categoria nem no fallback
# Outros. Se o jogo passar a ter itens de verdade aqui algum dia, tirar
# da lista.
_HIDDEN_CATEGORIES = frozenset({"SkinFeatures"})

_SLOT_NONE_VALUE = "__NONE__"

_MANDATORY_CATEGORIES = frozenset({"BodyCharacteristics"})

# Categorias que PODEM compartilhar cor entre si (todas usam
# tipicamente o GradientSet "Skin") -- pedido do usuario pra virar
# TOGGLE por categoria (era permanente/obrigatorio antes, ver
# DEVELOPER_NOTES.md): cada uma mantem sua PROPRIA paleta sempre
# visivel; o link (HYBLENDCC_ItemSlot.skin_linked) so decide se
# escolher uma cor nela propaga pras outras que TAMBEM estao linkadas
# no momento (ver _slot_on_color_update/_find_linked_skin_color em
# picker.py), nao mais uma property compartilhada unica
# (wm.hyblendcc_skintone, REMOVIDA) controlando as 3 (agora 4) de uma
# vez sem opcao de desligar. "Mouths" adicionado nesta sessao (nao
# fazia parte do grupo antes).
_LINKED_SKIN_CATEGORIES = ("BodyCharacteristics", "Faces", "Mouths", "Ears")

_SKIN_GRADIENT_SET_ID = "Skin"


_CAMEL_SPLIT_RE = re.compile(r"(?<!^)(?=[A-Z])")


def _prettify_key(key: str) -> str:
    """'HeadAccessory' -> 'Head Accessory' -- rotulo em INGLES pra UI a
    partir da chave interna (CamelCase), sem dicionario de traducao (ver
    nota de decisao de idioma acima de _SECTION_CATEGORIES). Chaves sem
    letra maiuscula no meio (ex. 'Haircuts', 'Overpants') voltam sem
    alteracao -- ja sao uma palavra legivel em ingles."""
    return _CAMEL_SPLIT_RE.sub(" ", key).strip()


def _sorted_enum(entries: list) -> list:
    """Ordena entradas (id, label, description) por label, sem
    reordenar strings numericas zero-padded incorretamente (ex:
    "01".."53" do GradientSet Skin ja ordena certo como string mesmo,
    ja que tem largura fixa -- nao precisa de int() pra isso)."""
    return sorted(entries, key=lambda e: e[1].lower())

_preview_collections: dict = {}


def _get_preview_collection():
    pcoll = _preview_collections.get("main")
    if pcoll is None:
        pcoll = bpy.utils.previews.new()
        _preview_collections["main"] = pcoll
    return pcoll


# ---------------------------------------------------------------------------
# Icones do JOGO (botoes fixos de Categoria/Sub-categoria, link de cor,
# tile "Nenhum" da UI GPU). Carregados direto da instalacao do Hytale
# (pasta configurada nas Preferences), NAO vem mais empacotados no addon.
# NAO usado pra thumbnail de item (essa vem de thumbnails/render.py).
#
# Cada icone e uma REFERENCIA "raiz:caminho" resolvida por
# scanner/hytale_install.py (as raizes -- apelidos de pasta -- moram la).
# Icone novo numa pasta que ja tem raiz = so a referencia aqui; pasta
# nova = +1 linha em hytale_install.ROOTS.
# ---------------------------------------------------------------------------

_hytale_dir_cache: dict = {"key": None, "dir": None, "at": 0.0}
# Com a MESMA configuracao, re-testa o disco a cada RECHECK s (igual ao
# game.hytale_dir do Toolkit): jogo instalado/removido com o Blender aberto.
_HYTALE_RECHECK = 3.0


def _invalidate_hytale_dir() -> None:
    """Chamar quando a pasta Hytale/modo mudar nas Preferences."""
    _hytale_dir_cache["key"] = None
    _hytale_dir_cache["dir"] = None
    _hytale_dir_cache["at"] = 0.0
    _icon_load_failed.clear()


def _hytale_dir():
    """Raiz da instalacao do Hytale configurada (Path) ou None. Barato:
    cacheado pela (modo, caminho) das Preferences -- so faz stat de disco
    quando a configuracao muda (ou a cada _HYTALE_RECHECK s). Nao escreve
    em property nenhuma (o preenchimento automatico mora em preferences.py)."""
    addon = bpy.context.preferences.addons.get(ADDON_PACKAGE)
    prefs = getattr(addon, "preferences", None) if addon is not None else None
    if prefs is None:          # durante register/unregister
        return None
    path_str = prefs.hytale_path
    key = (prefs.hytale_path_mode, path_str)
    now = time.monotonic()
    if _hytale_dir_cache["key"] == key and now - _hytale_dir_cache["at"] <= _HYTALE_RECHECK:
        return _hytale_dir_cache["dir"]
    found = hytale_install.find_hytale_dir(bpy.path.abspath(path_str)) if path_str else None
    if found is None and prefs.hytale_path_mode == "AUTO" and not path_str:
        found = hytale_install.default_hytale_dir()
    if _hytale_dir_cache["key"] == key and found != _hytale_dir_cache["dir"]:
        _icon_load_failed.clear()      # mudou no disco: tenta os icones de novo
    _hytale_dir_cache["key"] = key
    _hytale_dir_cache["dir"] = found
    _hytale_dir_cache["at"] = now
    return found


def game_found() -> bool:
    """Pasta do Hytale localizada? Igual ao Hyblend Toolkit (common.game_found):
    sem ela o addon fica TRAVADO -- somem o N-Panel (clássico e GPU) e os
    operadores que leem o jogo (create_player, aplicar item, miniaturas,
    recarregar catálogo, carregar preset) não rodam (poll). Continuam as
    Preferences e o "Locate Game". Barato (poll/draw): _hytale_dir() é
    cacheado pela (modo, caminho) das Preferences."""
    return _hytale_dir() is not None


def _game_file(ref: str):
    """Referencia "raiz:caminho" -> Path absoluto na instalacao do Hytale,
    ou None se a pasta Hytale nao estiver configurada. Nao checa se o
    arquivo existe."""
    root = _hytale_dir()
    return hytale_install.resolve(root, ref) if root is not None else None


_CUSTOM_ICON_PREFIX = "icon__"


def _pair(root: str, name: str) -> tuple:
    """Par (normal, selecionado) no padrao do jogo: Nome@2x.png /
    NomeSelected@2x.png, na mesma pasta."""
    return (f"{root}:{name}@2x.png", f"{root}:{name}Selected@2x.png")


# Tabela explicita chave interna -> (referencia normal, referencia
# selecionada). Nomes de arquivo sao os do PROPRIO JOGO. Alguns nao batem
# 1:1 com a chave interna (arquivo sempre no singular):
# BodyCharacteristics->BodyCharacteristic, Faces->Face, Mouths->Mouth,
# Undertops->Undertop, Overtops->Overtop, Haircuts->Haircut. `Capes` (a
# SUB-categoria) usa "Capes@2x.png", DIFERENTE de "Cape@2x.png" (esse e
# da CATEGORIA "Cape") -- sao dois icones distintos no jogo.
_SECTION_ICON_FILES = {
    "Head": _pair("avatar_categories", "Head"),
    "General": _pair("avatar_categories", "General"),
    "Torso": _pair("avatar_categories", "Torso"),
    "Legs": _pair("avatar_categories", "Legs"),
    "Cape": _pair("avatar_categories", "Cape"),
    _OUTROS_KEY: ("avatar:EmptyPartIcon@2x.png",) * 2,  # sem variante "selected" propria
}

_CATEGORY_ICON_FILES = {
    "Haircuts": _pair("avatar_categories", "Haircut"),
    "Eyebrows": _pair("avatar_categories", "Eyebrows"),
    "Eyes": _pair("avatar_categories", "Eyes"),
    "FacialHair": _pair("avatar_categories", "FacialHair"),
    "HeadAccessory": _pair("avatar_categories", "HeadAccessory"),
    "FaceAccessory": _pair("avatar_categories", "FaceAccessory"),
    "EarAccessory": _pair("avatar_categories", "EarAccessory"),
    "Underwear": _pair("avatar_categories", "Underwear"),
    "BodyCharacteristics": _pair("avatar_categories", "BodyCharacteristic"),
    "Faces": _pair("avatar_categories", "Face"),
    "Mouths": _pair("avatar_categories", "Mouth"),
    "Ears": _pair("avatar_categories", "Ears"),
    "Undertops": _pair("avatar_categories", "Undertop"),
    "Overtops": _pair("avatar_categories", "Overtop"),
    "Gloves": _pair("avatar_categories", "Gloves"),
    "Pants": _pair("avatar_categories", "Pants"),
    "Overpants": _pair("avatar_categories", "Overpants"),
    "Shoes": _pair("avatar_categories", "Shoes"),
    "Capes": _pair("avatar_categories", "Capes"),
}

# Tile "Nenhum" da UI GPU.
_EMPTY_PART_ICON_REF = "avatar:EmptyPartIcon@2x.png"

# Chaves (cache_key da preview collection) que falharam ao carregar pra
# pasta Hytale atual (arquivo nao existe nesta versao do jogo) -- evita
# reagendar o pre-carregamento a cada redesenho. Limpo ao trocar a pasta.
_icon_load_failed: set = set()


def _request_icon_precompute() -> None:
    """Agenda `_precompute_all_icons` (idempotente). Seguro de chamar do
    draw(): so registra um timer, nao toca bpy.data."""
    if not bpy.app.timers.is_registered(_precompute_all_icons):
        bpy.app.timers.register(_precompute_all_icons, first_interval=0.0)


def _cached_icon_kwargs(cache_key: str, fallback_native: str) -> dict:
    """Leitura pro draw(): icone ja carregado na preview collection ->
    icon_value; senao, icone nativo do Blender e agenda o carregamento
    num timer. NUNCA carrega/corta aqui: o corte usa bpy.data, proibido
    dentro de draw() (DEVELOPER_NOTES secao 3). O timer redesenha a
    sidebar quando terminar."""
    pcoll = _get_preview_collection()
    if cache_key in pcoll:
        return {"icon_value": pcoll[cache_key].icon_id}
    if cache_key not in _icon_load_failed:
        _request_icon_precompute()
    # native_icon: garante que o nome de fallback existe NESTA versao
    # do Blender (icone inexistente quebra o draw() inteiro).
    return {"icon": native_icon(fallback_native)}


def _load_icon(cache_key: str, src_path, crop_fn) -> bool:
    """So no timer. Corta (cache em disco) e carrega na preview
    collection. True se ja estava ou carregou; False se o arquivo nao
    existe (marca como falho pra pasta atual)."""
    pcoll = _get_preview_collection()
    if cache_key in pcoll:
        return True
    if src_path is None or not src_path.is_file():
        _icon_load_failed.add(cache_key)
        return False
    load_path = crop_fn(src_path) or src_path
    pcoll.load(cache_key, str(load_path), "IMAGE")
    return True


def _icon_cache_key(kind: str, key: str, active: bool) -> str:
    return f"{_CUSTOM_ICON_PREFIX}{kind}__{key}__{'sel' if active else 'norm'}"


def _icon_kwargs_for(kind: str, key: str, active: bool, fallback_native: str = "QUESTION") -> dict:
    """kwargs prontos pra operator()/label() -- icone do par (normal,
    selecionado) de _SECTION_ICON_FILES/_CATEGORY_ICON_FILES conforme
    `active` (kind="section" ou "category"). Enquanto o icone nao foi
    carregado (ou a pasta Hytale nao esta configurada), usa o icone
    nativo do Blender -- nunca quebra o layout."""
    table = _SECTION_ICON_FILES if kind == "section" else _CATEGORY_ICON_FILES
    if key not in table:
        return {"icon": fallback_native}
    return _cached_icon_kwargs(_icon_cache_key(kind, key, active), fallback_native)


def _load_icon_pair(kind: str, key: str, active: bool) -> bool:
    """So no timer. Corte usa a MESMA janela pros dois estados do par (ver
    `_cropped_icon_path_pair`) -- alguns pares tem um brilho no arquivo
    "selecionado" com area de conteudo bem maior que o "normal", e
    cortar cada um pela propria bbox fazia o desenho parecer ENCOLHER ao
    ficar ativo (bug real). So cai pro corte de arquivo unico quando os
    dois estados usam o mesmo arquivo (ex. EmptyPartIcon) ou falta um."""
    table = _SECTION_ICON_FILES if kind == "section" else _CATEGORY_ICON_FILES
    normal_ref, selected_ref = table[key]
    normal_path, selected_path = _game_file(normal_ref), _game_file(selected_ref)
    src_path = selected_path if active else normal_path

    def crop_fn(src):
        if (normal_ref != selected_ref and normal_path.is_file() and selected_path.is_file()):
            return _cropped_icon_path_pair(normal_path, selected_path, want_selected=active)
        return _cropped_icon_path(src)

    return _load_icon(_icon_cache_key(kind, key, active), src_path, crop_fn)


# Botao de "linkar cor" (Eye/Eye-Background e link de pele) -- so 2
# estados (sem selecao separada de hover).
_LINK_TOGGLE_ICON_FILES = {
    False: "avatar:MatchHairColorsIconOffHovered@2x.png",
    True: "avatar:MatchHairColorsIconOn@2x.png",
}


def _link_toggle_cache_key(active: bool) -> str:
    return f"{_CUSTOM_ICON_PREFIX}link_toggle__{'on' if active else 'off'}"


def _link_toggle_icon_kwargs(active: bool) -> dict:
    """kwargs prontos pra operator() do botao de link -- mesmo padrao de
    `_icon_kwargs_for`, fallback pros nativos LINKED/UNLINKED."""
    return _cached_icon_kwargs(_link_toggle_cache_key(active), "LINKED" if active else "UNLINKED")


# ---------------------------------------------------------------------------
# Swatch de cor circular (UI clássica) a partir do BaseColor REAL do
# manifest + escritor minimo de PNG RGBA (tambem usado pelo corte de margem
# dos icones, abaixo). Removido e RESTAURADO no item 58: a lentidao da
# paleta NAO vinha daqui (o PNG e gerado uma vez por cor e cacheado), e sim
# da cascata de EnumProperty -- ver picker._slot_item_value.
# ---------------------------------------------------------------------------

_SWATCH_ICON_PREFIX = "swatch__"


def _hex_to_rgb01(hex_str) -> tuple:
    """'#RRGGBB'/'RRGGBB'/'#RRGGBBAA' -> (r, g, b) float 0..1. Robusto a
    formato (o dado do jogo nao garante '#' nem tamanho fixo) -- cai pra
    cinza neutro se nao der pra interpretar, em vez de estourar."""
    s = (hex_str or "").lstrip("#")
    if len(s) < 6:
        return (0.5, 0.5, 0.5)
    try:
        return (int(s[0:2], 16) / 255.0, int(s[2:4], 16) / 255.0, int(s[4:6], 16) / 255.0)
    except ValueError:
        return (0.5, 0.5, 0.5)


def _png_chunk(tag: bytes, data: bytes) -> bytes:
    return struct.pack("!I", len(data)) + tag + data + struct.pack("!I", zlib.crc32(tag + data) & 0xFFFFFFFF)


def _write_rgba_png(path: Path, w: int, h: int, rows_topdown_rgba: bytes) -> None:
    """Escritor de PNG RGBA 8-bit generico (sem filtro por linha) --
    `rows_topdown_rgba` e RGBA plano, linha 0 = TOPO da imagem (convencao
    de arquivo PNG normal), `w*h*4` bytes. Usado tanto pelo swatch de cor
    (_write_circle_png) quanto pelo corte de margem dos icones
    (_cropped_icon_path/_pair, _crop_transparent_margin_inplace)."""
    rows = bytearray()
    stride = w * 4
    for y in range(h):
        rows.append(0)  # sem filtro nesta linha
        rows.extend(rows_topdown_rgba[y * stride:(y + 1) * stride])
    ihdr = struct.pack("!IIBBBBB", w, h, 8, 6, 0, 0, 0)
    idat = zlib.compress(bytes(rows), 9)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(_png_chunk(b"IHDR", ihdr))
        f.write(_png_chunk(b"IDAT", idat))
        f.write(_png_chunk(b"IEND", b""))


def _write_circle_png(path: Path, rgb: tuple, size: int = 64) -> None:
    """PNG RGBA circular gerado em Python puro (sem Pillow/bpy.data --
    seguro de chamar durante draw(), mesma tecnica ja validada no
    hyblendcc_ui_draft, so que agora com a cor REAL vinda do manifest em
    vez de um hash)."""
    r = max(0, min(255, int(rgb[0] * 255)))
    g = max(0, min(255, int(rgb[1] * 255)))
    b = max(0, min(255, int(rgb[2] * 255)))
    cx = cy = size / 2.0
    radius = size / 2.0 - 1.5
    rows = bytearray()
    for y in range(size):
        for x in range(size):
            dx = x + 0.5 - cx
            dy = y + 0.5 - cy
            dist = (dx * dx + dy * dy) ** 0.5
            if dist <= radius:
                alpha = 255
            elif dist <= radius + 1.0:
                alpha = int(255 * max(0.0, radius + 1.0 - dist))
            else:
                alpha = 0
            rows.extend([r, g, b, alpha])
    _write_rgba_png(path, size, size, bytes(rows))


def _swatch_icon_id(hex_color) -> int:
    """icon_id pro circulo de cor gerado a partir do BaseColor real do
    manifest. Cacheado em disco por hex (a mesma cor usada em varios
    Items/GradientSets so gera o arquivo uma vez) e carregado na preview
    collection uma vez por sessao do Blender. `hex_color=None` (item sem
    BaseColor) cai no cinza neutro de _hex_to_rgb01, nunca quebra."""
    hexkey = (hex_color or "").lstrip("#").lower() or "none"
    pcoll = _get_preview_collection()
    key = f"{_SWATCH_ICON_PREFIX}{hexkey}"
    if key in pcoll:
        return pcoll[key].icon_id
    path = temp_dir(TEMP_SWATCH_ICONS) / f"{hexkey}.png"
    if not path.is_file():
        _write_circle_png(path, _hex_to_rgb01(hex_color))
    return pcoll.load(key, str(path), "IMAGE").icon_id


# ---------------------------------------------------------------------------
# Corte automatico da margem vazia dos icones do jogo. Confirmado pelo
# usuario (com print real do Blender): os PNGs @2x tem bastante espaco
# transparente ao redor do desenho, o que faz o icone parecer minusculo
# dentro do botao mesmo com scale_x/scale_y grande. Em vez de pedir pra
# usuario re-exportar os PNGs, cortamos a margem em runtime (uma vez,
# cacheado em disco) usando o CARREGADOR DE IMAGEM DE VERDADE do Blender
# (bpy.data.images.load) -- evita reimplementar um decoder PNG generico
# em Python puro (so o ESCRITOR e proprio, ver _write_rgba_png -- decoder
# de PNG arbitrario, com bit depth/interlace variavel, e muito mais
# arriscado de acertar sem Pillow).
# ---------------------------------------------------------------------------

def _load_image_pixels(path: Path):
    """(largura, altura, pixels) via bpy.data.images.load -- pixels e
    RGBA float 0..1 piano, com a LINHA 0 embaixo (convencao do Blender,
    diferente de PNG normal -- ver o flip em _cropped_icon_path). Levanta
    excecao se falhar (chamador trata); remove a Image temporaria do
    bpy.data antes de devolver, pra nao vazar dado no arquivo .blend."""
    img = bpy.data.images.load(str(path), check_existing=False)
    try:
        w, h = img.size
        pixels = img.pixels[:]
    finally:
        bpy.data.images.remove(img)
    return w, h, pixels


def _content_bbox(w: int, h: int, pixels, alpha_threshold: float = 0.05):
    """(x0, y0, x1, y1) exclusivo do retangulo que cobre todo pixel com
    alpha > threshold -- independe de orientacao (bottom-up ou top-down),
    e so um min/max de indice. Devolve a imagem inteira se nao achar
    nenhum pixel com alpha (evita ZeroDivision/crop vazio)."""
    min_x, min_y, max_x, max_y = w, h, -1, -1
    for y in range(h):
        row = y * w * 4
        for x in range(w):
            if pixels[row + x * 4 + 3] > alpha_threshold:
                if x < min_x:
                    min_x = x
                if x > max_x:
                    max_x = x
                if y < min_y:
                    min_y = y
                if y > max_y:
                    max_y = y
    if max_x < 0:
        return (0, 0, w, h)
    return (min_x, min_y, max_x + 1, max_y + 1)


_CROP_ALGO_VERSION = 6  # incrementar sempre que _cropped_icon_path/_cropped_icon_path_pair mudar de
                        # logica/parametro -- o cache em disco e por (nome, mtime do ORIGINAL), que nao
                        # muda so porque o algoritmo mudou; sem isso o usuario ficaria vendo o corte
                        # antigo ate limpar a pasta temp na mao.


def _crop_cache_path(cache_key: str) -> Path:
    """Caminho do cache em disco pro icone cortado, dado um `cache_key`
    ja montado por quem chama (nome + mtime, ver _cropped_icon_path e
    _cropped_icon_path_pair) -- consolida a resolucao do diretorio de
    cache (`hyblendcc_cropped_icons` em tempfile.gettempdir()), que
    antes era repetida identica nas duas funcoes."""
    cache_dir = temp_dir(TEMP_CROPPED_ICONS)
    return cache_dir / f"{cache_key}_v{_CROP_ALGO_VERSION}.png"


def _compute_square_crop_rect(w: int, h: int, pixels):
    """Acha a bbox de conteudo, expande ate virar quadrado (centrado,
    clampado pra dentro da imagem original -- sem isso o resultado sai
    com o aspecto exato do desenho, quase nunca 1:1, e o botao quadrado
    ESTICA de forma nao-uniforme pra caber, distorcendo o icone -- bug
    real ja corrigido uma vez) + 2% de respiro. Devolve (x0, y0, x1, y1)
    ou `None` se nao houver nada pra cortar (bbox degenerada ou ja do
    tamanho da imagem toda). Separado de `_extract_rgba_topdown` (que
    APLICA esse retangulo) especificamente pra dar pra usar a bbox de UM
    arquivo (o normal) e aplicar em OUTRO (o selecionado) -- ver
    `_cropped_icon_path_pair`."""
    x0, y0, x1, y1 = _content_bbox(w, h, pixels)
    cw, ch = x1 - x0, y1 - y0
    if cw <= 0 or ch <= 0 or (cw >= w and ch >= h):
        return None

    side = max(cw, ch)
    mid_x, mid_y = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    x0, x1 = round(mid_x - side / 2.0), round(mid_x - side / 2.0) + side
    y0, y1 = round(mid_y - side / 2.0), round(mid_y - side / 2.0) + side
    if x0 < 0:
        x1 -= x0
        x0 = 0
    if y0 < 0:
        y1 -= y0
        y0 = 0
    if x1 > w:
        x0 -= (x1 - w)
        x1 = w
    if y1 > h:
        y0 -= (y1 - h)
        y1 = h
    x0, y0 = max(0, x0), max(0, y0)
    cw, ch = x1 - x0, y1 - y0
    if cw <= 0 or ch <= 0:
        return None

    pad = max(1, round(max(cw, ch) * 0.02))
    x0, y0 = max(0, x0 - pad), max(0, y0 - pad)
    x1, y1 = min(w, x1 + pad), min(h, y1 + pad)
    return (x0, y0, x1, y1)


def _extract_rgba_topdown(w: int, h: int, pixels, rect):
    """Aplica um retangulo (x0,y0,x1,y1) -- ver `_compute_square_crop_rect`
    -- num buffer de pixels (formato Blender, linha 0 embaixo) e devolve
    (largura, altura, bytes RGBA top-down prontos pra `_write_rgba_png`).
    `rect` pode ter vindo de OUTRA imagem (mesmas dimensoes W x H) --
    e exatamente isso que `_cropped_icon_path_pair` usa pra cortar o
    par normal/selecionado com a MESMA janela."""
    x0, y0, x1, y1 = rect
    cw, ch = x1 - x0, y1 - y0
    out_rows = bytearray()
    for row in range(ch):
        src_y = (y1 - 1) - row
        src_row_offset = src_y * w * 4
        for col in range(cw):
            src_x = x0 + col
            idx = src_row_offset + src_x * 4
            r, g, b, a = pixels[idx:idx + 4]
            out_rows.extend((
                max(0, min(255, int(r * 255))),
                max(0, min(255, int(g * 255))),
                max(0, min(255, int(b * 255))),
                max(0, min(255, int(a * 255))),
            ))
    return cw, ch, bytes(out_rows)


def _square_crop_pixels(w: int, h: int, pixels):
    """Nucleo do corte, reaproveitado pelas miniaturas de item
    renderizadas (`_crop_transparent_margin_inplace`, sem conceito de
    "par normal/selecionado"). Combina `_compute_square_crop_rect` +
    `_extract_rgba_topdown` num passo so. Devolve (largura, altura,
    bytes RGBA top-down) ou `None` se nao houver nada pra cortar."""
    rect = _compute_square_crop_rect(w, h, pixels)
    if rect is None:
        return None
    return _extract_rgba_topdown(w, h, pixels, rect)


def _cropped_icon_path(src_path: Path):
    """Versao cortada (so a bbox de conteudo + uma margem pequena de
    respiro) do PNG original, gerada uma vez e cacheada em disco por
    (nome, mtime do original, versao do algoritmo). Devolve None em
    QUALQUER falha (imagem sem alpha, bpy.data indisponivel, etc.) --
    quem chama cai pro arquivo original sem corte, nunca quebra por
    causa disso. So usada quando NAO existe um par normal/selecionado
    de verdade pra essa chave (ver `_cropped_icon_path_pair`, o caminho
    preferido pra icones de Categoria/Sub-categoria)."""
    try:
        out_path = _crop_cache_path(f"{src_path.stem}_{int(src_path.stat().st_mtime)}")
        if out_path.is_file():
            return out_path

        w, h, pixels = _load_image_pixels(src_path)
        cropped = _square_crop_pixels(w, h, pixels)
        if cropped is None:
            return None  # nada pra cortar (ou bbox degenerada) -- usa o original
        cw, ch, out_bytes = cropped
        _write_rgba_png(out_path, cw, ch, out_bytes)
        return out_path
    except Exception:
        return None


def _cropped_icon_path_pair(normal_path: Path, selected_path: Path, want_selected: bool):
    """Versao cortada de um PAR (normal, selecionado) do MESMO botao,
    usando a MESMA janela de corte pros dois -- calculada SEMPRE a
    partir do arquivo NORMAL. Sem isso, um icone com efeito de brilho/
    destaque no estado selecionado (area de conteudo visivel bem maior
    que o desenho "pelado", ex. medido de verdade: `General@2x.png` usa
    so 20% da area do canvas, `GeneralSelected@2x.png` usa 87% por causa
    do glow) sai cortado BEM MENOS apertado que o normal -- o corte,
    sozinho, ate acerta (o glow E conteudo visivel de verdade, nao deve
    ser cortado fora), mas os dois resultados ficam em ESCALAS
    diferentes, fazendo o desenho em si (nao o glow) parecer ENCOLHER
    quando o botao fica ativo. Bug real reportado com print pelo
    usuario, confirmado medindo pixel real dos 2 arquivos.

    Cacheado em disco por (nome dos dois arquivos + mtime dos dois,
    versao do algoritmo). Devolve None em qualquer falha (incluindo os
    dois arquivos terem dimensoes diferentes, caso em que a bbox do
    normal nao pode ser reaproveitada com seguranca) -- quem chama cai
    pro corte de arquivo unico (`_cropped_icon_path`) ou pro original
    sem corte."""
    try:
        target_path = selected_path if want_selected else normal_path
        cache_key = (
            f"{normal_path.stem}+{selected_path.stem}_"
            f"{int(normal_path.stat().st_mtime)}_{int(selected_path.stat().st_mtime)}_"
            f"{'sel' if want_selected else 'norm'}"
        )
        out_path = _crop_cache_path(cache_key)
        if out_path.is_file():
            return out_path

        nw, nh, npixels = _load_image_pixels(normal_path)
        rect = _compute_square_crop_rect(nw, nh, npixels)
        if rect is None:
            return None

        if target_path == normal_path:
            tw, th, tpixels = nw, nh, npixels
        else:
            tw, th, tpixels = _load_image_pixels(target_path)
            if (tw, th) != (nw, nh):
                return None  # canvas de tamanho diferente -- bbox do normal nao se aplica com seguranca

        cw, ch, out_bytes = _extract_rgba_topdown(tw, th, tpixels, rect)
        if cw <= 0 or ch <= 0:
            return None
        _write_rgba_png(out_path, cw, ch, out_bytes)
        return out_path
    except Exception:
        return None


def _crop_transparent_margin_inplace(path: Path) -> bool:
    """Corta a margem transparente de um PNG QUALQUER (usado nas
    miniaturas de ITEM renderizadas por `thumbnails/render.py` -- a
    camera enquadra pela diagonal 3D inteira da peca + 20% de folga, o
    que deixa MUITO espaco vazio ao redor do que realmente aparece na
    imagem, mesmo problema que ja resolvemos pros icones fixos de
    Categoria/Sub-categoria) e SOBRESCREVE o proprio arquivo com o
    resultado cortado. Devolve True se cortou de verdade, False se nao
    deu ou nao havia o que cortar -- nesse caso o arquivo original fica
    intacto, nunca quebra por causa disso.

    Chamar SO de dentro de um `Operator.execute()` (contexto normal de
    usuario, nunca de um callback de RNA -- items()/update()/etc. --,
    ver DEVELOPER_NOTES.md item 14-16 sobre por que isso e perigoso).
    `HYBLENDCC_OT_build_category_thumbnails` (picker.py) e o unico lugar
    que gera esses arquivos, e ja e um Operator normal -- contexto
    seguro pra chamar isso logo depois do render."""
    try:
        w, h, pixels = _load_image_pixels(path)
        cropped = _square_crop_pixels(w, h, pixels)
        if cropped is None:
            return False
        cw, ch, out_bytes = cropped
        _write_rgba_png(path, cw, ch, out_bytes)
        return True
    except Exception:
        return False


def _precompute_all_icons():
    """UNICO lugar que carrega icone do jogo -- sempre via
    `bpy.app.timers` (agendado no `register()`, ao trocar a pasta Hytale
    nas Preferences, ou pelo draw() ao achar um icone ainda nao
    carregado). NUNCA chamar direto de `draw()`/`items()`/`update()`: o
    corte usa `bpy.data.images.load/remove`, e bpy.data dentro de
    callback de RNA/draw ja causou crash nativo sem log (DEVELOPER_NOTES
    secao 3). Depois disso, o draw() so faz dict lookup.

    Sem pasta Hytale configurada: nao faz nada (o draw() segue com os
    icones nativos). Se carregou algo novo, redesenha as VIEW_3D pra
    trocar o fallback pelo icone real."""
    if _hytale_dir() is None:
        return None
    pcoll = _get_preview_collection()
    before = len(pcoll)
    for kind, table in (("section", _SECTION_ICON_FILES), ("category", _CATEGORY_ICON_FILES)):
        for key in table:
            for active in (False, True):
                cache_key = _icon_cache_key(kind, key, active)
                if cache_key not in _icon_load_failed:
                    _load_icon_pair(kind, key, active)
    for active in (False, True):
        cache_key = _link_toggle_cache_key(active)
        if cache_key not in _icon_load_failed:
            _load_icon(cache_key, _game_file(_LINK_TOGGLE_ICON_FILES[active]), _cropped_icon_path)
    if len(pcoll) != before:
        _tag_view3d_redraw()
    return None


def _tag_view3d_redraw() -> None:
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()
