"""builder/ -- so um pacote Python normal (sem classes bpy pra
registrar/desregistrar diretamente aqui -- os Operators moram em
prefab_importer.py, reexportados/registrados por __init__.py da raiz)."""
