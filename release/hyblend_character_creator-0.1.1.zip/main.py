"""Registro do Character Creator com o Hyblend Toolkit (núcleo) pronto -- chamado por __init__._activate.

So orquestra: importa as classes de cada modulo, registra tudo em
_CLASSES, e cuida das WindowManager properties que nao pertencem a
nenhum modulo especifico (hyblendcc_slots e as outras vivem aqui porque
precisam ser registradas numa ordem especifica em relacao as classes).

MAPA DO PACOTE (ordem de dependencia, de baixo pra cima -- ver
DEVELOPER_NOTES.md pra detalhes de cada um):
  toolkit.py      -- acesso ao nucleo (pasta do Hytale, hub, Preferences do nucleo, framework por GPU)
  compat.py       -- camada de compatibilidade Blender 4.5 <-> 5.x (so bpy)
  common.py       -- constantes/utilitarios sem dependencia interna nenhuma
  preferences.py  -- Preferences do addon (idioma do jogo, miniaturas) + Assets.zip
  picker.py       -- HYBLENDCC_ItemSlot, aplicar automatico, catalogo/thumbnail
  presets_ops.py  -- salvar/carregar/apagar preset
  player_ops.py   -- Create Player, Create Rig (Hyblend Anim)
  interface/      -- TODA a UI (N-panel, operadores de clique, widgets de
                     layout, draw das Preferences) -- ver interface/__init__.py

  builder/        -- monta bones+mesh (character_assembly.py e o principal)
  scanner/        -- le os manifests JSON do jogo (Cosmetics/CharacterCreator)
  thumbnails/     -- renderiza miniatura isolada (sem Armature real)
  presets/        -- so a leitura/escrita em disco do preset (sem bpy)
"""


from __future__ import annotations

import bpy
import bpy.utils.previews
from bpy.props import CollectionProperty, EnumProperty, StringProperty
from bpy.types import WindowManager

from . import translations
from .common import _precompute_all_icons, _preview_collections
from .interface import gpu_ui  # gpu_ui: UI experimental por GPU (5.0+), ver interface/gpu_ui/__init__.py
from .interface import panel as _interface_panel  # seletor dos addons Hyblend (hyblend_hub.py)
from .interface import OPERATOR_CLASSES as _UI_OPERATOR_CLASSES
from .interface import PANEL_CLASSES as _UI_PANEL_CLASSES
from .picker import (
    HYBLENDCC_ItemSlot,
    HYBLENDCC_OT_apply_slot,
    HYBLENDCC_OT_build_all_thumbnails,
    HYBLENDCC_OT_build_category_thumbnails,
    HYBLENDCC_OT_reload_catalog,
    _invalidate_item_enum_cache,
    cancel_pending_applies,
)
from .player_ops import HYBLENDCC_OT_create_player, HYBLENDCC_OT_create_rig
from .preferences import (
    HYBLENDCC_AddonPreferences,
    HYBLENDCC_OT_clear_cache,
    _restore_images_on_load,
)
from .presets_ops import (
    HYBLENDCC_OT_delete_preset,
    HYBLENDCC_OT_load_preset,
    HYBLENDCC_OT_save_preset,
    _preset_enum_items,
)


def _register_window_manager_props():
    WindowManager.hyblendcc_slots = CollectionProperty(type=HYBLENDCC_ItemSlot)

    # Estado da UI (uma Categoria/Sub-categoria ATIVA por vez -- so essa
    # e desenhada, nunca N grids grandes simultaneos, ver interface/panel.py).
    # StringProperty simples + os 2 Operators de clique
    # (HYBLENDCC_OT_select_section/_category, ver interface/operators.py).
    # `template_icon_view`+EnumProperty foi tentado DUAS vezes (ver
    # DEVELOPER_NOTES.md itens 14 e 15) e crashou o Blender do usuario
    # as duas -- a segunda mesmo depois de fechar a causa especifica
    # diagnosticada na primeira. NAO TENTAR DE NOVO sem um crash log de
    # verdade pra analisar (ver item 16) -- Operator/StringProperty e a
    # unica versao confirmada estavel apos varias rodadas de teste real.
    WindowManager.hyblendcc_active_section = StringProperty(default="")
    WindowManager.hyblendcc_active_category = StringProperty(default="")

    WindowManager.hyblendcc_preset_name = StringProperty(name="Preset Name", default="")
    WindowManager.hyblendcc_preset_selected = EnumProperty(name="Preset", items=_preset_enum_items)


def _unregister_window_manager_props():
    for name in ("hyblendcc_slots", "hyblendcc_active_section", "hyblendcc_active_category",
                 "hyblendcc_preset_name", "hyblendcc_preset_selected"):
        if hasattr(WindowManager, name):
            delattr(WindowManager, name)

_CLASSES = (
    HYBLENDCC_AddonPreferences,
    HYBLENDCC_OT_clear_cache,
    HYBLENDCC_ItemSlot,
    HYBLENDCC_OT_apply_slot,
    *_UI_OPERATOR_CLASSES,
    HYBLENDCC_OT_save_preset,
    HYBLENDCC_OT_load_preset,
    HYBLENDCC_OT_delete_preset,
    HYBLENDCC_OT_reload_catalog,
    HYBLENDCC_OT_build_all_thumbnails,
    HYBLENDCC_OT_build_category_thumbnails,
    HYBLENDCC_OT_create_player,
    HYBLENDCC_OT_create_rig,
    *_UI_PANEL_CLASSES,  # Panel por ultimo: desenha botao pra todos os Operators acima
)


def register():
    translations.register()           # primeiro: os outros podem montar textos no register() deles
    _interface_panel.hub_register()   # seletor dos addons Hyblend (painel bl_order 0) antes dos outros
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    _register_window_manager_props()
    # Preview collection NOVA -- qualquer icon_id cacheado de uma
    # collection anterior (ex. addon desabilitado/reabilitado na mesma
    # sessao do Blender) fica invalido a partir daqui. Limpa TODOS os
    # caches que guardam icon_id (nao so os de item) antes de qualquer
    # coisa tentar desenhar -- ver DEVELOPER_NOTES.md item 15 (crash
    # real relacionado a isso).
    _invalidate_item_enum_cache(category=None)
    _preview_collections["main"] = bpy.utils.previews.new()
    # Pre-carrega (corta/cacheia) todos os icones de Categoria/Sub-
    # categoria de uma vez, ANTES do primeiro draw() -- nunca de dentro
    # de draw() ou de um callback de RNA (items()/update()), onde mexer
    # em bpy.data (bpy.data.images.load/remove, usado no corte de
    # margem) e inseguro. bpy.app.timers roda fora desse contexto,
    # mesmo padrao ja usado em _defer_apply_slot.
    bpy.app.timers.register(_precompute_all_icons, first_interval=0.1)
    # (A pasta do Hytale e a auto-detecção dela são do núcleo, Hyblend Toolkit.)
    # .blend aberto: texturas de personagem que sumiram do assets_cache
    # (Clear Cache, outro PC) voltam do Assets.zip.
    bpy.app.handlers.load_post.append(_restore_images_on_load)
    gpu_ui.register()   # gpu_ui: nao faz nada abaixo do Blender 5.0


def _try(fn, *args):
    """Um passo do unregister: segue com o resto se falhar (register() que parou no meio deixa passos por fazer)."""
    try:
        fn(*args)
    except Exception:
        import traceback
        traceback.print_exc()


def _remove_previews():
    for pcoll in _preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    _preview_collections.clear()


def unregister():
    if _restore_images_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_restore_images_on_load)
    for fn in (_precompute_all_icons,):
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    _try(cancel_pending_applies)
    _try(gpu_ui.unregister)   # gpu_ui: antes de tudo -- derruba hosts/handlers/timers da UI por GPU
    _try(_remove_previews)
    # Mesma razao do register(): nao deixar nenhum icon_id cacheado
    # sobrevivendo a destruicao da preview collection.
    _try(_invalidate_item_enum_cache, None)

    _try(_unregister_window_manager_props)
    for cls in reversed(_CLASSES):
        if getattr(cls, "is_registered", False):
            _try(bpy.utils.unregister_class, cls)
    _try(_interface_panel.hub_unregister)
    _try(translations.unregister)
