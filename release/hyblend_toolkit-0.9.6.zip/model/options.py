"""Opções das janelas de import de modelo e os blocos de interface delas (mesma ordem/visual em todos os formatos).
Cada formato escolhe quais usa; o Anim usa as mesmas no .bbmodel/Bedrock (pela api)."""

from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty

from ..translations import tr
from .props import UNIT_SCALE_DEFAULT

# Tooltip específico por formato; o que não estiver aqui usa "importer.prop.<opção>".
TOOLTIP_KEYS = {
    "blockymodel": {
        "model_format": "importer.prop.blockymodel_model_format",
        "armature_name": "importer.prop.blockymodel_armature_name",
        "generate_reference_boxes": "importer.prop.blockymodel_generate_reference_boxes",
        "generate_uvs": "importer.prop.blockymodel_generate_uvs",
        "create_material": "importer.prop.blockymodel_create_material",
        "texture_mode": "importer.prop.blockymodel_texture_mode",
        "texture_filepath": "importer.prop.blockymodel_texture_filepath",
    },
    "bbmodel": {
        "model_format": "importer.prop.bbmodel_model_format",
        "armature_name": "importer.prop.bbmodel_armature_name",
        "generate_reference_boxes": "importer.prop.bbmodel_generate_reference_boxes",
        "generate_uvs": "importer.prop.bbmodel_generate_uvs",
        "create_material": "importer.prop.bbmodel_create_material",
    },
    "bedrock": {
        "model_format": "importer.prop.bedrock_model_format",
        "armature_name": "importer.prop.bedrock_armature_name",
        "texture_mode": "importer.prop.bedrock_texture_mode",
        "texture_filepath": "importer.prop.bedrock_texture_filepath",
    },
}


def tooltip_key(fmt, option):
    return TOOLTIP_KEYS.get(fmt, {}).get(option, f"importer.prop.{option}")


def model_format_enum(lang, fmt, with_auto=True, labels=None, item_keys=None):
    """"Model Type" (Character/Prop); `with_auto` = Auto-Detect (só formatos do Hytale)."""
    labels = labels or {"CHARACTER": "Character (64/block)", "PROP": "Prop (32/block)"}
    item_keys = item_keys or {"CHARACTER": "importer.prop.model_format_item_character",
                              "PROP": "importer.prop.model_format_item_prop"}
    items = [("AUTO", "Auto-Detect", tr("importer.prop.model_format_item_auto", lang))] if with_auto else []
    items += [(key, labels[key], tr(item_keys[key], lang)) for key in ("CHARACTER", "PROP")]
    return EnumProperty(name="Model Type", description=tr(tooltip_key(fmt, "model_format"), lang), items=items,
                        default="AUTO" if with_auto else "CHARACTER")


def _texture_mode_enum(lang, fmt):
    return EnumProperty(
        name="Texture Mode",
        description=tr(tooltip_key(fmt, "texture_mode"), lang),
        items=[("AUTO", "Automatic", tr(f"importer.prop.{fmt}_texture_mode_item_auto", lang)),
               ("MANUAL", "Manual", tr("importer.prop.texture_mode_item_manual", lang))],
        default="AUTO",
    )


_FACTORIES = {
    "armature_name": lambda lang, fmt: StringProperty(
        name="Armature Name", description=tr(tooltip_key(fmt, "armature_name"), lang), default=""),
    "orient_z_up": lambda lang, fmt: BoolProperty(
        name="Orient to Z-up (visual only)", description=tr(tooltip_key(fmt, "orient_z_up"), lang), default=True),
    "unit_scale": lambda lang, fmt: FloatProperty(
        name="Scale (Blender units per game unit)", description=tr(tooltip_key(fmt, "unit_scale"), lang),
        default=UNIT_SCALE_DEFAULT, min=0.0001, max=10.0),
    "generate_reference_boxes": lambda lang, fmt: BoolProperty(
        name="Generate Reference Meshes", description=tr(tooltip_key(fmt, "generate_reference_boxes"), lang),
        default=True),
    "flat_mesh_collections": lambda lang, fmt: BoolProperty(
        name="Flat Mesh Collections", description=tr(tooltip_key(fmt, "flat_mesh_collections"), lang),
        default=False),
    "generate_uvs": lambda lang, fmt: BoolProperty(
        name="Generate UVs", description=tr(tooltip_key(fmt, "generate_uvs"), lang), default=True),
    "create_material": lambda lang, fmt: BoolProperty(
        name="Create Material", description=tr(tooltip_key(fmt, "create_material"), lang), default=True),
    "texture_mode": _texture_mode_enum,
    "texture_filepath": lambda lang, fmt: StringProperty(
        name="Texture Image", description=tr(tooltip_key(fmt, "texture_filepath"), lang), default="",
        subtype="FILE_PATH"),
}


def import_option_props(lang, fmt, options):
    """{nome: Property} das opções pedidas pro formato `fmt`."""
    return {option: _FACTORIES[option](lang, fmt) for option in options}


def draw_rig_section(layout, op, lang, orient_enabled=True, show_model_format=True):
    """Caixa "Rig": Z-up, Character/Prop, escala."""
    box = layout.box()
    box.label(text=tr("importer.section_rig", lang))
    orient = box.column()
    orient.enabled = orient_enabled
    orient.prop(op, "orient_z_up", text=tr("importer.orient_z_up", lang))
    if show_model_format:
        box.prop(op, "model_format", text=tr("importer.model_format", lang))
    box.prop(op, "unit_scale", text=tr("importer.unit_scale", lang))
    return box


def draw_mesh_section(layout, op, lang):
    """Caixa das malhas; devolve a coluna interna pro formato acrescentar o que é só dele."""
    box = layout.box()
    box.label(text=tr("importer.section_visuals", lang))
    box.prop(op, "generate_reference_boxes", text=tr("importer.generate_reference_boxes", lang))
    sub = box.column()
    sub.enabled = op.generate_reference_boxes
    sub.prop(op, "flat_mesh_collections", text=tr("importer.flat_mesh_collections", lang))
    sub.prop(op, "generate_uvs", text=tr("importer.generate_uvs", lang))
    sub.prop(op, "create_material", text=tr("importer.create_material", lang))
    return sub


def draw_texture_options(layout, op, lang):
    """Texture Mode + caminho manual (só em Manual); ativo só com "Create Material"."""
    tex = layout.column()
    tex.enabled = op.generate_reference_boxes and op.create_material
    tex.prop(op, "texture_mode", text=tr("importer.texture_mode", lang))
    manual = tex.column()
    manual.enabled = op.texture_mode == "MANUAL"
    manual.prop(op, "texture_filepath", text=tr("importer.texture_filepath", lang))
    return tex
