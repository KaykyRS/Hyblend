"""Importação de formatos de fora do .blockymodel (o .blockymodel e o import de personagem são do núcleo, pela api):
  bbmodel.py (Blockbench + import_bbmodel_data), bedrock.py (Minecraft)
  converter/: só conversão de formatos de fora (puro Python)
Formato novo = arquivo novo aqui, registrado em _CLASSES e em menu_func_import (peças comuns: api.model).
"""

import bpy

from ..translations import register_localized_class, unregister_localized_class
from .bbmodel import IMPORT_OT_hytale_bbmodel, import_bbmodel_data  # noqa: F401
from .bedrock import IMPORT_OT_hytale_bedrock_model

_CLASSES = (
    IMPORT_OT_hytale_bbmodel,
    IMPORT_OT_hytale_bedrock_model,
)


def menu_func_import(self, context):
    from ..common import game_found
    if not game_found():          # sem a pasta do jogo: nada do addon nos menus
        return
    self.layout.operator(IMPORT_OT_hytale_bbmodel.bl_idname, text="Hytale Model (Blockbench .bbmodel)")
    self.layout.operator(IMPORT_OT_hytale_bedrock_model.bl_idname, text="Minecraft Bedrock Model (.json)")


def register():
    for cls in _CLASSES:
        register_localized_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    for cls in reversed(_CLASSES):
        unregister_localized_class(cls)
