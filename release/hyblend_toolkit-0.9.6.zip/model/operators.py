"""File > Import > Hytale Model (.blockymodel): Armature nova ou anexar numa existente, malhas com UV e textura
achada ao lado do modelo. A montagem é do build.py; aqui só as opções, a textura e os avisos."""

import json
import os

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper

from ..common import game_found
from ..translations import get_language, localized_props, tooltip, tr
from . import build, materials, textures
from .options import draw_mesh_section, draw_rig_section, draw_texture_options, import_option_props, \
    model_format_enum
from .props import armature_model_format, effective_unit_scale


def report_warnings(operator, warnings, lang):
    for level, key, fields in warnings:
        operator.report({level}, tr(key, lang).format(**fields))


def _props(lang):
    return {
        **import_option_props(lang, "blockymodel", (
            "armature_name", "orient_z_up", "unit_scale", "generate_reference_boxes", "flat_mesh_collections",
            "generate_uvs", "create_material", "texture_mode", "texture_filepath",
        )),
        "model_format": model_format_enum(lang, "blockymodel"),
        "filter_glob": StringProperty(default="*.blockymodel", options={"HIDDEN"}),
        "import_mode": EnumProperty(
            name="Import Mode",
            description=tr("importer.prop.blockymodel_import_mode", lang),
            items=[("NEW_ARMATURE", "Create New Armature", tr("importer.prop.blockymodel_import_mode_item_new", lang)),
                   ("ATTACH_EXISTING", "Attach to Existing Armature",
                    tr("importer.prop.blockymodel_import_mode_item_attach", lang))],
            default="NEW_ARMATURE",
        ),
        "target_armature_name": StringProperty(
            name="Target Armature", description=tr("importer.prop.blockymodel_target_armature_name", lang),
            default=""),
        "missing_face_mode": EnumProperty(
            name="Faces Missing Texture Data",
            description=tr("importer.prop.blockymodel_missing_face_mode", lang),
            items=[("SKIP", "Skip (leave empty) -- matches Blockbench",
                    tr("importer.prop.blockymodel_missing_face_mode_item_skip", lang)),
                   ("OPPOSITE_FALLBACK", "Reuse Opposite Face's Texture (cosmetic)",
                    tr("importer.prop.blockymodel_missing_face_mode_item_opposite", lang))],
            default="SKIP",
        ),
        "override_atlas_size": BoolProperty(
            name="Set Atlas Size Manually", description=tr("importer.prop.blockymodel_override_atlas_size", lang),
            default=False),
        "atlas_width": FloatProperty(
            name="Atlas Width (px)", description=tr("importer.prop.blockymodel_atlas_width", lang), default=256.0,
            min=1.0),
        "atlas_height": FloatProperty(
            name="Atlas Height (px)", description=tr("importer.prop.blockymodel_atlas_height", lang), default=128.0,
            min=1.0),
    }


@localized_props(_props)
class IMPORT_OT_hytale_blockymodel(Operator, ImportHelper):
    """Import a Hytale .blockymodel as an Armature (correct rest pose)"""

    bl_idname = "import_scene.hytale_blockymodel"
    bl_label = "Import .blockymodel"
    description = tooltip("importer.tooltip.blockymodel")
    bl_options = {"REGISTER", "UNDO"}
    filename_ext = ".blockymodel"

    @classmethod
    def poll(cls, context):
        return game_found()

    def draw(self, context):
        lang = get_language(context)
        layout = self.layout
        target = layout.box()
        target.label(text=tr("importer.section_target", lang))
        target.prop(self, "import_mode", text=tr("importer.import_mode", lang))
        if self.import_mode == "ATTACH_EXISTING":
            target.prop_search(self, "target_armature_name", bpy.data, "objects",
                               text=tr("importer.target_armature", lang))
        else:
            target.prop(self, "armature_name", text=tr("importer.armature_name", lang))
        draw_rig_section(layout, self, lang, orient_enabled=self.import_mode == "NEW_ARMATURE")
        sub = draw_mesh_section(layout, self, lang)
        atlas = sub.column()
        atlas.enabled = self.generate_uvs
        atlas.prop(self, "missing_face_mode", text=tr("importer.missing_face_mode", lang))
        atlas.prop(self, "override_atlas_size", text=tr("importer.override_atlas_size", lang))
        row = atlas.row()
        row.enabled = self.override_atlas_size
        row.prop(self, "atlas_width", text=tr("importer.atlas_width", lang))
        row.prop(self, "atlas_height", text=tr("importer.atlas_height", lang))
        draw_texture_options(sub, self, lang)

    def execute(self, context):
        lang = get_language(context)
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError) as exc:
            self.report({"ERROR"}, tr("model.error.read", lang).format(error=exc))
            return {"CANCELLED"}
        if not isinstance(data, dict) or not data.get("nodes"):
            self.report({"ERROR"}, tr("model.error.no_nodes", lang))
            return {"CANCELLED"}

        name = build.model_name(self.filepath)
        attach = self.import_mode == "ATTACH_EXISTING"
        if attach:
            armature_obj = bpy.data.objects.get(self.target_armature_name)
            if armature_obj is None or armature_obj.type != "ARMATURE":
                key = "model.error.no_object" if armature_obj is None else "model.error.not_armature"
                self.report({"ERROR"}, tr(key, lang).format(name=self.target_armature_name))
                return {"CANCELLED"}
            model_format = build.resolve_format(self.model_format, data, self.filepath, armature_obj)
            target_format = armature_model_format(armature_obj)
            if model_format != target_format:
                self.report({"WARNING"}, tr("model.warn.format_mismatch", lang).format(
                    file=os.path.basename(self.filepath), format=model_format, name=armature_obj.name,
                    target=target_format))
            collection, created = build.attachments_collection(context, armature_obj)
            if created:
                self.report({"WARNING"}, tr("model.warn.attachments_fallback", lang).format(
                    name=armature_obj.name, collection=collection.name))
        else:
            model_format = build.resolve_format(self.model_format, data, self.filepath)
            armature_obj, collection = build.new_armature(context, self.armature_name.strip() or name, model_format)
        scale = effective_unit_scale(self.unit_scale, model_format)

        material, atlas = None, None
        roots = data["nodes"]
        if self.generate_reference_boxes:
            atlas = ((self.atlas_width, self.atlas_height) if self.override_atlas_size
                     else build.geometry.atlas_size(roots))
            if self.create_material:
                material, atlas = self._material(name, atlas, lang)

        result = build.build(
            context, data, armature_obj, unit_scale=scale, attach=attach,
            stem=os.path.splitext(os.path.basename(self.filepath))[0], collection=collection,
            meshes=self.generate_reference_boxes, generate_uvs=self.generate_uvs,
            missing_face_mode=self.missing_face_mode, flat_collections=self.flat_mesh_collections, atlas=atlas,
            material=material,
        )
        report_warnings(self, result.warnings, lang)
        if not attach and self.orient_z_up:
            build.orient_z_up(armature_obj)
        context.view_layer.update()
        roots_text = ", ".join(r.get("name", "?") for r in roots)
        self.report({"INFO"}, tr("model.info.imported_attach" if attach else "model.info.imported", lang).format(
            count=result.nodes, roots=roots_text, name=armature_obj.name, format=model_format, scale=scale))
        return {"FINISHED"}

    def _material(self, name, atlas, lang):
        """(material, atlas): a textura carregada manda no atlas; as outras achadas viram variantes soltas."""
        paths, tier = textures.resolve(self.filepath, self.texture_mode, self.texture_filepath, name)
        message = textures.message(self.texture_mode, tier, paths, name, lang)
        if message is not None:
            self.report({message[0]}, message[1])
        images = [img for img in (materials.load_image(textures.clean_path(p)) for p in paths) if img is not None]
        if images and images[0].size[0] > 0 and images[0].size[1] > 0:
            atlas = (images[0].size[0], images[0].size[1])
        primary = images[0] if images else materials.placeholder_image(*atlas)
        return materials.flat_material(primary, name=name, variants=images[1:]), atlas


def menu_import(self, context):
    # Com o Anim 0.1.0 ligado, o operador dele toma o mesmo bl_idname e o menu dele já mostra a entrada.
    if not game_found() or getattr(bpy.types, "IMPORT_SCENE_OT_hytale_blockymodel", None) is not \
            IMPORT_OT_hytale_blockymodel:
        return
    self.layout.operator(IMPORT_OT_hytale_blockymodel.bl_idname, text="Hytale Model (.blockymodel)")


class HYBLEND_OT_import_character(Operator):
    """Import a Hytale character or creature with its default look (body + attachments)"""

    bl_idname = "hyblend.import_character"
    bl_label = "Import Character"
    description = tooltip("model.tooltip.import_character")
    bl_options = {"REGISTER", "UNDO"}

    character_id: StringProperty(name="Character", options={"SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return game_found()

    def execute(self, context):
        from . import catalog, character
        lang = get_language(context)
        try:
            result = character.import_character(context, self.character_id)
        except catalog.CatalogError as exc:
            self.report({"ERROR"}, tr(exc.key, lang).format(**exc.fields))
            return {"CANCELLED"}
        report_warnings(self, result.warnings, lang)
        self.report({"INFO"}, tr("model.info.character", lang).format(
            name=result.armature.name, parts=len(result.objects), bones=len(result.bones)))
        return {"FINISHED"}
