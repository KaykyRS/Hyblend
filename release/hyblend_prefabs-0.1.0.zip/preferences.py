"""preferences.py -- Preferences do addon e tudo que resolve o AssetsSource
a partir delas. Igual ao Hyblend Toolkit e ao Character Creator: o usuário
aponta a PASTA DO HYTALE (modo Automático = %APPDATA%/Hytale, preenchida
sozinha no boot); o Assets.zip, a arte e as fontes do jogo saem de dentro
dela (interface/gpu_ui/hytale_install.py, game.py). A pasta é UMA pra
todos os addons Hyblend (hyblend_hub.py, Documentos/Hyblend/Config/ui.json).

Tambem mora aqui o que a UI precisa saber SEM abrir o zip (status da
pasta configurada, pasta de cache) -- o painel (interface/) chama isso a
cada redraw, entao nada aqui pode ser pesado."""

from __future__ import annotations

import os
import shutil
import zipfile
from pathlib import Path

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import AddonPreferences, Operator

from . import hyblend_hub  # sincronia entre os addons Hyblend (UI por GPU), ver hyblend_hub.py
from .common import ADDON_PACKAGE, HUB_ID, game_found
from .scanner.assets_source import ZipAssetsSource
from .scanner.item_index import clear_index_caches

def _data_root() -> Path:
    """Documentos/Hyblend/Prefabs (regra de "Documentos" do hyblend_hub, a
    mesma dos outros addons). Versões antigas usavam sempre ~/Documents: se
    essa pasta já existe, continua nela."""
    legacy = Path.home() / "Documents" / "Hyblend" / "Prefabs"
    return legacy if legacy.is_dir() else Path(hyblend_hub.documents_dir()) / "Hyblend" / "Prefabs"


# Pasta onde o ZipAssetsSource extrai os arquivos sob demanda.
ASSETS_CACHE_DIR = _data_root() / "assets_cache"


class AssetsSourceError(Exception):
    """O Assets.zip não está disponível: pasta do Hytale não configurada,
    não é a pasta do jogo, ou o zip não abre (sumiu, travado, atualizando).
    A mensagem vai direto pro usuário (report do operador)."""


def get_prefs(context=None):
    context = context or bpy.context
    addon = context.preferences.addons.get(ADDON_PACKAGE)
    return addon.preferences if addon else None


def is_developer_mode(context=None) -> bool:
    """Developer Mode (Preferences): mostra ferramentas de depuracao --
    Copy Report, Export Debug Dump, opcoes Experimental do import, valores
    crus no inspetor. Desligado por padrao (usuario comum nao precisa)."""
    prefs = get_prefs(context)
    return bool(prefs and prefs.developer_mode)


def _game():
    """interface/gpu_ui/game.py (pasta do jogo, IGUAL ao do Toolkit; só lê as
    Preferences, funciona no 4.5). Import tardio: interface/ importa este
    arquivo no topo."""
    from .interface.gpu_ui import game
    return game


def _hytale_install():
    from .interface.gpu_ui import hytale_install     # Python puro (mapa da instalação)
    return hytale_install


def assets_status(context=None) -> tuple:
    """(estado, texto curto) pro painel/Preferences, sem abrir o zip -- só
    a pasta do Hytale (cacheada). estado: "MISSING" (nada configurado),
    "NOT_FOUND" (a pasta não é a do Hytale) ou "ZIP" (Assets.zip achado)."""
    prefs = get_prefs(context)
    found = _game().hytale_dir()
    if found is not None:
        return "ZIP", "Assets.zip"
    if prefs is None or not prefs.hytale_path:
        return "MISSING", "Not configured"
    return "NOT_FOUND", Path(bpy.path.abspath(prefs.hytale_path)).name or prefs.hytale_path


def _on_hytale_path_changed(self, context):
    """update= de hytale_path/hytale_path_mode: descarta o Assets.zip aberto e
    a pasta resolvida antigos (a UI por GPU troca arte/fontes no próximo
    build), e a pasta (UMA pra todos os addons Hyblend) vai pro hub -- os
    updates que isso causa nos outros addons não voltam."""
    _invalidate_assets_source()
    from .interface import gpu_ui
    gpu_ui.on_hytale_path_changed(context)
    hyblend_hub.share_hytale(HUB_ID, self.hytale_path_mode, self.hytale_path)


def autodetect_on_startup():
    """Timer do register(): modo Automático com o campo vazio (addon recém-
    instalado) -> acha a pasta e preenche sozinho (game.autodetect, o mesmo
    do Toolkit). Não sobrescreve caminho salvo nem o modo Manual."""
    _game().autodetect_on_startup()
    return None


class HYBLENDPREFABS_AddonPreferences(AddonPreferences):
    bl_idname = ADDON_PACKAGE

    # Pasta do Hytale: mesmos campos, textos e comportamento do Toolkit/CC
    # (descrições e itens em hyblend_hub, iguais nos três).
    hytale_path_mode: EnumProperty(
        name="Hytale Folder",
        description=hyblend_hub.HYTALE_MODE_DESCRIPTION,
        items=[(ident, label, tip) for ident, label, tip in hyblend_hub.HYTALE_MODE_ITEMS],
        default="AUTO",
        update=_on_hytale_path_changed,
    )
    hytale_path: StringProperty(
        name="Hytale Folder",
        description=hyblend_hub.HYTALE_PATH_DESCRIPTION,
        subtype="DIR_PATH",
        update=_on_hytale_path_changed,
    )
    # ---- UI por GPU (interface/gpu_ui/, Blender 5.0+) ----
    # A escolha é UMA pra todos os addons Hyblend: get/set no hub
    # (hyblend_hub.py, Documentos/Hyblend/Config/ui.json) -- ligar aqui liga
    # no Toolkit/Character Creator e vice-versa. O hub avisa cada addon
    # (gpu_ui.on_preference_changed), por isso sem update= aqui.
    use_gpu_ui: BoolProperty(
        name="Experimental GPU Interface",
        description="Draw the sidebar panel in the Hytale style (Blender 5.0 or newer). Turn off to use the "
        "classic Blender panel. Shared by all Hyblend addons: changing it here changes it in the others too",
        get=hyblend_hub.prop_get_gpu,
        set=hyblend_hub.prop_set_gpu, default=True,
    )
    # Tamanho do painel: COMPARTILHADO com os outros addons Hyblend (get/set
    # no hub, mesmo nome/padrão/limites nos três). O hub avisa cada addon
    # (gpu_ui.on_preference_changed) -- por isso sem update= aqui.
    gpu_ui_scale: FloatProperty(
        name="Panel Size",
        description="Size of the GPU panel, on top of Blender's Resolution Scale. Shared by all Hyblend addons",
        min=0.75, max=1.5, subtype="FACTOR",
        get=hyblend_hub.prop_get("panel_size"), set=hyblend_hub.prop_set("panel_size"),
        default=hyblend_hub.SETTINGS["panel_size"],
    )
    gpu_ui_panel_width: FloatProperty(
        name="Panel Width",
        description="0 = automatic. You can also drag the left edge of the panel. Shared by all Hyblend addons",
        min=0.0,
        get=hyblend_hub.prop_get("panel_width"), set=hyblend_hub.prop_set("panel_width"), default=0.0,
    )
    gpu_ui_panel_height: FloatProperty(
        name="Panel Height",
        description="0 = automatic (follows the content). You can also drag the bottom edge of the panel. "
        "Shared by all Hyblend addons",
        min=0.0,
        get=hyblend_hub.prop_get("panel_height"), set=hyblend_hub.prop_set("panel_height"), default=0.0,
    )
    developer_mode: BoolProperty(
        name="Developer Mode",
        description="Show debugging tools: Copy Report, Export Debug Dump (also in File > Export), the "
        "Experimental import options and raw prefab values in the Selection inspector",
        default=False,
    )

    def draw(self, context):
        """Mesma organização do Hyblend Toolkit: caixa "Hytale Folder" (desenho
        do hub, IGUAL nos três), as caixas do Prefabs e a aba colapsável
        "Experimental" com a sub-aba "GPU Interface (N-Panel)"."""
        layout = self.layout
        hyblend_hub.draw_hytale_folder(layout, self, _game().hytale_dir(), LOCATE_IDNAME, "Hyblend Prefabs")

        # -- Cache --
        box = layout.box()
        box.label(text="Cache", icon="FILE_CACHE")
        col = box.column(align=True)
        col.label(text="Files are extracted from Assets.zip on demand to:")
        col.label(text=str(ASSETS_CACHE_DIR))
        col.label(text="Clear it after a Hytale update so new textures/models are picked up.", icon="INFO")
        row = box.row(align=True)
        row.operator(HYBLENDPREFABS_OT_clear_assets_cache.bl_idname, icon="TRASH")
        sub = row.row(align=True)
        sub.enabled = ASSETS_CACHE_DIR.is_dir()      # ainda não existe = nada extraído ainda
        sub.operator("wm.path_open", text="Open Folder", icon="FILE_FOLDER").filepath = str(ASSETS_CACHE_DIR)

        # -- Developer --
        box = layout.box()
        box.label(text="Developer", icon="CONSOLE")
        box.prop(self, "developer_mode")
        if self.developer_mode:
            col = box.column(align=True)
            col.label(text="Shows: Copy Report, Export Debug Dump, Experimental import options,", icon="INFO")
            col.label(text="and raw prefab values in the Selection inspector.", icon="BLANK1")

        from .interface import gpu_ui
        hyblend_hub.draw_experimental(layout, "hyblendprefabs", [
            ("gpu_ui", hyblend_hub.GPU_TEXTS["box"], "WINDOW", lambda body: gpu_ui.draw_preferences(self, body)),
        ])


# "Locate Game": o mesmo do Toolkit/CC (local padrão; senão, seletor de pasta)
HYBLENDPREFABS_OT_locate_game = hyblend_hub.make_locate_operator(
    "hyblendprefabs", HUB_ID, ADDON_PACKAGE,
    default_dir=lambda: _hytale_install().default_hytale_dir(),
    find_dir=lambda path: _hytale_install().find_hytale_dir(path))
LOCATE_IDNAME = HYBLENDPREFABS_OT_locate_game.bl_idname


class HYBLENDPREFABS_OT_clear_assets_cache(Operator):
    """Apaga a pasta de cache de extracao (ASSETS_CACHE_DIR). O
    ZipAssetsSource so extrai um arquivo se ele ainda NAO existe no cache
    -- depois de uma atualizacao do jogo, sem limpar, o addon continuaria
    usando os arquivos da versao antiga."""

    bl_idname = "hyblendprefabs.clear_assets_cache"
    bl_label = "Clear Cache"
    bl_description = (
        "Delete every file extracted from Assets.zip. Do this after a Hytale update -- "
        "files are re-extracted on the next import"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        _invalidate_assets_source()
        failed = []
        if ASSETS_CACHE_DIR.is_dir():
            shutil.rmtree(ASSETS_CACHE_DIR, onerror=lambda fn, path, _exc: fn is os.rmdir or failed.append(path))
        # Texturas de prefabs já importados apontam pro cache: extraídas de
        # novo (versão nova do jogo) e recarregadas.
        restore_cached_images(context, only_missing=False)
        if failed:
            self.report({"WARNING"}, f"Hyblend Prefabs: cache cleared, but {len(failed)} file(s) are in use and "
                        "were kept (close other programs/Blender windows and try again).")
        else:
            self.report({"INFO"}, "Hyblend Prefabs: extracted files cache cleared.")
        return {"FINISHED"}


def restore_cached_images(context, only_missing=True) -> int:
    """Imagens do .blend que apontam pro cache de extração (texturas dos
    prefabs importados): re-extrai do Assets.zip e recarrega. Sem o jogo: nada."""
    if not game_found():
        return 0

    def extract(relative):
        get_assets_source(context).resolve_root(*relative.split("/"))

    return hyblend_hub.restore_cached_images(ASSETS_CACHE_DIR, extract, only_missing=only_missing)


@bpy.app.handlers.persistent
def _restore_images_on_load(_dummy=None):
    """load_post: .blend aberto depois de um Clear Cache -- as texturas que
    sumiram do cache voltam do Assets.zip."""
    try:
        restore_cached_images(bpy.context)
    except Exception:
        import traceback
        traceback.print_exc()


_assets_source_state = {"key": None, "source": None}


def _invalidate_assets_source() -> None:
    if _assets_source_state["source"] is not None:
        _assets_source_state["source"].close()
    _assets_source_state["key"] = None
    _assets_source_state["source"] = None
    clear_index_caches()


def get_assets_source(context):
    """AssetsSource do Assets.zip da pasta do Hytale configurada (o mesmo
    caminho do Character Creator), cacheado pelo caminho do zip."""
    prefs = get_prefs(context)
    hi = _hytale_install()
    root = _game().hytale_dir()
    if root is None:
        if prefs is None or not prefs.hytale_path:
            raise AssetsSourceError(
                "Configure the Hytale folder in Preferences > Add-ons > Hyblend Prefabs first (Locate Game).")
        expected = "/".join(hi.relative_parts(hi.ASSETS_ZIP))
        raise AssetsSourceError(
            f"'{bpy.path.abspath(prefs.hytale_path)}' is not a Hytale folder (could not find {expected} inside "
            "it) -- check the path in Preferences > Add-ons > Hyblend Prefabs.")

    zip_path = hi.resolve(root, hi.ASSETS_ZIP)
    if _assets_source_state["key"] == zip_path and _assets_source_state["source"] is not None:
        return _assets_source_state["source"]

    _invalidate_assets_source()
    try:
        source = ZipAssetsSource(zip_path, ASSETS_CACHE_DIR)
    except (OSError, zipfile.BadZipFile) as exc:     # sumiu, travado, ou meio gravado (launcher atualizando)
        _game().invalidate()
        raise AssetsSourceError(f"Could not open the game's Assets.zip ({exc}). If Hytale is updating, wait "
                                "for it to finish and try again.") from exc
    _assets_source_state["key"] = zip_path
    _assets_source_state["source"] = source
    return source


_CLASSES = (
    HYBLENDPREFABS_AddonPreferences,
    HYBLENDPREFABS_OT_locate_game,
    HYBLENDPREFABS_OT_clear_assets_cache,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    # Pasta do jogo no boot (depois do adopt do hub, 0,05 s): Automático com
    # o campo vazio -> acha e preenche sozinho (igual ao Toolkit/CC).
    if not bpy.app.timers.is_registered(autodetect_on_startup):
        bpy.app.timers.register(autodetect_on_startup, first_interval=0.5, persistent=True)
    # .blend aberto: texturas que sumiram do cache voltam do Assets.zip.
    bpy.app.handlers.load_post.append(_restore_images_on_load)


def unregister():
    if _restore_images_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_restore_images_on_load)
    if bpy.app.timers.is_registered(autodetect_on_startup):
        bpy.app.timers.unregister(autodetect_on_startup)
    _invalidate_assets_source()
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
