"""Desenho com o módulo `gpu` (shaders GLSL próprios) e `blf` (texto).

  * `panel`  – retângulo arredondado com borda: distância assinada (SDF) e
               antialiasing linear pela derivada da tela;
  * `shadow` – sombra com desfoque gaussiano ANALÍTICO (sem amostrar textura),
               método público de Evan Wallace, "Fast Rounded Rectangle Shadows"
               (https://madebyevan.com/shaders/fast-rounded-rectangle-shadows/, CC0);
  * `dots`   – textura pontilhada em grade escalonada, num único draw call;
  * `icon`   – máscara de ícone tingida no shader: PNG pronto (gpu_ui/icons,
               gerado por icons.write_masks) ou, sem ele, calculada em Python;
               ou PNG via resolver do app (set_image_icon_resolver);
  * `image`  – PNG do disco: encaixe cover/contain/stretch, cantos arredondados,
               supersampling ao reduzir e "nearest" ao ampliar;
  * `nine`   – 9-slice: molduras/botões que esticam sem deformar os cantos;
  * `blit`   – copia a textura de cache da UI para a tela;
  * `grad`   – degradê contínuo com dither (sem faixas), `Renderer.gradient`.

Da Home (0.9.5): `image(..., smooth=True)` amplia com bilinear (fotos,
fundos, miniaturas -- o padrão "nearest" é pra pixel art), `nine_slice(...,
flip_y=True)`, `text(..., italic=True)` (cisalhamento da matriz),
`allow_full_res(path)` (fundo 1920x1080 sem o _shrink) e `put_pixels(key,
...)` com chave `mem:` (imagem sem PNG, ex.: miniatura lida de um .blend).

Imagens do disco, 9-slice e resolver de ícone vieram do Hyblend Character
Creator (mesmo tronco de framework). O PNG é decodificado FORA do desenho
(timer `_decode_tick`); o desenho só sobe pixels prontos pra GPU.
"""

import hashlib
import os
import shutil
import tempfile
import time
from collections import OrderedDict
from functools import lru_cache

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix

from . import CONFIG, icons
from .core import Rect

_FONT_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "fonts")
_MASK_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icons")   # icons.write_masks()
_masks_queued = [False]
# Fontes embutidas (reserva). "Bold" e "Title" caem na SemiBold da Geist.
_DEFAULT_FONT_FILES = {"Regular": "Geist-Regular.ttf", "Medium": "Geist-Medium.ttf",
                       "SemiBold": "Geist-SemiBold.ttf", "Bold": "Geist-SemiBold.ttf",
                       "Title": "Geist-SemiBold.ttf"}
# Fontes trocadas pelo app (ex.: as do jogo): peso -> caminho absoluto.
# Peso sem arquivo (ou com arquivo sumido) usa a embutida.
_font_overrides = {}
CAP_RATIO = 0.71          # altura da maiúscula / tamanho (em): Geist, Nunito Sans e Lexend ~0.70-0.71
_FONTS = {}               # peso -> font id
_PATH_IDS = {}            # arquivo carregado (cópia) -> font id: UM blf.load por arquivo
# O Blender MAPEIA o arquivo da fonte na memória enquanto ela está carregada.
# No Windows isso prende a pasta: carregar direto de dentro do addon impedia
# a desinstalação ("Acesso negado" ao renomear a pasta), e de dentro do jogo
# poderia atrapalhar uma atualização do Hytale. Por isso as fontes são
# carregadas de uma CÓPIA na pasta temporária do sistema (nome da pasta por
# addon: framework.configure(font_copy_dir=...)).


def _font_copy_dir():
    return os.path.join(tempfile.gettempdir(), CONFIG.font_copy_dir)
_PROGRAMS = {}
_ICONS = {}

# Imagens do disco (PNG): cache LRU compartilhado por todos os painéis.
_IMAGES = OrderedDict()        # caminho -> (textura, largura, altura, bytes)
_IMAGE_MISSING = set()         # caminhos que falharam (não tenta de novo a cada quadro)
_IMAGE_FAILS = {}              # caminho -> tentativas com erro (desiste depois de 3)
_DECODE_QUEUE = OrderedDict()  # caminhos esperando o timer de decodificação
_DECODED = {}                  # caminho -> (largura, altura, pixels) prontos pra subir pra GPU
IMAGE_CACHE_BYTES = 192 * 1024 * 1024
LOAD_BUDGET = 8                # no máximo N texturas novas enviadas à GPU por renderização
LOAD_BUDGET_SECONDS = 0.012    # orçamento de decodificação por rodada do timer (~12 ms)
_image_bytes = 0

# --------------------------------------------------------------------------
# GLSL
# --------------------------------------------------------------------------

# Todos os programas desenham o mesmo quadrado unitário, esticado por `bounds`
# (x, y, largura, altura em pixels) mais uma margem `pad` para AA/sombra.
_VERT = """
void main() {
    vec2 p = uRect.xy - vec2(uPad) + pos * (uRect.zw + vec2(2.0 * uPad));
    vLocal = p - uRect.xy;
    gl_Position = ModelViewProjectionMatrix * vec4(p, 0.0, 1.0);
}
"""

_SDF = """
float roundedBox(vec2 p, vec2 halfSize, float r) {
    vec2 q = abs(p) - halfSize + vec2(r);
    return min(max(q.x, q.y), 0.0) + length(max(q, vec2(0.0))) - r;
}
"""

_PANEL_FRAG = _SDF + """
void main() {
    vec2 halfSize = uRect.zw * 0.5;
    float dist = roundedBox(vLocal - halfSize, halfSize, uRadius);
    float px = max(length(vec2(dFdx(dist), dFdy(dist))), 1e-4);  /* tamanho de 1 pixel em "dist" */
    float outside = clamp(0.5 + dist / px, 0.0, 1.0);             /* 1 fora, 0 dentro */
    float inner = uStroke > 0.0 ? clamp(0.5 + (dist + uStroke) / px, 0.0, 1.0) : 0.0;
    vec4 color = mix(uFill, uLine, inner);
    fragColor = vec4(color.rgb, color.a * (1.0 - outside));
}
"""

_SHADOW_FRAG = """
float gauss(float x, float sigma) {
    return exp(-(x * x) / (2.0 * sigma * sigma)) / (2.5066282746 * sigma);
}
vec2 erf2(vec2 x) {                       /* aproximação de erf (Abramowitz–Stegun) */
    vec2 s = sign(x), a = abs(x);
    x = 1.0 + (0.278393 + (0.230389 + 0.078108 * (a * a)) * a) * a;
    x *= x;
    return s - s / (x * x);
}
float shadowX(float x, float y, float sigma, float r, vec2 halfSize) {
    float delta = min(halfSize.y - r - abs(y), 0.0);
    float curved = halfSize.x - r + sqrt(max(0.0, r * r - delta * delta));
    vec2 integral = 0.5 + 0.5 * erf2((x + vec2(-curved, curved)) * (0.7071067 / sigma));
    return integral.y - integral.x;
}
void main() {
    vec2 halfSize = uRect.zw * 0.5;
    vec2 p = vLocal - halfSize;
    float sigma = max(uStroke, 0.5);        /* aqui `uStroke` = desfoque */
    float low = p.y - halfSize.y, high = p.y + halfSize.y;
    float start = clamp(-3.0 * sigma, low, high), end = clamp(3.0 * sigma, low, high);
    float stepY = (end - start) / 4.0, y = start + stepY * 0.5, value = 0.0;
    for (int i = 0; i < 4; i++) {         /* integra a gaussiana em Y com 4 amostras */
        value += shadowX(p.x, p.y - y, sigma, uRadius, halfSize) * gauss(y, sigma) * stepY;
        y += stepY;
    }
    fragColor = vec4(uFill.rgb, uFill.a * value);
}
"""

_DOTS_FRAG = """
void main() {
    float row = floor(vLocal.y / uSpacing);
    vec2 cell = vec2(vLocal.x + mod(row, 2.0) * uSpacing * 0.5, vLocal.y);   /* linhas alternadas */
    vec2 d = (fract(cell / uSpacing) - 0.5) * uSpacing;
    float spot = clamp(uRadius + 0.5 - length(d), 0.0, 1.0);
    vec2 corner = vec2(uRect.z, uRect.w);                               /* brilho no canto sup. direito */
    float glow = 1.0 - clamp(length(corner - vLocal) / length(uRect.zw), 0.0, 1.0);
    fragColor = vec4(uFill.rgb, uFill.a * spot * (0.25 + 0.75 * glow));
}
"""

_ICON_FRAG = """
void main() {
    ivec2 size = textureSize(image, 0);
    ivec2 px = clamp(ivec2(floor(vLocal / uRect.zw * vec2(size))), ivec2(0), size - ivec2(1));
    fragColor = vec4(uFill.rgb, uFill.a * texelFetch(image, px, 0).a);
}
"""

_IMAGE_FRAG = _SDF + """
void main() {
    ivec2 size = textureSize(image, 0);
    vec2 t = vLocal / uRect.zw;                             /* 0..1 dentro do destino */
    vec2 texel = mix(uUV.xy, uUV.zw, t) * vec2(size);
    vec2 footprint = abs(uUV.zw - uUV.xy) * vec2(size) / uRect.zw;  /* texels por pixel */
    /* Reduzindo: média de até 8x8 amostras (sem serrilhado; imagens
       enormes já chegam reduzidas pela decodificação). uMaxN = teto por
       eixo (framework.configure(image_samples=...): 4 = desenho antigo do CC).
       Ampliando: 1 amostra "nearest" (pixel art continua nítida). */
    int n = int(clamp(ceil(max(footprint.x, footprint.y)), 1.0, clamp(uMaxN, 1.0, 8.0)));
    bool smoothMag = uMode > 2.5;     /* 3 = foto/arte: ampliar com bilinear */
    vec4 acc = vec4(0.0);
    for (int j = 0; j < 8; j++) {
        for (int i = 0; i < 8; i++) {
            if (i < n && j < n) {
                vec2 o = (vec2(float(i), float(j)) + 0.5) / float(n) - 0.5;
                ivec2 px = clamp(ivec2(floor(texel + o * footprint)), ivec2(0), size - ivec2(1));
                vec4 c = texelFetch(image, px, 0);
                acc += vec4(c.rgb * c.a, c.a);              /* média pré-multiplicada */
            }
        }
    }
    acc /= float(n * n);
    if (smoothMag && n == 1) {                                 /* ampliando foto: bilinear, sem blocos */
        vec2 q = texel - 0.5;
        ivec2 a = ivec2(floor(q));
        vec2 f = q - vec2(a);
        ivec2 hi = size - ivec2(1);
        vec4 c00 = texelFetch(image, clamp(a, ivec2(0), hi), 0);
        vec4 c10 = texelFetch(image, clamp(a + ivec2(1, 0), ivec2(0), hi), 0);
        vec4 c01 = texelFetch(image, clamp(a + ivec2(0, 1), ivec2(0), hi), 0);
        vec4 c11 = texelFetch(image, clamp(a + ivec2(1, 1), ivec2(0), hi), 0);
        acc = mix(mix(vec4(c00.rgb * c00.a, c00.a), vec4(c10.rgb * c10.a, c10.a), f.x),
                  mix(vec4(c01.rgb * c01.a, c01.a), vec4(c11.rgb * c11.a, c11.a), f.x), f.y);
    }
    vec3 rgb = acc.a > 0.0 ? acc.rgb / acc.a : vec3(0.0);
    if (uMode > 0.5 && !smoothMag) {
        rgb = uFill.rgb;                                     /* ícone monocromático tingido */
    }
    vec2 halfSize = uRect.zw * 0.5;
    float dist = roundedBox(vLocal - halfSize, halfSize, uRadius);
    float px = max(length(vec2(dFdx(dist), dFdy(dist))), 1e-4);
    float inside = 1.0 - clamp(0.5 + dist / px, 0.0, 1.0);
    /* uMode 2 = silhueta: opaco onde a imagem tem qualquer pixel (base sólida
       por baixo de arte translúcida, no formato exato dela) */
    float alpha = (uMode > 1.5 && !smoothMag) ? step(0.003, acc.a) : acc.a;
    fragColor = vec4(rgb, alpha * uFill.a * inside);
}
"""

_NINE_FRAG = """
float sliceAxis(float p, float dst, float lo, float hi, float src, float s) {
    if (p < lo * s) return p / s;                           /* canto/borda inicial: 1:1 */
    if (p > dst - hi * s) return src - (dst - p) / s;       /* canto/borda final: 1:1 */
    float middle = max(dst - (lo + hi) * s, 1e-3);          /* miolo: estica */
    return lo + (p - lo * s) / middle * (src - lo - hi);
}
void main() {
    ivec2 size = textureSize(image, 0);
    vec2 src = vec2(size);
    float ly = uFlip > 0.5 ? uRect.w - vLocal.y : vLocal.y;     /* espelhado na vertical */
    vec2 t = vec2(sliceAxis(vLocal.x, uRect.z, uSlice.x, uSlice.z, src.x, uScale),
                  sliceAxis(ly, uRect.w, uSlice.y, uSlice.w, src.y, uScale));
    vec4 c = texelFetch(image, clamp(ivec2(floor(t)), ivec2(0), size - ivec2(1)), 0);
    vec3 rgb = uMode > 0.5 ? uFill.rgb : c.rgb;
    float alpha = uMode > 1.5 ? step(0.003, c.a) : c.a;      /* 2 = silhueta (ver _IMAGE_FRAG) */
    fragColor = vec4(rgb, alpha * uFill.a);
}
"""

_BLIT_FRAG = """
void main() {
    ivec2 size = textureSize(image, 0);
    ivec2 px = clamp(ivec2(floor(vLocal / uRect.zw * vec2(size))), ivec2(0), size - ivec2(1));
    vec4 c = texelFetch(image, px, 0);            /* pré-multiplicado, em sRGB */
    vec3 rgb = c.a > 0.0 ? c.rgb / c.a : vec3(0.0);
    if (uRadius > 0.5) {                           /* aqui `uRadius` = saída linear? */
        /* Gamma 2.2 puro, NÃO a curva sRGB exata: a viewport devolve pra tela
           com 2.2 -- com a sRGB exata os escuros clareavam (~+5, medido no
           Blender real: #16202C saía #1C2531; o branco quase não muda). */
        rgb = pow(rgb, vec3(2.2));
    }
    fragColor = vec4(rgb, c.a * uFill.a);
}
"""

_GRAD_FRAG = """
void main() {
    /* degradê contínuo: uFill no início (baixo / esquerda) -> uLine no fim,
       peso do início = (1-t)^uPower. Dither de +-0.5/255 por pixel: textura de 8 bits em
       tons escuros formaria faixas visíveis sem ele. */
    float t = uAxis > 0.5 ? vLocal.x / max(uRect.z, 1.0) : vLocal.y / max(uRect.w, 1.0);
    float w = pow(1.0 - clamp(t, 0.0, 1.0), max(uPower, 0.01));
    vec4 c = mix(uLine, uFill, w);
    float n = fract(sin(dot(floor(gl_FragCoord.xy), vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
    c.rgb += n / 255.0;
    c.a = clamp(c.a + n / 255.0, 0.0, 1.0);
    fragColor = c;
}
"""

_SOURCES = {"grad": _GRAD_FRAG, "panel": _PANEL_FRAG, "shadow": _SHADOW_FRAG, "dots": _DOTS_FRAG,
            "icon": _ICON_FRAG, "blit": _BLIT_FRAG, "image": _IMAGE_FRAG, "nine": _NINE_FRAG}
# Uniforms por programa: vec4 próprios (além de uRect/uFill) e até 3 floats,
# que vão EMPACOTADOS em `uParam` (x = uPad, y/z/w = os floats abaixo). O
# Blender conta float solto como 8 bytes (medido no 5.0 pelo chat do
# protótipo) e o mínimo GARANTIDO de push constants é 128 bytes: mat4 + 4
# vec4 = 128 cabe; mat4 + 3 vec4 + 3 floats = 136 estourava ("Consider using
# UBO") -- no OpenGL funciona, no Vulkan um retângulo/imagem podia sumir.
# Cada programa declara SÓ o que usa (o driver elimina o resto e o Blender
# reclamaria ao preencher).
_VEC4S = {"grad": ("uLine",), "panel": ("uLine",), "image": ("uUV",), "nine": ("uSlice",)}
_FLOATS = {
    "grad": ("uPower", "uAxis"),
    "panel": ("uRadius", "uStroke"),
    "shadow": ("uRadius", "uStroke"),
    "dots": ("uRadius", "uSpacing"),
    "icon": (),
    "blit": ("uRadius",),
    "image": ("uRadius", "uMode", "uMaxN"),
    "nine": ("uScale", "uMode", "uFlip"),
}


def _param_defines(kind):
    """`#define uRadius uParam.y` etc.: os shaders continuam usando os nomes."""
    names = ("uPad",) + _FLOATS[kind]
    return "".join("#define %s uParam.%s\n" % (n, "xyzw"[i]) for i, n in enumerate(names))


_TEXTURED = {"icon", "blit", "image", "nine"}


def _program(kind):
    entry = _PROGRAMS.get(kind)
    if entry:
        return entry
    info = gpu.types.GPUShaderCreateInfo()
    info.push_constant("MAT4", "ModelViewProjectionMatrix")
    for name in ("uRect", "uFill") + _VEC4S.get(kind, ()) + ("uParam",):   # máx. 64 + 4 x 16 = 128 bytes
        info.push_constant("VEC4", name)
    if kind in _TEXTURED:
        info.sampler(0, "FLOAT_2D", "image")
    iface = gpu.types.GPUStageInterfaceInfo("%s_gpu_%s_io" % (CONFIG.namespace, kind))
    iface.smooth("VEC2", "vLocal")
    info.vertex_in(0, "VEC2", "pos")
    info.vertex_out(iface)
    info.fragment_out(0, "VEC4", "fragColor")
    defines = _param_defines(kind)
    info.vertex_source(defines + _VERT)
    info.fragment_source(defines + _SOURCES[kind])
    shader = gpu.shader.create_from_info(info)
    batch = batch_for_shader(shader, "TRIS", {"pos": ((0, 0), (1, 0), (1, 1), (0, 1))},
                             indices=((0, 1, 2), (0, 2, 3)))
    _PROGRAMS[kind] = entry = (shader, batch)
    return entry


# --------------------------------------------------------------------------
# Fontes
# --------------------------------------------------------------------------

def set_font_files(files):
    """Troca as fontes: {peso: caminho} (ex.: Lexend/Nunito Sans da pasta
    do jogo). {} volta pras embutidas. Só guarda os caminhos; o blf.load
    acontece no próximo texto desenhado (como sempre)."""
    new = {weight: path for weight, path in (files or {}).items() if path}
    if new == _font_overrides:
        return
    _font_overrides.clear()
    _font_overrides.update(new)
    _FONTS.clear()
    _width_px.cache_clear()


def _font_path(weight):
    """Arquivo da fonte de um peso. Peso terminado em "!" (ex.: "Title!") =
    o MESMO arquivo em qualquer addon: a fonte do jogo, se houver, senão a
    embutida PADRÃO do framework (ignora configure(builtin_fonts=...)). Usado
    pelo seletor dos addons Hyblend (switcher.py), que tem que sair igual
    no Toolkit, no CC e no Prefabs."""
    shared = weight.endswith("!")
    if shared:
        weight = weight[:-1]
    path = _font_overrides.get(weight)
    if path and os.path.isfile(path):
        return path
    files = dict(_DEFAULT_FONT_FILES) if shared else dict(_DEFAULT_FONT_FILES, **CONFIG.builtin_fonts)
    return os.path.join(_FONT_DIR, files.get(weight, files["Regular"]))


def _font_copy(path):
    """Cópia da fonte na pasta temporária (ver _font_copy_dir). Nome com
    hash do caminho de origem; recopia se o tamanho mudou. Falhou -> usa o
    original (a fonte funciona; só a pasta fica presa como antes)."""
    try:
        key = hashlib.sha1(os.path.abspath(path).encode("utf-8")).hexdigest()[:12]
        folder = _font_copy_dir()
        copy = os.path.join(folder, "%s_%s" % (key, os.path.basename(path)))
        if not os.path.isfile(copy) or os.path.getsize(copy) != os.path.getsize(path):
            os.makedirs(folder, exist_ok=True)
            shutil.copyfile(path, copy)
        return copy
    except OSError:
        return path


def _font(weight):
    font_id = _FONTS.get(weight)
    if font_id is None:
        source = _font_path(weight)
        font_id = -1
        if os.path.exists(source):
            path = _font_copy(source)
            # Mesmo arquivo em vários pesos (Geist-SemiBold = SemiBold, Bold e
            # Title): carrega UMA vez. Antes eram 3 blf.load e 1 blf.unload,
            # e o arquivo continuava mapeado depois de desabilitar o addon.
            font_id = _PATH_IDS.get(path, -1)
            if font_id < 0:
                font_id = blf.load(path)
                if font_id >= 0:
                    _PATH_IDS[path] = font_id
        _FONTS[weight] = font_id = max(font_id, 0)      # 0 = fonte padrão do Blender
    return font_id


@lru_cache(maxsize=8192)
def _width_px(font_id, px, text):
    blf.size(font_id, px)
    return blf.dimensions(font_id, text)[0]


# --------------------------------------------------------------------------
# Ícones procedurais (máscaras alpha geradas em Python, enviadas à GPU)
# --------------------------------------------------------------------------

def _icon_texture(name, px):
    key = (name, px)
    if key in _ICONS:
        return _ICONS[key]
    ss = 4                                   # 4x4 amostras por pixel = borda suave
    data = []
    for row in range(px):                    # linha 0 = base da textura
        for col in range(px):
            hits = sum(icons.inside(name, ((col + (sx + 0.5) / ss) / px) * 2 - 1,
                                    ((row + (sy + 0.5) / ss) / px) * 2 - 1)
                       for sy in range(ss) for sx in range(ss))
            data.extend((1.0, 1.0, 1.0, hits / (ss * ss)))
    texture = _make_texture(px, px, gpu.types.Buffer("FLOAT", px * px * 4, data))
    _ICONS[key] = texture
    return texture


@lru_cache(maxsize=None)
def _icon_mask_path(name):
    """PNG pronto do ícone procedural (gpu_ui/icons/<nome>.png), ou "".
    Nome desconhecido = "dot" (igual ao icons.inside)."""
    name = icons.ALIASES.get(name, name)
    if name not in icons._ICONS:
        name = "dot"
    path = os.path.join(_MASK_DIR, name + ".png")
    return path if os.path.isfile(path) else ""


def _queue_all_masks():
    """Na 1ª vez que um ícone é pedido: põe TODAS as máscaras na fila de
    decodificação (timer, fora do desenho) -- poucas KB, chegam juntas."""
    if _masks_queued[0]:
        return
    _masks_queued[0] = True
    try:
        preload(os.path.join(_MASK_DIR, f) for f in sorted(os.listdir(_MASK_DIR)) if f.endswith(".png"))
    except OSError:
        pass


def _make_texture(width, height, buf):
    for fmt in ("RGBA16F", "SFLOAT_16_16_16_16", "RGBA32F", "SFLOAT_32_32_32_32"):
        try:   # os nomes de formato mudaram entre versões do Blender
            return gpu.types.GPUTexture((width, height), format=fmt, data=buf)
        except (TypeError, ValueError):
            continue
    return None


# --------------------------------------------------------------------------
# Imagens do disco
# --------------------------------------------------------------------------

def _decode_pixels(path):
    """Lê o PNG pelo Blender e devolve (largura, altura, pixels float32 RGBA,
    linha 0 = base), apagando o datablock temporário -- nada fica no .blend.

    SÓ roda dentro de `_decode_tick` (bpy.app.timers), NUNCA dentro de um
    draw handler: o protótipo original chamava bpy.data.images.load/remove
    durante o desenho, que é exatamente o padrão "mexer em bpy.data dentro
    de callback de desenho/RNA" associado a crashes nativos sem log (DEVELOPER_NOTES,
    "Nada de bpy.data"). Aqui o draw só cria a GPUTexture a
    partir de pixels JÁ decodificados (operação puramente de GPU)."""
    import numpy as np
    image = bpy.data.images.load(path, check_existing=False)
    try:
        width, height = image.size
        if width == 0 or height == 0:
            return None
        pixels = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(pixels)       # linha 0 = base, igual à nossa textura
        if image.is_float:                     # PNG 16 bits chega em cor linear: volta para sRGB
            rgb = pixels.reshape(-1, 4)[:, :3]
            rgb[:] = np.where(rgb <= 0.0031308, rgb * 12.92,
                              1.055 * np.power(np.maximum(rgb, 0.0), 1 / 2.4) - 0.055)
        if path in _FULL_RES:                  # fundo de tela cheia: sem reduzir
            return (width, height, np.ascontiguousarray(pixels))
        return _shrink(width, height, pixels)
    finally:
        bpy.data.images.remove(image)


MAX_IMAGE_SIDE = 512
_FULL_RES = set()              # caminhos que NÃO passam pelo _shrink (fundos de tela cheia)
MEM_PREFIX = "mem:"            # chave de imagem sem arquivo (pixels entregues por put_pixels)


def allow_full_res(path):
    """Imagem desenhada grande (fundo 1920x1080): decodifica sem reduzir a 512 px."""
    if path:
        _FULL_RES.add(path)


def put_pixels(key, width, height, pixels):
    """Imagem que não vem de PNG no disco (ex.: miniatura lida de dentro de um
    .blend). `pixels` = float32 RGBA, linha 0 = base. Chamar FORA do desenho
    (timer); o desenho sobe pra GPU como qualquer outra (renderer.texture)."""
    global _image_bytes
    entry = _IMAGES.pop(key, None)
    if entry:
        _image_bytes -= entry[3]
    _IMAGE_MISSING.discard(key)
    _DECODED[key] = _shrink(width, height, pixels)



def _shrink(width, height, pixels):
    """Imagem grande nas DUAS dimensões (logo de 2048 px) é reduzida pela
    média 2x2 até <= MAX_IMAGE_SIDE: a UI nunca desenha isso maior que
    ~100 px, e o shader só faz até 8x8 amostras. Faixas longas e baixas
    (ContainerHeader 1428x76) ficam intactas -- o 9-slice precisa delas."""
    import numpy as np
    img = pixels.reshape(height, width, 4)
    while width > MAX_IMAGE_SIDE and height > MAX_IMAGE_SIDE:
        img = img[:height - height % 2, :width - width % 2]
        a = img[..., 3:4]
        premul = np.concatenate([img[..., :3] * a, a], axis=-1)
        h2, w2 = premul.shape[0] // 2, premul.shape[1] // 2
        premul = premul.reshape(h2, 2, w2, 2, 4).mean(axis=(1, 3))
        alpha = premul[..., 3:4]
        rgb = np.where(alpha > 0, premul[..., :3] / np.maximum(alpha, 1e-6), 0.0)
        img = np.concatenate([rgb, alpha], axis=-1).astype(np.float32)
        height, width = h2, w2
    return (width, height, np.ascontiguousarray(img).ravel())


def _decode_tick():
    """Timer: decodifica a fila de PNGs pedidos pelo desenho, até ~12 ms por
    rodada (sem travar a interface). Enquanto sobrar fila, reagenda na hora;
    o runtime continua re-renderizando (renderer.pending_images) e pega os
    pixels prontos no próximo quadro."""
    started = time.perf_counter()
    while _DECODE_QUEUE and time.perf_counter() - started < LOAD_BUDGET_SECONDS:
        path, _ = _DECODE_QUEUE.popitem(last=False)
        if path in _IMAGES or path in _DECODED or path in _IMAGE_MISSING:
            continue
        try:
            result = _decode_pixels(path)
        except Exception:
            fails = _IMAGE_FAILS[path] = _IMAGE_FAILS.get(path, 0) + 1
            if fails == 1:
                import traceback
                print("[%s] failed to load image:" % CONFIG.label, path)
                traceback.print_exc()
            if fails >= 3:
                _IMAGE_MISSING.add(path)
            continue
        if result is None:
            _IMAGE_MISSING.add(path)
        else:
            _DECODED[path] = result
    return 0.0 if _DECODE_QUEUE else None


def _request_decode(path):
    """Põe na FRENTE da fila e garante o timer. Chamado SEMPRE que a imagem
    ainda falta (a cada quadro enquanto não chega; is_registered é barato).

    Abrir outro .blend apaga timers não-persistentes, mas NÃO esvazia
    _DECODE_QUEUE. A 1a versão só chamava isto se o caminho ainda não
    estivesse na fila -- os que sobraram nunca mais registravam o timer
    e nunca carregavam (achado no CC). Por isso também: perguntar ao Blender, nunca flag própria."""
    _DECODE_QUEUE[path] = None
    # Pedido pelo DESENHO passa na frente da pré-carga (preload enfileira
    # ~80 PNGs do jogo): o que está na tela chega primeiro. Sem isso o
    # banner da janela de boas-vindas era o último (~0,6 s).
    _DECODE_QUEUE.move_to_end(path, last=False)
    if not bpy.app.timers.is_registered(_decode_tick):
        bpy.app.timers.register(_decode_tick, first_interval=0.0)


def preload(paths):
    """Enfileira PNGs pra decodificar ANTES de serem desenhados (timer,
    fora do desenho). Os que já estão prontos/na fila/faltando são pulados;
    arquivo inexistente também (versão do jogo sem a peça: sem erro no
    console -- texture() marca como faltando se o desenho pedir). Do CC."""
    queued = False
    for path in paths:
        if (not path or path in _IMAGES or path in _DECODED or path in _IMAGE_MISSING
                or path in _DECODE_QUEUE or not os.path.isfile(path)):
            continue
        _DECODE_QUEUE[path] = None
        queued = True
    if queued and not bpy.app.timers.is_registered(_decode_tick):
        bpy.app.timers.register(_decode_tick, first_interval=0.0)


def _upload(decoded):
    """(largura, altura, pixels) -> (textura, largura, altura, bytes) -- só GPU."""
    width, height, pixels = decoded
    try:
        buf = gpu.types.Buffer("FLOAT", pixels.size, pixels)          # cópia direta (rápida)
    except TypeError:
        buf = gpu.types.Buffer("FLOAT", pixels.size, pixels.tolist())  # versões antigas
    texture = _make_texture(width, height, buf)
    return (texture, width, height, width * height * 8) if texture else None


def forget_images(paths=None):
    """Descarta imagens do cache (ex.: o PNG mudou no disco)."""
    global _image_bytes
    for path in list(_IMAGES) if paths is None else paths:
        entry = _IMAGES.pop(path, None)
        if entry:
            _image_bytes -= entry[3]
    _IMAGE_MISSING.clear()
    _IMAGE_FAILS.clear()
    _DECODE_QUEUE.clear()
    _DECODED.clear()


def drop_image(path):
    """Libera UMA imagem do cache (textura na GPU + pixels decodificados),
    sem mexer no resto da fila -- ex.: banner da janela de boas-vindas ao
    fechar. Se for pedida de novo, é decodificada de novo."""
    global _image_bytes
    entry = _IMAGES.pop(path, None)
    if entry:
        _image_bytes -= entry[3]
    _DECODED.pop(path, None)
    _DECODE_QUEUE.pop(path, None)


def forget_fonts():
    """Abrir/criar um .blend DESCARREGA as fontes do blf.load: o id antigo
    passa a medir 0 e não desenhar nada (medido no 5.0.1: Geist 20 px media 145 px
    antes de read_homefile e 0 depois, mesmo id). Esquece ids e larguras em cache; o próximo desenho recarrega.
    Chamado no load_post (runtime). Imagens/ícones são texturas de GPU --
    não são afetados."""
    _PATH_IDS.clear()
    _FONTS.clear()
    _width_px.cache_clear()


# Ícones por IMAGEM (opcional, genérico do framework): o app registra uma
# função nome -> (caminho PNG, tingir?) ou None. tingir=True usa o PNG como
# máscara pintada com a cor pedida (glifo claro que segue hover/estado);
# False desenha as cores do próprio PNG. Sem resolver, tudo procedural.
_image_icon_resolver = None


def set_image_icon_resolver(fn):
    """fn(nome) -> (caminho, tingir) | None. None desliga."""
    global _image_icon_resolver
    _image_icon_resolver = fn


def release_resources():
    try:
        if bpy.app.timers.is_registered(_decode_tick):
            bpy.app.timers.unregister(_decode_tick)
    except Exception:
        pass
    for path in _PATH_IDS:
        try:
            blf.unload(path)
        except Exception:
            pass
    _PATH_IDS.clear()
    _FONTS.clear()
    _PROGRAMS.clear()
    _ICONS.clear()
    _icon_mask_path.cache_clear()
    _masks_queued[0] = False
    forget_images()
    _width_px.cache_clear()


def _pixel_projection(width, height):
    """Projeção que leva pixels (0..w, 0..h) da textura para −1..1."""
    return Matrix(((2.0 / width, 0.0, 0.0, -1.0),
                   (0.0, 2.0 / height, 0.0, -1.0),
                   (0.0, 0.0, -1.0, 0.0),
                   (0.0, 0.0, 0.0, 1.0)))


def render_to_texture(offscreen, renderer, scale, x0, y0, w, h, draw):
    """Renderiza a UI na textura de cache (GPUOffScreen) -- usado pelo
    N-Panel (runtime) e pela janela flutuante (overlay). Reaproveita
    `offscreen` se couber (folga de 128 px: redimensionar não realoca a
    cada pixel); senão cria outro. (x0, y0) = canto da textura em pixels
    da região; draw() desenha em unidades lógicas. Devolve a textura."""
    off = offscreen
    if off is None or off.width < w or off.height < h or off.width > w + 384 or off.height > h + 384:
        off = gpu.types.GPUOffScreen(-(-w // 128) * 128, -(-h // 128) * 128)
    with off.bind():
        gpu.state.active_framebuffer_get().clear(color=(0.0, 0.0, 0.0, 0.0))
        with gpu.matrix.push_pop(), gpu.matrix.push_pop_projection():
            gpu.matrix.load_matrix(Matrix.Identity(4))
            gpu.matrix.load_projection_matrix(_pixel_projection(off.width, off.height))
            renderer.begin(scale)
            renderer.offset_x, renderer.offset_y = -x0 / scale, -y0 / scale
            try:
                draw()
            finally:
                renderer.end()
    return off


def _to_linear(c):
    """Cor da UI -> espaço da viewport: gamma 2.2 puro (mesmo motivo do blit)."""
    return tuple(max(0.0, v) ** 2.2 for v in c[:3]) + (c[3],)


# --------------------------------------------------------------------------
# Renderer
# --------------------------------------------------------------------------

class Renderer:
    """Converte unidades lógicas em pixels e emite as chamadas de GPU."""

    def __init__(self):
        self.scale = 1.0
        self.opacity = 1.0
        self.offset_x = 0.0
        self.offset_y = 0.0
        self.linear = False   # True ao desenhar direto no viewport (cor linear)
        self.pending_images = False   # alguma imagem ficou para o próximo quadro
        # True = ícones SÓ pelo desenho procedural calculado (sem a arte de
        # ícone do app nem as máscaras prontas): o mesmo resultado em qualquer
        # addon. Usado pela faixa do seletor (switcher.Themed).
        self.plain_icons = False
        self._clip = []
        self._mvp = None
        self._loads = 0

    def begin(self, scale, *, linear=False):
        self.scale, self.linear = scale, linear
        self.opacity, self.offset_x, self.offset_y = 1.0, 0.0, 0.0
        self._clip = []
        self._mvp = gpu.matrix.get_projection_matrix() @ gpu.matrix.get_model_view_matrix()
        self.pending_images, self._loads = False, 0

    def end(self):
        gpu.state.scissor_test_set(False)
        gpu.state.blend_set("NONE")

    def _px(self, r):
        s = self.scale
        return Rect((r.x + self.offset_x) * s, (r.y + self.offset_y) * s, r.w * s, r.h * s)

    def _color(self, c):
        c = (c[0], c[1], c[2], c[3] * self.opacity)
        return _to_linear(c) if self.linear else c

    def _run(self, kind, px_rect, fill, *, pad=1.0, texture=None, mvp=None, blend="ALPHA", **values):
        shader, batch = _program(kind)
        gpu.state.blend_set(blend)            # blf.draw() desliga o blend: religar sempre
        shader.bind()
        shader.uniform_float("ModelViewProjectionMatrix", mvp or self._mvp)
        shader.uniform_float("uRect", (px_rect.x, px_rect.y, px_rect.w, px_rect.h))
        shader.uniform_float("uFill", fill)
        for name in _VEC4S.get(kind, ()):
            shader.uniform_float(name, values[name])
        param = [pad, 0.0, 0.0, 0.0]
        for i, name in enumerate(_FLOATS[kind]):
            param[i + 1] = values[name]
        shader.uniform_float("uParam", param)
        if texture is not None:
            shader.uniform_sampler("image", texture)
        batch.draw(shader)

    # ---- primitivas ----
    def rect(self, rect, color, *, radius=0.0, border=None, border_width=1.0):
        p = self._px(rect)
        if p.w <= 0 or p.h <= 0:
            return
        s = self.scale
        self._run("panel", p, self._color(color),
                  uLine=self._color(border) if border else (0.0, 0.0, 0.0, 0.0),
                  uRadius=max(0.0, min(radius * s, p.w / 2, p.h / 2)),
                  uStroke=border_width * s if border else 0.0)

    def gradient(self, rect, start, end, *, power=1.0, horizontal=False):
        """Degradê suave (sem faixas): `start` embaixo/à esquerda, `end` no
        outro lado; peso do início = (1 - t) ** power."""
        p = self._px(rect)
        if p.w <= 0 or p.h <= 0:
            return
        self._run("grad", p, self._color(start), pad=0.0, uLine=self._color(end),
                  uPower=power, uAxis=1.0 if horizontal else 0.0)

    def shadow(self, rect, radius, color, blur=10.0, dy=-4.0):
        p = self._px(Rect(rect.x, rect.y + dy, rect.w, rect.h))
        s = self.scale
        self._run("shadow", p, self._color(color), uRadius=min(radius * s, p.w / 2, p.h / 2),
                  uStroke=blur * 0.5 * s, pad=blur * 1.5 * s)

    def dots(self, rect, color, spacing=11.0, radius=0.9):
        p = self._px(rect)
        self._run("dots", p, self._color(color), uRadius=radius * self.scale,
                  uSpacing=spacing * self.scale, pad=0.0)

    def icon(self, rect, name, color):
        # Ordem: 1) arte do app (set_image_icon_resolver, ex.: PNG do jogo);
        # 2) máscara pronta do addon (gpu_ui/icons) -- também a reserva
        # enquanto a arte do jogo decodifica; 3) cálculo em Python, só pra
        # ícone sem PNG (novo). Máscara ainda decodificando = vazio por
        # alguns quadros (nunca o cálculo caro dentro do desenho).
        if _image_icon_resolver is not None and not self.plain_icons:
            found = _image_icon_resolver(name)
            if found:
                path, tinted = found
                alpha = color[3] if len(color) > 3 else 1.0
                if path and self.image(rect, path, fit="contain",
                                       tint=color if tinted else None,
                                       opacity=1.0 if tinted else alpha):
                    return
        p = self._px(rect)
        size = max(4, int(round(min(p.w, p.h))))
        x, y = round(p.x + (p.w - size) / 2), round(p.y + (p.h - size) / 2)   # alinhado ao pixel
        # Máscara pronta (PNG no addon): carrega e tinge, sem calcular nada.
        mask = "" if self.plain_icons else _icon_mask_path(name)
        if mask:
            _queue_all_masks()
            s = self.scale
            if self.image(Rect(x / s - self.offset_x, y / s - self.offset_y, size / s, size / s), mask,
                          fit="stretch", tint=color):
                return
            if mask not in _IMAGE_MISSING:
                return      # ainda decodificando (alguns quadros): vazio -- nada de cálculo caro aqui
        texture = _icon_texture(name, size)      # sem PNG (ícone novo): cálculo antigo
        if texture is None:
            return
        self._run("icon", Rect(x, y, size, size), self._color(color), pad=0.0, texture=texture)

    # ---- imagens ----
    def texture(self, path):
        """(textura, largura, altura) de um PNG, ou None (faltando ou ainda na fila)."""
        global _image_bytes
        entry = _IMAGES.get(path)
        if entry is not None:
            _IMAGES.move_to_end(path)
            return entry
        if not path or path in _IMAGE_MISSING:
            return None
        decoded = _DECODED.get(path)
        if decoded is None:
            # Ainda não decodificado: pede ao timer (FORA do desenho) e
            # continua renderizando até chegar (pending_images).
            if path.startswith(MEM_PREFIX):
                return None                  # ainda não entregue (put_pixels) -- sem fila
            if not os.path.isfile(path):
                _IMAGE_MISSING.add(path)
                return None
            _request_decode(path)   # SEMPRE (correção 6): garante o timer mesmo se a fila sobrou de antes
            self.pending_images = True
            return None
        if self._loads >= LOAD_BUDGET:
            self.pending_images = True           # sobe pra GPU no próximo quadro
            return None
        self._loads += 1
        del _DECODED[path]
        entry = _upload(decoded)
        if entry is None:
            _IMAGE_MISSING.add(path)
            return None
        _IMAGES[path] = entry
        _image_bytes += entry[3]
        while _image_bytes > IMAGE_CACHE_BYTES and len(_IMAGES) > 1:
            _, old = _IMAGES.popitem(last=False)   # descarta a usada há mais tempo
            _image_bytes -= old[3]
        return entry

    def image(self, rect, path, *, fit="contain", radius=0.0, tint=None, opacity=1.0, silhouette=False,
              smooth=False):
        """Desenha um PNG do disco. fit: "cover" (preenche e corta),
        "contain" (cabe inteiro) ou "stretch". tint: cor para ícones
        monocromáticos. silhouette=True (com tint): cor sólida OPACA no
        formato da imagem -- base por baixo de arte translúcida. smooth=True:
        ampliação bilinear (fotos/fundos; o padrão "nearest" é pra pixel art). Retorna
        False se não há imagem (ainda) -- quem chama desenha um substituto."""
        entry = self.texture(path)
        if entry is None:
            return False
        texture, w, h, _ = entry
        uv = (0.0, 0.0, 1.0, 1.0)
        if fit == "cover" and rect.w > 0 and rect.h > 0:
            ratio = (w / h) / (rect.w / rect.h)
            if ratio > 1:                        # imagem mais larga: corta os lados
                m = (1 - 1 / ratio) / 2
                uv = (m, 0.0, 1 - m, 1.0)
            else:                                # mais alta: corta em cima/embaixo
                m = (1 - ratio) / 2
                uv = (0.0, m, 1.0, 1 - m)
        elif fit == "contain" and w > 0 and h > 0:
            k = min(rect.w / w, rect.h / h)
            cw, ch = w * k, h * k
            rect = Rect(rect.x + (rect.w - cw) / 2, rect.y + (rect.h - ch) / 2, cw, ch)
        p = self._px(rect)
        if p.w <= 0 or p.h <= 0:
            return True
        color = self._color(tint if tint is not None else (1.0, 1.0, 1.0, 1.0))
        color = color[:3] + (color[3] * opacity,)
        self._run("image", p, color, pad=0.0, texture=texture, uUV=uv,
                  uRadius=max(0.0, min(radius * self.scale, p.w / 2, p.h / 2)),
                  uMode=(2.0 if silhouette else 1.0) if tint is not None else (3.0 if smooth else 0.0),
                  uMaxN=float(CONFIG.image_samples))
        return True

    def nine_slice(self, rect, path, slices, *, scale=1.0, tint=None, opacity=1.0, silhouette=False,
                   flip_y=False):
        """Moldura 9-slice. slices = (esquerda, topo, direita, baixo) em pixels da
        imagem; cantos ficam em tamanho fixo (× scale), bordas e miolo esticam.
        silhouette=True (com tint): base opaca no formato da moldura."""
        entry = self.texture(path)
        if entry is None:
            return False
        texture = entry[0]
        p = self._px(rect)
        if p.w <= 0 or p.h <= 0:
            return True
        left, top, right, bottom = slices
        # Retângulo menor que as bordas (botão estreito): encolhe os cantos
        # por igual em vez de sobrepor/inverter o miolo.
        if left + right > 0:
            scale = min(scale, rect.w / (left + right))
        if top + bottom > 0:
            scale = min(scale, rect.h / (top + bottom))
        color = self._color(tint if tint is not None else (1.0, 1.0, 1.0, 1.0))
        self._run("nine", p, color[:3] + (color[3] * opacity,), pad=0.0, texture=texture,
                  uSlice=(left, bottom, right, top),
                  uScale=scale * self.scale,
                  uMode=(2.0 if silhouette else 1.0) if tint is not None else 0.0,
                  uFlip=1.0 if flip_y else 0.0)
        return True

    def blit(self, texture, x, y, w, h, *, opacity=1.0, linear=False):
        """Copia a textura de cache 1:1 em pixels da região atual."""
        mvp = gpu.matrix.get_projection_matrix() @ gpu.matrix.get_model_view_matrix()
        self._run("blit", Rect(x, y, w, h), (1.0, 1.0, 1.0, opacity), uRadius=1.0 if linear else 0.0,
                  pad=0.0, texture=texture, mvp=mvp)
        gpu.state.blend_set("NONE")

    def cover(self, x, y, w, h, color, *, replace=False):
        """Pinta um retângulo em PIXELS da região atual.

        replace=True escreve a cor sem misturar (inclusive o alpha): com
        (0, 0, 0, 0) a área fica transparente, "furando" a região.
        """
        mvp = gpu.matrix.get_projection_matrix() @ gpu.matrix.get_model_view_matrix()
        self._run("panel", Rect(x, y, w, h), color, pad=0.0, mvp=mvp,
                  blend="NONE" if replace else "ALPHA",
                  uLine=(0.0, 0.0, 0.0, 0.0), uRadius=0.0, uStroke=0.0)
        gpu.state.blend_set("NONE")

    # ---- texto ----
    def _tracking_px(self, tracking):
        """Espaço entre letras em PIXELS INTEIROS (mín. 1): com meio pixel
        (0,5 lógico na escala 1x) cada letra arredondava pra um lado e os
        vãos ficavam desiguais ("LOC AL IZ AR")."""
        return max(1, round(tracking * self.scale)) if tracking else 0

    def text_width(self, text, size=12.0, weight="Regular", tracking=0.0):
        px = max(6, round(size * self.scale))
        text = str(text)
        if tracking and CONFIG.text_tracking == "sum":
            # desenho antigo do CC: soma das letras soltas + espaço fracionário
            font_id = _font(weight)
            return (sum(_width_px(font_id, px, ch) for ch in text) / self.scale
                    + tracking * max(0, len(text) - 1))
        width = _width_px(_font(weight), px, text)
        if tracking:
            width += self._tracking_px(tracking) * max(0, len(text) - 1)
        return width / self.scale

    def _fit(self, text, width, size, weight):
        full = self.text_width(text, size, weight)
        if full <= width:
            return text
        # estimativa proporcional + ajuste fino (poucas medições, todas em cache)
        n = max(0, min(len(text) - 1, int(len(text) * width / max(full, 1e-3))))
        while n > 0 and self.text_width(text[:n] + "…", size, weight) > width:
            n -= 1
        while n + 1 < len(text) and self.text_width(text[:n + 1] + "…", size, weight) <= width:
            n += 1
        return text[:n].rstrip() + "…" if n else ""

    ITALIC_SLANT = 0.2       # itálico sintético (as fontes do jogo não têm itálico): x += 0.2 * y

    def text(self, rect, text, color, *, size=12.0, weight="Regular", align="LEFT", truncate=True,
             tracking=0.0, shadow=None, italic=False):
        """tracking: espaço extra entre letras (títulos em caixa alta).
        shadow: (cor RGBA, dx, dy) -- sombra nativa do blf (mesma chamada
        de desenho, sem desenhar o texto duas vezes)."""
        if rect.w <= 1 or rect.h <= 1:
            return
        text = str(text)
        if truncate and not tracking:
            text = self._fit(text, rect.w, size, weight)
        if not text:
            return
        font_id = _font(weight)
        px = max(6, round(size * self.scale))
        width = self.text_width(text, size, weight, tracking)
        if align == "CENTER":
            x = rect.x + (rect.w - width) / 2
        elif align == "RIGHT":
            x = rect.right - width
        else:
            x = rect.x
        # centraliza pela altura da maiúscula (métrica fixa da fonte, sem medir)
        y = rect.y + (rect.h - size * CAP_RATIO) / 2
        blf.size(font_id, px)
        blf.color(font_id, color[0], color[1], color[2], color[3] * self.opacity)
        if shadow is not None:
            (sr, sg, sb, sa), dx, dy = shadow
            blf.enable(font_id, blf.SHADOW)
            blf.shadow(font_id, 0, sr, sg, sb, sa * self.opacity)
            blf.shadow_offset(font_id, round(dx * self.scale), round(dy * self.scale))
        base_x = round((x + self.offset_x) * self.scale)
        base_y = round((y + self.offset_y) * self.scale)
        if italic:
            # O blf desenha pela matriz da GPU: inclina as letras em volta da
            # linha de base (o texto não sai do lugar, só o topo vai pra direita).
            k = self.ITALIC_SLANT
            gpu.matrix.push()
            gpu.matrix.multiply_matrix(Matrix(((1.0, k, 0.0, -k * base_y), (0.0, 1.0, 0.0, 0.0),
                                               (0.0, 0.0, 1.0, 0.0), (0.0, 0.0, 0.0, 1.0))))
        try:
            if not tracking:
                blf.position(font_id, base_x, base_y, 0)
                blf.draw(font_id, text)
                return
            if CONFIG.text_tracking == "sum":
                # desenho antigo do CC (framework.configure(text_tracking="sum"))
                for ch in text:
                    blf.position(font_id, round((x + self.offset_x) * self.scale), base_y, 0)
                    blf.draw(font_id, ch)
                    x += _width_px(font_id, px, ch) / self.scale + tracking
                return
            # Letra por letra, com espaço extra, tudo em pixels inteiros. A
            # posição vem da largura do PREFIXO (texto[:i]), não da soma das
            # letras soltas: a largura de uma letra sozinha (ex.: "Y" do
            # Lexend) passa do avanço dela dentro da palavra ("HY BLEND").
            step = self._tracking_px(tracking)
            for i, ch in enumerate(text):
                if ch == " ":
                    continue
                left = _width_px(font_id, px, text[:i]) if i else 0.0
                blf.position(font_id, base_x + round(left) + step * i, base_y, 0)
                blf.draw(font_id, ch)
        finally:
            if shadow is not None:
                blf.disable(font_id, blf.SHADOW)
            if italic:
                gpu.matrix.pop()

    # ---- recorte ----
    def _apply_clip(self):
        if not self._clip:
            gpu.state.scissor_test_set(False)
            return
        p = self._px(self._clip[-1])
        x, y = int(max(0.0, p.x)), int(max(0.0, p.y))
        gpu.state.scissor_set(x, y, max(0, int(p.right) - x), max(0, int(p.top) - y))
        gpu.state.scissor_test_set(True)

    def push_clip(self, rect):
        self._clip.append(self._clip[-1].intersect(rect) if self._clip else rect)
        self._apply_clip()

    def pop_clip(self):
        if self._clip:
            self._clip.pop()
        self._apply_clip()
