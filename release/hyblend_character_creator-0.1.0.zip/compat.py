"""compat.py -- camada de compatibilidade Blender 4.5 LTS <-> 5.x (5.0/5.1/
5.2 LTS). UNICO lugar do addon que pode perguntar "qual versao do Blender
e esta?" -- todo o resto chama as funcoes daqui em vez de espalhar
`if bpy.app.version >= ...` pelo codigo.

Camada 0 na hierarquia de import: depende SO de `bpy` (nada interno do
addon), entao qualquer modulo (common, builder/, thumbnails/, interface/)
pode importar daqui sem risco de import circular.

REGRA DE DESIGN: sempre que der, detectar pela PRESENCA do recurso
(hasattr / enum_items / try-except) e usar a versao so como desempate
ou pra escolher a ORDEM de tentativa. Motivo: versao e um proxy -- um
build alpha/beta, ou um patch de manutencao, pode ter o recurso antes/
depois do numero "oficial". Detectar pelo recurso real nunca erra.

Mudancas de API cobertas aqui (fonte: release notes oficiais do
Blender, docs/release_notes/5.0|5.1|5.2/python_api.md -- conferido
durante a sessao que criou este arquivo, ver DEVELOPER_NOTES item 56):

  5.0  - EEVEE: id do engine voltou de BLENDER_EEVEE_NEXT (4.2-4.5) pra
         BLENDER_EEVEE.                          -> set_eevee_engine()
  5.0  - Material.use_nodes virou no-op DEPRECADO (warning ao ler/
         escrever; remocao marcada pro 6.0). Material novo ja nasce com
         node_tree populado. No 4.5, nasce SEM node_tree ate ligar
         use_nodes.                              -> ensure_node_tree()
  4.2+ - Material.blend_method -> surface_render_method (blend_method
         virou alias deprecado); shadow_method -> use_transparent_shadow.
                                                  -> set_material_alpha_clip()
  5.0  - ImageFormatSettings exige `media_type` ANTES de `file_format`.
                                                  -> set_png_output()
  5.0  - Propriedades registradas via bpy.props NAO sao mais acessiveis
         por `obj["nome"]` (separadas das custom properties). Custom
         property de verdade (`obj["x"] = ...` sem registro) continua
         funcionando igual.                       -> get_id_prop()
  5.1  - Python 3.11 -> 3.13 (nenhum modulo da stdlib usado pelo addon
         foi removido -- conferido: json/zlib/struct/zipfile/tempfile/
         pathlib/dataclasses/re/os/math/shutil).
  5.2  - Nenhuma mudanca que toque este addon (GN modifier API,
         automasking, asset library index, template_palette -- nada
         disso e usado aqui).
"""

from __future__ import annotations

import bpy

# ---------------------------------------------------------------------------
# Versao
# ---------------------------------------------------------------------------

BLENDER_VERSION: tuple = tuple(bpy.app.version[:3])
IS_BLENDER_5_OR_NEWER: bool = BLENDER_VERSION >= (5, 0, 0)


def version_at_least(major: int, minor: int = 0, patch: int = 0) -> bool:
    """Usado pela trava da UI por GPU (interface/gpu_ui, so 5.0+). Pra
    diferenca de API, preferir detectar o recurso (ver cabecalho)."""
    return BLENDER_VERSION >= (major, minor, patch)


# ---------------------------------------------------------------------------
# Render engine
# ---------------------------------------------------------------------------

_EEVEE_ID_5X = "BLENDER_EEVEE"
_EEVEE_ID_4X = "BLENDER_EEVEE_NEXT"


def eevee_engine_candidates() -> tuple:
    """Ordem de tentativa do id do EEVEE -- o nome "certo" da versao
    atual primeiro, o outro como reserva (build intermediario, etc.)."""
    if IS_BLENDER_5_OR_NEWER:
        return (_EEVEE_ID_5X, _EEVEE_ID_4X)
    return (_EEVEE_ID_4X, _EEVEE_ID_5X)


def set_eevee_engine(scene) -> bool:
    """Seta EEVEE no `scene.render.engine` com o id certo pra versao.
    Devolve False (sem lancar) se nenhum dos ids for aceito -- nesse
    caso o engine fica como estava."""
    for engine_id in eevee_engine_candidates():
        try:
            scene.render.engine = engine_id
            return True
        except TypeError:
            continue
    return False


# ---------------------------------------------------------------------------
# Material / nodes
# ---------------------------------------------------------------------------

def ensure_node_tree(material):
    """Garante que o material tem node_tree e devolve ela.

    4.5: material novo nasce com `node_tree is None` -- precisa ligar
    `use_nodes` pra criar. 5.x: ja nasce com node_tree populado, e
    `use_nodes` e um no-op deprecado que gera warning -- entao SO
    encosta nele quando a arvore realmente nao existe (mesma estrategia
    que outros addons publicos adotaram pra essa transicao)."""
    if material.node_tree is None:
        try:
            material.use_nodes = True
        except AttributeError:
            # 6.0+ (use_nodes removido) -- a arvore deveria existir
            # sempre; se nao existe, nao ha nada mais a fazer aqui.
            pass
    return material.node_tree


def find_node_by_type(nodes, node_type: str):
    """Acha o primeiro no pelo `type` (ex. "BSDF_PRINCIPLED",
    "OUTPUT_MATERIAL") -- NUNCA pelo nome. O nome do no padrao pode vir
    traduzido (Preferences > Interface > Translation > "New Data") ou
    mudar entre versoes; o `type` e estavel."""
    for node in nodes:
        if node.type == node_type:
            return node
    return None


def ensure_principled_setup(node_tree):
    """Devolve (principled_bsdf, material_output) da arvore, CRIANDO o
    que faltar (e ligando BSDF -> Surface se tiver criado algum dos
    dois). Cobre as duas situacoes reais: arvore padrao que o Blender
    cria (4.5 ao ligar use_nodes / 5.x ao criar o material) e arvore
    vazia/diferente do esperado."""
    nodes = node_tree.nodes
    links = node_tree.links
    bsdf = find_node_by_type(nodes, "BSDF_PRINCIPLED")
    output = find_node_by_type(nodes, "OUTPUT_MATERIAL")
    created = False
    if output is None:
        output = nodes.new("ShaderNodeOutputMaterial")
        output.location = (300, 0)
        created = True
    if bsdf is None:
        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.location = (0, 0)
        created = True
    if created:
        links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    return bsdf, output


def set_material_alpha_clip(material) -> None:
    """Transparencia "recortada" (pixel-art: pixel e 100% visivel ou
    100% invisivel) no EEVEE, em qualquer versao suportada.

    4.2+ (inclui 4.5 e 5.x): `surface_render_method = "DITHERED"` -- e
    pra onde o antigo blend_method "CLIP" foi mapeado quando o EEVEE
    Next entrou. `use_transparent_shadow = True` substitui o antigo
    shadow_method "CLIP". Os nomes antigos ficam como reserva, SO se o
    novo nao existir. Nunca lanca -- uma property ausente so e pulada."""
    if hasattr(material, "surface_render_method"):
        try:
            material.surface_render_method = "DITHERED"
        except (AttributeError, TypeError):
            pass
    else:
        try:
            material.blend_method = "CLIP"
        except (AttributeError, TypeError):
            pass

    if hasattr(material, "use_transparent_shadow"):
        try:
            material.use_transparent_shadow = True
        except (AttributeError, TypeError):
            pass
    else:
        try:
            material.shadow_method = "CLIP"
        except (AttributeError, TypeError):
            pass


# ---------------------------------------------------------------------------
# Imagens
# ---------------------------------------------------------------------------

# Nomes de colorspace "dado cru, sem gamma" conhecidos entre configs OCIO
# (o padrao do Blender usa "Non-Color" desde o 4.0). Tentados em ordem.
_NON_COLOR_NAMES = ("Non-Color", "Generic Data", "Raw", "Data")


def set_image_non_color(image) -> bool:
    """Marca a imagem como DADO (luminancia usada como coordenada, nao
    uma cor) -- ver DEVELOPER_NOTES item 26 (bug real de cor quando isso
    ficava em sRGB). Tenta os nomes conhecidos; se a config OCIO do
    usuario nao tiver nenhum, usa `is_data` (flag independente de nome).
    Devolve True se conseguiu por algum caminho."""
    settings = image.colorspace_settings
    for name in _NON_COLOR_NAMES:
        try:
            settings.name = name
            return True
        except TypeError:
            continue
    try:
        settings.is_data = True
        return True
    except (AttributeError, TypeError):
        return False


def set_png_output(image_settings, color_mode: str = "RGBA") -> None:
    """Configura saida PNG num ImageFormatSettings (ex.
    `scene.render.image_settings`). 5.0+: `media_type` TEM que vir antes
    de `file_format` (senao o formato pode ser recusado). 4.5 nao tem
    `media_type` -- pula direto pro file_format."""
    if hasattr(image_settings, "media_type"):
        try:
            image_settings.media_type = "IMAGE"
        except (AttributeError, TypeError):
            pass
    image_settings.file_format = "PNG"
    image_settings.color_mode = color_mode


# ---------------------------------------------------------------------------
# Propriedades em ID/Bone
# ---------------------------------------------------------------------------

_MISSING = object()


def get_id_prop(owner, name: str, default=None):
    """Le uma propriedade "hytale_*"/"hyblendcc_*" de um Object/Bone/etc.
    independente de COMO ela foi gravada:

      1. custom property de verdade (`owner["name"] = ...`) -- como este
         addon grava, e como o Hyblend gravava ate aqui. Funciona igual
         no 4.5 e no 5.x.
      2. propriedade REGISTRADA via bpy.props (ex. se uma versao futura
         do Hyblend Toolkit passar a registrar `hytale_shape_offset`
         como property de verdade). No 5.0+ essa NAO aparece mais em
         `owner["name"]`/`owner.get()` -- so via getattr.

    Nao usa `bl_system_properties_get()` de proposito: a propria doc do
    5.0 desaconselha contornar o sistema de RNA assim."""
    try:
        value = owner.get(name, _MISSING)
    except (AttributeError, TypeError):
        value = _MISSING
    if value is not _MISSING:
        return value
    try:
        rna_props = owner.bl_rna.properties
    except AttributeError:
        return default
    if name in rna_props:
        return getattr(owner, name, default)
    return default


# ---------------------------------------------------------------------------
# Icones nativos
# ---------------------------------------------------------------------------

_native_icon_names = None


def _load_native_icon_names():
    global _native_icon_names
    if _native_icon_names is None:
        try:
            items = bpy.types.UILayout.bl_rna.functions["label"].parameters["icon"].enum_items
            _native_icon_names = frozenset(item.identifier for item in items)
        except (AttributeError, KeyError, TypeError):
            # Sem introspeccao disponivel -- confia no nome pedido.
            _native_icon_names = frozenset()
    return _native_icon_names


def native_icon(name: str, fallback: str = "QUESTION") -> str:
    """Nome de icone nativo que EXISTE nesta versao do Blender. Icone
    inexistente em `layout.operator(icon=...)` lanca TypeError e quebra
    o draw() do painel inteiro -- o 5.0 ja removeu icones (ex. RNA_ADD),
    entao qualquer icone novo usado pela UI passa por aqui. Lookup num
    frozenset cacheado: barato o bastante pra rodar em todo draw()."""
    names = _load_native_icon_names()
    if not names or name in names:
        return name
    return fallback if fallback in names else "NONE"
