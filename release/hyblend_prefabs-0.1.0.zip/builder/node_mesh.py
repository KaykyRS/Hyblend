"""node_mesh.py -- percorre a arvore de "nodes" de um .blockymodel e funde
tudo numa UNICA malha Blender (sem Armature/bones -- um bloco de prefab e
estatico). O resultado e cacheado e reaproveitado por todas as instancias
daquele item no prefab (ver prefab_importer.py)."""

from __future__ import annotations

import bpy
from mathutils import Matrix, Vector

from ..common import quat_xyzw, vec3
from .box_mesh import build_shape_mesh


def _shape_offset_of(node: dict, unit_scale: float) -> Vector:
    shape = node.get("shape") or {}
    return vec3(shape.get("offset", {})) * unit_scale


def _node_local_matrix(node: dict, parent_shape_offset: Vector, unit_scale: float) -> Matrix:
    pos = vec3(node.get("position", {})) * unit_scale
    pos = pos + parent_shape_offset
    rot = quat_xyzw(node.get("orientation", {"w": 1.0}))
    return Matrix.Translation(pos) @ rot.to_matrix().to_4x4()


def _append_mesh_into(master_bm, uv_layer, node_mesh: bpy.types.Mesh, world_matrix: Matrix) -> None:
    node_mesh.transform(world_matrix)
    src_uv = node_mesh.uv_layers.active.data if node_mesh.uv_layers.active else None

    bm_verts = [master_bm.verts.new(v.co) for v in node_mesh.vertices]
    for poly in node_mesh.polygons:
        loop_indices = poly.loop_indices
        face_verts = [bm_verts[node_mesh.loops[li].vertex_index] for li in loop_indices]
        try:
            face = master_bm.faces.new(face_verts)
        except ValueError:
            continue  # face duplicada (nao deve travar o import inteiro)
        if src_uv is not None:
            for loop, li in zip(face.loops, loop_indices):
                loop[uv_layer].uv = src_uv[li].uv

    bpy.data.meshes.remove(node_mesh)


def build_item_mesh(
    name: str,
    root_nodes: list,
    unit_scale: float,
    atlas_w: float,
    atlas_h: float,
    item_scale: float = 1.0,
    root_correction: Matrix | None = None,
) -> bpy.types.Mesh:
    """`root_nodes` = data["nodes"] cru do .blockymodel. Devolve uma
    bpy.types.Mesh com toda a geometria do item, posicionada relativa a
    origem do proprio item.

    `item_scale` -- campo "Scale" da raiz do JSON do item, aplicado em
    torno da origem antes de qualquer posicionamento no mundo.

    `root_correction` -- rotacao extra em torno da origem, aplicada ANTES
    do posicionamento no mundo. NAO CONFIRMADO visualmente (ver
    prefab_importer.py/_build_mesh_entry para quando isso e usado).
    Default None preserva o comportamento sem correcao."""
    import bmesh

    master = bmesh.new()
    uv_layer = master.loops.layers.uv.new()

    def visit(node: dict, parent_world: Matrix, parent_shape_offset: Vector) -> None:
        local = _node_local_matrix(node, parent_shape_offset, unit_scale)
        world = parent_world @ local  # matriz do pivo do no (sem offset proprio)

        this_shape_offset = _shape_offset_of(node, unit_scale)

        shape = node.get("shape") or {}
        shape_type = shape.get("type")
        # shape.visible == false -> pular (hitbox/parte oculta); filhos
        # continuam sendo visitados normalmente.
        if shape_type in ("box", "quad") and shape.get("visible", True) is not False:
            node_mesh = build_shape_mesh(node.get("name", "node"), shape, unit_scale, atlas_w, atlas_h)
            # Todo no tem dois deslocamentos: a matriz do pivo (usada pros
            # FILHOS) e o offset proprio do no (so entra na malha VISUAL).
            visual_world = world @ Matrix.Translation(this_shape_offset)
            _append_mesh_into(master, uv_layer, node_mesh, visual_world)

        for child in node.get("children", []):
            visit(child, world, this_shape_offset)

    root_matrix = Matrix.Diagonal((item_scale, item_scale, item_scale, 1.0))
    if root_correction is not None:
        root_matrix = root_matrix @ root_correction
    for root in root_nodes:
        visit(root, root_matrix, Vector((0.0, 0.0, 0.0)))

    master.normal_update()
    mesh = bpy.data.meshes.new(name + "_mesh")
    master.to_mesh(mesh)
    master.free()
    return mesh
