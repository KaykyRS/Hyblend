"""materials.py -- material flat (Image Texture -> Base Color), cacheado
por caminho resolvido."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import bpy

# Cache em memoria: caminho resolvido (str) -> bpy.types.Image / bpy.types.Material.
# Sobrevive entre chamadas do operator na mesma sessao do Blender, nao entre sessoes.
_image_cache: dict = {}
_material_cache: dict = {}
_tinted_image_cache: dict = {}
_transparency_cache: dict = {}  # nome da imagem -> bool

# Opcoes do Optimizer que afetam material, ligadas pelo operador de import
# so durante o execute() (ver prefab_importer.py). Fora do import ficam no
# padrao -- nada muda pra quem nao usa o Optimizer.
_options = {"smart_alpha": False}


def set_import_options(*, smart_alpha: bool = False) -> None:
    _options["smart_alpha"] = bool(smart_alpha)


def image_has_transparency(image: Optional[bpy.types.Image]) -> bool:
    """True se a imagem tem pelo menos UM pixel com alpha < 1. Imagem sem
    canal alpha (depth != 32) -> False. Resultado cacheado por nome (uma
    leitura de pixels por imagem unica -- texturas de bloco sao pequenas)."""
    if image is None:
        return False
    if image.depth != 32:
        return False
    key = image.name
    cached = _transparency_cache.get(key)
    if cached is not None:
        return cached
    try:
        import numpy as np

        width, height = image.size
        pixels = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(pixels)
        result = bool((pixels[3::4] < 0.999).any())
    except Exception:  # noqa: BLE001 -- na duvida, trata como transparente (seguro)
        result = True
    _transparency_cache[key] = result
    return result


def _cache_get_alive(cache: dict, key, data_collection) -> Optional[object]:
    """cache[key] se ainda for um datablock valido, senao None (e remove do cache).

    bool(datablock) pode passar mesmo quando um .name posterior lanca
    ReferenceError (visto no Blender 5.2 real, provavelmente apos Undo/redo
    ou reload do addon) -- as duas checagens precisam ficar no mesmo try/except."""
    cached = cache.get(key)
    if cached is None:
        return None
    try:
        if cached and cached.name in data_collection:
            return cached
    except ReferenceError:
        pass
    cache.pop(key, None)
    return None


def get_or_load_image(filepath: Optional[Path]) -> Optional[bpy.types.Image]:
    if filepath is None or not filepath.is_file():
        return None
    key = str(filepath)
    cached = _cache_get_alive(_image_cache, key, bpy.data.images)
    if cached is not None:
        return cached
    image = bpy.data.images.load(str(filepath), check_existing=True)
    _image_cache[key] = image
    return image


def _get_or_create_tinted_image(image: bpy.types.Image, tint: tuple) -> bpy.types.Image:
    """Copia de `image` com RGB multiplicado por `tint` (alpha intocado),
    cacheada por (nome da imagem, tint arredondado). Usado para
    BlockType.Tint*/BiomeTint* (ver block_def.py/_resolve_face_tint) --
    texturas base em escala de cinza que precisam de multiplicacao de cor.
    Pixels editados direto (Image.pixels), API estavel entre versoes do
    Blender. pack() no final desvincula a copia do arquivo original em disco."""
    key = (image.name, tuple(round(c, 4) for c in tint))
    cached = _cache_get_alive(_tinted_image_cache, key, bpy.data.images)
    if cached is not None:
        return cached

    import numpy as np

    tinted = image.copy()
    tinted.name = f"{image.name}_tint"

    px = np.empty(len(tinted.pixels), dtype=np.float32)
    tinted.pixels.foreach_get(px)
    px = px.reshape(-1, 4)
    px[:, 0] *= tint[0]
    px[:, 1] *= tint[1]
    px[:, 2] *= tint[2]
    tinted.pixels.foreach_set(px.ravel())
    tinted.update()
    tinted.pack()

    _tinted_image_cache[key] = tinted
    return tinted


def get_or_create_flat_material(
    name: str, image: Optional[bpy.types.Image], tint: Optional[tuple] = None
) -> bpy.types.Material:
    """Image Texture -> Base Color (+ Alpha para vidro/folhagem). Sem imagem ->
    placeholder cinza (ou a cor do tint cru, se houver) em vez de falhar o
    import inteiro por causa de um asset faltando."""
    if image is not None and tint is not None:
        image = _get_or_create_tinted_image(image, tint)

    # "Alpha Only When Needed" (Optimizer): imagem com canal alpha mas sem
    # nenhum pixel transparente vira material opaco (mais barato de desenhar
    # e renderizar). Visual identico.
    link_alpha = image is not None and image.depth in (32,)
    if link_alpha and _options["smart_alpha"] and not image_has_transparency(image):
        link_alpha = False

    if image is not None:
        key = f"img::{image.name}" + ("" if link_alpha or image.depth not in (32,) else "::opaque")
    elif tint is not None:
        key = f"tint::{tuple(round(c, 4) for c in tint)}"
    else:
        key = f"flat::{name}"
    cached = _cache_get_alive(_material_cache, key, bpy.data.materials)
    if cached is not None:
        return cached

    mat = bpy.data.materials.new(name=f"HB_{name}")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    output.location = (300, 0)
    bsdf.location = (0, 0)
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    # Preferencia do usuario: sem reflexo especular nos materiais importados.
    specular_input = bsdf.inputs.get("Specular IOR Level") or bsdf.inputs.get("Specular")
    if specular_input is not None:
        specular_input.default_value = 0.0

    if image is not None:
        tex = nodes.new("ShaderNodeTexImage")
        tex.image = image
        tex.interpolation = "Closest"  # texturas de bloco sao pixel art
        tex.location = (-300, 0)
        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
        if link_alpha:  # tem canal alpha (e, com smart_alpha, pixel transparente de verdade)
            links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
            mat.blend_method = "CLIP"
    elif tint is not None:
        bsdf.inputs["Base Color"].default_value = (*tint, 1.0)
    else:
        bsdf.inputs["Base Color"].default_value = (0.6, 0.6, 0.6, 1.0)

    _material_cache[key] = mat
    return mat


def clear_caches() -> None:
    """Chamado do unregister() -- so descarta as referencias, nao apaga os
    datablocks em si (o usuario pode ainda estar usando eles)."""
    _image_cache.clear()
    _material_cache.clear()
    _tinted_image_cache.clear()
    _transparency_cache.clear()
