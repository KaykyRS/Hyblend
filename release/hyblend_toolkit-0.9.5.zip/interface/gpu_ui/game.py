"""interface/gpu_ui/game.py -- arte e fontes do Hytale lidas da pasta do jogo.

O usuário aponta a pasta Hytale nas Preferences (`hytale_path`, modo
Automático = %APPDATA%/Hytale; a pasta é UMA pra todos os addons Hyblend,
ver hyblend_hub.py). ESTE ARQUIVO É IGUAL no Toolkit e no Prefabs (mudou
num -> copiar pro outro); as peças da Home só o Toolkit usa. Nada do jogo vem no zip do addon: sem a
pasta (ou com um arquivo faltando nesta versão do jogo) cada peça cai no
desenho procedural antigo e nas fontes Geist -- nunca quebra.

Todo arquivo é uma referência "raiz:caminho" (raízes em hytale_install.
ROOTS). Trocar/adicionar arte = editar SÓ as tabelas abaixo:
  ART          peça de interface -> (referência, bordas do 9-slice em px
               do PNG, escala). Escala = unidades lógicas da UI por px do
               PNG (PNG @2x do jogo: 0.5 = tamanho lógico do jogo).
  GLYPH_ICONS  nome de ícone procedural -> (referência, tingir?).
  FONT_FILES   peso de fonte do renderer -> referência.

Build/layout/draw rodam em draw handler: aqui só leitura de preference,
junção de caminho e stat de arquivo (cacheados por pasta). Nada de
bpy.data -- o PNG é decodificado pelo timer do renderer.
"""

import time
from pathlib import Path

import bpy

from ...common import ADDON_PACKAGE
from . import hytale_install

# --------------------------------------------------------------------------
# Tabelas
# --------------------------------------------------------------------------

_BTN = (24, 24, 24, 24)       # Common.ui: @ButtonBorderSize = 12 lógico
_BOX = (32, 32, 32, 32)       # InputBox/Dropdown/DropdownBox/OptionBackgroundPatch: Border 16

ART = {
    # Janela: @DecoratedContainer (Common/Container.ui)
    "frame": ("game_common:ContainerPatch@2x.png", (46, 46, 46, 46), 0.5),
    "header": ("game_common:ContainerHeader@2x.png", (100, 0, 100, 0), None),   # escala = altura/76
    "ornament": ("game_common:ContainerDecorationTop@2x.png", None, None),
    "ornament_bottom": ("game_common:ContainerDecorationBottom@2x.png", None, None),
    # Botões (Common.ui: Primary/Secondary/Destructive/Tertiary)
    "btn_primary": ("game_buttons:Primary@2x.png", _BTN, 0.25),
    "btn_primary_hover": ("game_buttons:Primary_Hovered@2x.png", _BTN, 0.25),
    "btn_primary_pressed": ("game_buttons:Primary_Pressed@2x.png", _BTN, 0.25),
    "btn_secondary": ("game_buttons:Secondary@2x.png", _BTN, 0.25),
    "btn_secondary_hover": ("game_buttons:Secondary_Hovered@2x.png", _BTN, 0.25),
    "btn_secondary_pressed": ("game_buttons:Secondary_Pressed@2x.png", _BTN, 0.25),
    "btn_danger": ("game_buttons:Destructive@2x.png", _BTN, 0.25),
    "btn_danger_hover": ("game_buttons:Destructive_Hovered@2x.png", _BTN, 0.25),
    "btn_danger_pressed": ("game_buttons:Destructive_Pressed@2x.png", _BTN, 0.25),
    "btn_disabled": ("game_buttons:Disabled@2x.png", _BTN, 0.25),
    "btn_active": ("game_buttons:Tertiary_Active@2x.png", _BTN, 0.25),     # contorno dourado
    # Campos
    "input": ("game_common:InputBox@2x.png", _BOX, 0.25),
    "input_hover": ("game_common:InputBoxHovered@2x.png", _BOX, 0.25),
    "input_edit": ("game_common:InputBoxSelected@2x.png", _BOX, 0.25),
    "dropdown": ("game_common:Dropdown@2x.png", _BOX, 0.25),
    "dropdown_hover": ("game_common:DropdownHovered@2x.png", _BOX, 0.25),
    "dropdown_open": ("game_common:DropdownPressed@2x.png", _BOX, 0.25),
    "dropdown_panel": ("game_common:DropdownBox@2x.png", _BOX, 0.25),     # lista aberta / fundo de lista
    "popup_item_hover": ("game_common:HoveredPopupItem@2x.png", None, None),
    "checkbox": ("game_common:CheckBoxFrame@2x.png", None, None),
    "checkmark": ("game_common:Checkmark@2x.png", None, None),
    # Superfícies
    "card": ("game_common:OptionBackgroundPatch@2x.png", _BOX, 0.25),
    "inset": ("game_common:ContainerPanelPatch@2x.png", (8, 8, 8, 8), 0.5),
    "inset_light": ("game_common:ContainerPanelLightPatch@2x.png", (8, 8, 8, 8), 0.5),
    "scroll_track": ("game_common:Scrollbar@2x.png", (6, 6, 6, 6), 0.5),
    "scroll_handle": ("game_common:ScrollbarHandle@2x.png", (6, 6, 6, 6), 0.5),
    "scroll_handle_hover": ("game_common:ScrollbarHandleHovered@2x.png", (6, 6, 6, 6), 0.5),
    "scroll_handle_drag": ("game_common:ScrollbarHandleDragged@2x.png", (6, 6, 6, 6), 0.5),
    # Detalhes
    "tab_marker": ("shared_controls:SubTabSelector.png", None, None),   # "^" dourado da sub-aba ativa
    "tab_separator": ("game_common:HeaderTabSeparator@2x.png", None, None),
    "divider_rune": ("shared_decor:CenterRuneDividerHorizontal.png", None, None),
    "selected_line": ("game_common:SelectedIconGradient.png", None, None),
    # ---- Home (menu principal do jogo: MainMenu/HomePage.ui, Adventure/WorldTile.ui).
    # Peças em HOME_ART: fora da pré-carga do sync() (só a Home usa; ela
    # carrega ao abrir -- home_page.on_open). Os fundos (bg_*) nem isso: só
    # o escolhido, e solto ao fechar (~16 MB cada na GPU).
    "bg_zone1": ("bg_images:Zone1.png", None, None),
    "bg_zone1_blur": ("bg_images:Zone1Blurred.png", None, None),
    "bg_zone2": ("bg_images:Zone2.png", None, None),
    "bg_zone2_blur": ("bg_images:Zone2Blurred.png", None, None),
    "bg_zone3": ("bg_images:Zone3.png", None, None),
    "bg_zone3_blur": ("bg_images:Zone3Blurred.png", None, None),
    "menu_gradient": ("main_menu:GradientOverlay.png", None, None),        # escurecimento da esquerda
    "menu_runes": ("main_menu:Runes@2x.png", None, None),                  # brilho dourado do item (hover)
    "world_tile": ("adventure:WorldTileOverlay@2x.png", None, None),       # card de mundo (faixa de baixo)
    "world_tile_hover": ("adventure:WorldTileOverlayHovered@2x.png", None, None),
    "world_tile_empty": ("adventure:EmptyWorldTilePatch@2x.png", (10, 10, 10, 10), 0.5),
    "mode_tile": ("adventure:GameModeTile@2x.png", None, None),            # card em pé (modo de jogo)
    "mode_tile_hover": ("adventure:GameModeTileHovered@2x.png", None, None),
    "mode_tile_selected": ("adventure:GameModeTileSelected@2x.png", None, None),
    "mode_icon_creative": ("adventure:GameModeIconCreative@2x.png", None, None),
    "no_preview": ("game_common:NoPreview@2x.png", None, None),            # placeholder oficial do jogo
    "wip_logo": ("game_common:WIPLogo@2x.png", None, None),
}

# Fundos da Home (Preferences: fixo ou sorteado).
BACKGROUNDS = ("ZONE1", "ZONE2", "ZONE3")
HOME_ART = frozenset(name for name in ART if name.startswith(("bg_", "menu_", "world_tile", "mode_"))) | {
    "no_preview", "wip_logo"}

# Nome procedural -> (referência, tingir?). tingir=True: glifo claro usado
# como máscara com a cor do estado (hover, desabilitado, destaque).
# False: cores do próprio PNG. Nome fora daqui continua procedural.
GLYPH_ICONS = {
    "search": ("shared_icons:IconSearch.png", True),
    "check": ("game_common:Checkmark@2x.png", True),
    "close": ("shared_icons:IconCross.png", True),
    "plus": ("shared_icons:IconPlus.png", True),
    "minus": ("shared_icons:IconMinus.png", True),
    "trash": ("shared_icons:IconTrash.png", True),
    "gear": ("shared_icons:IconSettings.png", True),
    "refresh": ("shared_icons:IconClockwise.png", True),
    "undo": ("shared_icons:IconCounterClockwise.png", True),
    "user": ("shared_icons:IconProfile.png", True),
    "heart": ("shared_icons:IconLikeFill.png", True),
    "sort": ("inventory:AutoSortIcon@2x.png", True),
    "folder": ("editor_asset_icons:Folder@2x.png", True),
    "edit": ("shared_editor_icons:EditIcon.png", True),
    "image": ("shared_editor_icons:Texture.png", False),
    "anim": ("shared_editor_icons:Animation.png", True),
    "cube": ("editor_asset_icons:Item@2x.png", True),
    "mesh": ("editor_asset_icons:Item@2x.png", True),
    "rig": ("shared_editor_icons:ParticleSystem.png", True),
    "import": ("editor_asset:ExportIcon@2x.png", True),
    "export": ("shared_editor_icons:OpenAssetIcon.png", True),
    "info": ("inventory:InfoIcon@2x.png", True),
    "warning": ("game_settings:IconWarning@2x.png", False),
    "experimental": ("game_common:WIPLogo@2x.png", False),        # avisos "experimental" (reserva: warning)
    "link": ("avatar:MatchHairColorsIconOffHovered@2x.png", False),
    "head": ("avatar_categories:Face@2x.png", True),
    "collection": ("inventory:Chest@2x.png", True),
    "shape": ("creative_library:IconTabBuild.png", True),
    "key": ("game_common:SliderHandle@2x.png", False),              # losango dourado = keyframe
    "globe": ("shop:IconRedirect@2x.png", True),                    # links pra sites
    "error": ("shared_icons:IconError.png", False),
    "lock": ("inventory:IconLock@2x.png", True),
    "play": ("editor_asset:WeatherDaytimeBarPlayIcon@2x.png", True),
    "eye": ("inventory:ArmorVisibilityOn@2x.png", False),
    "eye_off": ("inventory:ArmorVisibilityOff@2x.png", False),
    "chevron_down": ("game_common:AltDropdownCaretDown@2x.png", True),
    "chevron_up": ("game_common:AltDropdownCaretUp@2x.png", True),
    "chevron_right": ("game_common:DefaultDropdownCaret@2x.png", True),
    "chevron_left": ("game_common:DefaultDropdownCaretLeft@2x.png", True),
    "arrow_up": ("game_common:AltDropdownCaretUp@2x.png", True),
    "arrow_down": ("game_common:AltDropdownCaretDown@2x.png", True),
    # Home (reserva procedural em framework/icons.py)
    "history": ("shared_icons:IconHistory.png", True),
    "external": ("shop:IconRedirect@2x.png", True),
    "copy": ("shared_icons:IconCopy.png", True),                    # menu de contexto dos recentes
}

# Fontes do jogo (Shared/UI/Fonts). Nos .ui, "Default" = Nunito Sans e
# "Secondary" = Lexend (títulos/botões em caixa alta) -- suposição pelo uso.
FONT_FILES = {
    "Regular": "shared_fonts:NunitoSans-Regular.ttf",
    "Medium": "shared_fonts:NunitoSans-Medium.ttf",
    "SemiBold": "shared_fonts:NunitoSans-SemiBold.ttf",
    "Bold": "shared_fonts:NunitoSans-ExtraBold.ttf",
    "Title": "shared_fonts:Lexend-Bold.ttf",
}

# --------------------------------------------------------------------------
# Pasta Hytale
# --------------------------------------------------------------------------

_dir_cache = {"key": None, "dir": None, "at": 0.0}
# Com a MESMA configuração, re-testa o disco a cada RECHECK s: jogo instalado
# (ou removido/atualizando) com o Blender aberto destrava/trava sozinho.
RECHECK = 3.0
_exists = {"dir": None, "paths": {}}
# Pasta do build atual (gravada por sync(), no começo de cada build): as
# consultas de arte/ícone do desenho usam esta, sem ler as Preferences a
# cada peça (eram ~150 leituras de RNA por quadro).
_current = {"dir": None, "set": False}


def _prefs():
    addon = bpy.context.preferences.addons.get(ADDON_PACKAGE)
    return addon.preferences if addon is not None else None


def hytale_dir():
    """Raiz da instalação configurada (Path) ou None. Barato: cacheado pela
    (modo, caminho) das Preferences -- só faz stat quando a configuração
    muda (ou a cada RECHECK s). Não escreve em property (quem preenche é
    autodetect_*)."""
    prefs = _prefs()
    if prefs is None:
        return None
    mode = getattr(prefs, "hytale_path_mode", "AUTO")
    path = getattr(prefs, "hytale_path", "")
    key = (mode, path)
    now = time.monotonic()
    if _dir_cache["key"] != key or now - _dir_cache["at"] > RECHECK:
        found = hytale_install.find_hytale_dir(bpy.path.abspath(path)) if path else None
        if found is None and mode == "AUTO" and not path:
            found = hytale_install.default_hytale_dir()
        if _dir_cache["key"] == key and found != _dir_cache["dir"]:
            invalidate()                 # mudou no disco: arte/fontes de novo
        _dir_cache["key"], _dir_cache["dir"], _dir_cache["at"] = key, found, now
    return _dir_cache["dir"]


def invalidate():
    """Pasta/modo mudou nas Preferences."""
    _dir_cache["key"] = _dir_cache["dir"] = None
    _dir_cache["at"] = 0.0
    _exists["dir"], _exists["paths"] = None, {}
    _current["set"] = False


def file(ref):
    """Caminho (str) de uma referência se o arquivo EXISTE, senão ""."""
    root = _current["dir"] if _current["set"] else hytale_dir()
    if _exists["dir"] != root:
        _exists["dir"], _exists["paths"] = root, {}
    cache = _exists["paths"]
    if ref not in cache:
        path = hytale_install.resolve(root, ref) if root is not None else None
        cache[ref] = str(path) if path is not None and Path(path).is_file() else ""
    return cache[ref]


def art(name):
    """(caminho, bordas, escala) de uma peça de ART; caminho "" se faltar."""
    ref, slices, scale = ART[name]
    return file(ref), slices, scale


def skin_part(name):
    """Resolver do framework (core.set_skin): peça -> (png, bordas, escala)
    ou None (sem pasta/arquivo -> o widget desenha o procedural)."""
    if name not in ART:
        return None
    path, slices, scale = art(name)
    return (path, slices, scale) if path else None


def frame_style(name):
    """Style.frame (9-slice) de uma peça, ou None sem o PNG."""
    path, slices, scale = art(name)
    return (path, slices, scale) if path else None


def glyph_icon(name):
    """Resolver do renderer (set_image_icon_resolver)."""
    entry = GLYPH_ICONS.get(name)
    if entry is None:
        return None
    path = file(entry[0])
    return (path, entry[1]) if path else None


def font_files():
    return {weight: file(ref) for weight, ref in FONT_FILES.items()}


_synced_for = [object()]


def sync():
    """Chamado no começo de cada build (O(1) com a pasta igual). Quando a
    pasta muda: troca as fontes e PRÉ-CARREGA toda a arte das tabelas (a
    decodificação é no timer do renderer, fora do desenho) -- sem isso, o
    primeiro hover de cada botão mostrava o procedural por um quadro.
    Devolve a pasta (ou None)."""
    root = hytale_dir()
    _current["dir"], _current["set"] = root, True
    if _synced_for[0] != root:
        _synced_for[0] = root
        from .framework import renderer
        renderer.set_font_files(font_files() if root is not None else {})
        if root is not None:
            # Arte só da Home fica de fora (a Home pré-carrega ao abrir; os
            # fundos 1920x1080 nem assim -- só o escolhido).
            refs = [ref for name, (ref, _, _) in ART.items() if name not in HOME_ART]
            refs += [ref for ref, _ in GLYPH_ICONS.values()]
            renderer.preload(path for path in map(file, refs) if path)
    return root


def forget_sync():
    """unregister: o próximo register começa do zero (fontes/pré-carga)."""
    _synced_for[0] = object()


def autodetect():
    """Preenche hytale_path com a pasta padrão, se achar. Devolve o Path ou None."""
    found = hytale_install.default_hytale_dir()
    prefs = _prefs()
    if found is not None and prefs is not None:
        prefs.hytale_path = str(found)      # o update invalida o cache
    return found


def autodetect_on_startup():
    """Timer do register(): modo Automático com o campo vazio (addon recém-
    instalado) -> acha a pasta e preenche sozinho. Não sobrescreve caminho
    salvo nem o modo Manual."""
    prefs = _prefs()
    if prefs is not None and getattr(prefs, "hytale_path_mode", "AUTO") == "AUTO" and not prefs.hytale_path:
        autodetect()
    return None
