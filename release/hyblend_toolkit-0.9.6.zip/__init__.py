"""Hyblend Toolkit (núcleo): pasta do Hytale, Preferences, idioma, UI por GPU, Welcome/Home e a API dos addons
Hyblend que dependem dele (Anim, ...). Registra os submódulos de _MODULES (metadados em blender_manifest.toml)."""

from . import common, translations, preferences, model, interface, api, hyblend_link  # noqa: F401

# Versão da API pros dependentes (hyblend_link.attach(requires=...)). Ver api.py.
HYBLEND_CORE_API = 2

_MODULES = (translations, preferences, model, interface)


def register():
    for module in _MODULES:
        module.register()
    hyblend_link.publish_core(__package__, HYBLEND_CORE_API)     # por último: ativa os dependentes


def unregister():
    hyblend_link.withdraw_core(__package__)                       # primeiro: desativa os dependentes
    for module in reversed(_MODULES):
        module.unregister()


if __name__ == "__main__":
    register()
