"""interface/gpu_ui/ -- UI EXPERIMENTAL do Character Creator desenhada com gpu/blf.

Alternativa à UI clássica (interface/panel.py), NÃO substituta:
  * liga/desliga nas Preferences do NÚCLEO (Hyblend Toolkit, `use_gpu_ui`,
    LIGADO por padrão no 5.0+): a escolha é UMA pra todos os addons Hyblend;
  * só roda no Blender >= MIN_BLENDER (5.0). Antes disso a opção aparece
    travada e a UI clássica continua sozinha (nem shaders nem handlers
    desta pasta são carregados);
  * ligada, a UI clássica some (poll do HYBLENDCC_PT_test_panel) e esta
    aparece na aba "Hyblend" (framework/runtime.CATEGORY), a mesma do
    Toolkit e do Prefabs: com 2+ addons Hyblend, a faixa do seletor
    (framework/switcher.py) fica no topo e só o host do addon escolhido
    aparece (runtime.register(active=...)). Sozinho, tudo como antes.

Mesmas funções da UI clássica: a tela só lê o MESMO estado e chama os
MESMOS operadores -- nenhuma lógica de aplicar item/cor mora aqui (ver
app.py e bind.py).

Arquivos:
  framework    mini framework genérico: o código mora SÓ no Hyblend Toolkit; esta
               é a instância do CC (api.mount_gpu_framework, logo abaixo).
               O desenho antigo do CC (texto, imagem, fontes, sem máscaras de
               ícone) é mantido por framework.configure() no register()
  cc_icons.py  ícones procedurais de reserva do CC (por cima dos do framework)
  data.py      catálogo REAL do CC -> estrutura da tela (só leitura)
  bind.py      ponte com o Blender: operadores, properties, sync em timer
  widgets.py   peças com a cara do jogo
  app.py       a tela
  assets/ui/   moldura/título/ornamento (PROVISÓRIOS)
  (fontes Geist: as do framework, no Toolkit)

PRA REMOVER esta UI do addon: apagar esta pasta e desfazer os pontos que
a citam fora dela (todos marcados com o comentário "gpu_ui"):
  main.py                     -> gpu_ui.register()/unregister()
  interface/panel.py          -> poll() do HYBLENDCC_PT_test_panel e hub_register (gpu_ui=)
  preferences.py              -> on_hytale_changed (gpu_ui.on_hytale_path_changed)
"""

from __future__ import annotations

import bpy

from ...common import HUB_ID, game_found
from ...compat import version_at_least
from ...toolkit import api, core_preferences, hub as hyblend_hub

# Instância do framework do CC (código do Toolkit): ANTES de qualquer `from .framework import`.
api.mount_gpu_framework(__name__ + ".framework")

MIN_BLENDER = (5, 0, 0)   # era 5.2; baixado pra ficar igual aos outros addons Hyblend (framework unificado)


_registered = False


def is_supported() -> bool:
    return version_at_least(*MIN_BLENDER)


def _prefs(context=None):
    """Preferences do NÚCLEO (use_gpu_ui, gpu_ui_scale, gpu_ui_panel_width/_height: uma escolha pra todos)."""
    return core_preferences(context)


def is_enabled(context=None) -> bool:
    """True = a UI por GPU está ativa (preference ligada E Blender suporta
    E registrada). Usado pelo poll() da UI clássica pra sumir."""
    if not (_registered and is_supported()):
        return False
    prefs = _prefs(context)
    return bool(prefs is not None and getattr(prefs, "use_gpu_ui", False))


def set_enabled(context, value) -> None:
    prefs = _prefs(context)
    if prefs is not None:
        prefs.use_gpu_ui = bool(value)     # o set do hub avisa todos (on_preference_changed)


# --------------------------------------------------------------------------
# Chamado pelas Preferences (preferences.py / interface/preferences_ui.py)
# --------------------------------------------------------------------------

def on_preference_changed(context) -> None:
    """Ligou/desligou a UI, ou mudou escala/tamanho."""
    if _registered:
        from .framework import runtime
        if not is_enabled(context):
            runtime.shutdown_all()           # derruba hosts e draw handlers
        else:
            prefs = _prefs(context)
            runtime.apply_size("width", prefs.gpu_ui_panel_width)
            runtime.apply_size("height", prefs.gpu_ui_panel_height)
    hyblend_hub.redraw_view3d(context)


def on_hytale_path_changed(context) -> None:
    """Pasta/modo do Hytale mudou no núcleo (preferences.on_hytale_changed): jogo
    "sumiu" -> o N-Panel por GPU sai junto com a aba (igual ao Toolkit)."""
    if _registered and not game_found():
        from .framework import runtime
        runtime.shutdown_all()
    hyblend_hub.redraw_view3d(context)


def on_cache_cleared() -> None:
    """Clear Cache (preferences.HYBLENDCC_OT_clear_cache) apagou miniaturas e
    ícones do disco: a tela esquece as imagens já carregadas e recarrega."""
    if not _registered:
        return
    from . import bind, data
    from .framework import renderer
    data.forget_icons()          # os PNGs cortados (pasta temporária) foram apagados
    data.invalidate()
    renderer.forget_images()
    bind.forget_sync_attempt()   # catálogo relido + ícones cortados de novo (timer)
    bind.request_sync()
    hub_refresh()


# --------------------------------------------------------------------------
# Seletor dos addons Hyblend (hyblend_hub.py)
# --------------------------------------------------------------------------

def hub_refresh():
    """Aviso do hub (addon entrou/saiu, troca no seletor): reconstruir."""
    if _registered:
        from .framework import runtime
        for host in list(runtime._HOSTS.values()):
            host.invalidate()


def host_ok(context):
    """O host desta sidebar NÃO está quebrado (com erro, o painel-gancho
    mostra o aviso nativo -- e o seletor nativo volta junto)."""
    if not _registered:
        return False
    from .framework import runtime
    return runtime.host_status(context) != "ERROR"


def _hub_pick(f, ident):
    hyblend_hub.set_active(ident, f.context)


def _hub_resolve(ref):
    from . import data
    return data._game_icon_if_exists(ref)      # cacheado por pasta Hytale (a faixa resolve a cada build)


def _build(f):
    """Tela do CC + faixa do seletor dos addons Hyblend em cima (só com 2+
    addons; sozinho, a árvore é EXATAMENTE a de antes -- visual intocado)."""
    from . import app
    from .framework import switcher
    root = app.build(f)
    if not hyblend_hub.switcher_visible():
        return root
    return switcher.wrap(f, root, hyblend_hub.entries(f.context), _hub_pick, _hub_resolve)


def _hub_active():
    return hyblend_hub.is_active(HUB_ID)


# --------------------------------------------------------------------------
# Ligação com o runtime
# --------------------------------------------------------------------------

def _extra_scale(context):
    prefs = _prefs(context)
    return prefs.gpu_ui_scale if prefs is not None else 1.0


_SIZE_PROPS = {"width": "gpu_ui_panel_width", "height": "gpu_ui_panel_height"}


def _get_size(context, axis):
    prefs = _prefs(context)
    return getattr(prefs, _SIZE_PROPS[axis]) if prefs is not None else 0.0


def _set_size(context, axis, value):
    prefs = _prefs(context)
    if prefs is not None:
        setattr(prefs, _SIZE_PROPS[axis], value)   # salvo com as preferências do Blender


# --------------------------------------------------------------------------
# Painel-gancho + operadores de recuperação
# --------------------------------------------------------------------------

class HYBLENDCC_OT_gpu_ui_retry(bpy.types.Operator):
    bl_idname = "hyblendcc.gpu_ui_retry"
    bl_label = "Try Again"
    bl_description = "Try to start the GPU interface again"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        from .framework import runtime
        runtime.clear_error(context)
        if context.region is not None:
            context.region.tag_redraw()
        return {"FINISHED"}


class HYBLENDCC_OT_gpu_ui_disable(bpy.types.Operator):
    bl_idname = "hyblendcc.gpu_ui_disable"
    bl_label = "Use Classic Panel"
    bl_description = "Turn off the GPU interface (in all Hyblend addons) and go back to the classic panel"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        set_enabled(context, False)
        return {"FINISHED"}


def _make_host_panel():
    from .framework import runtime

    class HYBLENDCC_PT_gpu_ui_host(bpy.types.Panel):
        """Não desenha nada útil: só avisa o runtime que a aba está visível
        (o painel de verdade é desenhado por cima, via draw handler)."""
        bl_idname = "HYBLENDCC_PT_gpu_ui_host"
        bl_space_type = "VIEW_3D"
        bl_region_type = "UI"
        bl_category = runtime.CATEGORY
        bl_label = "Hyblend CC GPU UI"
        bl_options = {"HIDE_HEADER"}

        @classmethod
        def poll(cls, context):
            # sem o jogo: aba some (common.game_found); com outros addons
            # Hyblend: só se o CC é o escolhido no seletor
            return is_enabled(context) and game_found() and hyblend_hub.is_active(HUB_ID, context)

        def draw(self, context):
            runtime.ensure_host(context)
            # Erro / montando: o desenho do hub, IGUAL nos addons Hyblend.
            hyblend_hub.draw_gpu_host_status(self.layout, runtime.host_status(context), runtime.host_error(context),
                                             HYBLENDCC_OT_gpu_ui_retry.bl_idname, HYBLENDCC_OT_gpu_ui_disable.bl_idname)

    return HYBLENDCC_PT_gpu_ui_host


_classes = []


def _install_image_icons() -> None:
    """Glifos do jogo (lupa, check, setas...) no lugar dos procedurais --
    tabela em data.GLYPH_ICONS; o renderer cai no procedural se faltar."""
    from . import cc_icons, data  # noqa: F401  (cc_icons: desenhos de reserva do CC por cima dos do framework)
    from .framework import icons, renderer
    # "exit" (Use Classic Interface) só existe como ícone do jogo; sem a
    # pasta Hytale, a reserva procedural é o próprio "x".
    if "exit" not in icons.names():
        icons.icon("exit")(lambda x, y: icons.inside("x", x, y))
    renderer.set_image_icon_resolver(data.glyph_icon)


def register() -> None:
    """Só registra algo no Blender suportado -- abaixo de 5.0 nem o
    framework (shaders, handlers, fontes) é importado."""
    global _registered
    if not is_supported() or _registered:
        return
    from . import framework
    # Framework do Toolkit, instância do CC: nomes deste addon e o desenho
    # antigo do CC (texto com espaçamento somado, 4 amostras ao reduzir
    # imagem, Geist Bold, sem as máscaras prontas de ícone -- os de reserva
    # são os do cc_icons) -- o visual do CC NÃO muda.
    framework.configure(namespace="hyblendcc", label="Hyblend CC GPU UI", font_copy_dir="hyblend_cc_fonts",
                        builtin_fonts={"Bold": "Geist-Bold.ttf", "Title": "Geist-Bold.ttf"},
                        text_tracking="sum", image_samples=4, icon_masks=False)
    from . import app, widgets
    from .framework import runtime
    runtime.register(_build, _extra_scale, _get_size, _set_size, app.signature,
                     default_width=app.DEFAULT_WIDTH, min_width=app.MIN_WIDTH, theme=app.THEME,
                     tooltip=widgets.draw_tooltip, active=_hub_active)
    _install_image_icons()
    _classes[:] = [HYBLENDCC_OT_gpu_ui_retry, HYBLENDCC_OT_gpu_ui_disable, _make_host_panel()]
    for cls in _classes:
        bpy.utils.register_class(cls)
    _registered = True


def unregister() -> None:
    global _registered
    if not _registered:
        return
    from . import bind
    from .framework import runtime
    bind.cancel_sync()
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    _classes.clear()
    runtime.unregister()
    from .framework import renderer
    renderer.set_image_icon_resolver(None)
    _registered = False
