"""Inglês (canônico): toda key do Prefabs existe aqui. Key = "<arquivo dono>.<nome>" (ex.: "panel.btn_create_player").
Key nova: aqui E em pt_br.py (mesma key). Key repetida no dict sobrescreve em silêncio."""

LANGUAGE_CODE = "EN"
LANGUAGE_NAME = "English"

TRANSLATIONS = {
}
