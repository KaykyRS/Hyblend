"""interface/preferences_ui.py -- desenho da tela Edit > Preferences >
Add-ons > Hyblend Character Creator. A CLASSE de Preferences (as
properties em si + resolucao de caminho) continua em preferences.py --
so o draw() mora aqui, chamado por `HYBLENDCC_AddonPreferences.draw`.

Operadores referenciados pelo `bl_idname` em STRING (nao pela classe)
-- assim este arquivo nao precisa importar nada de preferences.py/
picker.py, e nao ha risco de import circular com o import tardio feito
em `HYBLENDCC_AddonPreferences.draw`."""

from __future__ import annotations


def draw_addon_preferences(prefs, context, layout) -> None:
    """A linha do idioma (dos itens), o atalho pras Preferences do nucleo (pasta do Hytale, idioma da
    interface, interface por GPU -- valem pra todos os addons Hyblend), a caixa das miniaturas e a do cache."""
    layout.prop(prefs, "language")

    box = layout.box()
    box.label(text="Hytale folder and interface settings are in the Hyblend Toolkit Preferences.", icon="INFO")
    box.operator("hytale.open_addon_preferences", text="Open Hyblend Toolkit Preferences", icon="PREFERENCES")

    box = layout.box()
    box.label(text="Thumbnails", icon="IMAGE_DATA")
    box.prop(prefs, "show_previews")
    box.operator("hyblendcc.build_all_thumbnails", icon="RENDER_STILL")

    # Cache: mesma caixa do Prefabs (o que é, onde fica, Clear Cache / Open Folder)
    from ..preferences import EXTRACT_CACHE_DIR
    cache_root = EXTRACT_CACHE_DIR.parent
    box = layout.box()
    box.label(text="Cache", icon="FILE_CACHE")
    col = box.column(align=True)
    col.label(text="Thumbnails and files extracted from Assets.zip are kept in:")
    col.label(text=str(cache_root))
    col.label(text="Clear it after a Hytale update so new textures/models are picked up.", icon="INFO")
    row = box.row(align=True)
    row.operator("hyblendcc.clear_cache", icon="TRASH")
    sub = row.row(align=True)
    sub.enabled = cache_root.is_dir()        # ainda não existe = nada gerado ainda
    sub.operator("wm.path_open", text="Open Folder", icon="FILE_FOLDER").filepath = str(cache_root)
