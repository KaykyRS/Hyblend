"""interface/__init__.py -- painel CLÁSSICO da Sidebar (N-Panel) da Viewport 3D.

So DESENHA: toda acao e um operador que mora em outro arquivo
(prefab_importer.py, builder/prefab_ops.py, builder/debug_export.py,
preferences.py). Mesma regra do Hyblend Toolkit/Character Creator.

Duas interfaces, MESMO conteudo:
- este painel (Blender 4.5+, aba "Hyblend" compartilhada com o Toolkit e o
  Character Creator);
- a UI por GPU (gpu_ui/, Blender 5.0+, ligada por padrao, mesma aba) --
  quando ativa, este painel some (poll).
Sem a pasta do jogo (common.game_found) o addon fica TRAVADO como o
Toolkit: os dois painéis somem; sobram as Preferences e o "Locate Game".
As duas mostram as mesmas secoes, na mesma ordem, com os mesmos textos;
textos/formatadores compartilhados moram em common_ui.py. Mudou um lado,
espelhar no outro (gpu_ui/pages/prefabs_page.py).

PUBLICO: pensado pra quem NAO e dev nem usuario avancado de Blender. Regras
que guiam o layout (ver DEVELOPER_NOTES.md, "Interface"):

- Uma coisa principal por vez, de cima pra baixo: (1) arquivos do jogo
  prontos? -> (2) importar -> (3) o que esta na cena -> (4) o que esta
  selecionado. Configuracoes e creditos ficam no fim, fechados.
- Secao que nao tem nada pra mostrar NAO aparece (sem prefab na cena nao
  existe "Prefabs in Scene" nem "Selected Object").
- Todo texto em UMA linha, sem explicacao tecnica; botao com texto em vez
  de icone solto sempre que couber; termo tecnico (malha unica, valores
  crus) so em "Details" ou Developer Mode.

Estrutura (secoes recolhiveis via layout.panel(), Blender 4.1+ -- o
estado aberto/fechado e salvo sozinho por idname, sem BoolProperty):

- Engrenagem (Preferences) no titulo do painel
- Status dos arquivos do jogo (um "pronto" discreto)
- Botao grande "Import Prefab" (+ dica de drag-and-drop sem prefab)
- Prefabs in Scene -- um sub-painel por prefab: nome + aviso de problema
  + olho no header; Select / Zoom To / lixeira, status do import,
  problemas (fechado) e Details (fechado) no corpo
- Selected Object -- inspetor do Object ativo
- Settings & Tools (fechado) -- Preferences, Clear Cache, Developer
- About (fechado) -- creditos e links

IDIOMA: UI em ingles, comentarios em portugues (mesmo padrao dos outros
addons Hyblend)."""

from __future__ import annotations

import os

import blf
import bpy
import bpy.utils.previews
from bpy.types import Panel

from ..builder.debug_export import EXPORT_OT_hyblend_debug_dump
from ..builder.emitters import PROP_OPT_INSTANCE_COUNT, PROP_OPT_INSTANCER_ITEM, PROP_OPT_SINGLE_MESH
from ..builder.prefab_importer import IMPORT_OT_hytale_prefab
from ..builder.prefab_ops import (
    HYBLENDPREFABS_OT_copy_report,
    HYBLENDPREFABS_OT_copy_text,
    HYBLENDPREFABS_OT_frame_prefab,
    HYBLENDPREFABS_OT_open_prefab_folder,
    HYBLENDPREFABS_OT_remove_prefab,
    HYBLENDPREFABS_OT_select_instances,
    HYBLENDPREFABS_OT_select_prefab,
    is_hytale_object,
    issue_count,
    iter_prefab_collections,
    load_report,
    prefab_collection_of,
    prefab_display_name,
)
from ..common import (
    ADDON_PACKAGE,
    HUB_ID,
    game_found,
    PROP_BLOCK_FILLER_RAW,
    PROP_BLOCK_GRID_POS,
    PROP_BLOCK_NAME,
    PROP_BLOCK_ROTATION_RAW,
    PROP_BLOCK_SUPPORT_RAW,
    PROP_ENTITY_ITEM_ID,
    PROP_ENTITY_ITEM_ID_RAW,
    PROP_ENTITY_KIND,
    PROP_ENTITY_MODEL_SCALE_RAW,
    PROP_ENTITY_POSITION_RAW,
    PROP_ENTITY_ROTATION_PITCH_RAW,
    PROP_ENTITY_ROTATION_ROLL_RAW,
    PROP_ENTITY_ROTATION_YAW_RAW,
    PROP_ENTITY_STATE,
    PROP_ENTITY_UUID,
    PROP_PREFAB_ROOT,
)
from ..preferences import (
    HYBLENDPREFABS_OT_clear_assets_cache,
    assets_status,
    is_developer_mode,
)
from . import common_ui as cu      # textos/formatadores compartilhados com a UI por GPU
from . import gpu_ui               # UI por GPU (Blender 5.0+), ver gpu_ui/__init__.py
from .. import hyblend_hub         # seletor/sincronia entre os addons Hyblend, ver hyblend_hub.py

# Icones customizados (PNGs em assets/icons/, copiados do Hyblend Toolkit).
# Se um arquivo faltar, o botao cai pro icone embutido do Blender.
_PANEL_ICON_FILES = {
    "nexus_mods": "nexus_mods.png",
    "github": "github.png",
    "patreon": "patreon.png",
    "instagram": "instagram.png",
    "twitter_x": "twitter_x.png",
    "youtube": "youtube.png",
    "hytale": "hytale.png",
}
_panel_icons_pcoll = None


def _load_panel_icons():
    global _panel_icons_pcoll
    pcoll = bpy.utils.previews.new()
    addon_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    icons_dir = os.path.join(addon_root, "assets", "icons")
    for key, filename in _PANEL_ICON_FILES.items():
        path = os.path.join(icons_dir, filename)
        if os.path.isfile(path):
            try:
                pcoll.load(key, path, "IMAGE")
            except Exception:  # noqa: BLE001 -- PNG ilegivel cai pro icone embutido
                pass
    _panel_icons_pcoll = pcoll


def _unload_panel_icons():
    global _panel_icons_pcoll
    if _panel_icons_pcoll is not None:
        bpy.utils.previews.remove(_panel_icons_pcoll)
        _panel_icons_pcoll = None


def _icon_kwargs(key: str, fallback: str) -> dict:
    """icon_value= (PNG customizado) se carregado, senao icon= embutido."""
    if _panel_icons_pcoll is not None and key in _panel_icons_pcoll:
        return {"icon_value": _panel_icons_pcoll[key].icon_id}
    return {"icon": fallback}


def _kv_row(layout, label, value, alert=False):
    """Linha "rotulo ..... valor" com proporcao fixa (split) -- num row()
    comum as duas labels disputariam a largura meio a meio."""
    split = layout.split(factor=0.4)
    split.label(text=label)
    value_row = split.row()
    value_row.alert = alert
    value_row.label(text=str(value))
    return value_row


# Margem estimada (px) entre context.region.width e a largura de texto
# disponivel dentro de um box -- ajustado no olho (o Blender nao expoe isso).
_WRAPPED_LABEL_MARGIN_PX = 50


def _draw_wrapped_label(layout, context, text):
    """layout.label() nunca quebra linha (trunca com "..."). Quebra `text`
    em varias labels medindo cada palavra com blf.dimensions() contra a
    largura atual da regiao (mesma tecnica do Hyblend Toolkit). So o aviso
    do About usa -- o resto do painel e tudo em uma linha."""
    region = context.region
    available_px = max((region.width if region else 300) - _WRAPPED_LABEL_MARGIN_PX, 80)
    col = layout.column(align=True)
    col.active = False          # acinzentado, como as outras dicas
    line = ""
    for word in text.split(" "):
        candidate = f"{line} {word}".strip()
        if blf.dimensions(0, candidate)[0] > available_px and line:
            col.label(text=line)
            line = word
        else:
            line = candidate
    if line:
        col.label(text=line)


def _hint(layout, text, icon="INFO"):
    """Frase curta acinzentada (dica, nao aviso)."""
    row = layout.row()
    row.active = False
    row.label(text=text, icon=icon)


class HYBLENDPREFABS_PT_main(Panel):
    """Painel classico. A UI por GPU (gpu_ui/pages/prefabs_page.py) mostra
    o MESMO conteudo, na mesma ordem, com os mesmos textos."""

    bl_label = "Hyblend Prefabs"
    bl_idname = "HYBLENDPREFABS_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Hyblend"  # compartilha a aba com Hyblend Toolkit / Character Creator
    bl_order = 10            # abaixo do seletor dos addons Hyblend (hyblend_hub, bl_order 0)

    @classmethod
    def poll(cls, context):
        # Sem a pasta do jogo: addon travado, a aba some (common.game_found,
        # igual ao Toolkit). Blender 5.0+ com a UI por GPU ligada (padrao): ela
        # assume a aba -- um ou outro, nunca os dois. Com outros addons
        # Hyblend: so quando o Prefabs e o escolhido no seletor (hyblend_hub).
        return game_found() and not gpu_ui.is_enabled(context) and hyblend_hub.is_active(HUB_ID, context)

    def draw_header(self, context):
        self.layout.label(text="", icon="MOD_BUILD")

    def draw_header_preset(self, context):
        # Engrenagem no titulo -- mesmo lugar da UI por GPU.
        op = self.layout.operator("preferences.addon_show", text="", icon="PREFERENCES", emboss=False)
        op.module = ADDON_PACKAGE

    def draw(self, context):
        layout = self.layout
        prefabs = iter_prefab_collections()

        ready = self._draw_assets_status(layout, context)
        self._draw_import(layout, ready, show_tip=not prefabs)

        # Sem prefab na cena, "Prefabs in Scene" e "Selected Object" nao tem
        # nada util pra mostrar -- escondidas pra quem acabou de instalar
        # ver so o essencial (status + botao de importar).
        if prefabs:
            layout.separator()
            self._draw_prefabs(layout, context, prefabs)
            self._draw_selection(layout, context, prefabs)

        self._draw_settings(layout, context)
        self._draw_about(layout, context)

    # -- 1. Arquivos do jogo -------------------------------------------------

    def _draw_assets_status(self, layout, context) -> bool:
        """Linha discreta "pronto". Sem a pasta do jogo o painel nem aparece
        (poll/common.game_found, igual ao Toolkit) -- o "Locate Game" fica
        nas Preferences. Devolve se esta pronto pra importar."""
        state, _text = assets_status(context)
        if state == "ZIP":
            layout.label(text="Hytale game files ready", icon="CHECKMARK")
        return state == "ZIP"

    # -- 2. Importar ---------------------------------------------------------

    def _draw_import(self, layout, ready, show_tip):
        col = layout.column()
        col.scale_y = 1.8
        col.enabled = ready
        col.operator_context = "INVOKE_DEFAULT"
        col.operator(IMPORT_OT_hytale_prefab.bl_idname, text="Import Prefab", icon="IMPORT")
        if show_tip and ready:
            _hint(layout, "Tip: drag a .prefab.json here")

    # -- 3. Prefabs in Scene -------------------------------------------------

    def _draw_prefabs(self, layout, context, prefabs):
        header, body = layout.panel("hyblendprefabs_scene", default_closed=False)
        header.label(text=f"Prefabs in Scene ({len(prefabs)})", icon="OUTLINER_COLLECTION")
        if body is None:
            return
        active_coll = prefab_collection_of(context.active_object)
        only_one = len(prefabs) == 1
        for coll in prefabs:
            self._draw_prefab_entry(body, context, coll, open_by_default=(only_one or coll == active_coll))

    def _draw_prefab_entry(self, layout, context, coll, open_by_default):
        report = load_report(coll)
        problems = issue_count(report) if report is not None else 0

        header, body = layout.panel(f"hyblendprefabs_pf_{coll.name}", default_closed=not open_by_default)
        header.label(text=prefab_display_name(coll))
        # A direita do nome: aviso de problema (visivel mesmo fechado) + olho.
        right = header.row(align=True)
        right.alignment = "RIGHT"
        if problems:
            warn = right.row()
            warn.alert = True
            warn.label(text=str(problems), icon="ERROR")
        lc = cu.layer_collection_for(context.view_layer, coll)
        if lc is not None:
            right.prop(lc, "hide_viewport", text="", emboss=False)

        if body is None:
            return

        # Acoes com texto; lixeira so com icone (universal e tem confirmacao).
        actions = body.row(align=True)
        actions.scale_y = 1.2
        op = actions.operator(HYBLENDPREFABS_OT_select_prefab.bl_idname, text="Select", icon="RESTRICT_SELECT_OFF")
        op.collection_name = coll.name
        op = actions.operator(HYBLENDPREFABS_OT_frame_prefab.bl_idname, text="Zoom To", icon="ZOOM_SELECTED")
        op.collection_name = coll.name
        op = actions.operator(HYBLENDPREFABS_OT_remove_prefab.bl_idname, text="", icon="TRASH")
        op.collection_name = coll.name

        if report is None:
            body.label(text="No summary (older version)", icon="INFO")
            return
        if problems == 0:
            body.label(text="Imported successfully", icon="CHECKMARK")
        else:
            self._draw_issues(body, coll, report, problems)
        self._draw_prefab_details(body, context, coll, report)

    def _draw_issues(self, layout, coll, report, problems):
        header, body = layout.panel(f"hyblendprefabs_issues_{coll.name}", default_closed=True)
        row = header.row()
        row.alert = True
        row.label(text=cu.problems_title(problems), icon="ERROR")
        if body is None:
            return
        for key, title, icon, _gpu_icon in cu.ISSUE_GROUPS:
            items = cu.issue_items(report, key)
            if not items:
                continue
            box = body.box()
            box.label(text=f"{title} ({len(items)})", icon=icon)
            col = box.column(align=True)
            col.scale_y = 0.85
            for item in items[:cu.MAX_ISSUES_SHOWN]:
                col.label(text=cu.issue_label(item), icon="DOT")
            if len(items) > cu.MAX_ISSUES_SHOWN:
                col.label(text=f"... and {len(items) - cu.MAX_ISSUES_SHOWN} more", icon="BLANK1")

    def _draw_prefab_details(self, layout, context, coll, report):
        """Numeros do import -- fechado por padrao: interessa pra quem quer
        conferir, nao pra quem so quer usar o prefab."""
        header, body = layout.panel(f"hyblendprefabs_details_{coll.name}", default_closed=True)
        header.label(text="Details", icon="INFO")
        if body is None:
            return

        dev = is_developer_mode(context)
        col = body.column(align=True)
        _kv_row(col, "Blocks", f"{report['blocks_placed']:,} / {report['blocks_total']:,}",
                alert=report["blocks_placed"] < report["blocks_total"])
        if report["entities_total"] >= 0:
            # entities_total ja exclui spawners/marcadores ignorados de
            # proposito (_is_ignored_entity) -- placed < total e falha real.
            _kv_row(col, "Entities", f"{report['entities_placed']:,} / {report['entities_total']:,}",
                    alert=report["entities_placed"] < report["entities_total"])
        else:
            _kv_row(col, "Entities", "Not imported")
        _kv_row(col, "Built as", cu.OUTPUT_LABELS.get(report["output"], report["output"]))
        if report["hidden_blocks"]:
            _kv_row(col, "Hidden blocks", f"{report['hidden_blocks']:,} removed")
        if report["hidden_faces"]:
            _kv_row(col, "Hidden faces", f"{report['hidden_faces']:,} removed")
        if report["region_skipped"]:
            _kv_row(col, "Outside region", f"{report['region_skipped']:,} skipped")
        if dev:
            _kv_row(col, "Unique meshes", f"{report['unique_meshes']:,}")

        if report["file"] or dev:
            footer = body.row(align=True)
            if report["file"]:
                op = footer.operator(HYBLENDPREFABS_OT_open_prefab_folder.bl_idname, text="Show File",
                                     icon="FILE_FOLDER")
                op.filepath = report["file"]
            if dev:
                op = footer.operator(HYBLENDPREFABS_OT_copy_report.bl_idname, text="Copy Report", icon="COPYDOWN")
                op.collection_name = coll.name

    # -- 4. Selected Object --------------------------------------------------

    def _draw_selection(self, layout, context, prefabs):
        obj = context.active_object
        header, body = layout.panel("hyblendprefabs_selection", default_closed=False)
        header.label(text="Selected Object", icon="RESTRICT_SELECT_OFF")
        if body is None:
            return

        if obj is not None and obj.get(PROP_PREFAB_ROOT):
            coll = prefab_collection_of(obj)
            box = body.box()
            box.label(text=prefab_display_name(coll) if coll else obj.name, icon="EMPTY_AXIS")
            _hint(box, "Move it to move the whole prefab")
            return
        if obj is not None and (PROP_OPT_INSTANCER_ITEM in obj or obj.get(PROP_OPT_SINGLE_MESH)):
            self._draw_selection_optimized(body, obj)
            return
        if not is_hytale_object(obj):
            _hint(body, "Click a block to see its info")
            return

        dev = is_developer_mode(context)
        col = body.box().column(align=True)
        if PROP_BLOCK_NAME in obj:
            self._draw_selection_block(col, obj, dev)
        else:
            self._draw_selection_entity(col, obj, dev)

        # Com varios prefabs na cena, diz de qual este Object faz parte.
        coll = prefab_collection_of(obj)
        if coll is not None and len(prefabs) > 1:
            _kv_row(col, "Prefab", prefab_display_name(coll))

        if obj.type == "MESH" and obj.data is not None and obj.data.users > 1:
            row = body.row()
            row.scale_y = 1.2
            row.operator(HYBLENDPREFABS_OT_select_instances.bl_idname,
                         text=f"Select All Copies ({obj.data.users})", icon="RESTRICT_SELECT_OFF")

    @staticmethod
    def _id_row(layout, item_id, icon, copy=True):
        """Nome do item em destaque (titulo do card) + botao de copiar."""
        row = layout.row(align=True)
        row.label(text=item_id, icon=icon)
        if copy:
            op = row.operator(HYBLENDPREFABS_OT_copy_text.bl_idname, text="", icon="COPYDOWN", emboss=False)
            op.text = item_id

    def _draw_selection_optimized(self, layout, obj):
        """Objects dos modos Instances/Single Mesh do Optimizer -- nao tem
        dado por bloco, so o resumo."""
        col = layout.box().column(align=True)
        if PROP_OPT_INSTANCER_ITEM in obj:
            self._id_row(col, str(obj.get(PROP_OPT_INSTANCER_ITEM, "")), "OUTLINER_OB_POINTCLOUD")
            _kv_row(col, "Copies", f"{int(obj.get(PROP_OPT_INSTANCE_COUNT, 0)):,}")
            return
        self._id_row(col, "Whole prefab (Single Mesh)", "MESH_DATA", copy=False)
        if obj.type == "MESH" and obj.data is not None:
            _kv_row(col, "Faces", f"{len(obj.data.polygons):,}")
            _kv_row(col, "Materials", f"{len(obj.data.materials):,}")

    def _draw_selection_block(self, col, obj, dev):
        item_id, state = cu.block_item_id(obj)
        self._id_row(col, item_id, "MESH_CUBE")
        _kv_row(col, "Type", "Block")
        if state:
            _kv_row(col, "State", state)
        grid = obj.get(PROP_BLOCK_GRID_POS)
        if grid is not None:
            _kv_row(col, "Position", cu.fmt_vec(grid, digits=0))
        _kv_row(col, "Rotation", cu.block_rotation_text(obj))
        if dev:
            self._draw_raw_values(col, obj, (
                ("name", PROP_BLOCK_NAME),
                ("rotation", PROP_BLOCK_ROTATION_RAW),
                ("support", PROP_BLOCK_SUPPORT_RAW),
                ("filler", PROP_BLOCK_FILLER_RAW),
            ))

    def _draw_selection_entity(self, col, obj, dev):
        kind = str(obj.get(PROP_ENTITY_KIND, ""))
        kind_label, kind_icon, _gpu_icon = cu.ENTITY_KIND_LABELS.get(kind, cu.ENTITY_KIND_FALLBACK)
        self._id_row(col, str(obj.get(PROP_ENTITY_ITEM_ID, obj.name)), kind_icon)
        _kv_row(col, "Type", kind_label)
        state = str(obj.get(PROP_ENTITY_STATE, "") or "")
        if state:
            _kv_row(col, "State", state)
        pos = obj.get(PROP_ENTITY_POSITION_RAW)
        if pos is not None:
            _kv_row(col, "Position", cu.fmt_vec(pos))
        _kv_row(col, "Rotation", cu.entity_rotation_text(obj))
        # Escala so aparece quando foge do normal (1) -- menos ruido.
        scale = cu.entity_scale(obj)
        if scale != 1.0 or dev:
            text = f"{scale:g}"
            model_scale = obj.get(PROP_ENTITY_MODEL_SCALE_RAW)
            if dev and model_scale is not None:
                text += f"  (model {float(model_scale):g})"
            _kv_row(col, "Scale", text)
        if dev:
            self._draw_raw_values(col, obj, (
                ("id", PROP_ENTITY_ITEM_ID_RAW),
                ("uuid", PROP_ENTITY_UUID),
                ("yaw", PROP_ENTITY_ROTATION_YAW_RAW),
                ("pitch", PROP_ENTITY_ROTATION_PITCH_RAW),
                ("roll", PROP_ENTITY_ROTATION_ROLL_RAW),
            ))

    @staticmethod
    def _draw_raw_values(col, obj, keys):
        """Developer Mode: valores CRUS do prefab gravados no Object
        (custom properties), sem nenhuma conversao."""
        col.separator(factor=0.5)
        col.label(text="Raw prefab values", icon="CONSOLE")
        for label, key in keys:
            if key in obj:
                _kv_row(col, label, cu.raw_value_text(obj[key]))

    # -- 5. Settings & Tools -------------------------------------------------

    def _draw_settings(self, layout, context):
        header, body = layout.panel("hyblendprefabs_tools", default_closed=True)
        header.label(text="Settings & Tools", icon="PREFERENCES")
        if body is None:
            return
        state, text = assets_status(context)
        ok = state == "ZIP"
        _kv_row(body, "Game files", text if ok else "Not set", alert=not ok)
        row = body.row(align=True)
        row.operator("preferences.addon_show", text="Preferences", icon="PREFERENCES").module = ADDON_PACKAGE
        # Quando usar fica no tooltip do operador (bl_description).
        row.operator(HYBLENDPREFABS_OT_clear_assets_cache.bl_idname, text="Clear Cache", icon="TRASH")
        if is_developer_mode(context):
            body.operator(EXPORT_OT_hyblend_debug_dump.bl_idname, text="Export Debug Dump", icon="EXPORT")

    # -- 6. About ------------------------------------------------------------

    def _draw_about(self, layout, context):
        """= aba Info do Hyblend Toolkit (_draw_info), sem o botão Welcome:
        crédito ao Hytale + aviso, Links, Créditos."""
        header, body = layout.panel("hyblendprefabs_about", default_closed=True)
        header.label(text="About", icon="INFO")
        if body is None:
            return

        def url_button(row, url, text, key, fallback):
            cell = row.row(align=True)
            cell.enabled = bool(url)
            cell.operator("wm.url_open", text=text, **_icon_kwargs(key, fallback)).url = url or ""

        hypixel_col = body.box().column(align=True)
        hytale_row = hypixel_col.row(align=True)
        hytale_row.label(text=cu.ABOUT_HYTALE_LABEL, icon="WORLD")
        hytale_sub = hytale_row.row(align=True)
        hytale_sub.alignment = "RIGHT"
        url_button(hytale_sub, cu.HYBLEND_HYTALE_URL, "Hytale", "hytale", "URL")
        _draw_wrapped_label(hypixel_col, context, cu.HYBLEND_DISCLAIMER)

        body.separator()

        links_box = body.box()
        links_box.label(text=cu.ABOUT_LINKS_LABEL, icon="URL")
        links_row = links_box.row(align=True)
        links_row.scale_y = 1.2
        url_button(links_row, cu.HYBLEND_NEXUSMODS_URL, "Nexus Mods", "nexus_mods", "WORLD")
        url_button(links_row, cu.HYBLEND_GITHUB_URL, "GitHub", "github", "COMMUNITY")

        body.separator()

        credits_col = body.box().column(align=True)
        credits_col.label(text=cu.ABOUT_CREDITS_LABEL, icon="USER")
        credits_col.label(text=cu.ABOUT_CREATED_BY_LABEL)
        credits_col.label(text=cu.HYBLEND_STUDIO_NAME)
        credits_row = credits_col.row(align=True)
        credits_row.label(text=cu.HYBLEND_AUTHOR_NAME)
        socials = credits_row.row(align=True)
        socials.alignment = "RIGHT"
        for url, key, fallback, _gpu_icon in cu.HYBLEND_SOCIAL_LINKS:
            url_button(socials, url, "", key, fallback)


_CLASSES = (HYBLENDPREFABS_PT_main,)


# --------------------------------------------------------------------------
# Seletor dos addons Hyblend (hyblend_hub.py)
# --------------------------------------------------------------------------

def _hub_register():
    """Seletor nativo, inscrição e pasta do Hytale no boot: o desenho padrão
    dos addons Hyblend (hyblend_hub.register_addon)."""
    hyblend_hub.register_addon(HUB_ID, "Prefabs", ADDON_PACKAGE, "hyblendprefabs", game_found=game_found,
                               gpu_ui=gpu_ui,
                               reason="Hytale folder not found: set it in the Hyblend Prefabs Preferences")


def _hub_unregister():
    hyblend_hub.unregister_addon(HUB_ID, ADDON_PACKAGE)


def register():
    _load_panel_icons()
    _hub_register()            # seletor (painel bl_order 0) antes dos paineis da aba
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    gpu_ui.register()          # nao faz nada abaixo do Blender 5.0


def unregister():
    gpu_ui.unregister()
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
    _hub_unregister()
    _unload_panel_icons()
