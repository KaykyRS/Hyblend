"""
HyblendToolkit -- pacote raiz.
====================================

Este arquivo só faz UMA coisa: registrar/desregistrar os submódulos de
_MODULES, nessa ordem (e na ordem inversa ao desregistrar). Só muda quando
um submódulo novo entra no pacote (ver DEVELOPER_NOTES.md).

Não existe `bl_info` aqui porque este é um addon no formato "Extension"
(Blender 4.2+) -- os metadados equivalentes vivem em blender_manifest.toml.
"""

from . import common, translations, templates, exporter, importer, anim, interface, rigger

_MODULES = (common, translations, templates, importer, anim, exporter, interface, rigger)


def register():
    for module in _MODULES:
        module.register()


def unregister():
    for module in reversed(_MODULES):
        module.unregister()


if __name__ == "__main__":
    register()
