"""model_tree.py -- escala e tamanho de atlas estimado, do núcleo (api.model): os mesmos do import do Hyblend."""

from __future__ import annotations

import json
from pathlib import Path

from ..toolkit import api

UNIT_SCALE_DEFAULT = api.model.props.UNIT_SCALE_DEFAULT


def estimate_atlas_size(blockymodel_path: Path) -> tuple:
    """(largura, altura) mínimas do atlas pelo maior canto usado -- só quando a textura de verdade não carrega
    (o tamanho dela é sempre melhor)."""
    with blockymodel_path.open(encoding="utf-8") as f:
        data = json.load(f)
    return api.model.geometry.atlas_size(data.get("nodes", []))
