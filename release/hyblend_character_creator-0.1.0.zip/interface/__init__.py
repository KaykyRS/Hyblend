"""interface/ -- TODA a camada de UI do addon (o que o usuario ve e clica),
separada da logica (picker.py, builder/, scanner/, thumbnails/,
presets_ops.py, player_ops.py). Pedido explicito do usuario (DEVELOPER_
NOTES item 56).

REGRA DE DEPENDENCIA: interface/ importa da logica; a logica NUNCA
importa de interface/ no topo do arquivo. Unica excecao documentada:
`HYBLENDCC_AddonPreferences.draw` (preferences.py) faz um import TARDIO
de `preferences_ui` dentro do proprio draw().

  widgets.py         primitivas de layout (grade de icone, gap fixo,
                     centralizacao fracionaria) -- sem import interno
  ui_data.py         prepara dado pra UI (agrupamento de Categoria,
                     entradas de swatch) -- so leitura
  operators.py       Operators de clique (select_*/toggle_*) -- so
                     escrevem estado de UI/slot, nunca aplicam direto
  panel.py           o N-panel (HYBLENDCC_PT_test_panel)
  preferences_ui.py  draw() da tela de Preferences do addon

`OPERATOR_CLASSES`/`PANEL_CLASSES` abaixo sao as classes de UI pra
registrar -- o __init__.py raiz junta com as classes de logica, com os
Panels POR ULTIMO (depois de todo Operator que eles desenham)."""

from __future__ import annotations

from .operators import (
    HYBLENDCC_OT_select_background_color,
    HYBLENDCC_OT_select_category,
    HYBLENDCC_OT_select_color,
    HYBLENDCC_OT_select_section,
    HYBLENDCC_OT_select_variant,
    HYBLENDCC_OT_toggle_background_link,
    HYBLENDCC_OT_toggle_skin_link,
)
from .panel import HYBLENDCC_PT_test_panel

OPERATOR_CLASSES = (
    HYBLENDCC_OT_select_section,
    HYBLENDCC_OT_select_category,
    HYBLENDCC_OT_select_variant,
    HYBLENDCC_OT_select_color,
    HYBLENDCC_OT_select_background_color,
    HYBLENDCC_OT_toggle_background_link,
    HYBLENDCC_OT_toggle_skin_link,
)

PANEL_CLASSES = (
    HYBLENDCC_PT_test_panel,
)
