"""hytale_install.py -- mapa da pasta de instalacao do Hytale (a pasta
"Hytale" que o launcher cria, ex. %APPDATA%/Hytale no Windows).

ESTE ARQUIVO É IDÊNTICO nos addons Hyblend (Toolkit e Prefabs:
interface/gpu_ui/hytale_install.py; Character Creator:
scanner/hytale_install.py). Mudou num -> copiar pros outros. ROOTS tem as
raízes que QUALQUER um deles usa (sobrar raiz não custa nada).

O usuario aponta SO a pasta Hytale; tudo que o addon le do jogo (o
Assets.zip, os icones da interface, ...) e resolvido a partir dela por
caminho RELATIVO fixo. Estrutura confirmada contra a listagem real da
instalacao (`dir /s /b` do usuario, set/2026).

Sem bpy: modulo puro (testavel fora do Blender).

COMO ADICIONAR ALGO NOVO DO JOGO
--------------------------------
Todo caminho do jogo e uma REFERENCIA no formato "raiz:caminho/relativo".
A raiz e um apelido de pasta registrado em ROOTS logo abaixo.

- Arquivo numa pasta que ja tem raiz -> so usar a referencia, ex.
  "avatar:SearchIcon@2x.png". Nada muda aqui.
- Pasta nova -> 1 linha em ROOTS. A raiz pode partir de outra raiz
  ("game_ui:Common") ou da propria pasta Hytale (sem ":").

Nunca varre diretorio: resolver uma referencia e so juntar caminho
(cacheado), entao o custo nao depende do tamanho da instalacao.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Optional

# apelido -> "outra_raiz:subpasta" OU caminho direto a partir da pasta
# Hytale (sem ":"). Sempre "/" como separador, independente do SO.
ROOTS = {
    "latest": "install/release/package/game/latest",
    "client_data": "latest:Client/Data",
    # Interface do jogo (Client/Data/Game/Interface) -- PNGs @2x
    "game_ui": "client_data:Game/Interface",
    "game_common": "game_ui:Common",
    "game_buttons": "game_common:Buttons",
    "game_settings": "game_common:Settings",
    "inventory": "game_ui:InGame/Pages/Inventory",
    "avatar": "game_ui:MainMenu/MyAvatar",
    "avatar_categories": "avatar:CategoryIcons",
    "avatar_presets": "avatar:AvatarPreset",
    "shop": "game_ui:MainMenu/Shop",
    # Menu principal do jogo (Home do Hyblend)
    "main_menu": "game_ui:MainMenu",
    "adventure": "main_menu:Adventure",
    # Interface do editor de assets (Client/Data/Editor/Interface) -- @2x
    "editor_ui": "client_data:Editor/Interface",
    "editor_common": "editor_ui:Common",
    "editor_asset": "editor_ui:AssetEditor",
    "editor_asset_icons": "editor_asset:AssetIcons",
    # Recursos compartilhados (Client/Data/Shared/UI) -- em geral SEM @2x
    "shared_ui": "client_data:Shared/UI",
    "shared_icons": "shared_ui:Textures/Icons",
    "shared_decor": "shared_ui:Textures/Decorations",
    "shared_controls": "shared_ui:Textures/Controls",
    "creative_library": "shared_ui:Textures/CreativeLibrary",
    "shared_editor_icons": "shared_ui:Editor/Icons",
    "shared_fonts": "shared_ui:Fonts",
    "bg_images": "shared_ui:Textures/BackgroundImages",     # fundos 1920x1080 da Home
}

# Arquivos fixos que os addons precisam (fora os icones, que ficam nas
# tabelas de cada addon: gpu_ui/game.py, common.py do CC).
ASSETS_ZIP = "latest:Assets.zip"

_MAX_PARENT_WALK = 8


def _split(ref: str):
    alias, sep, rel = ref.partition(":")
    if not sep:
        return None, ref
    return alias, rel


@lru_cache(maxsize=None)
def relative_parts(ref: str) -> tuple:
    """Referencia -> partes do caminho relativo a pasta Hytale. Resolve
    raiz dentro de raiz (recursivo, cacheado). Apelido desconhecido ou
    ciclo em ROOTS e erro de programacao: levanta KeyError/ValueError com
    a referencia no texto, pra aparecer no teste/console na hora."""
    return _relative_parts(ref, ())


def _relative_parts(ref: str, seen: tuple) -> tuple:
    alias, rel = _split(ref)
    rel_parts = tuple(p for p in rel.split("/") if p)
    if alias is None:
        return rel_parts
    if alias in seen:
        raise ValueError(f"hytale_install: cycle in ROOTS at '{alias}' ({' -> '.join(seen)})")
    if alias not in ROOTS:
        raise KeyError(f"hytale_install: unknown root '{alias}' in '{ref}'")
    return _relative_parts(ROOTS[alias], seen + (alias,)) + rel_parts


def resolve(hytale_dir: Path, ref: str) -> Path:
    """Caminho absoluto de uma referencia dentro de `hytale_dir`. Nao
    checa se existe (quem chama decide o fallback)."""
    return Path(hytale_dir).joinpath(*relative_parts(ref))


def is_hytale_dir(path: Path) -> bool:
    """A pasta e a raiz de uma instalacao do Hytale? Criterio: o
    Assets.zip existe no lugar esperado (o addon nao funciona sem ele)."""
    try:
        return resolve(path, ASSETS_ZIP).is_file()
    except OSError:
        return False


def find_hytale_dir(path) -> Optional[Path]:
    """Normaliza o que o usuario escolheu no modo Manual: aceita a
    propria pasta Hytale, qualquer pasta/arquivo DENTRO dela (ex. a
    pasta latest ou o proprio Assets.zip, subindo ate achar) ou a pasta
    que CONTEM "Hytale" (ex. Roaming). Devolve None se nada bater."""
    if not path:
        return None
    p = Path(path)
    if p.is_file():
        p = p.parent
    candidates = [p, *list(p.parents)[:_MAX_PARENT_WALK]]
    for c in candidates:
        if is_hytale_dir(c):
            return c
    child = p / "Hytale"
    if is_hytale_dir(child):
        return child
    return None


def default_hytale_dir() -> Optional[Path]:
    """Local padrao do launcher (confirmado no Windows:
    %APPDATA%/Hytale). Devolve None se nao existir -- o usuario usa o
    modo Manual. Outros SOs: acrescentar candidatos aqui quando houver
    uma instalacao real pra conferir."""
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    candidate = Path(appdata) / "Hytale"
    return candidate if is_hytale_dir(candidate) else None


def validate_roots() -> None:
    """Checagem de desenvolvimento: toda raiz resolve (sem ciclo, sem
    apelido desconhecido). Usada pelos testes."""
    for alias in ROOTS:
        relative_parts(alias + ":")
