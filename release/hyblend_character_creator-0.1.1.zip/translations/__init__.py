"""Textos do Character Creator: en.py/pt_br.py daqui (LANGUAGE_CODE, LANGUAGE_NAME, TRANSLATIONS), registrados no carregador do
Hyblend Toolkit. O idioma é o do núcleo (um só pra todos os addons Hyblend); key que não existe aqui cai na tabela do
núcleo e depois no inglês; key que não existe em lugar nenhum volta crua.

Uso: tr("arquivo.chave", get_language(context)); tooltip de botão: description = tooltip("arquivo.tooltip.nome");
tooltip de campo: @localized_props(fn) + register_localized_class (ver notas do Toolkit, "translations/").
IMPORTANTE: nada de tr() no nível do módulo (só dentro de função): a tabela entra no register().
"""

import os

from ..toolkit import api

OWNER = "cc"
_DIR = os.path.dirname(__file__)

get_language = api.get_language
localized_props = api.localized_props
register_localized_class = api.register_localized_class
unregister_localized_class = api.unregister_localized_class
register_refresh_hook = api.register_refresh_hook
unregister_refresh_hook = api.unregister_refresh_hook


def tr(key, lang):
    """Texto de `key` em `lang` (tabela do Character Creator, depois a do núcleo); senão inglês; senão a própria key."""
    return api.tr_for(OWNER, key, lang)


def tooltip(key):
    """classmethod description(cls, context, properties) pra `description = tooltip(...)` num Operator."""
    return api.tooltip_for(OWNER, key)


def _load():
    return api.load_tables(__package__, _DIR)


def register():
    """Primeiro a registrar (main.py): os outros módulos podem montar textos no register() deles."""
    api.register_table(OWNER, _load)


def unregister():
    api.unregister_table(OWNER)
