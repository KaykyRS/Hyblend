"""interface/gpu_ui/bind.py -- ponte entre a tela (widgets em Python puro) e o
Blender (properties + operadores). Adaptado do bind.py do Hyblend Toolkit.

REGRA (a mesma da UI clássica): nenhuma lógica de aplicar item/cor mora
aqui. Clique = o MESMO operador que o botão clássico chama
(`hyblendcc.select_color`, `...toggle_skin_link`, `...create_player`...)
ou a MESMA property que o widget clássico escreve (`slot.item_id` via
template_icon_view, `slot.gradient_set` via prop). O update() normal do
slot (picker.py) continua sendo quem agenda `_defer_apply_slot`.

Tudo que precisa MEXER em dado do Blender fora de um clique (carregar
catálogo, sincronizar slots com o Armature ativo, cortar ícones) roda em
`sync_tick`, um bpy.app.timers -- nunca dentro do draw handler.
"""

from __future__ import annotations

import traceback

import bpy

# --------------------------------------------------------------------------
# Operadores e properties
# --------------------------------------------------------------------------


def _override(f):
    """Operador roda como se o botão estivesse na sidebar (igual ao
    painel clássico): janela + área da View3D + região UI."""
    host = getattr(f, "host", None)
    found = host.lookup() if host is not None else None
    if not found:
        return {}
    window, area, sidebar, _viewport = found
    return {"window": window, "area": area, "region": sidebar}


def _op_callable(idname):
    module, name = idname.split(".", 1)
    return getattr(getattr(bpy.ops, module), name)


def run_op(f, idname, props=None, invoke=True, toast=None):
    """Roda o operador pelo bl_idname. Erro reportado pelo operador
    (report ERROR vira RuntimeError no bpy.ops) aparece como toast."""
    try:
        call = _op_callable(idname)
        with bpy.context.temp_override(**_override(f)):
            result = call("INVOKE_DEFAULT" if invoke else "EXEC_DEFAULT", True, **(props or {}))
    except RuntimeError as error:
        message = str(error).split("\n")[0].replace("Error: ", "").strip()
        f.toast(message or idname, error=True)
        return None
    except Exception as error:
        traceback.print_exc()
        f.toast("Error: %s" % error, error=True)
        return None
    if toast and result and "FINISHED" in result:
        f.toast(toast)
    return result


def op_poll(idname) -> bool:
    try:
        return bool(_op_callable(idname).poll())
    except Exception:
        return False


def op_description(idname) -> str:
    try:
        return _op_callable(idname).get_rna_type().description
    except Exception:
        return ""


def _undo_push(message):
    try:
        bpy.ops.ed.undo_push(message=message)
    except Exception:
        pass


def set_prop(f, owner, prop, value, undo=True):
    """Escreve numa property (dispara o update() normal dela)."""
    try:
        setattr(owner, prop, value)
    except (ReferenceError, AttributeError):
        return False
    except (TypeError, ValueError) as error:
        f.toast(str(error), error=True)
        return False
    if undo:
        try:
            label = owner.bl_rna.properties[prop].name or prop
        except (KeyError, AttributeError):
            label = prop
        _undo_push(label)
    return True


def prefs(context=None):
    from ...common import ADDON_PACKAGE
    context = context or bpy.context
    try:
        return context.preferences.addons[ADDON_PACKAGE].preferences
    except (KeyError, AttributeError):
        return None


# --------------------------------------------------------------------------
# Sincronização (fora do desenho)
# --------------------------------------------------------------------------

_last_attempt = None


_loaded_for = None      # (hytale_path, language) do último sync que carregou o catálogo
_failed_for = None      # idem, do último sync que NÃO conseguiu carregar


def _sync_key(context):
    from ...scanner.catalog import get_cache
    from . import data
    obj = context.active_object
    armature = obj.name if obj is not None and obj.type == "ARMATURE" else None
    wm = context.window_manager
    p = prefs(context)
    source = (p.hytale_path, p.language) if p is not None else (None, None)
    # Catálogo/idioma prontos PRA ESTA fonte: trocar o caminho dos Assets
    # ou o idioma nas Preferences tem que recarregar (a UI clássica faz
    # isso sozinha no draw, via ensure_loaded/ensure_lang_loaded).
    loaded = data.catalog_loaded() and _loaded_for == source
    lang = get_cache().language == source[1]
    return (source, loaded, data.icons_warm(), lang, armature,
            wm.get("hyblendcc_synced_for"), len(wm.hyblendcc_slots))


def maybe_sync(context) -> None:
    """Checagem BARATA (roda no build): o que a tela vai mostrar está
    pronto? Catálogo carregado PRA fonte atual (caminho + idioma), ícones
    cortados, slots sincronizados com o Armature ativo (mesma chave que
    picker._ensure_slots_synced usa). Se não, agenda `sync_tick`.

    Anti-loop: se o ÚLTIMO sync rodou com exatamente este mesmo estado e
    nada mudou (ex. pasta de idiomas não existe, catálogo vazio), não
    agenda de novo -- senão sync -> invalida -> rebuild -> sync... pra
    sempre."""
    global _last_attempt
    key = _sync_key(context)
    _source, loaded, icons, lang, armature, synced_for, n_slots = key
    ready = loaded and icons and lang and (armature is None or (synced_for == armature and n_slots))
    if ready or key == _last_attempt:
        return
    _last_attempt = key
    request_sync()


def catalog_failed(context) -> bool:
    """True = o último sync pra fonte atual rodou e o catálogo NÃO
    carregou (caminho inválido, zip sem Cosmetics/...). A tela mostra
    erro + Auto-Detect em vez de "Loading…" pra sempre."""
    p = prefs(context)
    return p is not None and _failed_for == (p.hytale_path, p.language)


def catalog_ready(context) -> bool:
    """Catálogo carregado E pra fonte atual (não um resto da anterior)."""
    from . import data
    p = prefs(context)
    return data.catalog_loaded() and p is not None and _loaded_for == (p.hytale_path, p.language)


def forget_sync_attempt():
    """Assets/idioma/catálogo mudaram por fora: permitir tentar de novo."""
    global _last_attempt, _loaded_for, _failed_for
    _last_attempt = None
    _loaded_for = None
    _failed_for = None


def request_sync():
    """Agenda `sync_tick` (idempotente). Pode ser chamado de dentro do
    build/draw -- só registra um timer, não mexe em dado nenhum.
    `is_registered` em vez de flag própria: abrir outro .blend apaga
    timers não-persistentes e uma flag ficaria presa (ver renderer)."""
    if not bpy.app.timers.is_registered(sync_tick):
        bpy.app.timers.register(sync_tick, first_interval=0.0)


def sync_tick():
    """Timer: faz o trabalho que a UI clássica faz dentro do draw() do
    painel (ensure_loaded/ensure_lang_loaded/_ensure_slots_synced), mais
    o corte de margem dos ícones, e pede pra tela reconstruir."""
    global _loaded_for, _failed_for
    from . import data
    try:
        from ...builder.character_assembly import AssemblyError
        from ...picker import _ensure_slots_populated, _ensure_slots_synced
        from ...preferences import _languages_dir
        from ...scanner.catalog import get_cache

        context = bpy.context
        p = prefs(context)
        if p is None or not p.hytale_path:
            return None
        source = (p.hytale_path, p.language)
        data.warm_icons()
        obj = getattr(context, "active_object", None)
        if obj is not None and obj.type == "ARMATURE":
            _ensure_slots_synced(context, obj)     # também popula (e carrega o catálogo)
        else:
            _ensure_slots_populated(context)       # só carrega o catálogo
        try:
            get_cache().ensure_lang_loaded(_languages_dir(context), p.language)
        except AssemblyError:
            pass
        if data.catalog_loaded():
            _loaded_for, _failed_for = source, None
        else:
            _loaded_for, _failed_for = None, source
        data.invalidate()
    except Exception:
        traceback.print_exc()
    invalidate_hosts()
    return None


def invalidate_hosts():
    from .framework import runtime
    for host in list(runtime._HOSTS.values()):
        host.invalidate()


def cancel_sync():
    forget_sync_attempt()
    try:
        if bpy.app.timers.is_registered(sync_tick):
            bpy.app.timers.unregister(sync_tick)
    except Exception:
        pass
