"""preferences.py -- Preferences do addon (pasta Hytale, idioma, mostrar
miniaturas) + tudo que resolve CAMINHOS de arquivo a partir dai. O
usuario aponta SO a pasta Hytale; o Assets.zip (e os icones, ver
common._game_file) sao achados dentro dela por caminho relativo fixo
(scanner/hytale_install.py).

Camada 2 na hierarquia de import (depois de common.py) -- so depende de
common.py e dos modulos externos (builder/scanner/thumbnails). NADA em
picker.py/presets_ops.py/player_ops.py/interface/ e importado no topo
deste arquivo, pra manter a dependencia sempre numa direcao so (unica
excecao: import TARDIO de interface/preferences_ui.py DENTRO do draw()
das Preferences -- ver comentario la) (ver DEVELOPER_NOTES.md pro
mapa completo)."""

from __future__ import annotations

import os
import zipfile
from pathlib import Path

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import AddonPreferences, Operator

from .builder.character_assembly import AssemblyError
from .common import (
    ADDON_PACKAGE,
    HUB_ID,
    _hytale_dir,
    _icon_load_failed,
    _invalidate_hytale_dir,
    _preview_collections,
    _request_icon_precompute,
    _tag_view3d_redraw,
)
from . import hyblend_hub  # gpu_ui: escolha da UI por GPU compartilhada entre os addons Hyblend
from .paths import TEMP_CROPPED_ICONS, TEMP_SWATCH_ICONS, data_root, temp_dir
from .scanner import hytale_install
from .scanner.assets_source import ZipAssetsSource
from .thumbnails.cache import cache_root as thumbnail_cache_root


def _language_enum_items(self, context):
    """Lista as pastas de idioma que existem de verdade em
    Common/Languages/ (ex. "en-US", "pt-BR") -- em vez de exigir digitar
    o nome certinho na mao. Definida aqui em cima (antes da classe de
    Preferences que usa ela) de proposito: uma EnumProperty precisa que
    o nome da funcao de items() ja exista no momento em que a classe e
    definida -- diferente de outras funcoes deste arquivo, que so
    precisam existir na hora em que sao CHAMADAS (bem mais tarde). O
    CORPO da funcao pode chamar _languages_dir/etc normalmente, ja que
    esse corpo so roda de verdade quando o Blender desenha o dropdown,
    momento em que o modulo inteiro ja carregou."""
    items = [("en-US", "en-US", "")]
    try:
        languages_dir = _languages_dir(context)
        if languages_dir.is_dir():
            items = [(lang, lang, "") for lang in sorted(p.name for p in languages_dir.iterdir() if p.is_dir())] or items
    except AssemblyError:
        pass
    # Lista guardada no módulo: o Blender NÃO guarda as strings de items()
    # dinâmicos -- sem referência viva, os rótulos podem sair corrompidos.
    if items != _LANGUAGE_ITEMS:
        _LANGUAGE_ITEMS[:] = items       # igual = mantém os MESMOS objetos de string
    return _LANGUAGE_ITEMS


_LANGUAGE_ITEMS: list = []


def _on_hytale_path_changed(self, context):
    """update= de hytale_path/hytale_path_mode: descarta a fonte de
    Assets e o caminho resolvido antigos e agenda o carregamento dos
    icones do jogo (timer -- nunca bpy.data aqui). A UI GPU percebe a
    troca pela propria assinatura (bind._sync_key)."""
    _invalidate_hytale_dir()
    _invalidate_assets_source()
    _request_icon_precompute()
    from .interface import gpu_ui      # import TARDIO (camada de cima), como no draw()
    gpu_ui.on_hytale_path_changed(context)
    # A pasta é UMA pra todos os addons Hyblend: o hub grava e copia pros
    # outros (os updates que isso causa neles não voltam).
    hyblend_hub.share_hytale(HUB_ID, self.hytale_path_mode, self.hytale_path)


class HYBLENDCC_AddonPreferences(AddonPreferences):
    bl_idname = ADDON_PACKAGE

    # Pasta do Hytale: mesmos campos, textos e comportamento do Toolkit/Prefabs
    # (descrições e itens em hyblend_hub, iguais nos três).
    hytale_path_mode: EnumProperty(
        name="Hytale Folder",
        description=hyblend_hub.HYTALE_MODE_DESCRIPTION,
        items=[(ident, label, tip) for ident, label, tip in hyblend_hub.HYTALE_MODE_ITEMS],
        default="AUTO",
        update=_on_hytale_path_changed,
    )
    hytale_path: StringProperty(
        name="Hytale Folder",
        description=hyblend_hub.HYTALE_PATH_DESCRIPTION,
        subtype="DIR_PATH",
        update=_on_hytale_path_changed,
    )
    language: EnumProperty(
        name="Language (item names)",
        description="Language folder under Common/Languages/ -- lists whatever actually exists in your "
        "Assets folder. Only affects the names shown in the picker -- if the key isn't found, shows the "
        "raw technical Id without breaking anything.",
        items=_language_enum_items,
    )
    show_previews: BoolProperty(
        name="Show Thumbnails",
        description="Item picker shows a grid of thumbnails (generated and cached to disk) instead of "
        "a text list. Turning it off switches back to a plain text list (lighter, no dependency on "
        "generated thumbnails) -- only use this if you prefer it.",
        default=True,
    )

    # --- gpu_ui: UI experimental por GPU (interface/gpu_ui/) -- so Blender 5.0+,
    # LIGADA por padrao. A escolha e UMA pra todos os addons Hyblend: get/set
    # no hub (hyblend_hub.py, Documentos/Hyblend/Config/ui.json) -- ligar aqui
    # liga no Toolkit/Prefabs e vice-versa. O hub avisa cada addon
    # (gpu_ui.on_preference_changed), por isso sem update= aqui. Abaixo do
    # 5.0 a opcao aparece travada (ver gpu_ui.draw_preferences) e
    # gpu_ui.is_enabled() ignora o valor.
    use_gpu_ui: BoolProperty(
        name="Experimental GPU Interface",
        description="Replace the classic panel with the experimental GPU-drawn Character Creator "
        "(in the \"Hyblend\" sidebar tab). Requires Blender 5.0+. Shared by all Hyblend addons: "
        "changing it here changes it in the others too",
        get=hyblend_hub.prop_get_gpu,
        set=hyblend_hub.prop_set_gpu, default=True,
    )
    # Tamanho do painel: COMPARTILHADO com os outros addons Hyblend (get/set
    # no hub, mesmo nome/padrão/limites nos três). O hub avisa cada addon
    # (gpu_ui.on_preference_changed) -- por isso sem update= aqui.
    gpu_ui_scale: FloatProperty(
        name="Panel Size",
        description="Size of the GPU panel, on top of Blender's Resolution Scale. Shared by all Hyblend addons",
        min=0.75, max=1.5, subtype="FACTOR",
        get=hyblend_hub.prop_get("panel_size"), set=hyblend_hub.prop_set("panel_size"),
        default=hyblend_hub.SETTINGS["panel_size"],
    )
    gpu_ui_panel_width: FloatProperty(
        name="Panel Width",
        description="0 = automatic. You can also drag the left edge of the panel. Shared by all Hyblend addons",
        min=0.0,
        get=hyblend_hub.prop_get("panel_width"), set=hyblend_hub.prop_set("panel_width"), default=0.0,
    )
    gpu_ui_panel_height: FloatProperty(
        name="Panel Height",
        description="0 = automatic (follows the content). You can also drag the bottom edge of the panel. "
        "Shared by all Hyblend addons",
        min=0.0,
        get=hyblend_hub.prop_get("panel_height"), set=hyblend_hub.prop_set("panel_height"), default=0.0,
    )

    def draw(self, context):
        # O desenho mora em interface/preferences_ui.py (toda UI do addon
        # fica em interface/ -- DEVELOPER_NOTES item 56). Import TARDIO
        # (dentro do draw, nao no topo) de proposito: preferences.py e
        # camada 2 e interface/ e a camada de cima -- no topo do arquivo
        # isso viraria import circular; aqui so roda quando o Blender
        # desenha a tela de Preferences, com tudo ja carregado.
        from .interface.preferences_ui import draw_addon_preferences

        draw_addon_preferences(self, context, self.layout)


# "Locate Game": o mesmo do Toolkit/Prefabs (local padrao; senao, seletor de
# pasta). Substitui o antigo "Auto-Detect Hytale" (hyblendcc.autodetect_assets).
HYBLENDCC_OT_locate_game = hyblend_hub.make_locate_operator(
    "hyblendcc", HUB_ID, ADDON_PACKAGE, default_dir=hytale_install.default_hytale_dir,
    find_dir=hytale_install.find_hytale_dir)


# Tudo que o CC gera/extrai e pode ser refeito (NUNCA os presets do usuario).
EXTRACT_CACHE_DIR = data_root() / "assets_cache"
_TEMP_CACHE_DIRS = (TEMP_CROPPED_ICONS, TEMP_SWATCH_ICONS)     # em tempfile.gettempdir()


class HYBLENDCC_OT_clear_cache(Operator):
    """Clear Cache: apaga TUDO que o addon gerou ou extraiu -- miniaturas
    (Documentos/Hyblend/CharacterCreator/thumbnail_cache/), os arquivos
    extraidos do Assets.zip (.../assets_cache/: o ZipAssetsSource so extrai
    o que ainda nao existe, entao depois de uma atualizacao do jogo ele
    continuaria com a versao antiga) e os icones cortados/bolinhas de cor
    (pasta temporaria). Os presets ficam. Tudo volta sozinho quando for
    preciso (catalogo, icones e miniaturas sob demanda)."""

    bl_idname = "hyblendcc.clear_cache"
    bl_label = "Clear Cache"
    bl_description = (
        "Delete everything the Character Creator generated or extracted (thumbnails, files extracted from "
        "Assets.zip, cropped icons). Do this after a Hytale update -- it is all rebuilt when needed. "
        "Presets are kept"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        import shutil

        from .picker import _invalidate_item_enum_cache   # import tardio (picker importa este arquivo)
        from .scanner.catalog import get_cache

        _invalidate_assets_source()          # fecha o Assets.zip antes de apagar o que ele extraiu
        pcoll = _preview_collections.get("main")
        if pcoll is not None:
            pcoll.clear()                    # solta os PNGs das miniaturas antes de apagar (Windows)
        roots = [thumbnail_cache_root(), EXTRACT_CACHE_DIR] + [temp_dir(name) for name in _TEMP_CACHE_DIRS]
        removed, failed = 0, []
        for root in roots:
            if root.is_dir():
                removed += sum(1 for _ in root.iterdir())
                shutil.rmtree(root, onerror=lambda fn, path, _exc: fn is os.rmdir or failed.append(path))
        get_cache().invalidate()             # catalogo relido do Assets.zip (versao nova do jogo)
        _invalidate_item_enum_cache()        # os items() guardam icon_id da preview collection
        _icon_load_failed.clear()
        _request_icon_precompute()           # icones de categoria cortados de novo (timer)
        # Texturas dos personagens que já existem apontam pra assets_cache:
        # extraídas de novo (versão nova do jogo) e recarregadas.
        restore_cached_images(context, only_missing=False)
        from .interface import gpu_ui        # import TARDIO (camada de cima)
        gpu_ui.on_cache_cleared()            # UI por GPU esquece as imagens/miniaturas antigas
        if failed:
            self.report({"WARNING"}, f"Character Creator cache cleared, but {len(failed)} file(s) are in use "
                        "and were kept (close other programs/Blender windows and try again).")
        else:
            self.report({"INFO"}, f"Character Creator cache cleared ({removed} entry/entries).")
        return {"FINISHED"}


def restore_cached_images(context, only_missing=True) -> int:
    """Imagens do .blend que apontam pra assets_cache (texturas dos
    personagens): re-extrai do Assets.zip e recarrega. Sem o jogo: nada."""
    from .common import game_found
    if not game_found():
        return 0

    def extract(relative):
        _get_assets_source(context).resolve_root(*relative.split("/"))

    return hyblend_hub.restore_cached_images(EXTRACT_CACHE_DIR, extract, only_missing=only_missing)


@bpy.app.handlers.persistent
def _restore_images_on_load(_dummy=None):
    """load_post: .blend aberto depois de um Clear Cache -- as texturas que
    sumiram do assets_cache voltam do Assets.zip."""
    try:
        restore_cached_images(bpy.context)
    except Exception:
        import traceback
        traceback.print_exc()


_assets_source_state = {"key": None, "source": None}


def _autodetect_hytale_on_startup():
    """Timer agendado no register(): no modo Automatico com o campo
    vazio (addon recem-instalado), acha a pasta Hytale e preenche o
    campo sozinho -- sem exigir o clique em Auto-Detect. Precisa ser
    timer: o N-Panel nao pode escrever em property dentro do draw(), e
    ele mostra "No Hytale folder" e para antes de qualquer coisa que
    detectaria a pasta (causa do bug antigo). Nao achou: nao faz nada, o
    botao Auto-Detect / modo Manual continuam la."""
    addon = bpy.context.preferences.addons.get(ADDON_PACKAGE)
    if addon is None:
        return None
    prefs = addon.preferences
    if prefs.hytale_path_mode != "AUTO" or prefs.hytale_path:
        return None
    found = hytale_install.default_hytale_dir()
    if found is not None:
        prefs.hytale_path = str(found)   # update= invalida caches e agenda os icones
        _tag_view3d_redraw()
    return None


def _invalidate_assets_source() -> None:
    if _assets_source_state["source"] is not None:
        _assets_source_state["source"].close()
    _assets_source_state["key"] = None
    _assets_source_state["source"] = None


def _get_assets_source(context):
    # Sem escrever em property aqui: isto roda até de dentro de items() de
    # EnumProperty (idioma). Automático com o campo vazio já acha o local
    # padrão em _hytale_dir(); o timer do boot preenche o campo.
    prefs = context.preferences.addons[ADDON_PACKAGE].preferences
    hytale_dir = _hytale_dir()
    if hytale_dir is None and not prefs.hytale_path:
        raise AssemblyError(
            "Configure the Hytale folder in Preferences > Add-ons > Hyblend Character Creator first."
        )
    if hytale_dir is None:
        expected = "/".join(hytale_install.relative_parts(hytale_install.ASSETS_ZIP))
        raise AssemblyError(
            f"'{bpy.path.abspath(prefs.hytale_path)}' is not a Hytale folder (could not find {expected} "
            "inside it) -- check the path in Preferences > Add-ons > Hyblend Character Creator."
        )

    zip_path = hytale_install.resolve(hytale_dir, hytale_install.ASSETS_ZIP)
    if _assets_source_state["key"] == zip_path and _assets_source_state["source"] is not None:
        return _assets_source_state["source"]

    _invalidate_assets_source()
    try:
        source = ZipAssetsSource(zip_path, EXTRACT_CACHE_DIR)
    except (OSError, zipfile.BadZipFile) as exc:     # sumiu, travado, ou meio gravado (launcher atualizando)
        _invalidate_hytale_dir()
        raise AssemblyError(f"Could not open the game's Assets.zip ({exc}). If Hytale is updating, wait "
                            "for it to finish and try again.") from exc
    _assets_source_state["key"] = zip_path
    _assets_source_state["source"] = source
    return source


def _resolve_assets_path(context, *relative_parts) -> Path:
    """Resolve um caminho relativo a Assets/Common/ -- e onde moram os
    .blockymodel/texturas de verdade (Model/GreyscaleTexture/Texture dos
    manifests, e as texturas de rampa do GradientSets.json)."""
    return _get_assets_source(context).resolve_common(*relative_parts)


def _character_creator_dir(context) -> Path:
    return _get_assets_source(context).resolve_root_dir("Cosmetics", "CharacterCreator")


def _languages_dir(context) -> Path:
    return _get_assets_source(context).resolve_common_dir("Languages")
