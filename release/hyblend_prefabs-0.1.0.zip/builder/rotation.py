"""rotation.py -- decodifica o campo inteiro "rotation" de um block[] do
.prefab.json (codificacao base-4: yaw=bits0-1, pitch=bits2-3, roll=bits4-5,
0-63) pra uma Matrix de rotacao Blender. Formula e fonte em DEVELOPER_NOTES.md
("Rotacao de blocks")."""

from __future__ import annotations

import math

from mathutils import Matrix


def decode_block_rotation(raw, apply_heuristic: bool = True) -> Matrix:
    """Matrix 4x4 de rotacao pura (sem translacao/pivo -- isso e do chamador,
    ver prefab_importer.py), em espaco de arquivo (antes do Y-up->Z-up do
    root). apply_heuristic=False ou raw vazio/None -> identidade."""
    if not apply_heuristic or not raw:
        return Matrix.Identity(4)

    raw = int(raw)
    yaw_index = raw % 4
    pitch_index = (raw // 4) % 4
    roll_index = (raw // 16) % 4

    pitch_deg = pitch_index * -90.0
    yaw_deg = yaw_index * -90.0
    roll_deg = roll_index * -90.0

    # MiEx_rotateX(a)=padrao(-a), MiEx_rotateY(a)=padrao(-a), MiEx_rotateZ(a)=padrao(a)
    rx = Matrix.Rotation(math.radians(-pitch_deg), 4, "X")
    ry = Matrix.Rotation(math.radians(-yaw_deg), 4, "Y")
    rz = Matrix.Rotation(math.radians(roll_deg), 4, "Z")
    return rz @ ry @ rx
