"""material_setup.py -- materiais dos itens, do núcleo (api.model.materials), mesmos nomes de sempre:
  Modo A (tingível): GreyscaleTexture (luminância, Non-Color) -> amostra a rampa do GradientSet (gradient map: a
  cor vem da rampa, a sombra da máscara; multiply deixaria chapado).
  Modo B (texturas prontas): imagem direto.
  *_preview_*: sem luz (Emission + Transparent), pra miniatura.
"""

from __future__ import annotations

from ..toolkit import api

_materials = api.model.materials


def build_flat_material(name: str, image):
    return _materials.flat_material(image, name=name)


def build_gradient_tint_material(name: str, greyscale_image, gradient_image):
    """Devolve (material, node da rampa)."""
    return _materials.gradient_material(name, greyscale_image, gradient_image)


def build_flat_preview_material(name: str, image):
    return _materials.flat_preview_material(image, name=name)


def build_gradient_tint_preview_material(name: str, greyscale_image, gradient_image):
    """Devolve (material, node da rampa)."""
    return _materials.gradient_preview_material(name, greyscale_image, gradient_image)
