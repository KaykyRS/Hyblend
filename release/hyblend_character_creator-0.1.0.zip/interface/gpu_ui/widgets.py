"""interface/gpu_ui/widgets.py -- peças com a cara do jogo, em cima do
framework (framework/core.py). Python puro + renderer: nada aqui importa
`bpy`; quem liga um widget a property/operador é app.py (via bind.py).

Base: widgets.py do protótipo (cores medidas nas capturas do jogo).
Mudanças do CC:
  * NavIcon usa o PAR REAL de ícones do jogo (normal / "Selected") em vez
    de pintar uma silhueta -- decisão do usuário (item 57);
  * ItemTile: tile "Nenhum" com EmptyPartIcon real; miniatura ainda não
    gerada mostra o NOME do item (não um quadrado vazio);
  * novos: LinkButton (ícone real MatchHairColors), Chip (variantes),
    DropdownHeader/OptionRow/option_list (Materials, presets -- adaptados
    do Hyblend Toolkit), FooterButton, EmptyState, TextButton.
"""

from __future__ import annotations

from .framework.core import Column, Rect, Style, Widget, fit_text
from .framework.motion import mix


def rgb(r, g, b, a=1.0):
    return (r / 255, g / 255, b / 255, a)


# Paleta: onde o jogo define a cor, ela vem dos .ui/PNGs reais do Hytale
# (Common.ui, Container.ui, MainMenu/MyAvatar/MyAvatarPage.ui, pixels das
# peças douradas) -- comentário com a origem. O resto é do protótipo.
C = type("Colors", (), dict(
    panel=rgb(23, 30, 40),
    title_band=rgb(33, 49, 72),
    title_pattern=rgb(28, 41, 61, 0.9),
    title_text=rgb(180, 200, 201),          # Container.ui @TitleStyle
    title_line=rgb(16, 20, 26),
    divider_a=rgb(43, 53, 66),          # MyAvatarPage.ui / Common.ui @ContentSeparator
    divider_b=rgb(43, 53, 66),          # idem
    nav_tile=rgb(28, 37, 51),
    nav_icon=rgb(55, 63, 76),
    nav_icon_hover=rgb(92, 103, 122),
    gold=rgb(236, 200, 131),          # ContainerTitleArrow / SelectedCategoryArrow
    gold_bright=rgb(241, 186, 80),          # Common.ui dourado forte / PartFrameSelected
    text=rgb(150, 169, 190),          # Common.ui @ColorDefaultLabel / MyAvatar @HeadlineLabelStyle
    text_dim=rgb(90, 106, 122),          # Common.ui @ColorCaptionLight
    search=rgb(21, 26, 36),
    search_icon=rgb(175, 176, 182),
    placeholder=rgb(75, 87, 108),          # MyAvatarPage.ui busca PlaceholderStyle
    tile=rgb(47, 58, 79),          # MyAvatarPage.ui @PartPreviewBackgroundColor
    tile_hover=rgb(96, 110, 136),
    x_icon=rgb(119, 133, 157),
    check=rgb(87, 217, 175),
    check_mark=rgb(19, 24, 33),
    button=rgb(32, 39, 48),
    button_hover=rgb(40, 50, 64),
    button_icon=rgb(70, 82, 100),
    footer=rgb(19, 25, 34),
    danger=rgb(230, 110, 110),
    tile_hover_bg=rgb(57, 69, 93),     # MyAvatarPage.ui @PartPreviewBackgroundColorHovered
    option_text=rgb(183, 206, 221),       # Common.ui entrada de dropdown
    option_hover=rgb(37, 46, 72),      # Common.ui HoveredEntryBackground (dropdown com título)
))

CONTROL_H = 26.0


class TitleBar(Widget):
    """Faixa do título. Com `header` (ContainerHeader do jogo): igual ao
    @DecoratedContainer do Common/Container.ui -- a faixa é esse PNG em
    9-slice só horizontal (pontas proporcionais à altura, meio estica) e o
    ornamento (ContainerDecorationTop) numa faixinha própria ACIMA dela.
    Igual ao widgets.Ornament do Toolkit: a faixinha tem só a altura da
    BARRA do PNG (12 de 22 linhas); a metade de baixo (transparente, com o
    losango pendurado) cai POR CIMA da faixa do título -- o ornamento fica
    colado no título, sem vão (com a faixa do seletor dos addons em cima,
    igual ao Toolkit e ao Prefabs). Sem `header`: a faixa provisória (cor +
    arabesco `pattern`)."""

    ORNAMENT_MAX_W = 236.0          # largura lógica máxima (jogo: 236x11)
    ORNAMENT_RATIO = 22.0 / 472.0   # altura/largura do PNG
    ORNAMENT_BAR = 12.0 / 22.0      # fração do PNG ocupada pela barra
    # O miolo azul do ContainerHeader começa ABAIXO da borda de cima (7 de
    # 38 no jogo, Padding Top 7 -> desce 3,5). Centralizar no retângulo
    # inteiro deixava o texto alto. 2 = valor afinado com o usuário no Toolkit.
    CONTENT_DROP = 2.0
    # Container.ui @TitleStyle: Secondary (Lexend), 15 numa faixa de 38,
    # LetterSpacing 0, ShrinkTextToFit até 11. Nossa faixa tem 32 -> 13.
    TITLE_SIZE = 13.0

    def __init__(self, text, pattern=None, ornament=None, height=32.0, header=None, header_slice=0):
        self.has_strip = bool(header and ornament)
        super().__init__(style=Style(height=None if self.has_strip else height))
        self.text, self.pattern, self.ornament = text, pattern, ornament
        self.header, self.header_slice, self.band_h = header, header_slice, height

    def _ornament_size(self, width):
        w = min(self.ORNAMENT_MAX_W, width * 0.62)
        return w, w * self.ORNAMENT_RATIO

    def _strip(self, width):
        return self._ornament_size(width)[1] * self.ORNAMENT_BAR if self.has_strip else 0.0

    def _extent(self, f, width):
        h = self.band_h + self._strip(width)
        return (h, h, h)

    def measure(self, f, max_w):
        return (max_w, self.extent(f, max_w)[1])

    def draw(self, f):
        r, rect = f.renderer, self.rect
        strip = self._strip(rect.w)
        band = Rect(rect.x, rect.y, rect.w, rect.h - strip)
        drew_header = False
        if self.header:
            # PNG do jogo tem 76 px de altura (@2x); pontas na mesma proporção.
            k = band.h / 76.0
            drew_header = r.nine_slice(band, self.header, (self.header_slice, 0, self.header_slice, 0), scale=k)
        if not drew_header:
            r.rect(band, C.title_band)
            if self.pattern:
                r.image(Rect(band.x, band.y, band.h * 3, band.h), self.pattern, fit="stretch",
                        tint=C.title_pattern)
            r.rect(Rect(band.x, band.y, band.w, 1), C.title_line)
        text_rect = band.inset(0, self.CONTENT_DROP * 2, 0, 0) if drew_header else band
        side = band.h * 100.0 / 76.0 if drew_header else 8.0      # não escrever sobre as runas das pontas
        if drew_header:
            size, tracking = fit_text(r, self.text, band.w - 2 * side, self.TITLE_SIZE, "Title", 0.0, min_size=11.0)
        else:      # faixa provisória: o visual de antes
            size, tracking = fit_text(r, self.text, band.w - 2 * side, 12.0, "Bold", 1.1)
        r.text(text_rect, self.text, C.title_text, size=size, weight="Title" if drew_header else "Bold",
               align="CENTER", tracking=tracking)
        if not self.ornament:
            return
        if strip:
            # ContainerDecorationTop: topo do PNG no topo da faixinha; a metade
            # transparente desce por cima da faixa do título (desenhada antes).
            w, h = self._ornament_size(rect.w)
            r.image(Rect(rect.x + (rect.w - w) / 2, rect.top - h, w, h), self.ornament, fit="stretch")
        else:
            r.image(Rect(rect.x + rect.w / 2 - 20, rect.top - 6, 40, 16), self.ornament, fit="stretch")


class FrameOrnament(Widget):
    """Ornamento de baixo da janela (ContainerDecorationBottom): faixa de 6
    abaixo da moldura, com a imagem de 11 subindo 5 por cima da borda --
    igual ao Anchor (Height 11, Bottom -6) do @DecoratedContainer."""

    def __init__(self, path):
        super().__init__(style=Style(height=6.0))
        self.path = path

    def draw(self, f):
        rect = self.rect
        w = min(236.0, rect.w * 0.62)
        h = w * 22.0 / 472.0
        f.renderer.image(Rect(rect.x + (rect.w - w) / 2, rect.top + 5 - h, w, h), self.path, fit="stretch")


class NavIcon(Widget):
    """Ícone das colunas da esquerda (Categoria / Sub-categoria).

    Ícone REAL do jogo: troca de PNG quando selecionado (par normal/
    "Selected" lido da pasta Hytale, igual à UI clássica). O brilho dourado
    atrás e o ">" do protótipo continuam por cima. Hover: o tile clareia
    (o ícone do jogo já tem cor própria -- não é tingido)."""
    interactive = True

    def __init__(self, key, icon, icon_selected, selected, on_click, tooltip=None, size=40.0, enabled=True):
        super().__init__(key, Style(height=size + 6), tooltip)
        self.icon, self.icon_selected = icon, icon_selected
        self.selected, self.callback, self.size, self.enabled = selected, on_click, size, enabled

    def draw(self, f):
        r = f.renderer
        s = self.size
        tile = Rect(self.rect.x + (self.rect.w - s) / 2, self.rect.y + (self.rect.h - s) / 2, s, s)
        hover = f.animate(self.key + ".hover", 1.0 if (f.hover == self.key and self.enabled) else 0.0, 0.12)
        sel = f.animate(self.key + ".sel", 1.0 if self.selected else 0.0, 0.2)
        r.rect(tile, mix(C.nav_tile, C.button_hover, hover * (1.0 - sel)), radius=4)
        if sel > 0.01:                                   # brilho dourado atrás do ícone
            r.shadow(tile.expand(-6), 10, C.gold[:3] + (0.30 * sel,), blur=14, dy=0)
        path = self.icon_selected if self.selected else self.icon
        opacity = 1.0 if self.enabled else 0.4
        if not r.image(tile.expand(-3), path, fit="contain", opacity=opacity):
            r.icon(tile.expand(-12), "dot", C.nav_icon)  # ainda carregando
        if sel > 0.01:
            chevron = Rect(tile.x - 13, tile.y + s / 2 - 6, 10, 12)
            r.icon(chevron, "chevron", C.gold[:3] + (sel,))

    def on_click(self, f, x, y):
        if self.enabled:
            self.callback(f)


class ItemTile(Widget):
    """Célula da grade: miniatura, hover, borda dourada e selo ✓ quando escolhida."""
    interactive = True

    def __init__(self, key, thumb, selected, on_click, none=False, tooltip=None, name="",
                 none_icon=None, badge_icon=None):
        super().__init__(key, None, tooltip)
        self.thumb, self.selected, self.callback, self.none = thumb, selected, on_click, none
        self.name, self.none_icon, self.badge_icon = name, none_icon, badge_icon

    def draw(self, f):
        r, rect = f.renderer, self.rect
        hover = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.1)
        r.rect(rect, mix(C.tile, C.tile_hover_bg, hover), radius=3)
        if self.none:
            size = min(rect.w, rect.h) * 0.55
            box = Rect(rect.x + (rect.w - size) / 2, rect.y + (rect.h - size) / 2, size, size)
            if not (self.none_icon and r.image(box, self.none_icon, fit="contain")):
                r.icon(box.expand(-size * 0.12), "x", C.x_icon)
        elif not (self.thumb and r.image(rect, self.thumb, fit="contain", radius=3)):
            # Miniatura ainda não gerada (ou carregando): o nome no lugar.
            # Gerar: rodapé > Settings > Generate Thumbnails.
            r.text(rect.inset(6, 0, 6, 0), self.name, C.text_dim, size=10, align="CENTER")
        if hover > 0.01 and not self.selected:
            r.rect(rect, (0, 0, 0, 0), radius=3, border=C.tile_hover[:3] + (hover,), border_width=1)
        if self.selected:
            r.rect(rect.expand(1), (0, 0, 0, 0), radius=4, border=C.gold_bright, border_width=2)
            badge = Rect(rect.right - 27, rect.y + 6, 22, 22)
            # Selo "equipado" do jogo (EquippedIcon); sem ele, o procedural.
            if not (self.badge_icon and r.image(badge.expand(1), self.badge_icon, fit="contain")):
                r.rect(badge, C.check, radius=11)
                r.icon(badge.expand(-5), "check", C.check_mark)

    def on_click(self, f, x, y):
        self.callback(f)


class Swatch(Widget):
    """Bolinha de cor. Selecionada: anel dourado com respiro."""
    interactive = True

    def __init__(self, key, color, selected, on_click, tooltip=None):
        super().__init__(key, None, tooltip)
        self.color, self.selected, self.callback = color, selected, on_click

    def draw(self, f):
        r, rect = f.renderer, self.rect
        hover = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.1)
        radius = min(rect.w, rect.h) / 2
        r.rect(rect, self.color, radius=radius)
        if self.selected:
            ring = rect.expand(3.5)
            r.rect(ring, (0, 0, 0, 0), radius=radius + 3.5, border=C.gold, border_width=2)
        elif hover > 0.01:
            ring = rect.expand(2.5)
            r.rect(ring, (0, 0, 0, 0), radius=radius + 2.5, border=(1, 1, 1, 0.35 * hover), border_width=1.5)

    def on_click(self, f, x, y):
        self.callback(f)


class SquareButton(Widget):
    """Botãozinho quadrado com ícone procedural (cadeado...). Com `images`
    ({"on", "off", "off_hover"} -> PNG do jogo que JÁ é o botão inteiro,
    ex. os cadeados de Randomization), desenha o PNG do estado no lugar do
    fundo + ícone; caminho vazio/faltando cai no procedural."""
    interactive = True

    def __init__(self, key, icon, on_click, active=False, tooltip=None, size=22.0, images=None):
        super().__init__(key, Style(width=size, height=size), tooltip)
        self.icon, self.callback, self.active, self.images = icon, on_click, active, images

    def draw(self, f):
        r, rect = f.renderer, self.rect
        hover = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.1)
        if self.images:
            state = "on" if self.active else ("off_hover" if hover > 0.5 else "off")
            path = self.images.get(state) or self.images.get("off" if state == "off_hover" else state)
            if path and r.image(rect, path, fit="contain"):
                return
        r.rect(rect, mix(C.button, C.nav_tile, hover), radius=3)
        color = C.gold if self.active else mix(C.button_icon, C.nav_icon_hover, hover)
        r.icon(rect.expand(-4), self.icon, color)

    def on_click(self, f, x, y):
        self.callback(f)


class LinkButton(Widget):
    """Corrente de "ligar cor" com os ícones REAIS do jogo
    (MatchHairColorsIconOn / OffHovered, os mesmos da UI clássica).
    Sem o PNG (ainda carregando), cai pro ícone procedural "link"."""
    interactive = True

    def __init__(self, key, linked, images, on_click, tooltip=None, size=22.0):
        super().__init__(key, Style(width=size, height=size), tooltip)
        self.linked, self.images, self.callback = linked, images, on_click

    def draw(self, f):
        r, rect = f.renderer, self.rect
        hover = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.1)
        r.rect(rect, mix(C.button, C.nav_tile, hover), radius=3)
        path = self.images.get(self.linked)
        if not (path and r.image(rect.expand(-2), str(path), fit="contain")):
            r.icon(rect.expand(-4), "link", C.gold if self.linked else C.button_icon)

    def on_click(self, f, x, y):
        self.callback(f)


class Breadcrumb(Widget):
    """ "HEAD ▸ HAIRCUTS" em caixa alta com o triângulo dourado."""

    def __init__(self, parts, size=15.0):
        super().__init__(style=Style(height=24, flex=1))   # ocupa o que sobra na linha
        self.parts, self.size = [p.upper() for p in parts], size

    def measure(self, f, max_w):
        return (max_w, 24.0)

    def draw(self, f):
        r, rect = f.renderer, self.rect
        size = self.size
        seps = 22.0 * (len(self.parts) - 1)
        # Nome longo ("GENERAL > BODY CHARACTERISTICS") em painel estreito:
        # diminui a fonte (até 11) antes de o último pedaço ser cortado com "…".
        while size > 11.0 and sum(r.text_width(p, size, "Title") for p in self.parts) + seps > rect.w:
            size -= 0.5
        x = rect.x
        for i, part in enumerate(self.parts):
            if i:
                r.icon(Rect(x + 6, rect.y + (rect.h - 10) / 2, 10, 10), "caret", C.gold)
                x += 22
            w = r.text_width(part, size, "Title")
            r.text(Rect(x, rect.y, min(w + 2, rect.right - x), rect.h), part, C.text,
                   size=size, weight="Title")
            x += w


class SectionTitle(Widget):
    """Título de bloco ("COLOR", "BACKGROUND", "VARIANT") -- caixa alta."""

    def __init__(self, text, size=14.0):
        super().__init__(style=Style(height=24, flex=1))
        self.text, self.size = text.upper(), size

    def measure(self, f, max_w):
        return (max_w, 24.0)

    def draw(self, f):
        size, _ = fit_text(f.renderer, self.text, self.rect.w, self.size, "Title", min_size=11.0)
        f.renderer.text(self.rect, self.text, C.text, size=size, weight="Title")


class Chip(Widget):
    """Botão de texto compacto (variantes: Left/Right...). Selecionado: dourado."""
    interactive = True

    def __init__(self, key, text, selected, on_click, tooltip=None):
        super().__init__(key, Style(height=CONTROL_H), tooltip)
        self.text, self.selected, self.callback = text, selected, on_click

    def measure(self, f, max_w):
        return (min(max_w, f.renderer.text_width(self.text, 12, "Medium") + 22), CONTROL_H)

    def draw(self, f):
        r, rect = f.renderer, self.rect
        hover = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.1)
        sel = f.animate(self.key + ".sel", 1.0 if self.selected else 0.0, 0.18)
        r.rect(rect, mix(mix(C.button, C.button_hover, hover), C.nav_tile, sel), radius=4,
               border=mix(C.button_hover, C.gold, sel), border_width=1)
        r.text(rect, self.text, mix(C.text, C.gold, sel), size=12, weight="Medium", align="CENTER")

    def on_click(self, f, x, y):
        self.callback(f)


class TextButton(Widget):
    """Botão com ícone procedural + texto (estados vazios, rodapé)."""
    interactive = True

    def __init__(self, key, text, on_click, icon=None, enabled=True, primary=False, selected=False,
                 tooltip=None, style=None):
        super().__init__(key, style or Style(height=30), tooltip)
        self.text, self.callback, self.icon = text, on_click, icon
        self.enabled, self.primary, self.selected = enabled, primary, selected

    def measure(self, f, max_w):
        w = f.renderer.text_width(self.text, 12, "Medium") + 26 + (20 if self.icon else 0)
        return (min(max_w, w), self.style.height or 30)

    def draw(self, f):
        r, rect = f.renderer, self.rect
        hover = f.animate(self.key + ".hover", 1.0 if (f.hover == self.key and self.enabled) else 0.0, 0.1)
        sel = f.animate(self.key + ".sel", 1.0 if self.selected else 0.0, 0.18)
        base = C.nav_tile if self.primary else C.button
        r.rect(rect, mix(mix(base, C.button_hover, hover), C.nav_tile, sel), radius=4,
               border=mix(C.gold[:3] + (0.55 if self.primary else 0.0,), C.gold, sel), border_width=1)
        fg = C.gold if (self.primary or self.selected) else C.text
        if not self.enabled:
            fg = C.placeholder
        if not self.text:
            # Só ícone: centro EXATO (a margem mínima e o respiro de 6 px
            # depois do ícone são para quando há texto -- item 62).
            if self.icon:
                r.icon(Rect(rect.x + (rect.w - 14) / 2, rect.y + (rect.h - 14) / 2, 14, 14), self.icon, fg)
            return
        # Encaixe (ShrinkTextToFit do jogo): encolhe até 10; se nem assim
        # couber com o ícone, o ícone sai antes de o texto ganhar "…".
        icon = self.icon
        room = rect.w - 14 - (20 if icon else 0)
        size, _ = fit_text(r, self.text, room, 12.0, "Medium", min_size=10.0)
        if icon and r.text_width(self.text, size, "Medium") > room:
            icon, room = None, rect.w - 14
            size, _ = fit_text(r, self.text, room, 12.0, "Medium", min_size=10.0)
        tw = r.text_width(self.text, size, "Medium")
        total = tw + (20 if icon else 0)
        x = rect.x + max(8.0, (rect.w - total) / 2)
        if icon:
            r.icon(Rect(x, rect.y + (rect.h - 14) / 2, 14, 14), icon, fg)
            x += 20
        r.text(Rect(x, rect.y, rect.right - x - 6, rect.h), self.text, fg, size=size, weight="Medium")

    def on_click(self, f, x, y):
        if self.enabled and self.callback:
            self.callback(f)


class EmptyState(Widget):
    """Mensagem centralizada (sem Assets / sem Armature / carregando)."""
    fills = True           # mede max_w (ver framework/core._row_flex)

    def __init__(self, title, detail="", icon="info", height=110.0):
        super().__init__(style=Style(height=height))
        self.title, self.detail, self.icon = title, detail, icon

    def draw(self, f):
        r, rect = f.renderer, self.rect
        cy = rect.y + rect.h * 0.62
        r.icon(Rect(rect.x + rect.w / 2 - 12, cy, 24, 24), self.icon, C.text_dim)
        r.text(Rect(rect.x, cy - 30, rect.w, 22), self.title, C.text, size=14, weight="Bold", align="CENTER")
        if self.detail:
            r.text(Rect(rect.x + 8, cy - 52, rect.w - 16, 18), self.detail, C.text_dim, size=11, align="CENTER")


# --------------------------------------------------------------------------
# Dropdown inline (adaptado do Hyblend Toolkit, cores do jogo)
# --------------------------------------------------------------------------

class DropdownHeader(Widget):
    """O campo fechado de um dropdown: valor atual + chevron."""
    fills = True
    interactive = True

    def __init__(self, key, text, on_click, is_open=False, tooltip=None, placeholder=False, style=None):
        super().__init__(key, style or Style(height=CONTROL_H, flex=1), tooltip)
        self.text, self.callback, self.is_open, self.placeholder = text, on_click, is_open, placeholder

    def measure(self, f, max_w):
        return (max_w, CONTROL_H)

    def draw(self, f):
        r, rect = f.renderer, self.rect
        h = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.12)
        o = f.animate(self.key + ".open", 1.0 if self.is_open else 0.0, 0.16)
        r.rect(rect, mix(C.search, C.button, h), radius=4, border=mix(C.button_hover, C.gold, o))
        fg = C.placeholder if self.placeholder else C.text
        r.text(Rect(rect.x + 9, rect.y, rect.w - 36, rect.h), self.text, fg, size=12)
        r.icon(Rect(rect.right - 20, rect.y + (rect.h - 11) / 2, 11, 11),
               "chevron_up" if self.is_open else "chevron_down", mix(C.text_dim, C.gold, o))

    def on_click(self, f, x, y):
        if self.callback:
            self.callback(f)


class OptionRow(Widget):
    """Uma opção dentro de um dropdown/menu inline."""
    interactive = True

    def __init__(self, key, text, on_click, icon=None, selected=False, enabled=True, tooltip=None):
        super().__init__(key, Style(height=24), tooltip)
        self.text, self.callback, self.icon = text, on_click, icon
        self.selected, self.enabled = selected, enabled

    def draw(self, f):
        r, rect = f.renderer, self.rect
        h = f.animate(self.key + ".hover", 1.0 if (f.hover == self.key and self.enabled) else 0.0, 0.1)
        r.rect(rect, mix(C.nav_tile[:3] + (0.0,), C.option_hover, h), radius=3)
        x = rect.x + 8
        fg = (C.gold if self.selected else C.option_text) if self.enabled else C.placeholder
        if self.icon:
            r.icon(Rect(x, rect.y + (rect.h - 13) / 2, 13, 13), self.icon, fg)
            x += 20
        r.text(Rect(x, rect.y, rect.right - x - 26, rect.h), self.text, fg, size=12)
        if self.selected:
            r.icon(Rect(rect.right - 20, rect.y + (rect.h - 11) / 2, 11, 11), "check", C.gold)

    def on_click(self, f, x, y):
        if self.enabled and self.callback:
            self.callback(f)


class _OptionList(Column):
    def __init__(self, children, key=None):
        super().__init__(children, key=key, style=Style(padding=(4, 4, 4, 4), gap=1, radius=4))

    def draw_box(self, f):
        f.renderer.shadow(self.rect, 4, (0, 0, 0, 0.35), blur=8, dy=-2)
        f.renderer.rect(self.rect, C.search, radius=4, border=C.button_hover)


def option_list(children, key=None):
    """Caixa que segura as opções abertas de um dropdown/menu."""
    return _OptionList([c for c in children if c is not None], key=key)


class FooterButton(TextButton):
    """Botão da barra do rodapé (abre/fecha a gaveta de opções)."""

    def __init__(self, key, text, icon, on_click, selected=False, enabled=True, tooltip=None):
        super().__init__(key, text, on_click, icon=icon, enabled=enabled, selected=selected,
                         tooltip=tooltip, style=Style(height=30, flex=1))


# --------------------------------------------------------------------------
# Tooltip do CC (balão próprio; runtime.register(tooltip=draw_tooltip))
# --------------------------------------------------------------------------

TOOLTIP_WIDTH, TOOLTIP_LINES, TOOLTIP_LINE_H = 300.0, 12, 15.0


def draw_tooltip(f, key, text, mouse, p):
    """Balão do tooltip do CC: o MESMO desenho de antes da troca de
    framework (era PanelHost._draw_tooltip do runtime antigo do CC). O
    runtime unificado decide QUANDO mostrar (atraso, foco, arrasto); aqui
    só o desenho. `p` = retângulo do painel (a textura em cache só cobre ele)."""
    from .framework.core import wrap_text
    r, th = f.renderer, f.theme
    wrap = max(40.0, min(TOOLTIP_WIDTH, p.w - 8) - 20)
    lines = wrap_text(r, text, wrap, 11, "Medium", max_lines=TOOLTIP_LINES, break_words=True)
    w = max(r.text_width(line, 11, "Medium") for line in lines) + 20
    h = len(lines) * TOOLTIP_LINE_H + 11
    a = f.animate("tip." + key, 1.0, 0.16, initial=0.0)
    mx, my = mouse
    x = min(max(p.x + 4, mx + 10), p.right - w - 4)
    y = my - 10 - h if my - 10 - h > p.y + 4 else my + 18      # embaixo do mouse; senão em cima
    y = max(p.y + 4, min(y, p.top - h - 4))
    box = Rect(x, y - 4 * (1 - a), w, h)
    old, r.opacity = r.opacity, r.opacity * a
    r.shadow(box, 6, th.shadow, blur=8, dy=-2)
    r.rect(box, th.surface_raised, radius=6, border=th.border)
    top = box.top - 5.5
    for line in lines:
        r.text(Rect(box.x + 10, top - TOOLTIP_LINE_H, w - 20, TOOLTIP_LINE_H), line, th.text,
               size=11, weight="Medium", truncate=False)
        top -= TOOLTIP_LINE_H
    r.opacity = old
