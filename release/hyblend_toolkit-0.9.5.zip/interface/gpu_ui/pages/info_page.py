"""Aba Info -- créditos e links (HYTALE_PT_main._draw_info). URLs e
nome do autor vêm das MESMAS constantes do painel clássico; os logos são
os MESMOS PNGs de assets/icons/ que o painel clássico usa (lidos do disco
pelo renderer, decodificados no timer dele -- nada de bpy/preview aqui)."""

import os
from functools import lru_cache

from ..framework.core import Column, Label, Row, Style
from ..widgets import Paragraph, card
from .. import classic_module

# interface/gpu_ui/pages/ -> raiz do addon -> assets/icons/
_ICON_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))))), "assets", "icons")


@lru_cache(maxsize=None)
def _brand(key):
    """Caminho do logo (assets/icons/<key>.png) ou None -> ícone genérico.
    Cacheado: os logos vêm no zip do addon, não mudam durante a sessão."""
    path = os.path.join(_ICON_DIR, key + ".png")
    return path if os.path.isfile(path) else None


def build(ui):
    classic = classic_module()
    t = ui.t

    hytale = card(
        Row(Label(t("panel.info_credits_hytale_label"), size=12, weight="SemiBold", style=Style(flex=1)),
            ui.url_button("info.hytale", classic.HYBLEND_HYTALE_URL, "Hytale", icon="globe",
                          image=_brand("hytale")),
            style=Style(gap=6, align="center")),
        Paragraph(t("panel.info_credits_hytale_disclaimer"), size=11),
    )
    links = card(
        Row(ui.url_button("info.nexus", classic.HYBLEND_NEXUSMODS_URL, "Nexus Mods", icon="globe",
                          image=_brand("nexus_mods"), flex=1),
            ui.url_button("info.github", classic.HYBLEND_GITHUB_URL, "GitHub", icon="link",
                          image=_brand("github"), flex=1),
            style=Style(gap=6)),
        title=t("panel.info_links_label"), icon="link",
    )
    links_row = Row(
        Label(classic.HYBLEND_AUTHOR_NAME, size=13, weight="SemiBold", style=Style(flex=1)),
        *(ui.url_button("info." + brand, url, icon=icon, image=_brand(brand))
          for url, brand, _fallback, icon in classic.HYBLEND_SOCIAL_LINKS),
        style=Style(gap=4, align="center"))
    # "Created by:" / estúdio / autor + redes (as duas linhas de nome juntas)
    credits = card(
        Label(t("panel.info_credits_created_by_label"), size=11, color=ui.theme.text_muted, style=Style(height=16)),
        Column(Label(classic.HYBLEND_STUDIO_NAME, size=13, weight="SemiBold", style=Style(height=20)),
               links_row, style=Style(gap=2)),
        title=t("panel.info_credits_label"), icon="user",
    )
    # Reabre a janela de boas-vindas (mesmo operador do painel clássico).
    welcome_button = ui.op("info.welcome", "hyblend.welcome", t("panel.btn_welcome"), icon="info", height=34)
    return [welcome_button, hytale, links, credits]
