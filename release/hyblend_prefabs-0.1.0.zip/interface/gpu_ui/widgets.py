"""Widgets do Hyblend em cima do framework (framework/core.py).

Continua "Python puro + renderer": nada aqui importa `bpy`. Quem liga um
widget a uma property/operador do Blender é bind.py -- os widgets só
recebem valores e callbacks.

Tamanhos em unidades lógicas (antes da escala de DPI). Alturas padrão:
controles 28, linhas de lista 26, botões grandes 34-38.
"""

import ast
import operator as _op

from .framework.core import (Button, Column, Icon, Label, Rect, Row, Style, Widget, fit_text, has_skin,
                             heading, pad, skin, wrap_text)
from .framework.motion import mix

CONTROL_H = 28.0
ROW_H = 26.0


# --------------------------------------------------------------------------
# Texto
# --------------------------------------------------------------------------

class Paragraph(Widget):
    """Texto com quebra de linha automática (layout.label() nunca quebra)."""

    def __init__(self, text, size=11.0, color=None, weight="Regular", line_height=None,
                 key=None, style=None, tooltip=None):
        super().__init__(key, style, tooltip)
        self.text, self.size, self.color, self.weight = str(text), size, color, weight
        self.line_h = line_height or round(size * 1.45)
        self._lines_for = None

    def _lines(self, f, width):
        if self._lines_for != width:
            self._lines_for = width
            self._cached = wrap_text(f.renderer, self.text, max(10.0, width), self.size, self.weight)
        return self._cached

    def _extent(self, f, width):
        l, t, r, b = self.style.padding
        h = len(self._lines(f, width - l - r)) * self.line_h + t + b
        return (h, h, h)

    def measure(self, f, max_w):
        return (max_w, self.extent(f, max_w)[1])

    def draw(self, f):
        self.draw_box(f)
        inner = self.rect.inset(*self.style.padding)
        top = inner.top
        for line in self._lines(f, inner.w):
            f.renderer.text(Rect(inner.x, top - self.line_h, inner.w, self.line_h), line,
                            self.color or f.theme.text_muted, size=self.size, weight=self.weight)
            top -= self.line_h


class Hint(Widget):
    """Ícone + texto quebrado, com fundo opcional por tom
    ("muted" | "info" | "warning" | "danger")."""

    ICON = 14.0

    def __init__(self, text, icon="info", tone="muted", key=None, style=None):
        super().__init__(key, style)
        self.text, self.icon, self.tone = str(text), icon, tone
        self._lines_for = None

    def _padding(self):
        return (8.0, 6.0, 8.0, 6.0) if self.tone in {"warning", "danger", "info"} else (2.0, 2.0, 2.0, 2.0)

    def _lines(self, f, width):
        l, _, r, _ = self._padding()
        text_w = max(10.0, width - l - r - self.ICON - 8)
        if self._lines_for != text_w:
            self._lines_for = text_w
            self._cached = wrap_text(f.renderer, self.text, text_w, 11.0)
        return self._cached

    def _extent(self, f, width):
        _, t, _, b = self._padding()
        h = max(self.ICON, len(self._lines(f, width)) * 16.0) + t + b
        return (h, h, h)

    def measure(self, f, max_w):
        return (max_w, self.extent(f, max_w)[1])

    def _colors(self, th):
        if self.tone == "warning":
            return th.warning_soft, th.warning, th.text
        if self.tone == "danger":
            return th.danger_soft, th.danger, th.text
        if self.tone == "info":
            return th.accent_soft, th.accent, th.text
        return None, th.text_muted, th.text_muted

    def draw(self, f):
        th, r = f.theme, f.renderer
        background, icon_color, text_color = self._colors(th)
        if background:
            r.rect(self.rect, background, radius=8 * th.radius_scale)
        l, t, _, _ = self._padding()
        top = self.rect.top - t
        r.icon(Rect(self.rect.x + l, top - 15, self.ICON, self.ICON), self.icon, icon_color)
        x = self.rect.x + l + self.ICON + 8
        width = self.rect.right - x - self._padding()[2]
        for line in self._lines(f, self.rect.w):
            r.text(Rect(x, top - 16, width, 16), line, text_color, size=11)
            top -= 16


class Heading(Widget):
    """Título de cartão no estilo do tema (Hytale: caixa alta, Lexend).
    Sem a setinha dourada do jogo depois do texto: parecia botão de
    expandir/recolher (retorno do usuário)."""

    def __init__(self, text, color=None, size=12.0):
        super().__init__(style=Style(flex=1, height=20))
        self.text, self.color, self.size = str(text), color, size

    def measure(self, f, max_w):
        return (max_w, 20.0)

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        text, weight, tracking = heading(th, self.text)
        size = self.size - (0.5 if th.heading_upper else 0.0)
        size, tracking = fit_text(r, text, rect.w, size, weight, tracking)
        r.text(rect, text, self.color or th.text, size=size, weight=weight, tracking=tracking)


def section_title(text, icon=None, right=None, color=None):
    """Título de um cartão: ícone (acento) + título do tema (+ algo à direita)."""
    parts = []
    if icon:
        parts.append(_AccentIcon(icon, color))
    parts.append(Heading(text, color=color))
    if right is not None:
        parts.append(right)
    return Row(parts, style=Style(gap=7, align="center", height=20))


class _AccentIcon(Icon):
    """Ícone do título: no acento do tema, a menos que venha cor própria."""

    def __init__(self, name, color=None):
        super().__init__(name, size=14, color=color, style=Style(width=16, height=18))

    def draw(self, f):
        if self.color is None and f.theme.heading_upper:
            self.color = f.theme.accent
        super().draw(f)


def card(*children, title=None, icon=None, right=None, key=None, tone=None, gap=8.0):
    """"box()" do painel clássico: superfície elevada com borda."""
    items = [c for c in children if c is not None]
    if len(items) == 1 and isinstance(items[0], (list, tuple)):
        items = [c for c in items[0] if c is not None]
    if title:
        items.insert(0, section_title(title, icon, right))
    return _Card(items, key=key, tone=tone, gap=gap)


class _Card(Column):
    def __init__(self, items, key=None, tone=None, gap=8.0):
        super().__init__(items, key=key, style=Style(padding=pad(10), gap=gap, radius=10))
        self.tone = tone

    def draw(self, f):
        # Cartão dentro de cartão = fundo "afundado" (ContainerPanelPatch),
        # como os sub-blocos do jogo; a profundidade vale só neste desenho.
        depth = getattr(f, "_card_depth", 0)
        self._nested = depth > 0
        f._card_depth = depth + 1
        try:
            super().draw(f)
        finally:
            f._card_depth = depth

    def draw_box(self, f):
        th = f.theme
        if getattr(self, "_nested", False) and skin(f, self.rect, "inset"):
            if self.tone in {"warning", "accent"}:
                f.renderer.rect(self.rect.expand(-1), (0, 0, 0, 0), radius=3,
                                border=(th.warning if self.tone == "warning" else th.accent)[:3] + (0.5,))
            return
        border = th.border
        if self.tone == "warning":
            border = th.warning[:3] + (0.35,)
        elif self.tone == "accent":
            border = th.accent[:3] + (0.35,)
        radius = 10 * th.radius_scale
        if skin(f, self.rect, "card"):
            # arte do jogo (fundo translúcido): só o contorno do tom por cima
            if self.tone in {"warning", "accent"}:
                f.renderer.rect(self.rect.expand(-1), (0, 0, 0, 0), radius=4, border=border[:3] + (0.6,),
                                border_width=1.5)
            return
        f.renderer.rect(self.rect, th.surface, radius=radius, border=border)


def labeled(label, *controls, split=0.38, tooltip=None, muted=True):
    """Rótulo à esquerda + controle(s) à direita, proporção fixa (o
    `split(factor=...)` do painel clássico)."""
    controls = [c for c in controls if c is not None]
    if len(controls) == 1:
        right = controls[0]
        right_style = right.style
        # o controle ocupa o resto: força flex no próprio controle
        right.style = _with(right_style, flex=100 * (1 - split), width=None)
    else:
        # O primeiro controle (campo de texto/dropdown) fica com a sobra;
        # os outros (conta-gotas, caixinhas) mantêm o tamanho próprio --
        # senão o campo mede a largura toda e empurra os botões pra fora.
        first = controls[0]
        if first.style.width is None and not first.style.flex:
            first.style = _with(first.style, flex=1.0)
        right = Row(controls, style=Style(flex=100 * (1 - split), gap=4, align="center"))
    text = _MutedLabel(label, size=11.5, color=None, tooltip=tooltip,
                       style=Style(flex=100 * split, padding=(2, 0, 6, 0), height=CONTROL_H))
    text.muted = muted
    # align="start" + sem altura fixa: se o controle crescer (dropdown
    # aberto, sugestões), o rótulo fica alinhado com a primeira linha.
    return Row(text, right, style=Style(gap=0, align="start"))


class _MutedLabel(Label):
    """Rótulo de linha (labeled): cor "muted" do tema."""
    muted = True

    def draw(self, f):
        if self.muted and self.color is None:
            self.color = f.theme.text_muted
        super().draw(f)


def _with(style, **changes):
    values = {name: getattr(style, name) for name in style.__dataclass_fields__}
    values.update(changes)
    return Style(**values)


# --------------------------------------------------------------------------
# Botões especiais
# --------------------------------------------------------------------------

def icon_button(key, icon, on_click, tooltip=None, enabled=True, variant="secondary", selected=False,
                size=CONTROL_H):
    return Button(key, "", on_click, icon=icon, tooltip=tooltip, enabled=enabled, variant=variant,
                  selected=selected, style=Style(width=size, height=size))


class SwipeButton(Button):
    """Botão com arrasto-alternar: o valor é aplicado já no APERTO, e todo
    botão do mesmo `swipe_group` que o mouse atravessar (segurando)
    recebe o MESMO valor -- como arrastar sobre checkboxes no Blender.

    swipe_value  = o que este botão aplicaria sozinho (ex.: "IK", ou o
                   inverso da visibilidade atual);
    swipe_id     = identidade do ALVO (dois botões do mesmo alvo -- FK e IK
                   da mesma cadeia -- contam uma vez só no arrasto);
    swipe_apply(f, valor) aplica; swipe_finish(f, n) roda ao soltar.
    on_insert_key(f) opcional = tecla I com o mouse em cima."""

    def __init__(self, key, text, *, swipe_group, swipe_id, swipe_value, swipe_apply,
                 swipe_finish=None, on_insert_key=None, **kw):
        super().__init__(key, text, None, **kw)
        self.swipe_group, self.swipe_id, self.swipe_value = swipe_group, swipe_id, swipe_value
        self.swipe_apply, self.swipe_finish = swipe_apply, swipe_finish
        if on_insert_key is not None:
            self.on_insert_key = on_insert_key

    def on_click(self, f, x, y):
        pass            # o runtime aplica no aperto (ver PanelHost._begin_swipe)


class CheckBox(Widget):
    """Caixinha de marcar (prop(..., text="") de um Bool)."""
    interactive = True

    def __init__(self, key, value, on_change, tooltip=None, enabled=True, style=None):
        super().__init__(key, style or Style(width=22, height=CONTROL_H), tooltip)
        self.value, self.callback, self.enabled = bool(value), on_change, enabled

    def measure(self, f, max_w):
        return (22.0, CONTROL_H)

    def draw(self, f):
        th, r = f.theme, f.renderer
        h = f.animate(self.key + ".hover", 1.0 if f.hover == self.key and self.enabled else 0.0, 0.12)
        t = f.animate(self.key + ".value", 1.0 if self.value else 0.0, 0.16)
        box = Rect(self.rect.x + (self.rect.w - 16) / 2, self.rect.y + (self.rect.h - 16) / 2, 16, 16)
        if skin(f, box.expand(1), "checkbox"):
            if t > 0.02:
                skin(f, box.inset(2, 2, 2, 2), "checkmark", tint=th.accent, opacity=t)
            if not self.enabled:
                r.rect(box, th.canvas[:3] + (0.45,), radius=3)
            elif h > 0.01:
                r.rect(box.expand(1), (0, 0, 0, 0), radius=3, border=th.accent[:3] + (0.5 * h,))
            return
        off = mix(th.input, th.surface_hover, h)
        r.rect(box, mix(off, th.accent, t), radius=4,
               border=mix(mix(th.border, (1, 1, 1, 0.25), h), th.accent, t))
        if t > 0.02:
            old, r.opacity = r.opacity, r.opacity * t
            r.icon(box.inset(2, 2, 2, 2), "check", th.accent_text)
            r.opacity = old
        if not self.enabled:
            r.rect(box, th.canvas[:3] + (0.45,), radius=4)

    def on_click(self, f, x, y):
        if self.enabled:
            self.callback(f, not self.value)


class SectionHeader(Widget):
    """Cabeçalho de seção recolhível (o prop(..., emboss=False) com
    TRIA_RIGHT/TRIA_DOWN do painel clássico).

    Hyblend Prefabs: `plain=True` desenha o título como texto comum (sem a
    caixa alta/Lexend do tema) -- nomes de prefab/arquivo ficam ilegíveis em
    caixa alta; `color` pinta ícone e título (ex.: aviso de problema)."""
    interactive = True

    def __init__(self, key, title, is_open, on_toggle, icon=None, right=None, tooltip=None, plain=False,
                 color=None):
        super().__init__(key, Style(height=CONTROL_H), tooltip, children=[right] if right else [])
        self.title, self.is_open, self.callback, self.icon = title, bool(is_open), on_toggle, icon
        self.right = right
        self.plain, self.color = plain, color

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        if self.right is not None:
            w = min(rect.w * 0.5, self.right.measure(f, rect.w * 0.5)[0])
            self.right.layout(f, Rect(rect.right - w - 6, rect.y, w, rect.h), clip)

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        h = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.12)
        o = f.animate(self.key + ".open", 1.0 if self.is_open else 0.0, 0.18)
        r.rect(rect, mix(th.surface_hover[:3] + (0.0,), th.surface_hover, h * 0.7), radius=7 * th.radius_scale)
        chevron = Rect(rect.x + 6, rect.y + (rect.h - 12) / 2, 12, 12)
        # troca de chevron com crossfade (o renderer não gira ícones)
        old = r.opacity
        r.opacity = old * (1.0 - o)
        r.icon(chevron, "chevron_right", th.text_muted)
        r.opacity = old * o
        r.icon(chevron, "chevron_down", th.accent)
        r.opacity = old
        x = chevron.right + 6
        if self.icon:
            r.icon(Rect(x, rect.y + (rect.h - 14) / 2, 14, 14), self.icon,
                   self.color or mix(th.text_muted, th.text, o))
            x += 20
        right_w = (self.right.rect.w + 10) if self.right is not None else 0
        box = Rect(x, rect.y, rect.right - x - right_w - 4, rect.h)
        fg = self.color or mix(th.text_muted, th.text, max(o, h))
        if self.plain:
            r.text(box, self.title, fg, size=12, weight="SemiBold")
        else:
            title, weight, tracking = heading(th, self.title)
            size, tracking = fit_text(r, title, box.w, 10.5 if th.heading_upper else 12, weight, tracking,
                                      min_size=9.0)
            r.text(box, title, fg, size=size, weight=weight if th.heading_upper else "Medium", tracking=tracking)
        for child in self.children:
            child.draw(f)

    def hit(self, x, y):
        if self.right is not None and self.right.visible_at(x, y):
            found = self.right.hit(x, y)
            if found is not None:
                return found
        return super().hit(x, y) if self.visible_at(x, y) else None

    def on_click(self, f, x, y):
        self.callback(f, not self.is_open)


class OptionRow(Widget):
    """Uma opção dentro de um dropdown/menu inline."""
    interactive = True

    def __init__(self, key, text, on_click, icon=None, selected=False, enabled=True,
                 tooltip=None, keeps_focus=False, detail=None):
        super().__init__(key, Style(height=ROW_H), tooltip)
        self.text, self.callback, self.icon = text, on_click, icon
        self.selected, self.enabled, self.keeps_focus, self.detail = selected, enabled, keeps_focus, detail

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        h = f.animate(self.key + ".hover", 1.0 if f.hover == self.key and self.enabled else 0.0, 0.1)
        if has_skin("popup_item_hover"):
            if h > 0.01 or self.selected:
                skin(f, rect, "popup_item_hover", opacity=max(h, 0.6 if self.selected else 0.0))
        else:
            base = th.accent_soft if self.selected else th.surface_hover[:3] + (0.0,)
            r.rect(rect, mix(base, th.surface_hover, h), radius=6 * th.radius_scale)
        x = rect.x + 8
        fg = th.text if self.enabled else th.text_muted
        if self.icon:
            r.icon(Rect(x, rect.y + (rect.h - 14) / 2, 14, 14), self.icon,
                   th.accent if self.selected else th.text_muted)
            x += 21
        detail_w = 0.0
        if self.detail:
            detail_w = min(rect.w * 0.45, r.text_width(self.detail, 11) + 6)
            r.text(Rect(rect.right - detail_w - 8, rect.y, detail_w, rect.h), self.detail,
                   th.text_muted, size=11, align="RIGHT")
        right = rect.right - 8 - detail_w - (18 if self.selected else 0)
        r.text(Rect(x, rect.y, right - x, rect.h), self.text, fg, size=12)
        if self.selected:
            r.icon(Rect(rect.right - 22, rect.y + (rect.h - 12) / 2, 12, 12), "check", th.accent)

    def on_click(self, f, x, y):
        if self.enabled and self.callback:
            self.callback(f)


def option_list(children, key=None):
    """Caixa que segura as opções abertas de um dropdown/menu."""
    return _OptionList(children, key=key)


class _OptionList(Column):
    def __init__(self, children, key=None):
        super().__init__(children, key=key, style=Style(padding=pad(4), gap=1, radius=8))

    def draw_box(self, f):
        th = f.theme
        f.renderer.shadow(self.rect, 8 * th.radius_scale, th.shadow[:3] + (0.35,), blur=8, dy=-2)
        if not skin(f, self.rect, "dropdown_panel"):
            f.renderer.rect(self.rect, th.surface_raised, radius=8 * th.radius_scale, border=th.border)


class DropdownHeader(Widget):
    """O campo fechado de um dropdown: valor atual + chevron."""
    interactive = True
    fills = True

    def __init__(self, key, text, on_click, is_open=False, icon=None, enabled=True, tooltip=None,
                 placeholder=False, style=None):
        super().__init__(key, style or Style(height=CONTROL_H), tooltip)
        self.text, self.callback, self.is_open, self.icon = text, on_click, is_open, icon
        self.enabled, self.placeholder = enabled, placeholder

    def measure(self, f, max_w):
        return (max_w, CONTROL_H)

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        h = f.animate(self.key + ".hover", 1.0 if f.hover == self.key and self.enabled else 0.0, 0.12)
        o = f.animate(self.key + ".open", 1.0 if self.is_open else 0.0, 0.16)
        part = "dropdown_open" if self.is_open else ("dropdown_hover" if h > 0.5 else "dropdown")
        if not (self.enabled and skin(f, rect, part, fallback="dropdown")):
            border = mix(mix(th.border, (1, 1, 1, 0.18), h), th.accent, o)
            r.rect(rect, mix(th.surface_raised, th.surface_hover, h), radius=7 * th.radius_scale, border=border)
        x = rect.x + 9
        if self.icon:
            r.icon(Rect(x, rect.y + (rect.h - 14) / 2, 14, 14), self.icon, th.text_muted)
            x += 20
        fg = th.text_muted if (self.placeholder or not self.enabled) else th.text
        r.text(Rect(x, rect.y, rect.right - x - 26, rect.h), self.text, fg, size=12)
        r.icon(Rect(rect.right - 20, rect.y + (rect.h - 11) / 2, 11, 11),
               "chevron_up" if self.is_open else "chevron_down", mix(th.text_muted, th.accent, o))

    def on_click(self, f, x, y):
        if self.enabled and self.callback:
            self.callback(f)


# --------------------------------------------------------------------------
# Edição de texto (compartilhada por campo de texto e campo de número)
# --------------------------------------------------------------------------

class _TextEditing:
    """Buffer de edição guardado no estado do host (sobrevive à
    reconstrução da árvore): `<key>.edit` (texto), `<key>.caret`,
    `<key>.blink`. Quem herda implementa commit(f, texto) e opcionalmente
    `edit_changed(f, texto)`."""

    def edit_text(self, f):
        return f.state.get(self.key + ".edit", "")

    def begin_edit(self, f, text):
        f.state[self.key + ".edit"] = text
        f.state[self.key + ".caret"] = len(text)
        f.state[self.key + ".select_all"] = True
        f.state[self.key + ".blink"] = f.now
        f.state["_focus"] = self.key

    def _end_edit(self, f):
        for suffix in (".edit", ".caret", ".blink", ".select_all"):
            f.state.pop(self.key + suffix, None)
        if f.state.get("_focus") == self.key:
            f.state.pop("_focus", None)

    def _get(self, f):
        text = self.edit_text(f)
        caret = min(len(text), max(0, f.state.get(self.key + ".caret", len(text))))
        return text, caret

    def _set(self, f, text, caret):
        changed = text != self.edit_text(f)
        f.state[self.key + ".edit"] = text
        f.state[self.key + ".caret"] = caret
        f.state[self.key + ".blink"] = f.now
        f.state.pop(self.key + ".select_all", None)
        if changed:
            hook = getattr(self, "edit_changed", None)
            if hook is not None:
                hook(f, text)

    def on_blur(self, f):
        """Clique fora = confirma (igual ao Blender)."""
        if self.key + ".edit" in f.state:
            text = self.edit_text(f)
            self._end_edit(f)
            self.commit(f, text)

    def handle_key(self, f, ev, clipboard):
        text, caret = self._get(f)
        t = ev.type
        select_all = f.state.get(self.key + ".select_all")

        def word_left(i):
            while i > 0 and text[i - 1] == " ":
                i -= 1
            while i > 0 and text[i - 1] != " ":
                i -= 1
            return i

        def word_right(i):
            while i < len(text) and text[i] == " ":
                i += 1
            while i < len(text) and text[i] != " ":
                i += 1
            return i

        if t in {"RET", "NUMPAD_ENTER"}:
            self._end_edit(f)
            self.commit(f, text)
        elif t == "ESC":
            self._end_edit(f)
        elif t == "TAB":
            self._end_edit(f)
            self.commit(f, text)
        elif select_all and t in {"BACK_SPACE", "DEL"}:
            self._set(f, "", 0)
        elif t == "BACK_SPACE":
            start = word_left(caret) if ev.ctrl else max(0, caret - 1)
            self._set(f, text[:start] + text[caret:], start)
        elif t == "DEL":
            end = word_right(caret) if ev.ctrl else min(len(text), caret + 1)
            self._set(f, text[:caret] + text[end:], caret)
        elif t == "LEFT_ARROW":
            self._set(f, text, 0 if select_all else (word_left(caret) if ev.ctrl else max(0, caret - 1)))
        elif t == "RIGHT_ARROW":
            self._set(f, text, word_right(caret) if ev.ctrl else min(len(text), caret + 1))
        elif t == "HOME":
            self._set(f, text, 0)
        elif t == "END":
            self._set(f, text, len(text))
        elif ev.ctrl and t == "A":
            f.state[self.key + ".select_all"] = True
        elif ev.ctrl and t == "V":
            paste = clipboard.get().replace("\n", " ").replace("\r", "")
            if select_all:
                self._set(f, paste, len(paste))
            else:
                self._set(f, text[:caret] + paste + text[caret:], caret + len(paste))
        elif ev.ctrl and t == "C":
            clipboard.set(text)
        elif ev.unicode and not ev.ctrl and ev.unicode.isprintable():
            if select_all:
                self._set(f, ev.unicode, len(ev.unicode))
            else:
                self._set(f, text[:caret] + ev.unicode + text[caret:], caret + len(ev.unicode))
        else:
            return False
        return True

    def draw_editing(self, f, area, size=12.0):
        """Texto em edição + cursor (e realce de "selecionar tudo")."""
        th, r = f.theme, f.renderer
        text, caret = self._get(f)
        caret_x = r.text_width(text[:caret], size)
        scroll = max(0.0, caret_x - area.w + 2)
        r.push_clip(area)
        try:
            if f.state.get(self.key + ".select_all") and text:
                w = min(area.w, r.text_width(text, size) + 2)
                r.rect(Rect(area.x - 1, area.y + (area.h - 18) / 2, w, 18), th.accent_soft, radius=3)
            if text:
                full = r.text_width(text, size) + 4
                r.text(Rect(area.x - scroll, area.y, full, area.h), text, th.text, size=size, truncate=False)
            blink = (f.now - f.state.get(self.key + ".blink", f.now)) % 1.0 < 0.55
            if blink:
                r.rect(Rect(area.x - scroll + caret_x, area.y + (area.h - 14) / 2, 1.2, 14), th.accent)
        finally:
            r.pop_clip()


class TextInput(_TextEditing, Widget):
    """Campo de texto ligado a um valor externo: mostra `value`; clique
    edita; Enter/clique fora confirma (commit), Esc cancela."""
    interactive = True
    fills = True
    focusable = True

    def __init__(self, key, value, on_commit, placeholder="", icon=None, enabled=True,
                 tooltip=None, on_edit=None, style=None):
        super().__init__(key, style or Style(height=CONTROL_H), tooltip)
        self.value, self.callback, self.placeholder, self.icon = str(value or ""), on_commit, placeholder, icon
        self.enabled, self.on_edit = enabled, on_edit

    def measure(self, f, max_w):
        return (max_w, CONTROL_H)

    def _text_rect(self):
        left = 28.0 if self.icon else 9.0
        return self.rect.inset(left, 0, 8, 0)

    def edit_changed(self, f, text):
        if self.on_edit:
            self.on_edit(f, text)

    def commit(self, f, text):
        if text != self.value and self.callback:
            self.callback(f, text)

    def on_focus(self, f, x, y):
        if not self.enabled:
            f.state.pop("_focus", None)
            return
        if self.key + ".edit" not in f.state:
            self.begin_edit(f, self.value)
        else:   # já editando: clique posiciona o cursor
            text, caret = self._get(f)
            area = self._text_rect()
            local = x - area.x + max(0.0, f.renderer.text_width(text[:caret], 12) - area.w + 2)
            best = min(range(len(text) + 1), key=lambda i: abs(f.renderer.text_width(text[:i], 12) - local))
            self._set(f, text, best)

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        editing = f.focus == self.key and self.key + ".edit" in f.state
        ft = f.animate(self.key + ".focus", 1.0 if editing else 0.0, 0.16)
        h = f.animate(self.key + ".hover", 1.0 if f.hover == self.key and self.enabled else 0.0, 0.12)
        part = "input_edit" if editing else ("input_hover" if h > 0.5 else "input")
        if not skin(f, rect, part, fallback="input"):
            border = mix(mix(th.border, (1, 1, 1, 0.18), h), th.accent, ft)
            r.rect(rect, th.input, radius=7 * th.radius_scale, border=border, border_width=1.0 + 0.5 * ft)
        if self.icon:
            r.icon(Rect(rect.x + 8, rect.y + (rect.h - 13) / 2, 13, 13), self.icon,
                   mix(th.text_muted, th.accent, ft))
        area = self._text_rect()
        if editing:
            self.draw_editing(f, area)
        elif self.value:
            r.text(area, self.value, th.text if self.enabled else th.text_muted, size=12)
        else:
            r.text(area, self.placeholder, mix(th.text_muted, th.input, 0.35), size=12)


_SAFE_OPS = {ast.Add: _op.add, ast.Sub: _op.sub, ast.Mult: _op.mul, ast.Div: _op.truediv,
             ast.Pow: _op.pow, ast.USub: _op.neg, ast.UAdd: _op.pos, ast.Mod: _op.mod}


def safe_eval(text):
    """Expressão numérica simples ("2*3", "-1.5", "90/2"), sem eval()."""
    def walk(node):
        if isinstance(node, ast.Expression):
            return walk(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _SAFE_OPS:
            return _SAFE_OPS[type(node.op)](walk(node.left), walk(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in _SAFE_OPS:
            return _SAFE_OPS[type(node.op)](walk(node.operand))
        raise ValueError(text)
    return float(walk(ast.parse(text.replace(",", ".").replace("°", "").strip(), mode="eval")))


class NumberField(_TextEditing, Widget):
    """Campo numérico estilo Blender: arrastar muda o valor, as setinhas
    somam/subtraem um passo, clique sem arrastar digita (aceita contas).

    `value` já vem na unidade de exibição (graus, se for ângulo) --
    bind.py converte na ida e na volta."""
    interactive = True
    fills = True
    cursor = "MOVE_X"

    def __init__(self, key, value, on_change, label="", *, integer=False, step=1.0, precision=2,
                 lo=None, hi=None, suffix="", on_commit=None, enabled=True, tooltip=None, style=None):
        super().__init__(key, style or Style(height=CONTROL_H), tooltip)
        self.value, self.callback, self.label = value, on_change, label
        self.integer, self.step, self.precision = integer, step, precision
        self.lo, self.hi, self.suffix, self.on_commit, self.enabled = lo, hi, suffix, on_commit, enabled

    def measure(self, f, max_w):
        return (max_w, CONTROL_H)

    def _clamp(self, v):
        if self.lo is not None:
            v = max(self.lo, v)
        if self.hi is not None:
            v = min(self.hi, v)
        return int(round(v)) if self.integer else v

    def fmt(self, v=None):
        v = self.value if v is None else v
        if self.integer:
            return "%d%s" % (int(v), self.suffix)
        return ("%." + str(self.precision) + "f%s") % (v, self.suffix)

    def _arrows(self):
        r = self.rect
        return Rect(r.x, r.y, 18, r.h), Rect(r.right - 18, r.y, 18, r.h)

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        editing = f.focus == self.key and self.key + ".edit" in f.state
        dragging = f.state.get("_drag", {}).get("key") == self.key
        hot = f.hover == self.key and self.enabled
        h = f.animate(self.key + ".hover", 1.0 if (hot or dragging) else 0.0, 0.12)
        ft = f.animate(self.key + ".focus", 1.0 if editing else 0.0, 0.16)
        f.track_mouse(rect)
        part = "input_edit" if editing else ("input_hover" if h > 0.5 else "input")
        if not skin(f, rect, part, fallback="input"):
            border = mix(mix(th.border, (1, 1, 1, 0.18), h), th.accent, ft)
            r.rect(rect, mix(th.input, th.surface_raised, h * 0.8), radius=7 * th.radius_scale, border=border,
                   border_width=1.0 + 0.5 * ft)
        if editing:
            self.draw_editing(f, rect.inset(9, 0, 9, 0))
            return
        fg = th.text if self.enabled else th.text_muted
        left, right = self._arrows()
        if h > 0.01 and not dragging:
            mx, my = f.mouse
            old, r.opacity = r.opacity, r.opacity * h
            for arrow, name in ((left, "chevron_left"), (right, "chevron_right")):
                color = th.accent if arrow.contains(mx, my) else th.text_muted
                r.icon(Rect(arrow.x + 5, arrow.y + (arrow.h - 9) / 2, 9, 9), name, color)
            r.opacity = old
        value_text = self.fmt()
        inner = rect.inset(20, 0, 20, 0)
        if self.label:
            vw = r.text_width(value_text, 12, "Medium")
            r.text(Rect(inner.x, inner.y, inner.w - vw - 6, inner.h), self.label, th.text_muted, size=11.5)
            r.text(inner, value_text, fg, size=12, weight="Medium", align="RIGHT")
        else:
            r.text(inner, value_text, fg, size=12, weight="Medium", align="CENTER")

    # ---- arrastar / clicar ----
    def begin_drag(self, f, x, y):
        if not self.enabled:
            return None
        return {"x": x, "y": y, "start": self.value, "moved": False, "last": self.value}

    def drag(self, f, x, y, data):
        dx = x - data["x"]
        if not data["moved"] and abs(dx) < 3:
            return
        data["moved"] = True
        per_px = 1.0 / 8.0 if self.integer else self.step / 4.0
        value = self._clamp(data["start"] + dx * per_px)
        if value != data["last"]:
            data["last"] = value
            self.callback(f, value, False)

    def end_drag(self, f, data, cancelled):
        if cancelled:
            if data["moved"]:
                self.callback(f, data["start"], True)
            return
        if data["moved"]:
            self.callback(f, data["last"], True)    # True = final (undo push)
            return
        left, right = self._arrows()
        if left.contains(data["x"], data["y"]):
            self.callback(f, self._clamp(self.value - (1 if self.integer else self.step)), True)
        elif right.contains(data["x"], data["y"]):
            self.callback(f, self._clamp(self.value + (1 if self.integer else self.step)), True)
        else:   # clique simples: digitar o valor
            self.begin_edit(f, self.fmt().rstrip(self.suffix) if self.suffix else self.fmt())

    def commit(self, f, text):
        try:
            value = self._clamp(safe_eval(text))
        except (ValueError, SyntaxError, ZeroDivisionError, TypeError, OverflowError):
            f.toast(text, error=True)
            return
        self.callback(f, value, True)


class ListRow(Widget):
    """Linha de lista (UIList): ícone, nome, detalhe à direita."""
    interactive = True

    def __init__(self, key, text, on_click, icon=None, detail=None, selected=False, on_double=None,
                 tooltip=None, muted=False):
        super().__init__(key, Style(height=ROW_H), tooltip)
        self.text, self.callback, self.icon, self.detail = text, on_click, icon, detail
        self.selected, self.on_double, self.muted = selected, on_double, muted

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        h = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.1)
        sel = f.animate(self.key + ".sel", 1.0 if self.selected else 0.0, 0.16)
        if has_skin("popup_item_hover"):
            if sel > 0.01:       # selecionado: brilho do item do jogo + linha dourada embaixo
                skin(f, rect, "popup_item_hover", opacity=sel)
                skin(f, Rect(rect.x, rect.y, rect.w, 1.5), "selected_line", opacity=sel)
            if h > 0.01:
                r.rect(rect, th.surface_hover[:3] + (0.55 * h * (1.0 - sel),), radius=2)
        else:
            color = mix(th.surface_hover[:3] + (0.0,), th.surface_hover, h)
            color = mix(color, th.accent_soft, sel)
            r.rect(rect, color, radius=6 * th.radius_scale)
        if sel > 0.01:
            r.rect(Rect(rect.x + 1, rect.y + 6, 2.5, rect.h - 12), th.accent[:3] + (sel,), radius=1.2)
        x = rect.x + 9
        if self.icon:
            r.icon(Rect(x, rect.y + (rect.h - 14) / 2, 14, 14), self.icon, mix(th.text_muted, th.accent, sel))
            x += 21
        detail_w = 0.0
        if self.detail:
            detail_w = min(rect.w * 0.42, r.text_width(self.detail, 11) + 4)
            r.text(Rect(rect.right - detail_w - 8, rect.y, detail_w, rect.h), self.detail,
                   th.text_muted, size=11, align="RIGHT")
        r.text(Rect(x, rect.y, rect.right - x - detail_w - 14, rect.h), self.text,
               th.text_muted if self.muted else th.text, size=12)

    def on_click(self, f, x, y):
        last = f.state.get(self.key + ".last_click")
        f.state[self.key + ".last_click"] = f.now
        if self.on_double is not None and last is not None and f.now - last < 0.4:
            f.state.pop(self.key + ".last_click", None)
            self.on_double(f)
            return
        if self.callback:
            self.callback(f)


def list_box(content, rows_visible, key):
    """Moldura com rolagem para uma lista (altura = até `rows_visible` linhas)."""
    from .framework.core import ScrollView
    h = rows_visible * (ROW_H + 2) + 8
    return ScrollView(key, content, style=Style(height=h, min_height=min(h, 3 * (ROW_H + 2) + 8),
                                                max_height=h, padding=pad(4), background=None,
                                                border=None, radius=8))


def list_with_buttons(list_widget, buttons):
    frame = _ListSurface([list_widget], style=Style(flex=1, radius=8))
    side = Column([b for b in buttons if b is not None], style=Style(width=CONTROL_H, gap=3))
    return Row(frame, side, style=Style(gap=6, align="start"))


class _ListSurface(Column):
    def draw_box(self, f):
        th = f.theme
        if not skin(f, self.rect, "dropdown_panel"):
            f.renderer.rect(self.rect, th.input, radius=8 * th.radius_scale, border=th.border)


# --------------------------------------------------------------------------
# Moldura do jogo: cabeçalho, ornamento, divisor rúnico, caixas com skin
# --------------------------------------------------------------------------

class TitleBand(Row):
    """Faixa do título, como o #Title do @DecoratedContainer do jogo
    (Common/Container.ui): 38 de altura, ContainerHeader em 9-slice só
    horizontal (HorizontalBorder 50 lógico = 100 px do @2x, pontas
    proporcionais à altura), título no meio. Os filhos (engrenagem) ficam
    à direita; a versão é desenhada aqui à esquerda e SOME se o título não
    couber (painel estreito). Título: sem espaço entre letras e fonte
    encolhendo até 10 antes de cortar (ShrinkTextToFit do jogo, mín. 11)."""

    PNG_HEIGHT = 76.0          # altura do ContainerHeader@2x
    # O miolo azul da faixa começa ABAIXO da borda de cima (7 de 38): no
    # centro exato do retângulo, texto/engrenagem pareciam altos. O jogo
    # usa Padding Top 7 (desce 3,5); aqui 2, ajustado a olho com o usuário.
    CONTENT_DROP = 2.0

    def __init__(self, title, children, header=None, version="", key=None, height=38.0, base=None):
        drop = 2 * self.CONTENT_DROP if header else 0.0
        super().__init__(children, key=key, style=Style(height=height, padding=(10, drop, 8, 0), gap=6,
                                                        align="center"))
        self.title, self.header, self.version = title, header, version
        self.base = base          # cor sólida por baixo da faixa (faixa opaca); None = translúcida do jogo

    def draw_box(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        drew = False
        if self.header:
            path, slices, _ = self.header
            if self.base:
                r.nine_slice(rect, path, slices, scale=rect.h / self.PNG_HEIGHT, tint=self.base, silhouette=True)
            drew = r.nine_slice(rect, path, slices, scale=rect.h / self.PNG_HEIGHT)
        if not drew:
            r.rect(rect, th.surface, radius=0)
            r.rect(Rect(rect.x, rect.y, rect.w, 1), th.border)
        text, weight, tracking = heading(th, self.title)
        tracking = 1.4 if th.heading_upper else 0.0
        band = rect.inset(0, self.style.padding[1], 0, 0)     # mesma descida dos filhos
        # lado direito = filhos de largura fixa (engrenagem); o Spacer flexível não conta
        right = max((rect.right - c.rect.x for c in self.children if c.style.width), default=0.0) + 6
        version_w = r.text_width(self.version, 10, "SemiBold") + 14 if self.version else 0.0
        # Título centralizado na faixa: o espaço útil é simétrico ao lado mais largo.
        side = max(right, version_w)
        size, tracking = fit_text(r, text, rect.w - 2 * side, 13, weight, tracking, min_size=10.0)
        if self.version and r.text_width(text, size, weight, tracking) > rect.w - 2 * side:
            side = right                     # ainda não coube: some a versão
            size, tracking = fit_text(r, text, rect.w - 2 * side, 13, weight, tracking, min_size=10.0)
        elif self.version:
            r.text(Rect(rect.x + 10, band.y, version_w, band.h), self.version, th.text_muted, size=10,
                   weight="SemiBold")
        r.text(Rect(rect.x + side, band.y, rect.w - 2 * side, band.h), text, th.text, size=size,
               weight=weight, align="CENTER", tracking=tracking)


class Ornament(Widget):
    """Ornamento do @DecoratedContainer do jogo (ContainerDecorationTop /
    Bottom, 472x22 px @2x). A BARRA ocupa só metade do PNG (12 de 22 linhas);
    a outra metade é transparente, com o losango do meio pendurado. A faixa
    do layout tem a altura da barra e a metade vazia cai POR CIMA da peça
    vizinha: o de baixo sobre a moldura, o de cima sobre a faixa do título
    (DecoratedContainer desenha o de cima por último). Sem isso sobrava um
    vão entre a barra de cima e o título. Sem a arte: não ocupa espaço."""

    MAX_W = 236.0              # largura lógica máxima (jogo: 236x11)
    RATIO = 22.0 / 472.0       # altura/largura do PNG
    BAR = 12.0 / 22.0          # fração do PNG ocupada pela barra

    def __init__(self, path, bottom=False, base=None):
        super().__init__(style=Style())
        self.path, self.bottom, self.base = path, bottom, base    # base: cor sólida por baixo (opaco)

    def _size(self, width):
        w = min(self.MAX_W, width * 0.62)
        return w, w * self.RATIO

    def _extent(self, f, width):
        h = self._size(width)[1] * self.BAR if self.path else 0.0
        return (h, h, h)

    def measure(self, f, max_w):
        return (max_w, self.extent(f, max_w)[1])

    def draw(self, f):
        if not self.path:
            return
        w, h = self._size(self.rect.w)
        # de baixo: base do PNG na base da faixa; de cima: topo no topo da faixa
        y = self.rect.y if self.bottom else self.rect.top - h
        rect = Rect(self.rect.x + (self.rect.w - w) / 2, y, w, h)
        if self.base:
            f.renderer.image(rect, self.path, fit="stretch", tint=self.base, silhouette=True)
        f.renderer.image(rect, self.path, fit="stretch")


class DecoratedContainer(Column):
    """@DecoratedContainer do jogo (Common/Container.ui), usado pelo N-Panel
    e pela janela de boas-vindas: [ornamento de cima, faixa do título,
    corpo (moldura ContainerPatch), ornamento de baixo]. Título e corpo são
    IRMÃOS (a moldura começa embaixo do título). O ornamento de cima é
    desenhado por ÚLTIMO -- a metade vazia dele cai por cima do título."""

    def draw(self, f):
        self.draw_box(f)
        if self.style.clip:
            f.renderer.push_clip(self.rect if self.clip is None else self.clip.intersect(self.rect))
        try:
            for child in self.children[1:] + self.children[:1]:
                child.draw(f)
        finally:
            if self.style.clip:
                f.renderer.pop_clip()


class RuneDivider(Widget):
    """Divisor com a runa central do jogo (CenterRuneDividerHorizontal);
    sem a arte, uma linha simples."""

    def __init__(self):
        super().__init__(style=Style(height=12.0))

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        cy = rect.y + rect.h / 2
        rune = Rect(rect.x + rect.w / 2 - 36, cy - 6, 72, 12)
        if skin(f, rune, "divider_rune"):
            r.rect(Rect(rect.x, cy - 0.5, rune.x - rect.x - 4, 1), th.border)
            r.rect(Rect(rune.right + 4, cy - 0.5, rect.right - rune.right - 4, 1), th.border)
        else:
            r.rect(Rect(rect.x, cy - 0.5, rect.w, 1), th.border)


class SkinRow(Row):
    """Row com fundo de uma peça da skin (ex.: toast em "inset_light");
    sem a arte, usa o background/border do próprio Style."""

    def __init__(self, children, part, key=None, style=None):
        super().__init__(children, key=key, style=style)
        self.part = part

    def draw_box(self, f):
        if not skin(f, self.rect, self.part):
            super().draw_box(f)


class CompactButton(Button):
    """Hyblend Prefabs: botão com ícone + texto que vira SÓ ÍCONE quando o
    texto não cabe nem encolhido (painel estreito) -- "SEL…"/"ZOO…" cortados
    eram ilegíveis. Nesse modo o rótulo vira o começo do tooltip."""

    def _fits(self, f):
        th, r = f.theme, f.renderer
        label, weight, tracking, size = self._label(th)
        room = self.rect.w - 18 - (22.0 if self.icon else 0.0)
        size, tracking = fit_text(r, label, room, size, weight, tracking, min_size=10.0)
        return r.text_width(label, size, weight, tracking) <= room

    def draw(self, f):
        if not self.icon or not self.text or self._fits(f):
            self._compact = False
            return super().draw(f)
        self._compact = True
        text, self.text = self.text, ""
        try:
            super().draw(f)
        finally:
            self.text = text


def compact_tooltip(button, extra=None):
    """Tooltip do CompactButton: só o texto extra normalmente; no modo
    só-ícone, "Rótulo: texto extra"."""
    def text():
        detail = extra() if callable(extra) else extra
        if getattr(button, "_compact", False):
            return "%s: %s" % (button.text, detail) if detail else button.text
        return detail or ""
    return text
