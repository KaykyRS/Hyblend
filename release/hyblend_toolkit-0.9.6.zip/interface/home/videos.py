"""Aprender = vídeos do Hyblend, pela lista `videos.json` da raiz do repositório do GitHub. Quem gera a lista é a
GitHub Action `.github/workflows/update-videos.yml` (de hora em hora, pela YouTube Data API: ordem da playlist,
traduções do título/descrição, duração). O addon NÃO lê o feed RSS do YouTube: desde o fim de 2025 ele devolve 404
por horas, e sem chave de API não traz traduções nem duração. Só a miniatura vem do YouTube (i.ytimg.com, estável).
Busca numa thread (lista + miniaturas que faltam), cache em <dados da extensão>/videos.json + videos/<id>.jpg (abre
na hora e funciona offline), no máximo a cada REFRESH_EVERY. Respeita o "Allow Online Access" do Blender.
Clique = abre o vídeo no navegador (watch?v=...&list=...: segue na playlist).

Formato do videos.json (texto = string ou {"EN": ..., "PT_BR": ...}; só "id" e "title" obrigatórios):
  {"videos": [{"id": "zHz_ntv7hc8", "title": {"EN": "...", "PT_BR": "..."}, "description": {...}, "duration": "1:01",
               "published": "2026-10-12"}]}
"""

import json
import os
import re
import threading
import time
from datetime import datetime

import bpy

from ...common import ADDON_PACKAGE

LIST_URL = "https://raw.githubusercontent.com/KaykyRS/Hyblend/HEAD/videos.json"   # HEAD = branch padrão
PLAYLIST_ID = "PLB4ckvIQ5dQ8"
PLAYLIST_URL = "https://www.youtube.com/playlist?list=" + PLAYLIST_ID
# Miniatura 16:9 (a hqdefault é 4:3 com faixas pretas): a 1280x720 quando existe, senão a 320x180.
THUMB_URLS = ("https://i.ytimg.com/vi/{id}/hq720.jpg", "https://i.ytimg.com/vi/{id}/mqdefault.jpg")
REFRESH_EVERY = 3600          # = o agendamento da Action (raw.githubusercontent.com não tem limite como a API)
TIMEOUT = 10.0
MAX_VIDEOS = 50
_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")      # vira nome de arquivo: nada fora disso
_DURATION = re.compile(r"^\d{1,2}(:\d{2}){1,2}$")   # "1:01", "12:40", "1:02:03"

_state = {"loaded": False, "videos": [], "fetched_at": 0.0, "status": "idle", "error": ""}
_job = {"thread": None, "result": None, "lock": threading.Lock()}


def _data_dir(create=False):
    try:
        return bpy.utils.extension_path_user(ADDON_PACKAGE, create=create)
    except Exception:
        return bpy.utils.user_resource("CONFIG", path="hyblend_toolkit", create=create)


def thumb_path(base, ident):
    return os.path.join(base, "videos", ident + ".jpg")


def watch_url(ident):
    return "https://www.youtube.com/watch?v=%s&list=%s" % (ident, PLAYLIST_ID)


def text(value, lang):
    """Campo traduzível ({"EN": ..., "PT_BR": ...} ou string) no idioma pedido; senão inglês; senão o 1º."""
    if isinstance(value, dict):
        return value.get(lang) or value.get("EN") or next(iter(value.values()), "")
    return value or ""


def _load_cache():
    if _state["loaded"]:
        return
    _state["loaded"] = True
    base = _data_dir()
    try:
        with open(os.path.join(base, "videos.json"), encoding="utf-8") as handle:
            data = json.load(handle)
        items = parse_list(data)
        for item in items:                           # caminho refeito aqui (a pasta de dados pode ter mudado)
            path = thumb_path(base, item["id"])
            item["thumb"] = path if os.path.isfile(path) else ""
        _state["videos"] = items
        _state["fetched_at"] = float(data.get("fetched_at", 0.0))
    except (OSError, ValueError, TypeError):
        pass


def _save_cache():
    saved = [{k: v for k, v in item.items() if k != "thumb"} for item in _state["videos"]]
    try:
        with open(os.path.join(_data_dir(create=True), "videos.json"), "w", encoding="utf-8") as handle:
            json.dump({"fetched_at": _state["fetched_at"], "videos": saved}, handle)
    except OSError as error:
        print("[Hyblend] Home: could not save videos cache:", error)


def online_allowed():
    return bool(getattr(bpy.app, "online_access", True))


def videos():
    """[{"id", "title", "description", "duration", "published" (epoch ou 0), "thumb" (caminho ou "")}]
    na ordem da lista. title/description: string ou {idioma: texto} (ver text())."""
    _load_cache()
    return _state["videos"]


def status():
    """"idle" | "loading" | "ok" | "error" | "offline" -- e quando atualizou."""
    _load_cache()
    return _state["status"], _state["error"], _state["fetched_at"]


def refresh(force=False):
    """Busca em segundo plano (se permitido e se o cache estiver velho). Fora do desenho."""
    _load_cache()
    if _job["thread"] is not None:
        return
    if not online_allowed():
        _state["status"] = "offline"
        return
    if not force and _state["fetched_at"] and time.time() - _state["fetched_at"] < REFRESH_EVERY:
        _state["status"] = "ok"
        return
    _state["status"], _state["error"] = "loading", ""
    _job["result"] = None
    base = _data_dir(create=True)                    # bpy só na thread principal
    thread = threading.Thread(target=_worker, args=(LIST_URL, base), name="hyblend_videos", daemon=True)
    _job["thread"] = thread
    thread.start()
    if not bpy.app.timers.is_registered(_poll):
        bpy.app.timers.register(_poll, first_interval=0.25)


def _text_field(value):
    """string ou {idioma: string} -> o mesmo, limpo; outra coisa -> ""."""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        return {str(k): v.strip() for k, v in value.items() if isinstance(v, str) and v.strip()}
    return ""


def parse_list(data):
    """JSON da lista -> vídeos válidos (entrada estranha é pulada; lista que não é a nossa = ValueError)."""
    if not isinstance(data, dict) or not isinstance(data.get("videos"), list):
        raise ValueError("not a Hyblend video list")
    items = []
    for entry in data["videos"][:MAX_VIDEOS]:
        if not isinstance(entry, dict) or not _VIDEO_ID.match(str(entry.get("id", ""))):
            continue
        title = _text_field(entry.get("title"))
        if not title:
            continue
        published = entry.get("published", 0)
        if isinstance(published, str):              # "2026-10-12" ou ISO completo
            try:
                published = datetime.fromisoformat(published.strip()).timestamp()
            except ValueError:
                published = 0
        duration = str(entry.get("duration", "")).strip()
        items.append({"id": entry["id"], "title": title, "description": _text_field(entry.get("description")),
                      "duration": duration if _DURATION.match(duration) else "",
                      "published": float(published) if isinstance(published, (int, float)) else 0.0})
    return items


# --- THREAD: só rede, JSON e arquivos ---

def _open(url):
    import ssl
    import urllib.request
    try:
        import certifi
        context = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        context = ssl.create_default_context()
    request = urllib.request.Request(url, headers={"User-Agent": "Hyblend-Toolkit"})
    return urllib.request.urlopen(request, timeout=TIMEOUT, context=context)


def _fetch_thumb(ident, path):
    for url in THUMB_URLS:
        try:
            with _open(url.format(id=ident)) as response:
                data = response.read()
        except Exception:
            continue
        if data:
            tmp = path + ".part"
            with open(tmp, "wb") as out:
                out.write(data)
            os.replace(tmp, path)
            return True
    return False


def _worker(url, base):
    """Resultado: ("ok", [vídeos com "thumb"]) ou ("error", texto). 404/timeout/sem internet levantam no urlopen;
    resposta que não é a lista, no parse_list."""
    try:
        with _open(url) as response:
            items = parse_list(json.loads(response.read().decode("utf-8")))
        folder = os.path.join(base, "videos")
        os.makedirs(folder, exist_ok=True)
        for item in items:
            path = thumb_path(base, item["id"])
            ok = os.path.isfile(path) or _fetch_thumb(item["id"], path)
            item["thumb"] = path if ok else ""
        keep = {item["id"] + ".jpg" for item in items}
        for name in os.listdir(folder):              # vídeo que saiu da lista: miniatura sai junto
            if name.endswith((".jpg", ".part")) and name not in keep:
                try:
                    os.remove(os.path.join(folder, name))
                except OSError:
                    pass
        result = ("ok", items)
    except Exception as error:                       # sem internet, arquivo fora do ar, JSON quebrado...
        result = ("error", str(error)[:200])
    with _job["lock"]:
        _job["result"] = result


def _poll():
    """Timer (thread principal): pega o resultado da thread quando chegar."""
    with _job["lock"]:
        result = _job["result"]
    if result is None:
        thread = _job["thread"]
        if thread is not None and thread.is_alive():
            return 0.25
        result = ("error", "no answer")
    _job["thread"], _job["result"] = None, None
    kind, payload = result
    if kind == "ok":
        _state["videos"], _state["fetched_at"] = payload, time.time()
        _state["status"], _state["error"] = "ok", ""
        _save_cache()
    else:
        _state["status"], _state["error"] = "error", payload
        print("[Hyblend] Home: videos:", payload)
    from ..gpu_ui import home_host as host
    host.refresh_all()
    return None


def cancel():
    """unregister: sai o timer E a busca pela metade (o módulo sobrevive ao desligar; religado na mesma sessão,
    um _job["thread"] velho travaria o refresh() pra sempre)."""
    if bpy.app.timers.is_registered(_poll):
        bpy.app.timers.unregister(_poll)
    with _job["lock"]:
        _job["thread"], _job["result"] = None, None
    if _state["status"] == "loading":
        _state["status"] = "idle"
