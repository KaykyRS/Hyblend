"""character_assembly.py -- anexa um .blockymodel (corpo, roupa, cabelo...) no Armature do Player e
rastreia o que cada slot criou (trocar/remover uma peça desfaz só ela).

A montagem (bones + malhas) é a do núcleo (api.model.build), a MESMA do File > Import do Hyblend: o Armature
fica legível/reimportável/exportável pelo Anim. O que é só do CC fica aqui: malhas direto na collection (sem uma
por bone, senão trocar de peça deixa collection vazia), objeto ativo/modo de volta como estavam e o registro dos
slots (custom property `hyblendcc_slot_<categoria>` no Armature).
"""

from __future__ import annotations

import json
from pathlib import Path

import bpy

from ..compat import get_id_prop
from ..toolkit import api

_build = api.model.build
UNIT_SCALE_DEFAULT = api.model.props.UNIT_SCALE_DEFAULT
_ATTACHMENTS_COLLECTION_PROP = api.model.props.ATTACHMENTS_COLLECTION_PROP


class AssemblyError(Exception):
    """Peça que não dá pra anexar com segurança (ex: .blockymodel vazio/inválido)."""


def _warning_texts(warnings):
    lang = api.get_language(bpy.context)
    return [api.tr_for(None, key, lang).format(**fields) for _level, key, fields in warnings]


def assemble_item(
    context,
    armature_obj: "bpy.types.Object",
    blockymodel_path: Path,
    atlas_w: float,
    atlas_h: float,
    unit_scale: float = UNIT_SCALE_DEFAULT,
    generate_uvs: bool = True,
    collection=None,
    suppress_root_warning: bool = False,
    reattach_children: dict | None = None,
) -> tuple:
    """Lê `blockymodel_path` e monta no `armature_obj`: bones novos (ou o wrapper "{arquivo}:{nó}" dentro do bone
    que já existe, nos pontos de ancoragem) e as malhas presas a eles.

    `suppress_root_warning`: Armature vazio de propósito (criar o Player do zero) -- monta como modelo NOVO (sem
    ancoragem e sem o aviso de "raiz sem bone").
    `reattach_children`: {filho: pai} devolvido por remove_equipped_slot() -- bones de OUTROS slots (ou do Create
    Rig) que eram filhos dos bones removidos, religados por NOME.

    Devolve (objetos criados, bones criados (pai antes do filho, nunca os reaproveitados), avisos em texto)."""
    try:
        with blockymodel_path.open(encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError) as exc:
        raise AssemblyError(f"Could not read '{blockymodel_path.name}': {exc}") from exc
    if not isinstance(data, dict) or not data.get("nodes"):
        raise AssemblyError(f"'{blockymodel_path.name}' has no nodes at all (empty or invalid .blockymodel).")

    if collection is None:
        collection, _created = _build.attachments_collection(context, armature_obj)

    prev_active = context.view_layer.objects.active
    prev_mode = prev_active.mode if prev_active is not None else "OBJECT"
    try:
        result = _build.build(
            context, data, armature_obj, unit_scale=unit_scale, attach=not suppress_root_warning,
            stem=blockymodel_path.stem, collection=collection, generate_uvs=generate_uvs, bone_collections=False,
            atlas=(atlas_w, atlas_h), reattach_children=reattach_children,
        )
    finally:
        if prev_active is not None and prev_active.name in context.view_layer.objects:
            context.view_layer.objects.active = prev_active
            try:
                bpy.ops.object.mode_set(mode=prev_mode)
            except RuntimeError:
                pass
    return result.objects, result.bones, _warning_texts(result.warnings)


# ---------------------------------------------------------------------------
# "Slot equipado" -- rastreia o que foi criado pra cada categoria (ex.
# "Pants", "Gloves") num Armature, pra poder DESFAZER por completo antes
# de aplicar um item novo na mesma categoria. Sem isso, trocar de
# item/cor repetidas vezes so empilha bones/meshes -- cada troca deixaria
# a peca anterior grudada, ao inves de substituir.
#
# Guardado como JSON dentro de uma unica custom property por slot no
# proprio Armature Object (`hyblendcc_slot_<categoria>`) -- sobrevive
# salvar/reabrir o .blend, e nao depende de nenhum estado do addon em
# memoria (troca de sessao do Blender nao perde o rastro).
# ---------------------------------------------------------------------------

_SLOT_PROP_PREFIX = "hyblendcc_slot_"


def _slot_prop_name(slot_key: str) -> str:
    return f"{_SLOT_PROP_PREFIX}{slot_key}"


def record_equipped_slot(
    armature_obj: "bpy.types.Object",
    slot_key: str,
    created_objs: list,
    created_bone_names: list,
    item_id: str = "",
    color: str = "",
    variant: str = "",
    gradient_set: str = "",
    background_color: str = "",
    background_linked: bool = False,
    skin_linked: bool = True,
    atlas_size=None,
) -> None:
    """Grava o que foi criado nesta aplicacao, pra uma remocao futura
    (ver remove_equipped_slot) saber exatamente o que desfazer.

    `item_id`/`color`/`variant`/`gradient_set`: guardados so pra UI
    conseguir se RESINCRONIZAR depois (ex: trocar de Armature ativo e
    voltar, reabrir o .blend) -- sem isso, o picker nao tem como saber o
    que ja esta equipado de verdade, so o que foi selecionado nesta
    sessao do Blender. `variant` e o key de uma ItemVariant (ver
    manifest_parser.py), vazio pra maioria dos itens. `gradient_set` e o
    GradientSet ESCOLHIDO PELO USUARIO pra esse item (pode ser diferente
    do que o manifest declara como padrao -- pedido explicito, o usuario
    pode trocar Skin por Hair/etc manualmente), vazio pra itens em modo
    discreto (sem GradientSet nenhum envolvido).

    `background_color`/`background_linked`: feature pedida pelo usuario
    -- alguns itens tem um no "*Background*" separado na malha (ex.
    Eye-Background) que pode ter uma cor PROPRIA, independente da cor
    principal do item, controlada por um botao de "link" na UI (ver
    picker.py -- so importa quando o item de fato tem um no assim,
    senao fica so gravado sem uso nenhum).

    `skin_linked`: feature pedida pelo usuario -- BodyCharacteristics/
    Faces/Mouths/Ears cada um mantem a PROPRIA paleta, mas pode estar
    "linkado" (default True, pra bater com o comportamento anterior a
    esta feature -- eram sempre linkados, sem opcao de desligar) com as
    outras categorias do grupo tambem linkadas no momento -- escolher
    uma cor numa propaga pras outras linkadas (ver
    _find_linked_skin_color/_slot_on_color_update em picker.py). So
    importa pras 4 categorias do grupo, gravado sem uso nenhum pras
    demais.

    `atlas_size`: (w, h) usado nas UVs; registro sem ele (antigo) nunca
    usa o atalho de so trocar o material (recolor_equipped_slot)."""
    payload = {
        "objects": [o.name for o in created_objs],
        "bones": list(created_bone_names),
        "item_id": item_id,
        "color": color,
        "variant": variant,
        "gradient_set": gradient_set,
        "background_color": background_color,
        "background_linked": background_linked,
        "skin_linked": skin_linked,
    }
    if atlas_size is not None:
        # Tamanho do atlas usado nas UVs -- recolor_equipped_slot so troca
        # o material no lugar se o atlas da cor nova for o MESMO.
        payload["atlas"] = [float(atlas_size[0]), float(atlas_size[1])]
    armature_obj[_slot_prop_name(slot_key)] = json.dumps(payload)


def get_equipped_item(armature_obj: "bpy.types.Object", slot_key: str):
    """Le de volta (item_id, color, variant, gradient_set,
    background_color, background_linked, skin_linked) do que esta
    gravado nesse slot, ou None se nada estiver equipado ali. Usado
    pela UI (Panel) pra mostrar o dropdown ja no valor certo, sem
    depender de estado em memoria que se perde ao trocar de Armature
    ativo ou reabrir o arquivo. `background_color`/`background_linked`
    vem com default seguro (""/False) pra dado gravado ANTES dessa
    feature existir. `skin_linked` default True -- ANTES desta feature,
    BodyCharacteristics/Faces/Ears eram SEMPRE linkados (sem opcao de
    desligar), entao dado antigo deve continuar se comportando como
    linkado."""
    raw = get_id_prop(armature_obj, _slot_prop_name(slot_key))
    if not raw:
        return None
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None
    item_id = payload.get("item_id", "")
    color = payload.get("color", "")
    variant = payload.get("variant", "")
    gradient_set = payload.get("gradient_set", "")
    background_color = payload.get("background_color", "")
    background_linked = bool(payload.get("background_linked", False))
    skin_linked = bool(payload.get("skin_linked", True))
    if not item_id:
        return None
    return item_id, color, variant, gradient_set, background_color, background_linked, skin_linked



def remove_equipped_slot(context, armature_obj: "bpy.types.Object", slot_key: str) -> dict:
    """Desfaz por completo a ultima aplicacao gravada nesse slot (se
    existir) -- remove os Objects (mesh + vertex group + modifier, tudo
    junto) e os bones que foram CRIADOS especificamente pra ela (nunca
    bones reaproveitados do Player, ver assemble_item). Chamar
    ANTES de aplicar um item novo na mesma categoria.

    Devolve {filho: pai} dos bones de FORA deste slot (wrappers de outros
    itens, bones do Create Rig do Toolkit) que eram filhos diretos de um
    bone removido. Apagar um bone faz o Blender subir os filhos pro avo
    -- removendo o corpo inteiro, rosto/boca/orelhas/cabelo ficavam SEM
    PAI (bug real). Quem vai recriar o slot passa isso pra
    assemble_item(reattach_children=...); quem so remove pode ignorar."""
    prop_name = _slot_prop_name(slot_key)
    raw = armature_obj.get(prop_name)
    if not raw:
        return {}

    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        del armature_obj[prop_name]
        return {}

    for obj_name in payload.get("objects", []):
        obj = bpy.data.objects.get(obj_name)
        if obj is not None:
            mesh_data = obj.data
            # Vazamento real corrigido: o material criado pra este item
            # (ver _resolve_item_material -- um material NOVO, com arvore
            # de nos propria, por item+cor) nunca era limpo aqui, so a
            # malha/objeto. Capturamos os materiais ANTES de remover a
            # malha, e limpamos os que ficaram sem nenhum usuario depois.
            materials = list(mesh_data.materials) if mesh_data is not None else []
            bpy.data.objects.remove(obj, do_unlink=True)
            if mesh_data is not None and mesh_data.users == 0:
                bpy.data.meshes.remove(mesh_data)
            for mat in materials:
                if mat is not None and mat.users == 0:
                    bpy.data.materials.remove(mat)

    # Lido em Object Mode (armature.bones), antes de entrar no Edit Mode.
    bone_names = [n for n in payload.get("bones", []) if n in armature_obj.data.bones]
    removed = set(bone_names)
    external_children: dict = {}
    for bone_name in bone_names:
        for child in armature_obj.data.bones[bone_name].children:
            if child.name not in removed:
                external_children[child.name] = bone_name

    if bone_names:
        prev_active = context.view_layer.objects.active
        prev_mode = armature_obj.mode
        context.view_layer.objects.active = armature_obj
        armature_obj.select_set(True)

        bpy.ops.object.mode_set(mode="EDIT")
        try:
            edit_bones = armature_obj.data.edit_bones
            # Remove na ordem REVERSA de criacao (filho antes de pai) --
            # created_bone_names foi preenchido pai-antes-de-filho durante
            # a criacao, entao invertido garante que nenhum bone seja
            # removido enquanto ainda tem filho vivo apontando pra ele.
            for bone_name in reversed(bone_names):
                bone = edit_bones.get(bone_name)
                if bone is not None:
                    edit_bones.remove(bone)
        finally:
            bpy.ops.object.mode_set(mode="OBJECT")
            if prev_active is not None:
                context.view_layer.objects.active = prev_active
            try:
                bpy.ops.object.mode_set(mode=prev_mode)
            except RuntimeError:
                pass

    del armature_obj[prop_name]
    return external_children


def recolor_equipped_slot(armature_obj: "bpy.types.Object", slot_key: str, atlas_size, material_for) -> bool:
    """Troca SO o material dos objetos ja equipados nesse slot, sem
    recriar bone nenhum -- usado quando o item e a variante nao mudaram
    (so cor/GradientSet/fundo; ex. o link de pele propagando pro corpo).
    Recriar os bones do corpo so pra trocar a cor soltava os outros itens
    e apagava constraints que o Create Rig do Toolkit pos nesses bones.

    `material_for(obj)` devolve o material daquele objeto (ou None).
    Devolve False (sem mexer em nada) quando nao da pra garantir o mesmo
    resultado de uma reaplicacao completa: registro antigo sem `atlas`,
    atlas diferente (a UV depende dele), ou algum objeto sumiu -- quem
    chama faz a reconstrucao normal nesse caso."""
    raw = get_id_prop(armature_obj, _slot_prop_name(slot_key))
    if not raw:
        return False
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return False
    stored_atlas = payload.get("atlas")
    if not stored_atlas or [float(v) for v in stored_atlas] != [float(v) for v in atlas_size]:
        return False
    objs = [bpy.data.objects.get(n) for n in payload.get("objects", [])]
    if not objs or any(o is None or o.type != "MESH" for o in objs):
        return False

    # Resolve TUDO antes de mexer: se material_for levantar erro (textura
    # faltando), nenhum objeto fica sem material pela metade.
    new_materials = [material_for(obj) for obj in objs]

    old_materials = set()
    for obj, mat in zip(objs, new_materials):
        old_materials.update(m for m in obj.data.materials if m is not None)
        obj.data.materials.clear()
        if mat is not None:
            obj.data.materials.append(mat)
    # Mesma limpeza do remove_equipped_slot (material sem usuario = vazamento).
    for mat in old_materials:
        if mat.users == 0:
            bpy.data.materials.remove(mat)
    return True


def equipped_slot_record(armature_obj: "bpy.types.Object", slot_key: str):
    """(objects, bones) gravados nesse slot -- pra regravar o registro
    depois de recolor_equipped_slot sem perder o que desfazer."""
    raw = get_id_prop(armature_obj, _slot_prop_name(slot_key))
    try:
        payload = json.loads(raw) if raw else {}
    except (json.JSONDecodeError, TypeError):
        payload = {}
    return payload.get("objects", []), payload.get("bones", [])
