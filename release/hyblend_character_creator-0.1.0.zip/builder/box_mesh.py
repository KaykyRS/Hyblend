"""box_mesh.py -- gera a geometria (Mesh do Blender) de uma peca a partir
do dict "shape" cru do .blockymodel.

A matematica de UV (constantes + compute_face_uv + make_box_mesh/
make_quad_mesh) e uma ADAPTACAO DIRETA do importer/__init__.py do Hyblend
-- copiada de proposito em vez de reescrita do zero. O Hyblend ja passou
por um processo de validacao numerica extenso contra exports reais do
Blockbench (comentarios originais preservados abaixo explicam a fonte de
cada pedaco). Reescrever isso do zero arriscaria reintroduzir bugs sutis
de rotacao/espelho de UV que ja foram encontrados e corrigidos la.

`build_shape_mesh()`, no fim do arquivo, e a ponte NOVA (nao existe no
Hyblend) entre um dict "shape" cru e essa geracao de geometria -- usada
por character_assembly.py.

Requer bpy/bmesh/mathutils -- so roda dentro do Blender. Nao testavel no
sandbox de desenvolvimento.
"""

from __future__ import annotations

import bmesh
import bpy
from mathutils import Vector

# ---------------------------------------------------------------------------
# Constantes de UV de caixa/quad -- copiadas do importer/__init__.py do
# Hyblend (mesma fonte, mesma validacao). Ver o arquivo original pra notas
# completas de como cada uma foi derivada.
# ---------------------------------------------------------------------------

FACE_AXES_BY_FIXED_AXIS = {
    "z": (0, 1),  # (axis_u, axis_v) = (x, y) -> front/back
    "y": (0, 2),  # (x, z) -> top/bottom
    "x": (2, 1),  # (z, y) -> left/right
}

BOX_FACE_FIXED_AXIS = {
    "front": "z",
    "back": "z",
    "top": "y",
    "bottom": "y",
    "left": "x",
    "right": "x",
}

BOX_FACES_LOOP_ORDER = [
    ("back", (0, 1, 2, 3)),
    ("front", (4, 7, 6, 5)),
    ("bottom", (0, 4, 5, 1)),
    ("right", (1, 5, 6, 2)),
    ("top", (2, 6, 7, 3)),
    ("left", (3, 7, 4, 0)),
]

OPPOSITE_FACE = {
    "front": "back", "back": "front",
    "top": "bottom", "bottom": "top",
    "left": "right", "right": "left",
}

NORMAL_TO_HYTALE_FACE_KEY = {
    "+Z": "front", "-Z": "back",
    "+X": "right", "-X": "left",
    "+Y": "top", "-Y": "bottom",
}

# Sinal "base" (s,t -> pixel), SEM nenhuma rotacao/espelho, de cada face.
# Ver importer/__init__.py do Hyblend pra derivacao completa (engenharia
# reversa numerica contra Player_With_Face.gltf, 0 divergencias em 64 faces).
BOX_FACE_BASE_SIGN = {
    "back": (-1, -1),
    "right": (-1, -1),
    "front": (+1, -1),
    "left": (+1, -1),
    "top": (+1, +1),
    "bottom": (+1, -1),
}


def face_size_raw(size_raw, fixed_axis):
    """Largura/altura (em unidades de jogo, NAO escaladas) da face cujo
    eixo fixo e `fixed_axis` ('x'/'y'/'z')."""
    au, av = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
    comps = (size_raw.x, size_raw.y, size_raw.z)
    return comps[au], comps[av]


def _blockbench_uv_rect(fw, fh, angle, mirror, offset):
    """Retangulo [x1, y1, x2, y2] em PIXELS (podendo vir "invertido") que o
    textureLayout de UMA face descreve. Port fiel do algoritmo do plugin
    oficial Blockbench<->Hytale (ver importer/__init__.py do Hyblend,
    _blockbench_uv_rect, pra referencia de linha de codigo fonte)."""
    ux = offset.get("x", 0.0)
    uy = offset.get("y", 0.0)
    uv_size = [fw, fh]
    mx = bool(mirror.get("x"))
    my = bool(mirror.get("y"))
    uv_mirror = [-1.0 if mx else 1.0, -1.0 if my else 1.0]
    k = angle or 0

    if k == 90:
        uv_size[0], uv_size[1] = uv_size[1], uv_size[0]
        uv_mirror[0], uv_mirror[1] = uv_mirror[1], uv_mirror[0]
        uv_mirror[0] *= -1
        x1, y1 = ux, uy + uv_size[1] * uv_mirror[1]
        x2, y2 = ux + uv_size[0] * uv_mirror[0], uy
    elif k == 270:
        uv_size[0], uv_size[1] = uv_size[1], uv_size[0]
        uv_mirror[0], uv_mirror[1] = uv_mirror[1], uv_mirror[0]
        uv_mirror[1] *= -1
        x1, y1 = ux + uv_size[0] * uv_mirror[0], uy
        x2, y2 = ux, uy + uv_size[1] * uv_mirror[1]
    elif k == 180:
        uv_mirror[0] *= -1
        uv_mirror[1] *= -1
        x1, y1 = ux + uv_size[0] * uv_mirror[0], uy + uv_size[1] * uv_mirror[1]
        x2, y2 = ux, uy
    else:
        x1, y1 = ux, uy
        x2, y2 = ux + uv_size[0] * uv_mirror[0], uy + uv_size[1] * uv_mirror[1]

    return x1, y1, x2, y2


def compute_face_uv(local_co, half_extents, axis_u, axis_v, face_key, tex_offset, face_w, face_h, mirror, angle, atlas_w, atlas_h):
    """UV de um vertice de uma face -- ver importer/__init__.py do Hyblend
    pra derivacao completa (validado numericamente + porte do codigo fonte
    oficial do Blockbench pra rotacao de 90/180/270)."""
    hu = half_extents[axis_u] or 1.0
    hv = half_extents[axis_v] or 1.0
    s = (local_co[axis_u] + hu) / (2.0 * hu)
    t = (local_co[axis_v] + hv) / (2.0 * hv)

    bs, bt = BOX_FACE_BASE_SIGN.get(face_key, (1, -1))
    s_bb = s if bs > 0 else 1.0 - s
    t_bb = t if bt > 0 else 1.0 - t

    k = int(round((angle or 0) / 90.0)) % 4
    for _ in range(k):
        s_bb, t_bb = t_bb, 1.0 - s_bb

    x1, y1, x2, y2 = _blockbench_uv_rect(face_w, face_h, angle, mirror, tex_offset)
    px = x1 + (x2 - x1) * s_bb
    py = y1 + (y2 - y1) * t_bb

    u = px / atlas_w
    v = 1.0 - (py / atlas_h)
    return u, v


def make_box_mesh(name, size_scaled, size_raw, shape, atlas_w, atlas_h, generate_uvs=True, missing_face_mode="SKIP"):
    """Cria uma malha de caixa CENTRADA NA ORIGEM. Ver importer/__init__.py
    do Hyblend pra explicacao completa de missing_face_mode (SKIP e o
    comportamento fiel ao Blockbench: face sem entrada no textureLayout
    nunca teve textura, nao e "buraco por engano")."""
    hx, hy, hz = size_scaled.x / 2.0, size_scaled.y / 2.0, size_scaled.z / 2.0
    half_extents = (hx, hy, hz)

    verts_co = [
        (-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
        (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz),
    ]

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm = bmesh.new()
    bm_verts = [bm.verts.new(co) for co in verts_co]

    uv_layer = bm.loops.layers.uv.new() if generate_uvs else None
    tex_layout = shape.get("textureLayout", {})

    for face_key, idxs in BOX_FACES_LOOP_ORDER:
        lookup_key = face_key
        if face_key not in tex_layout:
            if missing_face_mode == "OPPOSITE_FALLBACK":
                lookup_key = OPPOSITE_FACE.get(face_key)
                if lookup_key not in tex_layout:
                    continue
            else:
                continue

        face = bm.faces.new([bm_verts[i] for i in idxs])
        if uv_layer is not None:
            info = tex_layout[lookup_key]
            fixed_axis = BOX_FACE_FIXED_AXIS[face_key]
            axis_u, axis_v = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
            fw, fh = face_size_raw(size_raw, fixed_axis)
            tex_offset = info.get("offset", {})
            mirror = info.get("mirror", {})
            angle = info.get("angle", 0)
            for loop in face.loops:
                local_co = loop.vert.co
                u, v = compute_face_uv(
                    local_co, half_extents, axis_u, axis_v, face_key, tex_offset, fw, fh, mirror, angle, atlas_w, atlas_h
                )
                loop[uv_layer].uv = (u, v)

    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    return mesh


def make_quad_mesh(name, shape, size_scaled_2d, size_raw_2d, atlas_w, atlas_h, generate_uvs=True):
    """Cria uma malha plana (1 ou 2 faces, se doubleSided). Ver
    importer/__init__.py do Hyblend pra notas completas."""
    normal = shape.get("settings", {}).get("normal", "+Z")
    axis_letter = normal[-1].lower() if normal else "z"
    fixed_axis = axis_letter if axis_letter in ("x", "y", "z") else "z"
    axis_u, axis_v = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
    geom_face_key = NORMAL_TO_HYTALE_FACE_KEY.get(normal, "front")

    hu, hv = size_scaled_2d.x / 2.0, size_scaled_2d.y / 2.0
    half_extents = [0.0, 0.0, 0.0]
    half_extents[axis_u] = hu or 1.0
    half_extents[axis_v] = hv or 1.0

    def assemble(val_u, val_v):
        co = [0.0, 0.0, 0.0]
        co[axis_u] = val_u
        co[axis_v] = val_v
        return tuple(co)

    verts_co = [assemble(-hu, -hv), assemble(hu, -hv), assemble(hu, hv), assemble(-hu, hv)]

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm = bmesh.new()

    uv_layer = bm.loops.layers.uv.new() if generate_uvs else None
    tex_layout = shape.get("textureLayout", {})
    face_key = next(iter(tex_layout.keys()), None)

    def build_face(vert_order):
        verts = [bm.verts.new(verts_co[i]) for i in vert_order]
        face = bm.faces.new(verts)
        if uv_layer is not None and face_key is not None:
            info = tex_layout[face_key]
            tex_offset = info.get("offset", {})
            mirror = info.get("mirror", {})
            angle = info.get("angle", 0)
            for loop in face.loops:
                local_co = loop.vert.co
                u, v = compute_face_uv(
                    local_co, tuple(half_extents), axis_u, axis_v, geom_face_key, tex_offset,
                    size_raw_2d.x, size_raw_2d.y, mirror, angle, atlas_w, atlas_h,
                )
                loop[uv_layer].uv = (u, v)

    default_order = (0, 1, 2, 3)
    flipped_order = (3, 2, 1, 0)
    primary_order = flipped_order if (normal and normal.startswith("-")) else default_order

    build_face(primary_order)
    if shape.get("doubleSided"):
        build_face(flipped_order if primary_order is default_order else default_order)

    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    return mesh


# ---------------------------------------------------------------------------
# NOVO (nao existe no Hyblend): ponte entre um dict "shape" cru e as
# funcoes de geracao acima.
# ---------------------------------------------------------------------------

def build_shape_mesh(name, shape, unit_scale, atlas_w, atlas_h, generate_uvs=True):
    """Recebe o dict "shape" cru de um no do .blockymodel e devolve uma
    bpy.types.Mesh pronta, centrada na origem local do proprio no --
    quem chama posiciona o Object resultante via sua propria matriz de
    mundo (ver character_assembly.py -- a peca inteira agora tem seu
    proprio bone, entao a posicao vem do bone, nao mais de um calculo
    relativo separado aqui)."""
    settings = shape.get("settings", {})
    size_dict = settings.get("size", {})
    size_raw = Vector((size_dict.get("x", 1.0), size_dict.get("y", 1.0), size_dict.get("z", 1.0)))

    stretch_dict = shape.get("stretch", {"x": 1.0, "y": 1.0, "z": 1.0})
    stretch = Vector((stretch_dict.get("x", 1.0), stretch_dict.get("y", 1.0), stretch_dict.get("z", 1.0)))

    # tamanho final escalado = size_raw * unit_scale * stretch (stretch e
    # adimensional, nao passa por unit_scale)
    size_scaled = Vector((
        size_raw.x * unit_scale * stretch.x,
        size_raw.y * unit_scale * stretch.y,
        size_raw.z * unit_scale * stretch.z,
    ))

    shape_type = shape.get("type")
    if shape_type == "box":
        return make_box_mesh(name, size_scaled, size_raw, shape, atlas_w, atlas_h, generate_uvs)
    if shape_type == "quad":
        return make_quad_mesh(name, shape, size_scaled, size_raw, atlas_w, atlas_h, generate_uvs)

    raise ValueError(
        f"Peca {name!r} tem shape.type={shape_type!r}, sem gerador conhecido (so 'box'/'quad' sao "
        "suportados). Isso indica um tipo de shape novo no arquivo de origem que ainda nao foi visto/tratado."
    )
