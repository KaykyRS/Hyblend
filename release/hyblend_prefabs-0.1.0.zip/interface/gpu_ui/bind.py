"""Ponte entre os widgets (Python puro) e o Blender (RNA + operadores).

Versão enxuta do bind.py do Hyblend Toolkit: o Prefabs não tem sistema de
tradução (UI em inglês), então `UI.t` não existe -- as páginas escrevem o
texto direto. Regra igual à do painel clássico: NENHUMA lógica de import
mora aqui; a UI só lê as MESMAS properties e chama os MESMOS operadores
(pelo bl_idname) que interface/__init__.py usa.

`UI` é criado uma vez por reconstrução da árvore (ver app.build).
"""

import traceback

import bpy

from .framework.core import Button, Column, Style
from .widgets import CONTROL_H, CheckBox, CompactButton, SectionHeader, compact_tooltip, icon_button, labeled


# --------------------------------------------------------------------------
# RNA / operadores
# --------------------------------------------------------------------------

def rna_prop(owner, prop):
    try:
        return owner.bl_rna.properties[prop]
    except (KeyError, AttributeError, ReferenceError):
        return None


def prop_description(owner, prop):
    p = rna_prop(owner, prop)
    return p.description if p is not None else ""


def owner_key(owner, prop, index=None):
    try:
        base = "%x" % owner.as_pointer()
    except (AttributeError, ReferenceError):
        base = str(id(owner))
    return "p.%s.%s%s" % (base, prop, "" if index is None else "[%d]" % index)


def _idname_call(idname):
    mod, name = idname.split(".", 1)
    return getattr(getattr(bpy.ops, mod), name)


def _undo_push(message):
    try:
        bpy.ops.ed.undo_push(message=message)
    except Exception:
        pass


# --------------------------------------------------------------------------
# UI: o "layout" das páginas
# --------------------------------------------------------------------------

class UI:
    def __init__(self, f):
        self.f = f
        self.context = f.context
        self.wm = f.context.window_manager
        self.state = f.state
        self.theme = f.theme

    # ---- contexto para rodar operadores ----
    def override(self):
        """Operadores rodam como se o botão estivesse na sidebar (igual ao
        painel clássico): janela + área da View3D + região UI."""
        host = getattr(self.f, "host", None)
        found = host.lookup() if host is not None else None
        if not found:
            return {}
        window, area, sidebar, _viewport = found
        return {"window": window, "area": area, "region": sidebar}

    def run_op(self, f, idname, props=None, label="", toast=False, invoke=True):
        try:
            call = _idname_call(idname)
            with bpy.context.temp_override(**self.override()):
                result = call("INVOKE_DEFAULT" if invoke else "EXEC_DEFAULT", True, **(props or {}))
        except RuntimeError as error:
            # report ERROR do operador vira RuntimeError no bpy.ops
            message = str(error).split("\n")[0].replace("Error: ", "").strip()
            f.toast(message or label, error=True)
            return None
        except Exception as error:
            traceback.print_exc()
            f.toast("Error: %s" % error, error=True)
            return None
        if toast and "FINISHED" in result:
            f.toast(label)
        return result

    def op_poll(self, idname):
        try:
            return bool(_idname_call(idname).poll())
        except Exception:
            return False

    @staticmethod
    def op_description(idname):
        """Tooltip igual ao do botão clássico (bl_description do operador)."""
        def text():
            try:
                return _idname_call(idname).get_rna_type().description
            except Exception:
                return ""
        return text

    def op(self, key, idname, text="", icon=None, props=None, variant="secondary", enabled=True,
           height=None, style=None, tooltip=None, toast=False, flex=None, invoke=True, compact=False):
        """compact=True: vira só ícone quando o texto não cabe (CompactButton)."""
        ok = enabled and self.op_poll(idname)
        st = style or Style(height=height or CONTROL_H, flex=flex or 0.0,
                            width=(height or CONTROL_H) if (not text and icon) else None)

        def click(f):
            self.run_op(f, idname, props, label=text or idname, toast=toast, invoke=invoke)

        if compact and icon and text:
            button = CompactButton(key, text, click, icon=icon, variant=variant, enabled=ok, style=st)
            button.tooltip = compact_tooltip(button, tooltip or self.op_description(idname))
            return button
        return Button(key, text, click, icon=icon, variant=variant, enabled=ok, style=st,
                      tooltip=tooltip or self.op_description(idname))

    def url_button(self, key, url, text="", icon=None, image=None, flex=None):
        from .pages.common import ImageButton
        enabled = bool(url)

        def click(f):
            self.run_op(f, "wm.url_open", {"url": url})
        return ImageButton(key, text, click, icon=icon, image=image, enabled=enabled,
                           tooltip=url or None, style=Style(height=CONTROL_H, flex=flex or 0.0,
                                                            width=None if text else CONTROL_H + 2))

    # ---- escrita em property ----
    def set(self, f, owner, prop, value, final=True):
        try:
            setattr(owner, prop, value)
        except (ReferenceError, AttributeError):
            return False
        except (TypeError, ValueError) as error:
            f.toast(str(error), error=True)
            return False
        if final:
            p = rna_prop(owner, prop)
            _undo_push(p.name if p is not None and p.name else prop)
        return True

    def check(self, owner, prop, key=None, tooltip=None, enabled=True):
        return CheckBox(key or owner_key(owner, prop), bool(getattr(owner, prop)),
                        lambda f, v: self.set(f, owner, prop, v),
                        tooltip=tooltip or (lambda: prop_description(owner, prop)), enabled=enabled)

    # ---- seções recolhíveis ----
    def is_open(self, key, default):
        return bool(self.state.get("_sec." + key, default))

    def section(self, key, title, icon, build_content, default_open=True, right=None, tooltip=None,
                plain=False, color=None):
        """Seção recolhível. O aberto/fechado mora no estado do host (o
        painel clássico usa o layout.panel() do Blender, que não dá pra ler
        daqui) -- vale enquanto a sidebar estiver aberta nesta sessão."""
        state_key = "_sec." + key
        is_open = self.is_open(key, default_open)

        def toggle(f, value):
            f.state[state_key] = value

        header = SectionHeader("sec." + key, title, is_open, toggle, icon=icon, right=right, tooltip=tooltip,
                               plain=plain, color=color)
        if not is_open:
            return header
        content = build_content()
        if isinstance(content, (list, tuple)):
            content = Column([c for c in content if c is not None], style=Style(gap=6))
        return Column(header, Column(content, style=Style(padding=(4, 2, 0, 2), gap=6)), style=Style(gap=4))

    def labeled(self, label, *controls, split=0.38, tooltip=None):
        return labeled(label, *controls, split=split, tooltip=tooltip)

    def icon_button(self, key, icon, on_click, tooltip=None, enabled=True, selected=False):
        return icon_button(key, icon, on_click, tooltip=tooltip, enabled=enabled, selected=selected)
