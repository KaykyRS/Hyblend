"""Home do Hyblend: tela inicial em tela cheia no visual do menu do Hytale. Só existe com a UI por GPU e o jogo achado.
  __init__.py   disponibilidade, estado (welcome.json), splash, cobertura escura do startup, operador + menu File
  actions.py    ações dos botões    data.py  recentes + miniatura do .blend e conteúdo placeholder
  thumbs.py     miniaturas em 640 px a cada save    releases.py  Changelog = releases do GitHub
  addons.py     aba Add-ons: baixa/instala/atualiza/liga/desinstala os addons Hyblend pelos releases
  videos.py     Aprender = videos.json do GitHub (gerado pela Action) + miniaturas do YouTube em cache
Tela: gpu_ui/pages/home_page.py; host: gpu_ui/home_host.py. Quando abre: ver welcome._boot_tick
(abertura do Blender, se "Mostrar ao abrir"; nunca ao instalar; na mão em File > Hyblend Home).
O splash do Blender fica desligado no 5.0+ (original em welcome.json, volta ao desabilitar).
"""

import time

import bpy

from ...common import ADDON_PACKAGE

# --- Textos / Preferences ---


def t(key, lang=None):
    """Texto traduzido no idioma do addon (Preferences > Language)."""
    from ...translations import get_language, tr
    return tr(key, lang or get_language(bpy.context))


def language(context=None):
    from ...translations import get_language
    return get_language(context or bpy.context)


def prefs(context=None):
    addon = (context or bpy.context).preferences.addons.get(ADDON_PACKAGE)
    return addon.preferences if addon is not None else None


# --- Disponibilidade ---

def supported():
    """UI por GPU registrada (Blender >= gpu_ui.MIN_BLENDER)."""
    from .. import gpu_ui
    return gpu_ui.is_registered()


def game_found():
    from ..gpu_ui import game
    return game.hytale_dir() is not None


def is_registered():
    """Home registrada (Blender 5.0+): o splash do Blender está nas mãos dela."""
    return _registered


def available():
    """A Home pode abrir agora (Blender suportado + pasta do jogo)."""
    return _registered and supported() and game_found()


# --- Estado (welcome.json) ---

def show_on_startup():
    from .. import welcome
    return bool(welcome.state_value("home_startup"))


def set_show_on_startup(value):
    from .. import welcome
    welcome.set_state_value("home_startup", bool(value))


def wants_startup():
    """A Home é a tela de abertura (disponível + "Mostrar ao abrir")? Com
    isso o Welcome não abre sozinho no startup."""
    return available() and show_on_startup()


# --- Splash do Blender: desligado enquanto o addon está ativo (5.0+) ---

def disable_blender_splash():
    """Guarda o valor original (só na 1ª vez) e desliga o splash."""
    from .. import welcome
    view = bpy.context.preferences.view
    if welcome.state_value("splash_original") is None:
        welcome.set_state_value("splash_original", bool(view.show_splash))
    if view.show_splash:
        view.show_splash = False


def restore_blender_splash():
    """Desabilitou o addon: o splash volta ao que era antes."""
    from .. import welcome
    original = welcome.state_value("splash_original")
    if original is not None:
        try:
            bpy.context.preferences.view.show_splash = original
        except Exception:
            pass
        welcome.set_state_value("splash_original", None)


def splash_wanted():
    """O usuário tinha o splash do Blender ligado antes do addon?"""
    from .. import welcome
    if not _registered:
        return bool(bpy.context.preferences.view.show_splash)
    original = welcome.state_value("splash_original")
    return True if original is None else original


def show_native_splash(window=None):
    """Abre o splash do Blender na mão (a Home não abriu no startup)."""
    wm = bpy.context.window_manager
    if not wm or not wm.windows or not splash_wanted():
        return False
    window = window or wm.windows[0]
    try:
        with bpy.context.temp_override(window=window, screen=window.screen):
            bpy.ops.wm.splash("INVOKE_DEFAULT")
        return True
    except Exception as error:
        print("[Hyblend] splash:", error)
        return False


# --- Cobertura escura da inicialização: cobre as áreas até a Home ficar pronta (sem o cubo piscando) ---
# Topbar e status bar não têm tipo Python: ficam.

_COVER_SPACES = ("SpaceView3D", "SpaceOutliner", "SpaceProperties", "SpaceDopeSheetEditor", "SpaceGraphEditor",
                 "SpaceNLA", "SpaceImageEditor", "SpaceNodeEditor", "SpaceSequenceEditor", "SpaceClipEditor",
                 "SpaceTextEditor", "SpaceConsole", "SpaceInfo", "SpaceSpreadsheet", "SpaceFileBrowser")
_COVER_REGIONS = ("WINDOW", "HEADER", "TOOL_HEADER", "UI", "TOOLS", "CHANNELS", "FOOTER", "NAVIGATION_BAR",
                  "EXECUTE", "ASSET_SHELF", "ASSET_SHELF_HEADER", "HUD", "PREVIEW")
COVER_TIMEOUT = 8.0            # nunca fica preso: some sozinho depois disso
_cover = {"handles": [], "started": 0.0, "decided": False}


def _cover_draw(linear_window):
    import gpu
    from gpu_extras.batch import batch_for_shader
    region = bpy.context.region
    if region is None:
        return
    from ..gpu_ui.app import THEME
    color = THEME.canvas
    if linear_window and region.type == "WINDOW":      # viewport 3D: buffer linear (igual ao host)
        color = tuple(max(0.0, v) ** 2.2 for v in color[:3]) + (1.0,)
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    w, h = region.width, region.height
    batch = batch_for_shader(shader, "TRIS", {"pos": ((0, 0), (w, 0), (w, h), (0, h))},
                             indices=((0, 1, 2), (0, 2, 3)))
    gpu.state.blend_set("NONE")
    shader.bind()
    shader.uniform_float("color", color[:3] + (1.0,))
    batch.draw(shader)


def cover_start():
    if _cover["handles"] or bpy.app.background:
        return
    _cover["started"] = time.monotonic()
    _cover["decided"] = False
    for name in _COVER_SPACES:
        space = getattr(bpy.types, name, None)
        if space is None:
            continue
        for region_type in _COVER_REGIONS:
            try:
                handle = space.draw_handler_add(_cover_draw, (name == "SpaceView3D",), region_type, "POST_PIXEL")
            except (TypeError, ValueError):
                continue
            _cover["handles"].append((space, handle, region_type))
    if not bpy.app.timers.is_registered(_cover_watch):
        bpy.app.timers.register(_cover_watch, first_interval=0.05)


def cover_stop():
    for space, handle, region_type in _cover["handles"]:
        try:
            space.draw_handler_remove(handle, region_type)
        except (ValueError, ReferenceError):
            pass
    had = bool(_cover["handles"])
    _cover["handles"] = []
    if bpy.app.timers.is_registered(_cover_watch):
        bpy.app.timers.unregister(_cover_watch)
    if had:
        wm = bpy.context.window_manager
        for window in (wm.windows if wm else ()):
            for area in window.screen.areas:
                area.tag_redraw()


def cover_decided():
    """O boot já decidiu (abriu ou não a Home): a cobertura pode sair se a Home não estiver aberta."""
    _cover["decided"] = True


def _cover_watch():
    """Tira a cobertura quando a Home já desenha por conta própria (ou no tempo limite)."""
    from ..gpu_ui import home_host
    if not _cover["handles"]:
        return None
    gone = _cover["decided"] and not home_host.is_open()       # Home não abriu / fechou com erro
    if gone or home_host.is_ready() or time.monotonic() - _cover["started"] > COVER_TIMEOUT:
        cover_stop()
        return None
    return 0.05


# --- Abrir ---

def _main_window(preferred_ptr=None):
    from ..gpu_ui import home_host
    wm = bpy.context.window_manager
    windows = list(wm.windows) if wm else []
    if preferred_ptr:
        for window in windows:
            if window.as_pointer() == preferred_ptr and home_host._largest_view3d(window) is not None:
                return window
    with_view = [w for w in windows if home_host._largest_view3d(w) is not None]
    if not with_view:
        return None
    return max(with_view, key=lambda w: home_host._largest_view3d(w).width * home_host._largest_view3d(w).height)


def show(window_ptr=None, page=None):
    """Abre a Home AGORA (chamar de timer, fora de operador/desenho). False
    sem jogo / sem View3D / Blender sem a UI por GPU."""
    if not available():
        return False
    window = _main_window(window_ptr)
    if window is None:
        return False
    from ..gpu_ui import home_host
    from ..gpu_ui.pages import home_page
    home_page.on_open(page)
    return home_host.open_home(window)


def is_open():
    if not _registered:
        return False
    from ..gpu_ui import home_host
    return home_host.is_open()


_pending = []          # timers de show_later ainda não disparados (unregister limpa)


def show_later(window_ptr=None, delay=0.0, page=None):
    """Abre a Home num timer (fora de operador/desenho). page = página
    inicial ("CHANGELOG"...; None = a última da sessão)."""
    def run():
        if run in _pending:
            _pending.remove(run)
        show(window_ptr, page=page)
        return None
    _pending.append(run)
    bpy.app.timers.register(run, first_interval=delay)


class HYBLEND_OT_home(bpy.types.Operator):
    """File > Hyblend Home: abre a Home (precisa da pasta do Hytale)."""
    bl_idname = "hyblend.home"
    bl_label = "Hyblend Home"

    @classmethod
    def description(cls, context, properties):
        return t("home.tooltip.open_home")

    def execute(self, context):
        if not game_found():
            self.report({"WARNING"}, t("home.not_found"))
            return {"CANCELLED"}
        ptr = context.window.as_pointer() if context.window else None
        # FORA deste operador (timer): o tela cheia e o modal não abrem daqui de dentro
        show_later(ptr)
        return {"FINISHED"}


def _file_menu(self, context):
    self.layout.operator(HYBLEND_OT_home.bl_idname, text=t("home.menu_entry"), icon="HOME")
    self.layout.separator()


# --- Preferences (bloco "Home") ---

def draw_preferences(prefs_, layout, context, lang):
    """Conteúdo da aba "Home" (dentro de Experimental) -- a aba colapsável
    é montada por preferences.py."""
    from ...translations import tr
    box = layout.column()
    if not supported():
        from .. import gpu_ui
        box.label(text=tr("importer.prefs_gpu_ui_requires", lang).format(
            required="%d.%d" % gpu_ui.MIN_BLENDER[:2], current=bpy.app.version_string), icon="ERROR")
        return
    col = box.column()
    col.prop(prefs_, "home_startup", text=tr("importer.prefs_home_startup", lang))
    row = col.row(align=True)
    row.prop(prefs_, "home_background_mode", expand=True)
    row = col.row(align=True)
    row.active = prefs_.home_background_mode == "FIXED"
    row.prop(prefs_, "home_background", text="")
    row.prop(prefs_, "home_background_blur", toggle=True, text=tr("importer.prefs_home_blur", lang))
    col.prop(prefs_, "home_scale", text=tr("importer.prefs_home_scale", lang))
    row = col.row()
    row.prop(prefs_, "home_hires_thumbs", text=tr("importer.prefs_home_hires_thumbs", lang))
    from . import thumbs
    size = thumbs.cache_size()
    if size:
        row.label(text="%.1f MB" % (size / 1048576.0))
    open_row = col.row()
    open_row.enabled = game_found()
    open_row.operator(HYBLEND_OT_home.bl_idname, text=tr("importer.prefs_home_open", lang), icon="WINDOW")
    if not game_found():
        col.label(text=tr("home.not_found", lang), icon="INFO")


def on_look_changed(context):
    """update= das props home_* de aparência: Home aberta redesenha."""
    if _registered:
        from ..gpu_ui import home_host
        home_host.refresh_all()


def on_thumbs_changed(prefs_, context):
    """Desligou: apaga o cache (espaço de volta); os recentes voltam pra
    miniatura de 128 px de dentro do .blend."""
    from . import thumbs
    if not prefs_.home_hires_thumbs:
        thumbs.clear_cache()
    if is_open():
        from . import data
        from ..gpu_ui import home_host
        data.refresh()
        home_host.refresh_all()


# --- Registro ---

_registered = False


def register(startup):
    """Chamado por interface/__init__.py DEPOIS do gpu_ui. `startup` = carga
    dos addons na abertura do Blender (welcome._registered_by_session_load)."""
    global _registered
    if not supported() or _registered:
        return
    from . import thumbs
    bpy.utils.register_class(HYBLEND_OT_home)
    bpy.types.TOPBAR_MT_file.prepend(_file_menu)
    thumbs.register()
    _registered = True
    if bpy.app.background:
        return
    disable_blender_splash()
    if startup and show_on_startup() and game_found():
        cover_start()          # a Home deve abrir: nada do cubo antes dela (sai sozinha se não abrir)


def unregister():
    global _registered
    from . import addons, data, releases, thumbs, videos
    # Buscas/downloads pela metade saem SEMPRE (mesmo sem a Home: a aba Add-ons das Preferences do 4.5 usa addons.py).
    releases.cancel()
    videos.cancel()
    addons.cancel()
    if not _registered:
        return
    for fn in _pending:
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    _pending.clear()
    cover_stop()
    data.cancel_timers()
    thumbs.unregister()
    bpy.types.TOPBAR_MT_file.remove(_file_menu)
    bpy.utils.unregister_class(HYBLEND_OT_home)
    if not bpy.app.background:
        restore_blender_splash()
    _registered = False
