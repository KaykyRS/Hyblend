"""interface/gpu_ui/ -- N-Panel EXPERIMENTAL desenhado com gpu/blf.

Alternativa ao painel clássico (interface/__init__.py), NÃO substituto:
  * liga/desliga em Preferences > "Experimental GPU Interface"
    (`use_gpu_ui`, LIGADO por padrão no 5.0+). A escolha é UMA pra todos
    os addons Hyblend (hyblend_hub.py): ligar aqui liga no CC/Prefabs;
  * só roda no Blender >= MIN_BLENDER (5.0). Antes disso a opção aparece
    travada e o painel clássico continua sozinho;
  * com ela ligada, o painel clássico some (poll de HYTALE_PT_main) e
    este desenha na mesma aba "Hyblend";
  * com outros addons Hyblend instalados, a aba é dividida: a faixa do
    seletor (framework/switcher.py) fica no topo e só o host do addon
    escolhido aparece (runtime.register(active=...)).

Mesmas funções da UI clássica: as páginas (pages/) só leem as MESMAS
properties e chamam os MESMOS operadores pelo bl_idname -- nenhuma lógica
de import/export/rig mora aqui.

Arquivos:
  framework/   mini framework genérico (portado do protótipo "Mini GPU UI"):
               layout flex, widgets base, shaders, runtime (modal + draw
               handlers + cache em textura), navegador, ícones procedurais
  widgets.py   widgets do Hyblend (campo numérico, dropdown, lista, card...)
  bind.py      ponte widgets <-> RNA/operadores (UI.op, UI.enum, UI.number...)
  pages/       uma página por aba do painel clássico
  app.py       a tela (cabeçalho + abas + página + toast)
  pages/welcome_page.py  janela de boas-vindas (versão GPU; a lógica e a
               versão nativa ficam em interface/welcome.py), desenhada
               pela janela flutuante framework/overlay.py
  game.py      arte e fontes do Hytale lidas da pasta do jogo (tabelas ART,
               GLYPH_ICONS, FONT_FILES); sem a pasta, tudo procedural/Geist
  hytale_install.py  mapa da pasta de instalação (Python puro, do CC)
  home_host.py tela cheia da Home (0.9.5), irmão do framework/overlay.py;
               a página é pages/home_page.py, os dados/ações interface/home/
  markdown.py, richtext.py  Markdown das releases (Changelog da Home) ->
               texto formatado
  fonts/       Geist (OFL, ver fonts/OFL-Geist.txt) -- reserva sem o jogo
  icons/       máscaras PNG dos ícones procedurais (framework/icons.py gera:
               python interface/gpu_ui/framework/icons.py)

Pra REMOVER esta UI do addon: apagar esta pasta E interface/home/ (a Home
só existe em cima dela) e desfazer os pontos que a citam fora dela (todos
marcados com "gpu_ui"). Atenção: interface/welcome.py usa
game.py/hytale_install.py daqui pra achar a pasta do jogo -- mover esses
dois pra fora antes (sem eles, a janela de boas-vindas fica só na versão
nativa e sem "Localizar jogo"):
  interface/__init__.py  -> import, poll() do HYTALE_PT_main, register/unregister
  importer/preferences.py -> props gpu_ui_*, home_*, hytale_path(_mode) e os blocos no draw()
  interface/welcome.py    -> decisão Home x Welcome no _boot_tick
  translations/*.py       -> keys "gpu_ui.*", "home.*", "importer.prefs_gpu_ui*", "importer.prefs_home*"
"""

import sys

import bpy

from ... import hyblend_hub
from ...common import ADDON_PACKAGE, HUB_ID, game_found

MIN_BLENDER = (5, 0, 0)   # era 5.2; baixado na 0.9.4 (nada no framework exige o 5.2)

_registered = False


def is_supported():
    return bpy.app.version >= MIN_BLENDER


def _prefs(context=None):
    context = context or bpy.context
    try:
        return context.preferences.addons[ADDON_PACKAGE].preferences
    except (KeyError, AttributeError):
        return None


def is_registered():
    """Framework da UI por GPU carregado (Blender suportado)? Vale pra
    janela de boas-vindas também, independente do N-Panel ligado."""
    return _registered


def open_welcome(window, area):
    """Janela de boas-vindas (versão GPU) centralizada na View3D `area`."""
    if not _registered or window is None or area is None:
        return False
    from . import app
    from .framework import overlay
    from .pages import welcome_page
    return overlay.open_overlay("welcome", window, area, welcome_page.build, theme=app.THEME, text=_text,
                                scale=_welcome_scale, width=welcome_page.WIDTH, on_close=welcome_page.release)


def _welcome_scale(context):
    """Tamanho da janela de boas-vindas (Preferences > Janela de boas-vindas),
    independente da escala do N-Panel."""
    from ..welcome import size_factor
    return size_factor(context)


def _home_scale(context):
    """Tamanho da Home (Preferences > Home > Escala), por cima da escala do Blender."""
    prefs = _prefs(context)
    return getattr(prefs, "home_scale", 1.0) if prefs is not None else 1.0


def is_enabled(context=None):
    """True = a UI por GPU está ativa (preference ligada E Blender suporta)."""
    if not (_registered and is_supported()):
        return False
    prefs = _prefs(context)
    return bool(prefs is not None and getattr(prefs, "use_gpu_ui", False))


def set_enabled(context, value):
    prefs = _prefs(context)
    if prefs is not None:
        prefs.use_gpu_ui = bool(value)     # o set= do hub avisa todos os addons (on_preference_changed)


def classic_module():
    """interface/__init__.py (painel clássico) -- constantes da aba Info
    e os ícones de marca já carregados por ele."""
    return sys.modules[__package__.rpartition(".")[0]]


# --------------------------------------------------------------------------
# Chamado pelas Preferences (importer/preferences.py) -- import tardio lá
# --------------------------------------------------------------------------

def on_preference_changed(context):
    """Ligou/desligou a UI, ou mudou escala/tamanho."""
    if _registered:
        from .framework import runtime
        if not is_enabled(context):
            runtime.shutdown_all()           # derruba hosts e draw handlers
        else:
            prefs = _prefs(context)
            runtime.apply_size("width", prefs.gpu_ui_panel_width)
            runtime.apply_size("height", prefs.gpu_ui_panel_height)
    hyblend_hub.redraw_view3d(context)


def hub_refresh():
    """Aviso do hub (addon entrou/saiu, troca no seletor): reconstruir."""
    if _registered:
        from .framework import runtime
        for host in list(runtime._HOSTS.values()):
            host.invalidate()


def host_ok(context):
    """O host desta sidebar NÃO está quebrado (com erro, o painel-gancho
    mostra o aviso nativo -- e o seletor nativo volta junto)."""
    if not _registered:
        return False
    from .framework import runtime
    return runtime.host_status(context) != "ERROR"


def _hub_pick(f, ident):
    hyblend_hub.set_active(ident, f.context)


def _hub_resolve(ref):
    from . import game
    return game.file(ref)


def _build(f):
    """Tela do Toolkit + faixa do seletor dos addons Hyblend em cima (só com
    2+ addons; sozinho, a árvore é exatamente a de antes)."""
    from . import app
    from .framework import switcher
    root = app.build(f)
    if not hyblend_hub.switcher_visible():
        return root
    return switcher.wrap(f, root, hyblend_hub.entries(f.context), _hub_pick, _hub_resolve)


def _hub_active():
    return hyblend_hub.is_active(HUB_ID)


def on_hytale_path_changed(context):
    """Pasta/modo do Hytale mudou: esquece o caminho resolvido; o próximo
    build troca arte e fontes (game.sync) -- a assinatura do app muda."""
    from . import game
    game.invalidate()
    if _registered and not game_found():
        from .framework import runtime
        runtime.shutdown_all()          # jogo "sumiu": o N-Panel por GPU sai junto com a aba
    hyblend_hub.redraw_view3d(context)


def draw_preferences(prefs, layout, context, lang):
    """Conteúdo da aba "Interface por GPU" (dentro de Experimental) -- a
    aba colapsável é montada por importer/preferences.py. O desenho é o do
    hub (IGUAL no CC e no Prefabs), com os textos traduzidos."""
    from ...translations import tr
    hyblend_hub.draw_gpu_settings(layout, prefs, is_supported(), MIN_BLENDER, texts={
        "use": tr("importer.prefs_gpu_ui", lang), "requires": tr("importer.prefs_gpu_ui_requires", lang),
        "size": tr("importer.prefs_gpu_ui_scale", lang), "width": tr("importer.prefs_gpu_ui_width", lang),
        "height": tr("importer.prefs_gpu_ui_height", lang)})


# --------------------------------------------------------------------------
# Ligação com o runtime
# --------------------------------------------------------------------------

def _extra_scale(context):
    prefs = _prefs(context)
    return prefs.gpu_ui_scale if prefs is not None else 1.0


_SIZE_PROPS = {"width": "gpu_ui_panel_width", "height": "gpu_ui_panel_height"}


def _get_size(context, axis):
    prefs = _prefs(context)
    return getattr(prefs, _SIZE_PROPS[axis]) if prefs is not None else 0.0


def _set_size(context, axis, value):
    prefs = _prefs(context)
    if prefs is not None:
        setattr(prefs, _SIZE_PROPS[axis], value)   # salvo com as preferências do Blender


def _text(key):
    from ...translations import get_language, tr
    return tr(key, get_language(bpy.context))


# --------------------------------------------------------------------------
# Painel-gancho
# --------------------------------------------------------------------------

class HYBLEND_OT_gpu_ui_retry(bpy.types.Operator):
    bl_idname = "hyblend.gpu_ui_retry"
    bl_label = "Retry"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        from .framework import runtime
        runtime.clear_error(context)
        if context.region is not None:
            context.region.tag_redraw()
        return {"FINISHED"}


class HYBLEND_OT_gpu_ui_disable(bpy.types.Operator):
    bl_idname = "hyblend.gpu_ui_disable"
    bl_label = "Use Classic Interface"
    bl_description = "Turn off the GPU interface (in all Hyblend addons) and go back to the classic panel"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        set_enabled(context, False)
        return {"FINISHED"}


def _make_host_panel():
    from .framework import runtime

    class HYBLEND_PT_gpu_ui_host(bpy.types.Panel):
        """Não desenha nada útil: só avisa o runtime que a aba está visível
        (o painel de verdade é desenhado por cima, via draw handler)."""
        bl_space_type = "VIEW_3D"
        bl_region_type = "UI"
        bl_category = runtime.CATEGORY
        bl_label = "Hyblend GPU UI"
        bl_options = {"HIDE_HEADER"}

        @classmethod
        def poll(cls, context):
            # sem o jogo: aba some (common.game_found); com outros addons
            # Hyblend: só se o Toolkit é o escolhido no seletor
            return is_enabled(context) and game_found() and hyblend_hub.is_active(HUB_ID, context)

        def draw(self, context):
            runtime.ensure_host(context)
            status = runtime.host_status(context)
            if status == "READY":            # o normal: nada embaixo do host (sem montar os textos)
                return
            # Erro / montando: o desenho do hub, IGUAL nos addons Hyblend.
            hyblend_hub.draw_gpu_host_status(self.layout, status, runtime.host_error(context),
                                             HYBLEND_OT_gpu_ui_retry.bl_idname, HYBLEND_OT_gpu_ui_disable.bl_idname,
                                             texts={k: _text("gpu_ui." + k) for k in ("failed", "retry", "use_classic", "loading")})

    return HYBLEND_PT_gpu_ui_host


_classes = []
_ICON_ALIASES = {"experimental": "warning"}      # aviso "experimental" (jogo: WIPLogo)


def register():
    """Só registra algo no Blender suportado -- abaixo de 5.0 nem os
    shaders/handlers da UI por GPU são carregados."""
    global _registered
    if not is_supported() or _registered:
        return
    from . import framework
    # Framework unificado (igual nos 3 addons): nomes deste addon.
    framework.configure(namespace="hyblend", label="Hyblend GPU UI", font_copy_dir="hyblend_toolkit_fonts")
    from . import app, game, home_host
    from .framework import core, icons, overlay, renderer, runtime
    from .pages import home_page
    # Nomes de ícone só do app, sem desenho procedural próprio: a reserva
    # (sem a pasta do jogo) é o desenho de outro nome.
    for name, fallback in _ICON_ALIASES.items():
        icons._ICONS.setdefault(name, icons._ICONS[fallback])
    icons.ALIASES.update(_ICON_ALIASES)                    # máscara pronta: usa o PNG do desenho de origem
    runtime.register(_build, _extra_scale, _get_size, _set_size, app.signature, _text, theme=app.THEME,
                     active=_hub_active)
    overlay.register()                                     # janelas flutuantes (boas-vindas)
    home_host.configure(home_page.build, app.THEME, scale=_home_scale, text=_text, on_close=home_page.release)
    home_host.register()                                   # Home em tela cheia (interface/home/)
    renderer.set_image_icon_resolver(game.glyph_icon)     # ícones do jogo (procedural sem a pasta)
    core.set_skin(game.skin_part)                          # arte do jogo por peça (idem)
    _classes[:] = [HYBLEND_OT_gpu_ui_retry, HYBLEND_OT_gpu_ui_disable, _make_host_panel()]
    for cls in _classes:
        bpy.utils.register_class(cls)
    if not bpy.app.timers.is_registered(game.autodetect_on_startup):
        bpy.app.timers.register(game.autodetect_on_startup, first_interval=0.5, persistent=True)
    _registered = True


def unregister():
    global _registered
    if not _registered:
        return
    from . import game, home_host
    from .framework import core, overlay, renderer, runtime
    if bpy.app.timers.is_registered(game.autodetect_on_startup):
        bpy.app.timers.unregister(game.autodetect_on_startup)
    renderer.set_image_icon_resolver(None)
    core.set_skin(None)
    game.invalidate()
    game.forget_sync()
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    _classes.clear()
    home_host.unregister()
    overlay.unregister()
    runtime.unregister()
    _registered = False
