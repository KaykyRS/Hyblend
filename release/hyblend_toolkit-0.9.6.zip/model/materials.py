"""Materiais do import (4.5 e 5.x): textura chapada, textura tingida por gradiente (Greyscale + rampa do
GradientSet) e as versões sem luz pra miniatura. Textura pixel art: sempre "Closest"."""

import os

import bpy


# --- Compatibilidade 4.5 <-> 5.x ---

def node_tree(material):
    """A árvore do material (4.5: nasce sem ela até ligar use_nodes; 5.x: já existe, use_nodes é deprecado)."""
    if material.node_tree is None:
        try:
            material.use_nodes = True
        except AttributeError:
            pass
    return material.node_tree


def _find(nodes, node_type):
    return next((n for n in nodes if n.type == node_type), None)


def alpha_clip(material):
    """Transparência recortada no EEVEE (4.2+: surface_render_method; antes: blend_method)."""
    for attr, value, old_attr, old_value in (("surface_render_method", "DITHERED", "blend_method", "CLIP"),
                                             ("use_transparent_shadow", True, "shadow_method", "CLIP")):
        target, val = (attr, value) if hasattr(material, attr) else (old_attr, old_value)
        try:
            setattr(material, target, val)
        except (AttributeError, TypeError):
            pass


def set_non_color(image):
    """Imagem como dado (luminância usada como coordenada da rampa, sem gamma)."""
    settings = image.colorspace_settings
    for name in ("Non-Color", "Generic Data", "Raw", "Data"):
        try:
            settings.name = name
            return True
        except TypeError:
            continue
    try:
        settings.is_data = True
        return True
    except (AttributeError, TypeError):
        return False


# --- Imagens ---

def load_image(path):
    """Imagem do disco (reaproveita a já carregada) ou None."""
    if not path or not os.path.isfile(bpy.path.abspath(str(path))):
        return None
    try:
        return bpy.data.images.load(str(path), check_existing=True)
    except RuntimeError:
        return None


def placeholder_image(width, height):
    image = bpy.data.images.new("Hytale_Placeholder", width=max(int(width), 1), height=max(int(height), 1),
                                alpha=True)
    image.generated_color = (0.6, 0.6, 0.6, 1.0)
    return image


def material_name(image):
    """Nome curto: o arquivo sem extensão (dois "Brown.png" de pastas diferentes: o material ganha ".001")."""
    if image is None:
        return "Hytale_Material"
    return os.path.splitext(bpy.path.basename(image.filepath) or image.name)[0]


def _image_node(nodes, image, location, interpolation="Closest"):
    node = nodes.new("ShaderNodeTexImage")
    node.image = image
    node.interpolation = interpolation
    node.location = location
    return node


# --- Materiais ---

def flat_material(image, name=None, variants=()):
    """Imagem -> Base Color + Alpha (Principled sem brilho). `variants` = outras imagens como nodes soltos
    (trocar à mão no navegador do node). Sem imagem: placeholder cinza."""
    mat = bpy.data.materials.new(name or material_name(image))
    tree = node_tree(mat)
    nodes, links = tree.nodes, tree.links
    bsdf = _find(nodes, "BSDF_PRINCIPLED")
    output = _find(nodes, "OUTPUT_MATERIAL")
    if output is None:
        output = nodes.new("ShaderNodeOutputMaterial")
        output.location = (300, 0)
    if bsdf is None:
        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.location = (0, 0)
        links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    if "Roughness" in bsdf.inputs:
        bsdf.inputs["Roughness"].default_value = 1.0
    specular = bsdf.inputs.get("Specular IOR Level") or bsdf.inputs.get("Specular")
    if specular is not None:
        specular.default_value = 0.0
    tex = _image_node(nodes, image, (bsdf.location.x - 300, bsdf.location.y))
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
    for i, extra in enumerate(variants, start=1):
        node = _image_node(nodes, extra, (tex.location.x, tex.location.y - 260 * i))
        node.label = extra.name
    alpha_clip(mat)
    return mat


def _gradient_chain(nodes, links, greyscale, ramp):
    """Greyscale (luminância) -> X da busca na rampa (gradient map: a cor vem da rampa, a sombra da máscara)."""
    set_non_color(greyscale)
    grey = _image_node(nodes, greyscale, (-600, 0))
    grey.label = "Greyscale"
    sep = nodes.new("ShaderNodeSeparateColor")
    sep.location = (-350, 0)
    links.new(grey.outputs["Color"], sep.inputs["Color"])
    combine = nodes.new("ShaderNodeCombineXYZ")
    combine.location = (-150, 0)
    links.new(sep.outputs["Red"], combine.inputs["X"])
    ramp_node = _image_node(nodes, ramp, (50, 0), interpolation="Linear")
    ramp_node.extension = "EXTEND"
    ramp_node.label = "Gradient"
    links.new(combine.outputs["Vector"], ramp_node.inputs["Vector"])
    return grey, ramp_node


def _clean_material(name):
    mat = bpy.data.materials.new(name)
    tree = node_tree(mat)
    tree.nodes.clear()
    return mat, tree.nodes, tree.links


def gradient_material(name, greyscale, ramp):
    """Textura tingida: Greyscale + rampa do GradientSet -> Principled. Devolve (material, node da rampa)."""
    mat, nodes, links = _clean_material(name)
    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (600, 0)
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (350, 0)
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    grey, ramp_node = _gradient_chain(nodes, links, greyscale, ramp)
    links.new(grey.outputs["Alpha"], bsdf.inputs["Alpha"])
    links.new(ramp_node.outputs["Color"], bsdf.inputs["Base Color"])
    alpha_clip(mat)
    return mat, ramp_node


def _unlit_end(nodes, links, color_out, alpha_out, x):
    """Emission + Transparent no Output: a cor aparece como é, sem luz da cena (miniatura)."""
    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (x + 500, 0)
    emission = nodes.new("ShaderNodeEmission")
    emission.location = (x, 100)
    links.new(color_out, emission.inputs["Color"])
    transparent = nodes.new("ShaderNodeBsdfTransparent")
    transparent.location = (x, -100)
    mix = nodes.new("ShaderNodeMixShader")
    mix.location = (x + 250, 0)
    links.new(alpha_out, mix.inputs["Fac"])
    links.new(transparent.outputs["BSDF"], mix.inputs[1])
    links.new(emission.outputs["Emission"], mix.inputs[2])
    links.new(mix.outputs["Shader"], output.inputs["Surface"])


def flat_preview_material(image, name=None):
    mat, nodes, links = _clean_material(name or material_name(image) + "_Preview")
    tex = _image_node(nodes, image, (-400, 0))
    _unlit_end(nodes, links, tex.outputs["Color"], tex.outputs["Alpha"], -100)
    alpha_clip(mat)
    return mat


def gradient_preview_material(name, greyscale, ramp):
    mat, nodes, links = _clean_material(name)
    grey, ramp_node = _gradient_chain(nodes, links, greyscale, ramp)
    _unlit_end(nodes, links, ramp_node.outputs["Color"], grey.outputs["Alpha"], 250)
    alpha_clip(mat)
    return mat, ramp_node
