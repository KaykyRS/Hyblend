"""Textura de um modelo solto no disco (File > Import): busca automática do PNG ao lado do modelo e a mensagem
do resultado. O import pelo Assets.zip não usa isto: o JSON do jogo já diz qual textura."""

import os

import bpy

from ..translations import tr

# Limite de arquivos olhados na busca na pasta acima (pode ser um resource pack grande).
PARENT_SEARCH_MAX_FILES = 20000


def clean_path(path):
    """Tira aspas e espaços das pontas ("Copiar como caminho" do Windows vem com aspas)."""
    if not path:
        return path
    path = path.strip()
    if len(path) >= 2 and path[0] == path[-1] and path[0] in ("\"", "'"):
        path = path[1:-1].strip()
    return path


def _pngs(folder, accept=lambda name: True):
    try:
        names = sorted(os.listdir(folder))
    except OSError:
        return []
    return [os.path.join(folder, n) for n in names if n.lower().endswith(".png") and accept(n)]


def discover_strict(dirname, model_name):
    """Como o plugin oficial: PNGs da pasta que começam com o nome do modelo (ou "Texture.png") e a pasta
    "{Modelo}_Textures/". Todos (variantes), sem repetir."""
    if not dirname or not os.path.isdir(dirname):
        return []
    paths = _pngs(dirname, lambda n: n.startswith(model_name) or n == "Texture.png")
    folder = os.path.join(dirname, f"{model_name}_Textures")
    if os.path.isdir(folder):
        paths += _pngs(folder)
    return list(dict.fromkeys(paths))


def discover_loose(dirname, model_name):
    """Extra nossa: a ÚNICA pasta irmã "*_Textures" (ex.: Player_With_Face usa Player_Textures/). Mais de uma =
    ambíguo, não adivinha."""
    if not dirname or not os.path.isdir(dirname):
        return []
    try:
        entries = os.listdir(dirname)
    except OSError:
        return []
    folders = [os.path.join(dirname, e) for e in entries
               if e.endswith("_Textures") and os.path.isdir(os.path.join(dirname, e))]
    return _pngs(folders[0]) if len(folders) == 1 else []


def _name_prefixes(model_name):
    """Do mais pro menos específico (bulbasaur_male -> bulbasaur)."""
    parts = model_name.split("_")
    return ["_".join(parts[:len(parts) - cut]) for cut in range(len(parts)) if parts[:len(parts) - cut]]


def collect_pngs(folders):
    """PNGs das pastas e subpastas, em ordem de nome; para em PARENT_SEARCH_MAX_FILES."""
    pngs = []
    seen = 0
    for folder in folders:
        for dirpath, dirnames, files in os.walk(folder):
            dirnames.sort()
            for fname in sorted(files):
                seen += 1
                if fname.lower().endswith(".png"):
                    pngs.append(os.path.join(dirpath, fname))
            if seen > PARENT_SEARCH_MAX_FILES:
                return pngs
    return pngs


def match_by_name(pngs, model_name):
    """PNGs que começam com o nome do modelo (ou ele cortado em "_xxx"); o nível mais específico vence e o nome
    exato vem primeiro (vira a textura ligada)."""
    for prefix in _name_prefixes(model_name):
        low = prefix.lower()
        matches = [p for p in pngs if os.path.basename(p).lower().startswith(low)]
        if matches:
            exact = [p for p in matches if os.path.splitext(os.path.basename(p))[0].lower() == low]
            return exact + [p for p in matches if p not in exact]
    return []


def discover_parent(dirname, model_name):
    """Último passo: pastas com "texture" no nome UM nível acima (e subpastas), filtradas pelo nome do modelo."""
    if not dirname or not model_name:
        return []
    here = os.path.normpath(os.path.abspath(dirname))
    parent = os.path.dirname(here)
    if not parent or parent == here:
        return []
    try:
        siblings = sorted(os.listdir(parent))
    except OSError:
        return []
    folders = [os.path.join(parent, e) for e in siblings
               if "texture" in e.lower() and os.path.isdir(os.path.join(parent, e))
               and os.path.normpath(os.path.join(parent, e)) != here]
    return match_by_name(collect_pngs(folders), model_name)


def resolve(model_filepath, texture_mode, manual_path, model_name):
    """(caminhos, camada). MANUAL: o arquivo, ou os PNGs da pasta filtrados pelo nome. AUTO: estrita -> LOOSE ->
    PARENT. Camadas: MANUAL, MANUAL_FOLDER(_EMPTY), STRICT, LOOSE, PARENT, NONE. O preferido vem primeiro."""
    if texture_mode == "MANUAL":
        manual_path = clean_path(manual_path)
        if not manual_path:
            return [], "NONE"
        folder = bpy.path.abspath(manual_path)
        if os.path.isdir(folder):
            found = match_by_name(collect_pngs([folder]), model_name)
            return (found, "MANUAL_FOLDER") if found else ([], "MANUAL_FOLDER_EMPTY")
        return [manual_path], "MANUAL"

    dirname = os.path.dirname(model_filepath)
    candidates, tier = discover_strict(dirname, model_name), "STRICT"
    if not candidates:
        candidates, tier = discover_loose(dirname, model_name), "LOOSE"
    if not candidates:
        candidates = discover_parent(dirname, model_name)
        return (candidates, "PARENT") if candidates else ([], "NONE")
    preferred = next((p for p in candidates if os.path.splitext(os.path.basename(p))[0].startswith(model_name)), None)
    if preferred:
        candidates = [preferred] + [p for p in candidates if p != preferred]
    return candidates, tier


def report(texture_mode, tier, paths, model_name):
    """(nível, key de tradução, campos) do resultado da busca, ou None (Manual sem nada escolhido)."""
    if texture_mode == "MANUAL" and tier == "NONE":
        return None
    extra = max(len(paths) - 1, 0)
    fields = {"name": os.path.basename(paths[0]) if paths else "", "model": model_name, "extra": extra,
              "path": paths[0] if paths else ""}
    if tier == "MANUAL" and paths and not os.path.isfile(bpy.path.abspath(paths[0])):
        return "WARNING", "model.texture.manual_missing", fields
    if tier == "MANUAL":
        return None
    level = "WARNING" if tier == "MANUAL_FOLDER_EMPTY" else "INFO"
    return level, "model.texture." + tier.lower(), fields


def message(texture_mode, tier, paths, model_name, lang):
    """(nível, texto traduzido) do resultado da busca, ou None."""
    result = report(texture_mode, tier, paths, model_name)
    if result is None:
        return None
    level, key, fields = result
    text = tr(key, lang).format(**fields)
    if fields["extra"] and tier not in ("NONE", "MANUAL_FOLDER_EMPTY"):
        text += " " + tr("model.texture.variants", lang).format(**fields)
    return level, text
