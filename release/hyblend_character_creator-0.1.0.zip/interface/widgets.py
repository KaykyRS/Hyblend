"""interface/widgets.py -- primitivas de LAYOUT reaproveitaveis (grades
de botao-icone, celula-gap de largura fixa, centralizacao fracionaria).
Nao conhecem catalogo, slot nem operador especifico -- recebem tudo por
parametro/callback. Movidas de panel.py sem mudar uma linha de logica
(ver DEVELOPER_NOTES item 56) -- o historico de cada decisao (itens
10-53) continua valendo e esta nos docstrings abaixo.

Nenhum import interno: e a camada mais baixa de interface/."""

from __future__ import annotations


def _draw_fixed_icon_grid(
    layout, entries, columns, icon_scale, is_active, operator_idname, bind_fn,
    center=True, fill_gaps=True, center_incomplete_row=False, unify_rows=False,
):
    """Grid de botoes-icone com tamanho FIXO. SEMPRE reserva `columns`
    celulas de largura por linha, mesmo quando sobram menos entradas
    reais que isso na ultima linha -- descoberto na pratica (print real
    do usuario) que uma linha com poucos botoes e SEM nada reservando o
    resto do espaco faz o Blender ESTICAR o(s) botao(oes) restante(s)
    pra preencher a linha toda, ficando desproporcional/deformado.
    `fill_gaps` so controla se essa reserva e VISIVEL (`fill_gaps=True`,
    icone "X" desabilitado -- usado pela grade de Item) ou INVISIVEL
    (`fill_gaps=False`, `icon="BLANK1"` + `emboss=False` -- usado por
    Categoria/Sub-categoria, pedido explicito do usuario: nao mostrar
    nenhum botao vazio, mas SEM esticar os reais).

    `center_incomplete_row` (pedido explicito do usuario -- ver
    DEVELOPER_NOTES.md, tentativa 2): quando a ULTIMA linha sobra com
    menos entradas reais que `columns`, usa CENTRALIZACAO FRACIONARIA
    via `split()` (`_draw_centered_partial_row`) em vez de encaixar em
    colunas inteiras -- com colunas inteiras, um numero de sobra IMPAR
    nunca fica realmente centralizado (so da pra escolher entre duas
    posicoes igualmente erradas pra um lado ou pro outro, ver
    DEVELOPER_NOTES.md pra explicacao completa). A grade de Item usa
    `center_incomplete_row=False` (padrao) -- la o "empurrado pra
    esquerda" com celula de reserva VISIVEL e o esperado.

    `unify_rows` (SEPARADO de `center_incomplete_row` de proposito --
    ver DEVELOPER_NOTES.md itens 40 e 51 -- REVERTIDO do item 49, que
    tinha unificado os dois mecanismos e acabou fazendo a Sub-
    categoria herdar o mesmo bug de esticamento em retangulo que a
    Categoria sempre teve, sem querer): manda TODA linha (cheia OU
    parcial) pelo mecanismo de `_draw_centered_partial_row`, nao so as
    parciais. Usado SO pela grade de Sub-categoria (numero de itens
    varia bastante entre secoes -- 3, 5, 7 -- e o espacamento entre
    botoes so ficou CONSISTENTE nesses tamanhos todos depois dessa
    unificacao, ver itens 38/39/47/48 -- confirmado pelo usuario como
    "Perfeito!" nesse estado). A grade de Categoria/Secao NAO usa isso
    (`unify_rows=False`, o padrao) -- ela sempre tem EXATAMENTE
    `columns` itens (sempre "linha cheia"), entao usar o mecanismo
    unificado nela so trazia efeito colateral sem resolver problema
    nenhum (ela nunca teve o problema de inconsistencia entre tamanhos
    de linha, ja que so tem UM tamanho de linha possivel) -- E ainda
    "contaminava" a Sub-categoria com o bug de esticamento dela (ver
    item 51, revertido).

    Portado do hyblendcc_ui_draft (ver DEVELOPER_NOTES.md la -- varios
    bugs reais do Blender resolvidos, nao repetir):

    1. `scale_x`/`scale_y` pro tamanho (nao `ui_units_x`/`ui_units_y` --
       deu resultado INVERTIDO na pratica).
    2. `row.alignment` explicito ("CENTER"/"LEFT") -- sem isso o Blender
       assume 'EXPAND' e estica os botoes mesmo com scale fixo.
    3. Celula individual com `row(align=False)` -- `align=True` numa
       celula de UM botao so aciona o bug T28391 do proprio rastreador
       do Blender (esticava a primeira celula, encolhia as demais).
    4. Espaco entre celulas via uma CELULA de largura fixa (nao
       `separator(factor=X)` -- ver DEVELOPER_NOTES.md item 39:
       `separator()` se comporta como elemento FLEXIVEL que expande
       conforme sobra espaco na linha, nao como largura garantida).
    5. Linha CHEIA ou SEM centralizacao: sempre desenha `columns`
       celulas (reais ou de reserva) -- reserva com um Operator de
       VERDADE desabilitado (nao um `label("")`) e nunca "pula" a
       celula (isso e o que causava o esticamento).

    `entries`: lista de dict {"key":..., "icon_kwargs": {...}}.
    `is_active(entry)` -> bool. `bind_fn(op, entry)` atribui a(s)
    property(ies) do operador criado."""
    scale_x, scale_y = icon_scale if isinstance(icon_scale, tuple) else (icon_scale, icon_scale)

    is_first_row = True
    for start in range(0, len(entries), columns):
        chunk = entries[start:start + columns]

        if not is_first_row:
            # Mesmo espacador com CONTEUDO de verdade usado em
            # _draw_category_group entre a grade de Categoria e a de
            # Sub-categoria (ver DEVELOPER_NOTES.md item 43) -- aqui
            # entre linhas CONSECUTIVAS da MESMA grade (ex: Head tem 7
            # sub-categorias, quebra em 2 linhas). Bug real reportado
            # com print: quando o layout pai e uma column(align=True)
            # (usado pra suprimir a margem GRANDE entre Categoria e
            # Sub-categoria, ver item 42), o align=True TAMBEM suprimia
            # a margem entre essas 2 linhas internas da mesma grade,
            # colando elas sem querer.
            gap_row = layout.row()
            gap_row.scale_y = 0.15
            gap_row.operator(operator_idname, text="", icon="BLANK1", emboss=False)
            gap_row.enabled = False
        is_first_row = False

        if unify_rows or (center_incomplete_row and 0 < len(chunk) < columns):
            _draw_centered_partial_row(
                layout, chunk, columns, scale_x, scale_y, operator_idname, bind_fn, is_active,
            )
            continue

        row = layout.row(align=True)
        row.alignment = "CENTER" if center else "LEFT"
        for i, entry in enumerate(chunk):
            if i > 0:
                _draw_gap_cell(row, operator_idname, scale_x, scale_y, gap_ratio=0.15)
            cell = row.row(align=False)
            cell.scale_x = scale_x
            cell.scale_y = scale_y
            op = cell.operator(
                operator_idname, text="", depress=is_active(entry), **entry["icon_kwargs"],
            )
            bind_fn(op, entry)
        for i in range(len(chunk), columns):
            # So alcancado quando center_incomplete_row=False (a grade
            # de Item, ver docstring da funcao) -- Categoria/Sub-
            # categoria sempre usam center_incomplete_row=True, caem no
            # bloco acima antes de chegar aqui.
            _draw_gap_cell(row, operator_idname, scale_x, scale_y, gap_ratio=0.15)
            cell = row.row(align=False)
            cell.scale_x = scale_x
            cell.scale_y = scale_y
            if fill_gaps:
                cell.operator(operator_idname, text="", icon="X")
            else:
                cell.operator(operator_idname, text="", icon="BLANK1", emboss=False)
            cell.enabled = False


def _draw_gap_cell(container, operator_idname, scale_x, scale_y, gap_ratio):
    """Espaco fixo de verdade entre botoes -- celula com `scale_x`
    reduzido (fracao `gap_ratio` do tamanho do botao real) desenhando
    um Operator desabilitado/invisivel, em vez de `separator(factor=X)`
    (ver DEVELOPER_NOTES.md item 39 -- `separator()` se comporta como
    elemento flexivel, nao largura fixa garantida; essa celula
    reaproveita o MESMO mecanismo que ja da tamanho fixo confiavel aos
    proprios botoes de icone)."""
    gap = container.row(align=False)
    gap.scale_x = scale_x * gap_ratio
    gap.scale_y = scale_y
    gap.operator(operator_idname, text="", icon="BLANK1", emboss=False)
    gap.enabled = False


def _draw_operator_grid_flow(layout, entries, columns, operator_idname, bind_fn, icon_kwargs_fn, is_active=lambda e: False, scale=None):
    """Grade via `grid_flow` (ferramenta NATIVA do Blender pra grade --
    `even_columns`/`even_rows` garantem celula uniforme sozinhos, sem
    precisar reimplementar largura/gap na mao como `_draw_fixed_icon_grid`
    faz). Consolida os 3 usos identicos que existiam neste arquivo
    (Colors, Cor do Fundo, Secao/Categoria -- cada um reescrevendo a
    MESMA chamada de `grid_flow` + o MESMO loop de operator() por
    conta propria) numa funcao so -- os 3 lugares agora so escolhem O
    QUE desenhar (via os callbacks), nao COMO desenhar a grade em si.

    `entries`: lista de qualquer coisa (tupla, string, dict...) --
    generico de proposito, cada `entry` so passa pelos 3 callbacks.
    `icon_kwargs_fn(entry)` -> dict pro `operator()` (icon/icon_value).
    `bind_fn(op, entry)` seta a(s) property(ies) do operador criado.
    `is_active(entry)` -> bool pro `depress`. `scale`, se dado, aplica
    em `scale_x`/`scale_y` do grid inteiro (usado pra icones GRANDES,
    ex. Secao -- Colors/Cor do Fundo usam o tamanho nativo do swatch,
    sem precisar disso)."""
    grid = layout.grid_flow(row_major=True, columns=columns, even_columns=True, even_rows=True, align=True)
    if scale is not None:
        grid.scale_x = scale
        grid.scale_y = scale
    for entry in entries:
        op = grid.operator(operator_idname, text="", depress=is_active(entry), **icon_kwargs_fn(entry))
        bind_fn(op, entry)


def _draw_centered_partial_row(layout, chunk, columns, scale_x, scale_y, operator_idname, bind_fn, is_active):
    """Centralizacao FRACIONARIA (nao por coluna inteira) de uma linha
    -- usa `split(factor=...)` pra reservar exatamente a largura que os
    botoes desta linha REALMENTE precisam (ver `buttons_frac` abaixo),
    com o vazio restante dividido IGUAL dos dois lados. `split()`
    reserva a fracao ANTES de desenhar qualquer coisa dentro --
    diferente de um `label("")` solto numa row normal (que nao reserva
    espaco nenhum, ver bug #5 acima), aqui o espaco vazio e garantido
    pelo proprio split, nao pelo conteudo.

    `buttons_frac` e PROPORCIONAL a `scale_x` relativo a 2.6 (escala de
    Categoria -- a referencia onde uma linha CHEIA, n==columns,
    realmente deveria ocupar ~100% da largura, porque os botoes de
    Categoria SAO grandes o bastante pra isso fazer sentido). Sem essa
    correcao, uma linha CHEIA de uma grade com icone MENOR (Sub-
    categoria) tambem reservava ~100% da largura mesmo os botoes reais
    sendo bem menores que isso -- e como so a linha PARCIAL calculava
    `leading_frac` (a linha cheia caia direto no `else`, sem sobra
    nenhuma reservada), o espaco vazio sobrando ficava JOGADO TODO PRA
    DIREITA (`buttons_row.alignment="LEFT"`, sem ninguem dividindo esse
    vazio) -- bug real reportado com print: a linha CHEIA de Sub-
    categoria ficava encostada na esquerda igual Categoria, mas a
    linha PARCIAL ficava corretamente centralizada. Com a correcao, a
    MESMA formula vale pras duas -- nao precisa mais de tratamento
    especial pra "linha cheia" vs "linha parcial", os dois casos usam
    o `buttons_frac` proporcional normalmente.

    REVERTIDO do item 49 (ver DEVELOPER_NOTES.md item 51): o item 49
    tinha trocado esse `split()` por celulas de escala auto-ajustavel
    achando que resolveria o esticamento em retangulo da Categoria --
    resolveu meio-caminho (a Sub-categoria passou a crescer junto com
    o painel, como pedido), mas ISSO TAMBEM fez a Sub-categoria herdar
    o MESMO bug de esticamento em retangulo que so a Categoria tinha
    antes (ela usava um mecanismo DIFERENTE, sem esse problema).
    Confirmado pelo usuario que a Sub-categoria estava "Perfeita" ANTES
    do item 49 -- revertido de volta pra essa versao exata (split()),
    aceitando que o problema de esticamento da Categoria continua sem
    solucao, mas ISOLADO -- so afeta a Categoria de novo, nao mais os
    dois.

    RISCO CONHECIDO (usuario ciente, ver DEVELOPER_NOTES.md): o mesmo
    tipo de "poucos botoes numa area sem nada mais competindo por
    espaco" que causou o bug do botao esticado (linha inteira sem
    filler nenhum). Aqui o botao fica dentro de uma fatia de largura
    JA REDUZIDA pelo split (proporcional ao que ele ocuparia numa
    coluna normal), entao o excesso pra esticar, se houver, deveria ser
    bem menor -- mas isso so foi verificado matematicamente (as fracoes
    somam exatamente 1.0), NAO visualmente."""
    n = len(chunk)
    scale_ratio = scale_x / 2.6
    buttons_frac = min(max((n / columns) * scale_ratio, 0.0001), 0.9999)
    leading_frac = (1.0 - buttons_frac) / 2.0

    row = layout.row()
    if leading_frac > 1e-6:
        outer = row.split(factor=leading_frac)
        outer.label(text="")
        remaining_frac = 1.0 - leading_frac
        inner_factor = min(max(buttons_frac / remaining_frac, 0.0001), 0.9999)
        inner = outer.split(factor=inner_factor)
    else:
        inner = row.split(factor=buttons_frac)

    buttons_row = inner.row(align=True)
    buttons_row.alignment = "LEFT"
    for i, entry in enumerate(chunk):
        if i > 0:
            _draw_gap_cell(buttons_row, operator_idname, scale_x, scale_y, gap_ratio=0.25)
        cell = buttons_row.row(align=False)
        cell.scale_x = scale_x
        cell.scale_y = scale_y
        op = cell.operator(operator_idname, text="", depress=is_active(entry), **entry["icon_kwargs"])
        bind_fn(op, entry)
    inner.label(text="")
