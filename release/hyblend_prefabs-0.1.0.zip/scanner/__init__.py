"""scanner/ -- so um pacote Python normal (sem classes bpy pra
registrar/desregistrar), igual ao scanner/ do Hyblend Character Creator."""
