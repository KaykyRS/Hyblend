"""material_setup.py -- monta o material de um item "tingivel" (Modo A:
GreyscaleTexture + GradientSet -- ver scanner/manifest_parser.py) usando
a tecnica de gradient map descoberta ao analisar GradientSets.json:

    A GreyscaleTexture guarda LUMINANCIA (sombra/dobra/brilho da peca),
    NAO cor. A "cor" de verdade vem de uma imagem-rampa (ex.
    TintGradients/Hair/Brown.png) que e amostrada usando essa luminancia
    como coordenada de busca (U). Trocar de cor = trocar qual rampa e
    amostrada; a mascara em cinza nunca muda.

Isso NAO e um tint simples (multiply) -- usar multiply em vez de gradient
map perderia a variacao de sombra/brilho que a rampa carrega, e o
resultado ficaria visivelmente "mais chapado" que o jogo real.

Requer bpy -- so roda dentro do Blender.
"""

from __future__ import annotations

import bpy

from ..compat import ensure_node_tree, ensure_principled_setup, set_material_alpha_clip


def _new_empty_material(name: str):
    """Cria um Material novo com nodes ligados e a arvore JA LIMPA (sem
    o Principled BSDF/Output padrao que o Blender cria sozinho) --
    ponto de partida usado por toda funcao build_* deste arquivo que
    monta a arvore de nodes do zero (`build_gradient_tint_material`,
    `build_flat_preview_material`, `build_gradient_tint_preview_material`
    -- consolida um bloco de 6 linhas que era identico nas 3). NAO usado
    por `build_flat_material`, que reaproveita o Principled BSDF padrao
    em vez de limpar -- padrao genuinamente diferente, nao forcado
    pra dentro deste helper. Devolve (material, nodes, links)."""
    mat = bpy.data.materials.new(name=name)
    nt = ensure_node_tree(mat)  # 4.5: cria a arvore; 5.x: ja existe (use_nodes deprecado)
    nodes = nt.nodes
    links = nt.links
    nodes.clear()
    return mat, nodes, links


def _build_gradient_sample_chain(nodes, links, greyscale_image: "bpy.types.Image", gradient_image: "bpy.types.Image"):
    """Monta a cadeia Greyscale -> Separate Color -> Combine XYZ ->
    rampa (o "gradient map" descrito no topo do arquivo) -- IDENTICA
    (mesmas posicoes inclusive) entre `build_gradient_tint_material` e
    `build_gradient_tint_preview_material`; a UNICA diferenca real
    entre as duas funcoes e o que vem DEPOIS desta cadeia (Base Color
    do Principled BSDF vs Emission+Mix Shader pro preview shadeless).
    Devolve (grey_tex, ramp_tex) -- quem chama liga
    `ramp_tex.outputs["Color"]` no destino que preferir, e
    `grey_tex.outputs["Alpha"]` pro alpha do material."""
    grey_tex = nodes.new("ShaderNodeTexImage")
    grey_tex.location = (-600, 0)
    grey_tex.image = greyscale_image
    grey_tex.interpolation = "Closest"
    grey_tex.label = "Greyscale (luminancia)"

    sep = nodes.new("ShaderNodeSeparateColor")
    sep.location = (-350, 0)
    links.new(grey_tex.outputs["Color"], sep.inputs["Color"])

    combine = nodes.new("ShaderNodeCombineXYZ")
    combine.location = (-150, 0)
    links.new(sep.outputs["Red"], combine.inputs["X"])

    ramp_tex = nodes.new("ShaderNodeTexImage")
    ramp_tex.location = (50, 0)
    ramp_tex.image = gradient_image
    ramp_tex.extension = "EXTEND"
    ramp_tex.interpolation = "Linear"
    ramp_tex.label = "Gradient Ramp (cor)"
    links.new(combine.outputs["Vector"], ramp_tex.inputs["Vector"])

    return grey_tex, ramp_tex


def build_flat_material(name: str, image: "bpy.types.Image"):
    """Material simples -- imagem direto na Base Color/Alpha, sem
    gradiente nenhum. Usado pro Modo B (Textures discretas, ja coloridas
    de verdade) e tambem como fallback de conferencia visual (mostrar uma
    textura crua sem processar)."""
    mat = bpy.data.materials.new(name=name)
    nt = ensure_node_tree(mat)
    # Busca por TIPO (nao pelo nome "Principled BSDF", que pode vir
    # traduzido) e cria o que faltar -- ver compat.ensure_principled_setup.
    bsdf, _output = ensure_principled_setup(nt)
    tex_node = nt.nodes.new("ShaderNodeTexImage")
    tex_node.image = image
    tex_node.interpolation = "Closest"  # sem isso a textura borra (baixa resolucao, pixel-art)
    nt.links.new(tex_node.outputs["Color"], bsdf.inputs["Base Color"])
    nt.links.new(tex_node.outputs["Alpha"], bsdf.inputs["Alpha"])
    set_material_alpha_clip(mat)  # compat: surface_render_method/use_transparent_shadow (4.2+) ou nomes antigos
    return mat


def build_gradient_tint_material(name: str, greyscale_image: "bpy.types.Image", gradient_image: "bpy.types.Image"):
    """Monta um material novo com o setup de gradient map.

    Layout de nos:
      Image Texture (greyscale, Closest -- sem blend entre pixels, mesmo
      espirito pixel-art do jogo)
        -> Separate Color (canal R -- a mascara e cinza, R=G=B, mas
           Separate Color exige um dos 3 mesmo assim)
        -> Combine XYZ (X = luminancia, Y=0, Z=0)
        -> Image Texture (a rampa -- Vector customizado em vez de UV
           default, Extension='EXTEND' pra nao repetir/cortar fora de
           [0,1], Interpolation='Linear' pra suavizar entre os poucos
           pixels de largura que uma rampa costuma ter)
        -> Base Color do Principled BSDF
    """
    mat, nodes, links = _new_empty_material(name)

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (600, 0)

    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (350, 0)
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])

    grey_tex, ramp_tex = _build_gradient_sample_chain(nodes, links, greyscale_image, gradient_image)

    # Alpha vem da propria mascara de luminancia (e a textura que define
    # o recorte/silhueta da peca) -- sem isso, partes que deveriam ser
    # transparentes (ex. vazado entre dedos de uma luva, ou uma peca de
    # roupa com furo de proposito) aparecem solidas.
    links.new(grey_tex.outputs["Alpha"], bsdf.inputs["Alpha"])
    set_material_alpha_clip(mat)  # compat: surface_render_method/use_transparent_shadow (4.2+) ou nomes antigos

    links.new(ramp_tex.outputs["Color"], bsdf.inputs["Base Color"])

    return mat, ramp_tex


# ---------------------------------------------------------------------------
# Materiais de PREVIEW (thumbnail) -- SEM Principled BSDF de proposito.
#
# Pedido explicito: a miniatura precisa mostrar a peca sem interferencia
# nenhuma de luz/sombra/specular/roughness -- so a cor base, "chapada".
# Principled BSDF sempre reage a luz da cena (mesmo com valores default),
# entao a solucao e ligar a cor final direto num node Emission (que NAO
# depende de luz nenhuma) no Material Output, e usar Mix Shader com
# Transparent BSDF pra ainda respeitar o Alpha da textura (recorte/
# silhueta) -- exatamente como discutido na conversa. Como Emission
# dispensa luz, thumbnails/render.py nem cria mais um Light na cena
# temporaria.
#
# Estrutura identica ao material "de verdade" (mesma cadeia de gradient
# map pro Modo A) ate a Base Color -- so o que vem DEPOIS muda (Emission+
# Mix em vez de Principled BSDF direto).
# ---------------------------------------------------------------------------


def build_flat_preview_material(name: str, image: "bpy.types.Image"):
    """Equivalente "shadeless" de build_flat_material -- mesmo uso (Modo
    B / fallback), mas ligado em Emission+Mix Shader em vez de
    Principled BSDF."""
    mat, nodes, links = _new_empty_material(name)

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (400, 0)

    tex_node = nodes.new("ShaderNodeTexImage")
    tex_node.location = (-400, 0)
    tex_node.image = image
    tex_node.interpolation = "Closest"

    emission = nodes.new("ShaderNodeEmission")
    emission.location = (-100, 100)
    links.new(tex_node.outputs["Color"], emission.inputs["Color"])

    transparent = nodes.new("ShaderNodeBsdfTransparent")
    transparent.location = (-100, -100)

    mix = nodes.new("ShaderNodeMixShader")
    mix.location = (150, 0)
    links.new(tex_node.outputs["Alpha"], mix.inputs["Fac"])
    links.new(transparent.outputs["BSDF"], mix.inputs[1])
    links.new(emission.outputs["Emission"], mix.inputs[2])
    links.new(mix.outputs["Shader"], output.inputs["Surface"])

    set_material_alpha_clip(mat)  # compat: surface_render_method/use_transparent_shadow (4.2+) ou nomes antigos
    return mat


def build_gradient_tint_preview_material(name: str, greyscale_image: "bpy.types.Image", gradient_image: "bpy.types.Image"):
    """Equivalente "shadeless" de build_gradient_tint_material -- mesma
    cadeia greyscale->rampa (ver docstring la em cima), so troca o fim:
    Emission+Mix Shader em vez de Principled BSDF, entao a cor da rampa
    aparece exatamente como e (sem sombra/brilho da cena por cima).
    Devolve (material, ramp_tex_node) -- mesma assinatura de
    build_gradient_tint_material, por consistencia (mesmo que o segundo
    valor normalmente nao seja usado numa miniatura, que e gerada uma vez
    so)."""
    mat, nodes, links = _new_empty_material(name)

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (650, 0)

    grey_tex, ramp_tex = _build_gradient_sample_chain(nodes, links, greyscale_image, gradient_image)

    emission = nodes.new("ShaderNodeEmission")
    emission.location = (250, 100)
    links.new(ramp_tex.outputs["Color"], emission.inputs["Color"])

    transparent = nodes.new("ShaderNodeBsdfTransparent")
    transparent.location = (250, -100)

    mix = nodes.new("ShaderNodeMixShader")
    mix.location = (450, 0)
    links.new(grey_tex.outputs["Alpha"], mix.inputs["Fac"])
    links.new(transparent.outputs["BSDF"], mix.inputs[1])
    links.new(emission.outputs["Emission"], mix.inputs[2])
    links.new(mix.outputs["Shader"], output.inputs["Surface"])

    set_material_alpha_clip(mat)  # compat: surface_render_method/use_transparent_shadow (4.2+) ou nomes antigos
    return mat, ramp_tex
