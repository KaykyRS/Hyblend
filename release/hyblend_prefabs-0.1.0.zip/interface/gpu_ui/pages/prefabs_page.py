"""A página do painel por GPU -- MESMO conteúdo e MESMA ordem do painel
clássico (interface/__init__.py, HYBLENDPREFABS_PT_main):

  arquivos do jogo -> Import Prefab -> Prefabs in Scene -> Selected Object
  -> Settings & Tools (fechado) -> About (fechado)

Mesmas regras de texto do clássico (público = usuário comum): tudo em
uma linha, sem explicação técnica; seção sem nada útil não aparece.
Textos/formatadores compartilhados vêm de interface/common_ui.py; ações são
os MESMOS operadores (bl_idname) do clássico. Nada de lógica de import aqui.

Botão/campo novo no clássico -> espelhar aqui (e vice-versa).
"""

import os
from functools import lru_cache

from ....builder.emitters import PROP_OPT_INSTANCE_COUNT, PROP_OPT_INSTANCER_ITEM, PROP_OPT_SINGLE_MESH
from ....builder.prefab_ops import (
    is_hytale_object,
    issue_count,
    load_report,
    prefab_collection_of,
    prefab_display_name,
)
from ....common import (
    ADDON_PACKAGE,
    PROP_BLOCK_FILLER_RAW,
    PROP_BLOCK_GRID_POS,
    PROP_BLOCK_NAME,
    PROP_BLOCK_ROTATION_RAW,
    PROP_BLOCK_SUPPORT_RAW,
    PROP_ENTITY_ITEM_ID,
    PROP_ENTITY_ITEM_ID_RAW,
    PROP_ENTITY_KIND,
    PROP_ENTITY_MODEL_SCALE_RAW,
    PROP_ENTITY_POSITION_RAW,
    PROP_ENTITY_ROTATION_PITCH_RAW,
    PROP_ENTITY_ROTATION_ROLL_RAW,
    PROP_ENTITY_ROTATION_YAW_RAW,
    PROP_ENTITY_STATE,
    PROP_ENTITY_UUID,
    PROP_PREFAB_ROOT,
)
from ....preferences import assets_status, is_developer_mode
from ... import common_ui as cu
from ..framework.core import Column, Icon, Label, Row, Style
from ..widgets import Hint, Paragraph, RuneDivider, card, icon_button

# Operadores (os mesmos do painel clássico)
OP_IMPORT = "import_scene.hytale_prefab"
OP_SELECT = "hyblendprefabs.select_prefab"
OP_FRAME = "hyblendprefabs.frame_prefab"
OP_REMOVE = "hyblendprefabs.remove_prefab"
OP_OPEN_FOLDER = "hyblendprefabs.open_prefab_folder"
OP_COPY_REPORT = "hyblendprefabs.copy_report"
OP_COPY_TEXT = "hyblendprefabs.copy_text"
OP_SELECT_COPIES = "hyblendprefabs.select_instances"
OP_CLEAR_CACHE = "hyblendprefabs.clear_assets_cache"
OP_DEBUG_DUMP = "export_scene.hyblend_debug_dump"
OP_PREFERENCES = "preferences.addon_show"

ROW_KV = 20.0         # altura de uma linha "rótulo ..... valor"

# interface/gpu_ui/pages/ -> raiz do addon -> assets/icons/ (logos do About,
# os MESMOS PNGs do painel clássico)
_ICON_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))))), "assets", "icons")


@lru_cache(maxsize=None)
def _brand(key):
    path = os.path.join(_ICON_DIR, key + ".png")
    return path if os.path.isfile(path) else None


# --------------------------------------------------------------------------
# Peças pequenas
# --------------------------------------------------------------------------

def _kv(ui, label, value, color=None):
    """Linha "rótulo ..... valor" (o _kv_row do clássico), compacta."""
    th = ui.theme
    return Row(
        Label(label, size=11.5, color=th.text_muted, style=Style(flex=40, height=ROW_KV)),
        Label(str(value), size=11.5, weight="Medium", color=color or th.text, style=Style(flex=60, height=ROW_KV)),
        style=Style(gap=4, height=ROW_KV),
    )


def _status_line(ui, text, icon, color, muted=True):
    """Ícone colorido + frase curta (ex.: "Imported successfully")."""
    th = ui.theme
    return Row(Icon(icon, size=14, color=color, style=Style(width=16)),
               Label(text, size=11.5, color=th.text_muted if muted else th.text, style=Style(flex=1)),
               style=Style(gap=6, height=ROW_KV, align="center"))


def _title_row(ui, key, text, icon, copy=True):
    """Título de cartão do inspetor: ícone + nome do item + copiar."""
    th = ui.theme
    parts = [Icon(icon, size=14, color=th.accent, style=Style(width=16)),
             Label(text, size=12.5, weight="SemiBold", style=Style(flex=1))]
    if copy:
        parts.append(ui.op(key + ".copy", OP_COPY_TEXT, "", icon="copy", props={"text": text},
                           variant="ghost", tooltip="Copy name", height=24))
    return Row(parts, style=Style(gap=6, height=24, align="center"))


# --------------------------------------------------------------------------
# 1. Arquivos do jogo + 2. Import
# --------------------------------------------------------------------------

def _assets(ui):
    """Linha discreta "pronto". Sem a pasta do jogo a aba nem aparece
    (common.game_found, igual ao Toolkit) -- o "Locate Game" fica nas
    Preferences. Devolve (widget ou None, pronto?)."""
    state, _text = assets_status(ui.context)
    if state == "ZIP":
        return _status_line(ui, "Hytale game files ready", "check", ui.theme.success), True
    return None, False


def _import(ui, ready, show_tip):
    items = [ui.op("import", OP_IMPORT, "Import Prefab", icon="import", variant="primary", height=38,
                   enabled=ready)]
    if show_tip and ready:
        items.append(Hint("Tip: drag a .prefab.json here", icon="info"))
    return items


# --------------------------------------------------------------------------
# 3. Prefabs in Scene
# --------------------------------------------------------------------------

def _prefabs(ui, prefabs):
    active = prefab_collection_of(ui.context.active_object)
    only_one = len(prefabs) == 1

    def content():
        return [_prefab_card(ui, coll, open_default=(only_one or coll == active)) for coll in prefabs]

    return ui.section("scene", "Prefabs in Scene (%d)" % len(prefabs), "collection", content)


def _prefab_card(ui, coll, open_default):
    th = ui.theme
    name = coll.name
    report = load_report(coll)
    problems = issue_count(report) if report is not None else 0

    # À direita do nome: aviso de problema (visível mesmo fechado) + olho.
    right = []
    if problems:
        right.append(Row(Icon("error", size=13, color=th.danger, style=Style(width=14)),
                         Label(str(problems), size=11.5, weight="SemiBold", color=th.danger),
                         style=Style(gap=3, align="center", height=24),
                         ))
    lc = cu.layer_collection_for(ui.context.view_layer, coll)
    if lc is not None:
        hidden = bool(lc.hide_viewport)
        right.append(icon_button("pf.%s.eye" % name, "eye_off" if hidden else "eye",
                                 lambda f, lc=lc, hidden=hidden: ui.set(f, lc, "hide_viewport", not hidden),
                                 tooltip="Show or hide in the viewport", variant="ghost", size=24))

    def content():
        props = {"collection_name": name}
        items = [Row(
            ui.op("pf.%s.select" % name, OP_SELECT, "Select", icon="shape", props=props, flex=1,
                  compact=True),
            ui.op("pf.%s.frame" % name, OP_FRAME, "Zoom To", icon="search", props=props, flex=1,
                  compact=True),
            ui.op("pf.%s.remove" % name, OP_REMOVE, "", icon="trash", props=props, variant="danger"),
            style=Style(gap=4),
        )]
        if report is None:
            items.append(_status_line(ui, "No summary (older version)", "info", th.text_muted))
            return items
        if problems == 0:
            items.append(_status_line(ui, "Imported successfully", "check", th.success))
        else:
            items.append(_issues(ui, name, report, problems))
        items.append(_details(ui, name, report))
        return items

    section = ui.section("pf." + name, prefab_display_name(coll), None, content, default_open=open_default,
                         right=Row(right, style=Style(gap=4, align="center")) if right else None, plain=True)
    return card(section, key="pf.%s.card" % name, gap=4)


def _issues(ui, name, report, problems):
    th = ui.theme

    def content():
        blocks = []
        for key, title, _blender_icon, icon in cu.ISSUE_GROUPS:
            items = cu.issue_items(report, key)
            if not items:
                continue
            rows = [Row(Icon(icon, size=13, color=th.text_muted, style=Style(width=14)),
                        Label("%s (%d)" % (title, len(items)), size=11.5, weight="SemiBold", style=Style(flex=1)),
                        style=Style(gap=6, height=ROW_KV, align="center"))]
            for item in items[:cu.MAX_ISSUES_SHOWN]:
                rows.append(Label(cu.issue_label(item), size=11, color=th.text_muted,
                                  style=Style(height=17, padding=(20, 0, 0, 0))))
            if len(items) > cu.MAX_ISSUES_SHOWN:
                rows.append(Label("... and %d more" % (len(items) - cu.MAX_ISSUES_SHOWN), size=11,
                                  color=th.text_muted, style=Style(height=17, padding=(20, 0, 0, 0))))
            blocks.append(card(rows, gap=1))
        return blocks

    return ui.section("pf.%s.issues" % name, cu.problems_title(problems), "error", content,
                      default_open=False, plain=True, color=th.danger)


def _details(ui, name, report):
    th = ui.theme
    dev = is_developer_mode(ui.context)

    def content():
        rows = [_kv(ui, "Blocks", f"{report['blocks_placed']:,} / {report['blocks_total']:,}",
                    color=th.danger if report["blocks_placed"] < report["blocks_total"] else None)]
        if report["entities_total"] >= 0:
            # entities_total já exclui spawners/marcadores ignorados -- placed < total é falha real.
            rows.append(_kv(ui, "Entities", f"{report['entities_placed']:,} / {report['entities_total']:,}",
                            color=th.danger if report["entities_placed"] < report["entities_total"] else None))
        else:
            rows.append(_kv(ui, "Entities", "Not imported"))
        rows.append(_kv(ui, "Built as", cu.OUTPUT_LABELS.get(report["output"], report["output"])))
        if report["hidden_blocks"]:
            rows.append(_kv(ui, "Hidden blocks", f"{report['hidden_blocks']:,} removed"))
        if report["hidden_faces"]:
            rows.append(_kv(ui, "Hidden faces", f"{report['hidden_faces']:,} removed"))
        if report["region_skipped"]:
            rows.append(_kv(ui, "Outside region", f"{report['region_skipped']:,} skipped"))
        if dev:
            rows.append(_kv(ui, "Unique meshes", f"{report['unique_meshes']:,}"))
        items = [Column(rows, style=Style(gap=0))]
        buttons = []
        if report["file"]:
            buttons.append(ui.op("pf.%s.folder" % name, OP_OPEN_FOLDER, "Show File", icon="folder",
                                 props={"filepath": report["file"]}, flex=1))
        if dev:
            buttons.append(ui.op("pf.%s.report" % name, OP_COPY_REPORT, "Copy Report", icon="copy",
                                 props={"collection_name": name}, flex=1))
        if buttons:
            items.append(Row(buttons, style=Style(gap=4)))
        return items

    return ui.section("pf.%s.details" % name, "Details", "info", content, default_open=False, plain=True)


# --------------------------------------------------------------------------
# 4. Selected Object
# --------------------------------------------------------------------------

def _selection(ui, prefabs):
    obj = ui.context.active_object

    def content():
        if obj is not None and obj.get(PROP_PREFAB_ROOT):
            coll = prefab_collection_of(obj)
            return [card(_title_row(ui, "sel.root", prefab_display_name(coll) if coll else obj.name, "shape",
                                    copy=False),
                         Hint("Move it to move the whole prefab", icon="info"), gap=6)]
        if obj is not None and (PROP_OPT_INSTANCER_ITEM in obj or obj.get(PROP_OPT_SINGLE_MESH)):
            return [_selection_optimized(ui, obj)]
        if not is_hytale_object(obj):
            return [Hint("Click a block to see its info", icon="info")]

        dev = is_developer_mode(ui.context)
        if PROP_BLOCK_NAME in obj:
            rows = _block_rows(ui, obj, dev)
        else:
            rows = _entity_rows(ui, obj, dev)
        coll = prefab_collection_of(obj)
        if coll is not None and len(prefabs) > 1:       # vários prefabs: diz de qual é
            rows.append(_kv(ui, "Prefab", prefab_display_name(coll)))
        items = [card(rows, gap=2)]
        if obj.type == "MESH" and obj.data is not None and obj.data.users > 1:
            items.append(ui.op("sel.copies", OP_SELECT_COPIES, f"Select All Copies ({obj.data.users})",
                               icon="shape", height=30))
        return items

    return ui.section("selection", "Selected Object", "cube", content)


def _block_rows(ui, obj, dev):
    item_id, state = cu.block_item_id(obj)
    rows = [_title_row(ui, "sel.block", item_id, "cube"), _kv(ui, "Type", "Block")]
    if state:
        rows.append(_kv(ui, "State", state))
    grid = obj.get(PROP_BLOCK_GRID_POS)
    if grid is not None:
        rows.append(_kv(ui, "Position", cu.fmt_vec(grid, digits=0)))
    rows.append(_kv(ui, "Rotation", cu.block_rotation_text(obj)))
    if dev:
        rows += _raw_rows(ui, obj, (("name", PROP_BLOCK_NAME), ("rotation", PROP_BLOCK_ROTATION_RAW),
                                    ("support", PROP_BLOCK_SUPPORT_RAW), ("filler", PROP_BLOCK_FILLER_RAW)))
    return rows


def _entity_rows(ui, obj, dev):
    kind = str(obj.get(PROP_ENTITY_KIND, ""))
    kind_label, _blender_icon, icon = cu.ENTITY_KIND_LABELS.get(kind, cu.ENTITY_KIND_FALLBACK)
    rows = [_title_row(ui, "sel.entity", str(obj.get(PROP_ENTITY_ITEM_ID, obj.name)), icon),
            _kv(ui, "Type", kind_label)]
    state = str(obj.get(PROP_ENTITY_STATE, "") or "")
    if state:
        rows.append(_kv(ui, "State", state))
    pos = obj.get(PROP_ENTITY_POSITION_RAW)
    if pos is not None:
        rows.append(_kv(ui, "Position", cu.fmt_vec(pos)))
    rows.append(_kv(ui, "Rotation", cu.entity_rotation_text(obj)))
    scale = cu.entity_scale(obj)
    if scale != 1.0 or dev:              # escala só quando foge do normal
        text = "%g" % scale
        model_scale = obj.get(PROP_ENTITY_MODEL_SCALE_RAW)
        if dev and model_scale is not None:
            text += "  (model %g)" % float(model_scale)
        rows.append(_kv(ui, "Scale", text))
    if dev:
        rows += _raw_rows(ui, obj, (("id", PROP_ENTITY_ITEM_ID_RAW), ("uuid", PROP_ENTITY_UUID),
                                    ("yaw", PROP_ENTITY_ROTATION_YAW_RAW), ("pitch", PROP_ENTITY_ROTATION_PITCH_RAW),
                                    ("roll", PROP_ENTITY_ROTATION_ROLL_RAW)))
    return rows


def _raw_rows(ui, obj, keys):
    """Developer Mode: valores CRUS do prefab (custom properties)."""
    rows = [Label("Raw prefab values", size=11, weight="SemiBold", color=ui.theme.accent,
                  style=Style(height=ROW_KV, padding=(0, 4, 0, 0)))]
    for label, key in keys:
        if key in obj:
            rows.append(_kv(ui, label, cu.raw_value_text(obj[key])))
    return rows


def _selection_optimized(ui, obj):
    """Objects dos modos Instances/Single Mesh do Optimizer -- sem dado por bloco."""
    if PROP_OPT_INSTANCER_ITEM in obj:
        return card(_title_row(ui, "sel.inst", str(obj.get(PROP_OPT_INSTANCER_ITEM, "")), "cube"),
                    _kv(ui, "Copies", f"{int(obj.get(PROP_OPT_INSTANCE_COUNT, 0)):,}"), gap=2)
    rows = [_title_row(ui, "sel.single", "Whole prefab (Single Mesh)", "cube", copy=False)]
    if obj.type == "MESH" and obj.data is not None:
        rows += [_kv(ui, "Faces", f"{len(obj.data.polygons):,}"),
                 _kv(ui, "Materials", f"{len(obj.data.materials):,}")]
    return card(rows, gap=2)


# --------------------------------------------------------------------------
# 5. Settings & Tools + 6. About
# --------------------------------------------------------------------------

def _settings(ui):
    th = ui.theme

    def content():
        state, text = assets_status(ui.context)
        ok = state == "ZIP"
        items = [_kv(ui, "Game files", text if ok else "Not set", color=None if ok else th.danger),
                 Row(ui.op("set.prefs", OP_PREFERENCES, "Preferences", icon="gear",
                           props={"module": ADDON_PACKAGE}, flex=1, compact=True,
                           tooltip="Open this addon's preferences"),
                     # Quando usar fica no tooltip do operador (bl_description).
                     ui.op("set.cache", OP_CLEAR_CACHE, "Clear Cache", icon="trash", flex=1, compact=True),
                     style=Style(gap=4))]
        if is_developer_mode(ui.context):
            items.append(ui.op("set.dump", OP_DEBUG_DUMP, "Export Debug Dump", icon="import"))
        return items

    return ui.section("tools", "Settings & Tools", "gear", content, default_open=False)


def _about(ui):
    """= aba Info do Hyblend Toolkit (gpu_ui/pages/info_page.py), sem o
    botão Welcome: crédito ao Hytale + aviso, Links, Créditos."""
    th = ui.theme

    def content():
        hytale = card(
            Row(Label(cu.ABOUT_HYTALE_LABEL, size=12, weight="SemiBold", style=Style(flex=1)),
                ui.url_button("about.hytale", cu.HYBLEND_HYTALE_URL, "Hytale", icon="globe",
                              image=_brand("hytale")),
                style=Style(gap=6, align="center")),
            Paragraph(cu.HYBLEND_DISCLAIMER, size=11),
        )
        links = card(
            Row(ui.url_button("about.nexus", cu.HYBLEND_NEXUSMODS_URL, "Nexus Mods", icon="globe",
                              image=_brand("nexus_mods"), flex=1),
                ui.url_button("about.github", cu.HYBLEND_GITHUB_URL, "GitHub", icon="link",
                              image=_brand("github"), flex=1),
                style=Style(gap=6)),
            title=cu.ABOUT_LINKS_LABEL, icon="link",
        )
        author = Row(
            Label(cu.HYBLEND_AUTHOR_NAME, size=13, weight="SemiBold", style=Style(flex=1)),
            *(ui.url_button("about." + brand, url, icon=icon, image=_brand(brand))
              for url, brand, _fallback, icon in cu.HYBLEND_SOCIAL_LINKS),
            style=Style(gap=4, align="center"))
        # "Created by:" / estúdio / autor + redes (as duas linhas de nome juntas)
        credits = card(
            Label(cu.ABOUT_CREATED_BY_LABEL, size=11, color=th.text_muted, style=Style(height=16)),
            Column(Label(cu.HYBLEND_STUDIO_NAME, size=13, weight="SemiBold", style=Style(height=20)),
                   author, style=Style(gap=2)),
            title=cu.ABOUT_CREDITS_LABEL, icon="user",
        )
        return [hytale, links, credits]

    return ui.section("about", "About", "info", content, default_open=False)


# --------------------------------------------------------------------------
# Página
# --------------------------------------------------------------------------

def build(ui, prefabs):
    assets, ready = _assets(ui)
    items = [assets] if assets is not None else []
    items += _import(ui, ready, show_tip=not prefabs)
    # Sem prefab na cena, "Prefabs in Scene" e "Selected Object" não têm
    # nada útil: escondidos (mesma regra do clássico).
    if prefabs:
        items.append(RuneDivider())
        items.append(_prefabs(ui, prefabs))
        items.append(_selection(ui, prefabs))
    items.append(_settings(ui))
    items.append(_about(ui))
    return items

