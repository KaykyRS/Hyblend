"""lang_parser.py -- le arquivos .lang (Common/Languages/<idioma>/
avatarCustomization/*.lang) que resolvem os `Name` dos manifests (ex.
"avatarCustomization.gloves.BasicGloves_Basic.name") pro texto real
mostrado no jogo (ex. "Basic Gloves").

FORMATO CONFIRMADO contra um gloves.lang real (ver conversa de design):
"ChaveLocal.name = Texto Bonito" por linha, uma entrada por linha. O
parser tambem aceita comentarios (# ou !) e linhas vazias por seguranca,
mas isso nao foi confirmado como parte do formato oficial -- so nao
atrapalha se existir.

Falha graciosamente: uma pasta/arquivo faltando ou mal-formado nunca
quebra o addon -- o pior caso e o picker mostrar o Id tecnico cru em vez
do nome bonito (comportamento atual, ja aceito)."""

from __future__ import annotations

from pathlib import Path


def parse_lang_file(path: Path) -> dict:
    """Le um unico .lang, devolve {chave: valor}. Linhas invalidas
    (sem '=', comentario, vazias) sao silenciosamente puladas -- um
    arquivo parcialmente corrompido ainda contribui as chaves que
    conseguiu ler, em vez de tudo falhar."""
    result = {}
    try:
        with path.open(encoding="utf-8") as f:
            for raw_line in f:
                line = raw_line.strip()
                if not line or line.startswith("#") or line.startswith("!"):
                    continue
                if "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                if key:
                    result[key] = value.strip()
    except OSError:
        pass
    return result


def load_avatar_customization_lang(languages_dir: Path, language: str) -> dict:
    """Le TODOS os .lang de Common/Languages/<language>/avatarCustomization/
    e devolve um dict unico mesclado (chave completa -> texto). `languages_dir`
    e o caminho pra "Common/Languages" (ver _resolve_assets_path no
    __init__.py -- e relativo a Common/, nao a Assets/ direto).

    IMPORTANTE (confirmado contra um gloves.lang real): a chave DENTRO do
    arquivo NAO tem o prefixo completo -- e so "BasicGloves_Basic.name",
    nao "avatarCustomization.gloves.BasicGloves_Basic.name" (que e o que
    o campo "Name" dos manifests usa). O prefixo "avatarCustomization.
    <categoria>." vem IMPLICITO do proprio nome do arquivo (gloves.lang
    -> prefixo "avatarCustomization.gloves."), nao do conteudo. Por isso
    reconstituimos a chave completa aqui, usando o nome do arquivo (sem
    extensao) como o segmento do meio -- e o que faz o resultado bater
    1:1 com o `Name` que os manifests de Cosmetics/CharacterCreator/*.json
    realmente usam.

    Devolve dict vazio (nunca levanta excecao) se a pasta do idioma nao
    existir -- idioma nao instalado/nome errado vira "picker mostra Id
    cru", nao erro."""
    folder = languages_dir / language / "avatarCustomization"
    merged: dict = {}
    if not folder.is_dir():
        return merged
    for lang_file in sorted(folder.glob("*.lang")):
        prefix = f"avatarCustomization.{lang_file.stem}."
        for local_key, value in parse_lang_file(lang_file).items():
            merged[prefix + local_key] = value
    return merged
