"""Constantes e checagens do núcleo usadas por todo o Toolkit (pacote, hub, pasta do jogo)."""

# bl_idname das AddonPreferences = nome do pacote raiz.
ADDON_PACKAGE = __package__
# Id do núcleo no hyblend_hub (botão do seletor da aba "Hyblend"; com o Anim ligado, mostra "Anim").
HUB_ID = "toolkit"
# Canal do autor: créditos da aba Info (interface/__init__.py). Os vídeos da Home vêm da playlist (home/videos.py).
HYBLEND_AUTHOR_YOUTUBE_URL = "https://www.youtube.com/@KaaykyModder"


def game_found():
    """Pasta do Hytale localizada? Sem ela os addons Hyblend só mostram o Welcome (painéis e import/export travados).
    Barato (cacheado), pode ir em poll/draw."""
    game = _game_module()
    return game is not None and game.hytale_dir() is not None


_GAME = []      # interface/gpu_ui/game, importado 1x (game_found roda em todo poll)


def _game_module():
    if not _GAME:
        try:
            from .interface.gpu_ui import game
        except ImportError:          # register() no meio: interface/ ainda não carregou
            return None
        _GAME.append(game)
    return _GAME[0]
