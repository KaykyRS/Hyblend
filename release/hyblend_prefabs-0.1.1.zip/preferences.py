"""preferences.py -- Preferences do addon (Developer Mode, cache) e tudo que
resolve o AssetsSource. A PASTA DO HYTALE é a do núcleo (Preferences do
Hyblend Toolkit, UMA pra todos os addons Hyblend; modo Automático =
%APPDATA%/Hytale, preenchida sozinha no boot pelo núcleo); o Assets.zip, a
arte e as fontes do jogo saem de dentro dela (toolkit.hytale_install/game).

Tambem mora aqui o que a UI precisa saber SEM abrir o zip (status da
pasta configurada, pasta de cache) -- o painel (interface/) chama isso a
cada redraw, entao nada aqui pode ser pesado."""

from __future__ import annotations

import os
import shutil
import zipfile
from pathlib import Path

import bpy
from bpy.props import BoolProperty
from bpy.types import AddonPreferences, Operator

from .common import ADDON_PACKAGE, game_found
from .scanner.item_index import clear_index_caches
from .toolkit import ZipAssetsSource, core_preferences, documents_dir, game, hub, hytale_install


def _data_root() -> Path:
    """Documentos/Hyblend/Prefabs (regra de "Documentos" do núcleo, a
    mesma dos outros addons). Versões antigas usavam sempre ~/Documents: se
    essa pasta já existe, continua nela."""
    legacy = Path.home() / "Documents" / "Hyblend" / "Prefabs"
    return legacy if legacy.is_dir() else Path(documents_dir()) / "Hyblend" / "Prefabs"


# Pasta onde o ZipAssetsSource extrai os arquivos sob demanda.
ASSETS_CACHE_DIR = _data_root() / "assets_cache"


class AssetsSourceError(Exception):
    """O Assets.zip não está disponível: pasta do Hytale não configurada,
    não é a pasta do jogo, ou o zip não abre (sumiu, travado, atualizando).
    A mensagem vai direto pro usuário (report do operador)."""


def get_prefs(context=None):
    context = context or bpy.context
    addon = context.preferences.addons.get(ADDON_PACKAGE)
    return addon.preferences if addon else None


def is_developer_mode(context=None) -> bool:
    """Developer Mode (Preferences): mostra ferramentas de depuracao --
    Copy Report, Export Debug Dump, opcoes Experimental do import, valores
    crus no inspetor. Desligado por padrao (usuario comum nao precisa)."""
    prefs = get_prefs(context)
    return bool(prefs and prefs.developer_mode)


def _hytale_path(context=None) -> str:
    """Campo "pasta do Hytale" das Preferences do núcleo ("" sem ele)."""
    prefs = core_preferences(context)
    return getattr(prefs, "hytale_path", "") if prefs is not None else ""


def assets_status(context=None) -> tuple:
    """(estado, texto curto) pro painel/Preferences, sem abrir o zip -- só
    a pasta do Hytale (cacheada). estado: "MISSING" (nada configurado),
    "NOT_FOUND" (a pasta não é a do Hytale) ou "ZIP" (Assets.zip achado)."""
    found = game.hytale_dir()
    if found is not None:
        return "ZIP", "Assets.zip"
    path = _hytale_path(context)
    if not path:
        return "MISSING", "Not configured"
    return "NOT_FOUND", Path(bpy.path.abspath(path)).name or path


def on_hytale_changed(_mode=None, _path=None):
    """A pasta do Hytale mudou no núcleo (hub, on_hytale): descarta o Assets.zip aberto (a UI por GPU troca
    arte/fontes no próximo build)."""
    _invalidate_assets_source()
    from .interface import gpu_ui
    gpu_ui.on_hytale_path_changed(bpy.context)


class HYBLENDPREFABS_AddonPreferences(AddonPreferences):
    bl_idname = ADDON_PACKAGE

    # Pasta do Hytale e interface por GPU: nas Preferences do núcleo (Hyblend Toolkit), valem pra todos.
    developer_mode: BoolProperty(
        name="Developer Mode",
        description="Show debugging tools: Copy Report, Export Debug Dump (also in File > Export), the "
        "Experimental import options and raw prefab values in the Selection inspector",
        default=False,
    )

    def draw(self, context):
        """Atalho pras Preferences do núcleo (pasta do Hytale, interface por GPU -- valem pra todos os addons
        Hyblend) e as caixas do Prefabs."""
        layout = self.layout
        box = layout.box()
        box.label(text="Hytale folder and interface settings are in the Hyblend Toolkit Preferences.", icon="INFO")
        box.operator("hytale.open_addon_preferences", text="Open Hyblend Toolkit Preferences", icon="PREFERENCES")

        # -- Cache --
        box = layout.box()
        box.label(text="Cache", icon="FILE_CACHE")
        col = box.column(align=True)
        col.label(text="Files are extracted from Assets.zip on demand to:")
        col.label(text=str(ASSETS_CACHE_DIR))
        col.label(text="Clear it after a Hytale update so new textures/models are picked up.", icon="INFO")
        row = box.row(align=True)
        row.operator(HYBLENDPREFABS_OT_clear_assets_cache.bl_idname, icon="TRASH")
        sub = row.row(align=True)
        sub.enabled = ASSETS_CACHE_DIR.is_dir()      # ainda não existe = nada extraído ainda
        sub.operator("wm.path_open", text="Open Folder", icon="FILE_FOLDER").filepath = str(ASSETS_CACHE_DIR)

        # -- Developer --
        box = layout.box()
        box.label(text="Developer", icon="CONSOLE")
        box.prop(self, "developer_mode")
        if self.developer_mode:
            col = box.column(align=True)
            col.label(text="Shows: Copy Report, Export Debug Dump, Experimental import options,", icon="INFO")
            col.label(text="and raw prefab values in the Selection inspector.", icon="BLANK1")


class HYBLENDPREFABS_OT_clear_assets_cache(Operator):
    """Apaga a pasta de cache de extracao (ASSETS_CACHE_DIR). O
    ZipAssetsSource so extrai um arquivo se ele ainda NAO existe no cache
    -- depois de uma atualizacao do jogo, sem limpar, o addon continuaria
    usando os arquivos da versao antiga."""

    bl_idname = "hyblendprefabs.clear_assets_cache"
    bl_label = "Clear Cache"
    bl_description = (
        "Delete every file extracted from Assets.zip. Do this after a Hytale update -- "
        "files are re-extracted on the next import"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        _invalidate_assets_source()
        failed = []
        if ASSETS_CACHE_DIR.is_dir():
            shutil.rmtree(ASSETS_CACHE_DIR, onerror=lambda fn, path, _exc: fn is os.rmdir or failed.append(path))
        # Texturas de prefabs já importados apontam pro cache: extraídas de
        # novo (versão nova do jogo) e recarregadas.
        restore_cached_images(context, only_missing=False)
        if failed:
            self.report({"WARNING"}, f"Hyblend Prefabs: cache cleared, but {len(failed)} file(s) are in use and "
                        "were kept (close other programs/Blender windows and try again).")
        else:
            self.report({"INFO"}, "Hyblend Prefabs: extracted files cache cleared.")
        return {"FINISHED"}


def restore_cached_images(context, only_missing=True) -> int:
    """Imagens do .blend que apontam pro cache de extração (texturas dos
    prefabs importados): re-extrai do Assets.zip e recarrega. Sem o jogo: nada."""
    if not game_found():
        return 0

    def extract(relative):
        get_assets_source(context).resolve_root(*relative.split("/"))

    return hub.restore_cached_images(ASSETS_CACHE_DIR, extract, only_missing=only_missing)


@bpy.app.handlers.persistent
def _restore_images_on_load(_dummy=None):
    """load_post: .blend aberto depois de um Clear Cache -- as texturas que
    sumiram do cache voltam do Assets.zip."""
    try:
        restore_cached_images(bpy.context)
    except Exception:
        import traceback
        traceback.print_exc()


_assets_source_state = {"key": None, "source": None}


def _invalidate_assets_source() -> None:
    if _assets_source_state["source"] is not None:
        _assets_source_state["source"].close()
    _assets_source_state["key"] = None
    _assets_source_state["source"] = None
    clear_index_caches()


def get_assets_source(context):
    """AssetsSource do Assets.zip da pasta do Hytale configurada (o mesmo
    caminho do Character Creator), cacheado pelo caminho do zip."""
    hi = hytale_install
    root = game.hytale_dir()
    if root is None:
        path = _hytale_path(context)
        if not path:
            raise AssetsSourceError(
                "Configure the Hytale folder in Preferences > Add-ons > Hyblend Toolkit first (Locate Game).")
        expected = "/".join(hi.relative_parts(hi.ASSETS_ZIP))
        raise AssetsSourceError(
            f"'{bpy.path.abspath(path)}' is not a Hytale folder (could not find {expected} inside "
            "it) -- check the path in Preferences > Add-ons > Hyblend Toolkit.")

    zip_path = hi.resolve(root, hi.ASSETS_ZIP)
    if _assets_source_state["key"] == zip_path and _assets_source_state["source"] is not None:
        return _assets_source_state["source"]

    _invalidate_assets_source()
    try:
        source = ZipAssetsSource(zip_path, ASSETS_CACHE_DIR)
    except (OSError, zipfile.BadZipFile) as exc:     # sumiu, travado, ou meio gravado (launcher atualizando)
        game.invalidate()
        raise AssetsSourceError(f"Could not open the game's Assets.zip ({exc}). If Hytale is updating, wait "
                                "for it to finish and try again.") from exc
    _assets_source_state["key"] = zip_path
    _assets_source_state["source"] = source
    return source


_CLASSES = (
    HYBLENDPREFABS_AddonPreferences,
    HYBLENDPREFABS_OT_clear_assets_cache,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    # (A pasta do jogo e a auto-detecção dela no boot são do núcleo, Hyblend Toolkit.)
    # .blend aberto: texturas que sumiram do cache voltam do Assets.zip.
    bpy.app.handlers.load_post.append(_restore_images_on_load)


def unregister():
    if _restore_images_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_restore_images_on_load)
    _invalidate_assets_source()
    for cls in reversed(_CLASSES):
        if getattr(cls, "is_registered", False):
            bpy.utils.unregister_class(cls)
