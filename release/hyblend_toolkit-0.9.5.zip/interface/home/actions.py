"""Ações dos botões da Home (interface/gpu_ui/pages/home_page.py). Tudo que troca de arquivo fecha a Home ANTES
(host.close_home: o layout volta do tela cheia num timer) e roda a ação
depois, nesse mesmo timer, com o contexto da janela."""

import os

import bpy

from ..gpu_ui import home_host as host


def _override(window):
    area = host._largest_view3d(window) if window is not None else None
    if area is None and window is not None:
        area = max(window.screen.areas, key=lambda a: a.width * a.height, default=None)
    region = next((r for r in area.regions if r.type == "WINDOW"), None) if area else None
    ctx = {"window": window, "screen": window.screen}
    if area is not None:
        ctx["area"] = area
    if region is not None:
        ctx["region"] = region
    return ctx


def new_file(f=None):
    """Arquivo novo. Na abertura do Blender o arquivo já é novo: só fecha."""
    def then(window):
        if bpy.data.is_dirty or bpy.data.filepath:
            with bpy.context.temp_override(**_override(window)):
                bpy.ops.wm.read_homefile("INVOKE_DEFAULT")
    host.close_home(then)


def open_dialog(f=None):
    def then(window):
        with bpy.context.temp_override(**_override(window)):
            bpy.ops.wm.open_mainfile("INVOKE_DEFAULT", True)    # True: entra nos recentes (ver open_file)
    host.close_home(then)


def open_file(f, path):
    if not os.path.isfile(path):
        from . import t as tr
        f.toast(tr("home.recent.missing"), error=True)
        return

    def then(window):
        with bpy.context.temp_override(**_override(window)):
            # INVOKE sem seletor: o Blender ainda pergunta se há alterações não salvas.
            # 2º argumento True (undo): sem ele o Blender trata como chamada de
            # script e NÃO põe o arquivo em File > Open Recent (op_undo_depth > 0
            # em WM_operator_call_py -> wm_files.cc pula wm_history_file_update).
            bpy.ops.wm.open_mainfile("INVOKE_DEFAULT", True, filepath=path, display_file_selector=False)
    host.close_home(then)


def open_folder(f, folder):
    if os.path.isdir(folder):
        bpy.ops.wm.path_open(filepath=folder)


def copy_path(f, path):
    from . import t as tr
    bpy.context.window_manager.clipboard = path
    f.toast(tr("home.menu.copied"))


def remove_recent(f, path):
    """Tira o arquivo da lista de recentes DO BLENDER (File > Open Recent também).
    A lista vive na memória do Blender e é regravada no recent-files.txt a cada
    abrir/salvar: então reescreve o arquivo e manda o Blender relê-lo
    (wm.read_history) -- senão a próxima gravação traria o caminho de volta."""
    from . import data, thumbs
    from . import t as tr
    history = os.path.join(bpy.utils.user_resource("CONFIG"), "recent-files.txt")
    keep = [p for p in thumbs.recent_blends() if p != path]
    try:
        with open(history, "w", encoding="utf-8") as handle:
            handle.writelines(p + "\n" for p in keep)
        bpy.ops.wm.read_history()
    except Exception as error:
        f.toast("%s %s" % (tr("home.error_prefix"), error), error=True)
        return
    data.refresh()
    f.toast(tr("home.menu.removed"))


def open_url(f, url):
    """Links (YouTube, GitHub): abrem no navegador, a Home continua aberta."""
    if url:
        bpy.ops.wm.url_open(url=url)


def preferences(f=None):
    def then(window):
        with bpy.context.temp_override(**_override(window)):
            # Mesmo operador da engrenagem do N-Panel (Preferences do Toolkit).
            bpy.ops.hytale.open_addon_preferences()
    host.close_home(then)
