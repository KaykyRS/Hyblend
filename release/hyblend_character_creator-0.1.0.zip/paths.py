"""paths.py -- onde o Character Creator guarda coisas em disco (puro
Python, sem bpy). Um lugar só: Clear Cache, miniaturas, presets e a
extração do Assets.zip usam estes nomes.

  <Documentos>/Hyblend/CharacterCreator/   (Documentos = regra do hyblend_hub,
      thumbnail_cache/  presets/  assets_cache/      a mesma dos outros addons)
  <temp>/hyblendcc_cropped_icons, <temp>/hyblendcc_swatch_icons
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from .hyblend_hub import documents_dir

TEMP_CROPPED_ICONS = "hyblendcc_cropped_icons"
TEMP_SWATCH_ICONS = "hyblendcc_swatch_icons"


def data_root() -> Path:
    """Documentos/Hyblend/CharacterCreator. Versões antigas usavam sempre
    ~/Documents: se essa pasta já existe, continua nela (presets não somem)."""
    legacy = Path.home() / "Documents" / "Hyblend" / "CharacterCreator"
    if legacy.is_dir():
        return legacy
    return Path(documents_dir()) / "Hyblend" / "CharacterCreator"


def temp_dir(name: str) -> Path:
    return Path(tempfile.gettempdir()) / name
