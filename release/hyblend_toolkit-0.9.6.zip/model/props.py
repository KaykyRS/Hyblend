"""Constantes do .blockymodel e as propriedades que o import grava (bone/Armature), usadas também pelo export
e pelo rig do Anim. IMPORTANTE: nome de propriedade gravada no .blend nunca muda (arquivos antigos)."""

from mathutils import Matrix, Quaternion, Vector

# 1 unidade Blender = 1/64 unidade do jogo (character).
UNIT_SCALE_DEFAULT = 1.0 / 64.0

# Formato do modelo (ids do plugin do Blockbench): character = 64 unidades/bloco, prop = 32.
# Ausente no .blockymodel = character (menos dentro de uma pasta "Blocks").
MODEL_FORMAT_CHARACTER = "character"
MODEL_FORMAT_PROP = "prop"
BLOCK_SIZE_BY_MODEL_FORMAT = {MODEL_FORMAT_CHARACTER: 64, MODEL_FORMAT_PROP: 32}

# Na Armature: "character"/"prop" (ausente = character).
ARMATURE_MODEL_FORMAT_PROP = "hytale_model_format"
# Na Armature: collections das malhas (Attach procura a de attachments).
MAIN_COLLECTION_PROP = "hytale_meshes_main_collection"
ATTACHMENTS_COLLECTION_PROP = "hytale_meshes_attachments_collection"

# No bone: shape.offset já escalado (reimport de attachments ancora no centro da caixa).
BONE_SHAPE_OFFSET_PROP = "hytale_shape_offset"
# No bone: lista com o dict "shape" do arquivo (o export refaz tipo/tamanho/UV com ele).
BONE_SHAPE_JSON_PROP = "hytale_shape_json"
# No bone: rest (16 floats) de quando o import criou o bone; nunca regravada.
BONE_IMPORT_REST_PROP = "hytale_import_rest"
# No bone: nome do arquivo quando o Blender precisou renomear (nome repetido no arquivo).
BONE_ORIGINAL_NAME_PROP = "hytale_original_name"
# No bone: nome de antes do Rename Bones do Anim (Attach acha o bone renomeado por ele).
BONE_RENAMED_FROM_PROP = "hytale_renamed_from"

# Comprimento visual do bone (só estética), em unidades do jogo.
BONE_DISPLAY_LENGTH = 4.0


def normalize_model_format(value):
    """prop (ou hytale_prop) -> prop; qualquer outra coisa -> character."""
    value = (value or "").strip().lower()
    if value.startswith("hytale_"):
        value = value[len("hytale_"):]
    return MODEL_FORMAT_PROP if value == MODEL_FORMAT_PROP else MODEL_FORMAT_CHARACTER


def armature_model_format(armature_obj):
    if armature_obj is None:
        return MODEL_FORMAT_CHARACTER
    return normalize_model_format(armature_obj.get(ARMATURE_MODEL_FORMAT_PROP, MODEL_FORMAT_CHARACTER))


def effective_unit_scale(character_unit_scale, model_format):
    """"Unit Scale" de character -> escala real do formato (prop sai do mesmo tamanho no Blender)."""
    block_size = BLOCK_SIZE_BY_MODEL_FORMAT[normalize_model_format(model_format)]
    return character_unit_scale * BLOCK_SIZE_BY_MODEL_FORMAT[MODEL_FORMAT_CHARACTER] / block_size


def store_import_rest(edit_bone):
    """Grava a rest lendo de volta a matriz do EditBone recém-criado (já arredondada pelo Blender)."""
    m = edit_bone.matrix
    edit_bone[BONE_IMPORT_REST_PROP] = [float(m[r][c]) for r in range(4) for c in range(4)]


def import_rest_matrix(bone):
    """Matrix da rest do import, ou None (bone sem ela ou dado inválido)."""
    raw = bone.get(BONE_IMPORT_REST_PROP)
    if raw is None:
        return None
    try:
        values = [float(v) for v in raw]
    except (TypeError, ValueError):
        return None
    if len(values) != 16:
        return None
    return Matrix([values[r * 4:r * 4 + 4] for r in range(4)])


def bone_file_name(bone):
    """Nome do bone no arquivo (colisão do import ou antes do Rename Bones), ou None."""
    original = bone.get(BONE_ORIGINAL_NAME_PROP) or bone.get(BONE_RENAMED_FROM_PROP)
    return original if original and original != bone.name else None


def vec3(d, default=0.0):
    """{'x','y','z'} do arquivo -> Vector."""
    d = d or {}
    return Vector((d.get("x", default), d.get("y", default), d.get("z", default)))


def quat_xyzw(d):
    """{'x','y','z','w'} do arquivo -> Quaternion (w,x,y,z)."""
    d = d or {}
    return Quaternion((d.get("w", 1.0), d.get("x", 0.0), d.get("y", 0.0), d.get("z", 0.0)))
