"""interface/panel.py -- a UI de verdade (sidebar N-panel, aba "HyChar
Creator"): grade de Categoria/Sub-categoria (estilo character
creator do Hytale), grade de Item, Colors (swatch + Materials), Create
e More Options (Presets/Assets) -- unico modulo que conhece TODOS os
outros, porque e ele que desenha botao pra cada operador.

REESCRITO DO ZERO (pedido explicito do usuario -- reestruturacao visual
completa, ver DEVELOPER_NOTES.md). Portado do addon separado
`hyblendcc_ui_draft` (rascunho validado visualmente pelo usuario antes
de mexer aqui), com uma diferenca de arquitetura IMPORTANTE em relacao
ao rascunho: la, o slot era um StringProperty simples e a selecao virou
Operator PORQUE precisava fugir do EnumProperty.update() (a esse ponto
ainda nao se sabia se dava pra reaproveitar o mecanismo antigo). Aqui, o
slot (HYBLENDCC_ItemSlot em picker.py) CONTINUA EnumProperty -- os novos
Operators de clique (_OT_select_*/_toggle_*, ver interface/operators.py) so
ATRIBUEM a mesma property de sempre, disparando o update() normal
(_slot_on_item_update etc.) exatamente como um dropdown mudando de
valor. Isso reaproveita 100% do caminho ja testado, incluindo o
timer/temp_override de _defer_apply_slot -- resolve de vez a pendencia
#5 do DEVELOPER_NOTES.md do rascunho ("validar se o timer/defer ainda e
necessario ao portar pro addon real").

IDIOMA: UI em ingles (pedido explicito do usuario -- "podia ter mantido
em ingles na UI, portugues como comentario"). Os rotulos de
Categoria/Sub-categoria vem da propria CHAVE interna (ja em ingles,
formatada por common._prettify_key -- ver ali o comentario com o nome
em portugues de cada uma, pra referencia rapida)."""


from __future__ import annotations

import bpy
from bpy.types import Panel

from ..common import (
    ADDON_PACKAGE,
    HUB_ID,
    game_found,
    _LINKED_SKIN_CATEGORIES,
    _SLOT_NONE_VALUE,
    _icon_kwargs_for,
    _link_toggle_icon_kwargs,
    _prettify_key,
    _swatch_icon_id,
)
from ..picker import (
    HYBLENDCC_OT_build_category_thumbnails,
    HYBLENDCC_OT_reload_catalog,
    _ensure_slots_synced,
    _find_slot,
    _item_model_has_background_node,
    _slot_item_value,
)
from ..player_ops import HYBLENDCC_OT_create_player, HYBLENDCC_OT_create_rig, _hyblend_generate_rig_available
from ..preferences import HYBLENDCC_OT_locate_game
from ..presets_ops import HYBLENDCC_OT_delete_preset, HYBLENDCC_OT_load_preset, HYBLENDCC_OT_save_preset
from ..scanner.catalog import get_cache
from . import gpu_ui  # gpu_ui: so pro poll() -- ver interface/gpu_ui/__init__.py
from .. import hyblend_hub  # seletor/sincronia entre os addons Hyblend, ver hyblend_hub.py

from .operators import (
    HYBLENDCC_OT_select_background_color,
    HYBLENDCC_OT_select_category,
    HYBLENDCC_OT_select_color,
    HYBLENDCC_OT_select_section,
    HYBLENDCC_OT_select_variant,
    HYBLENDCC_OT_toggle_background_link,
    HYBLENDCC_OT_toggle_skin_link,
)
from .ui_data import _grid_color_entries, _group_categories
from .widgets import _draw_fixed_icon_grid, _draw_operator_grid_flow


class HYBLENDCC_PT_test_panel(Panel):
    bl_label = "Hyblend Character Creator"
    bl_idname = "HYBLENDCC_PT_test_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Hyblend"  # compartilha a aba do N-Panel com o Hyblend Toolkit
    bl_order = 10            # abaixo do seletor dos addons Hyblend (hyblend_hub, bl_order 0)

    @classmethod
    def poll(cls, context):
        # Sem a pasta do jogo: o addon fica travado e a aba some (common.game_found,
        # igual ao Toolkit). gpu_ui: com a UI experimental por GPU ligada (e
        # suportada), a clássica some -- nunca as duas ao mesmo tempo. Com
        # outros addons Hyblend: só quando o CC é o escolhido no seletor.
        return game_found() and not gpu_ui.is_enabled(context) and hyblend_hub.is_active(HUB_ID, context)

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[ADDON_PACKAGE].preferences

        if not prefs.hytale_path:
            layout.label(text="Hytale folder not found", icon="ERROR")
            layout.operator(HYBLENDCC_OT_locate_game.bl_idname, text="Locate Game", icon="VIEWZOOM")
            layout.label(text="(or set it in the add-on Preferences)")
            return

        obj = context.active_object
        if obj is None or obj.type != "ARMATURE":
            layout.label(text="No Armature selected.", icon="INFO")
            create_box = layout.box()
            create_box.label(text="Start by creating a Player from scratch:")
            create_box.operator(HYBLENDCC_OT_create_player.bl_idname, icon="ARMATURE_DATA")
            create_box.label(text="(or select an existing Armature in the scene)")
            return

        wm = context.window_manager
        _ensure_slots_synced(context, obj)

        cache = get_cache()
        groups = _group_categories(cache)
        if not groups:
            layout.label(text="Empty catalog.", icon="ERROR")
            return

        # active_section/active_category podem apontar pra algo que
        # sumiu (Assets trocado, catalogo recarregado) -- normaliza pro
        # primeiro disponivel em vez de desenhar uma tela vazia.
        if wm.hyblendcc_active_section not in groups:
            wm.hyblendcc_active_section = next(iter(groups))
        active_section = wm.hyblendcc_active_section
        section_categories = groups[active_section]
        if wm.hyblendcc_active_category not in section_categories:
            wm.hyblendcc_active_category = section_categories[0]
        active_category = wm.hyblendcc_active_category
        slot = _find_slot(wm, active_category)

        layout.label(text=f"Armature: {obj.name}", icon="ARMATURE_DATA")

        self._draw_category_group(layout, groups, active_section, active_category)
        self._draw_items(layout, context, active_section, active_category, slot)
        self._draw_colors(layout, context, active_category, slot)
        self._draw_create(layout)
        self._draw_more_options(layout, context)

    # -- Categoria (grupo grande + sub-categoria) --

    def _draw_category_group(self, layout, groups, active_section, active_category):
        """DEFINITIVAMENTE Operator + _draw_fixed_icon_grid (NAO
        template_icon_view). Ver DEVELOPER_NOTES.md itens 14-16 -- essa
        abordagem crashou o Blender do usuario DUAS vezes, a segunda
        mesmo depois de eu ter corrigido a causa especifica identificada
        na primeira. Sem um crash log de verdade pra investigar, nao
        tentar de novo -- essa aqui (Operator) e a unica confirmada
        estavel apos multiplas rodadas de teste real do usuario."""
        header, body = self._panel(layout, "hyblendcc_group", "Category")
        if body is None:
            return

        # column(align=True) ENVOLVENDO as duas grades -- suprime a
        # margem padrao entre elas (ver historico completo abaixo).
        # Usuario reportou com print que os botoes ficaram OFF-CENTER
        # depois disso (grudados mais pra esquerda, sobra vazio a
        # direita) -- tanto na grade de Categoria (linha regular,
        # row.alignment="CENTER") quanto na de Sub-categoria (split()
        # explicito, nao usa "alignment" nenhum) -- as DUAS tecnicas de
        # centralizacao internas mostraram o MESMO desalinhamento, o
        # que descarta as tecnicas internas como causa (senao so uma
        # delas estaria errada) e aponta pro proprio CONTAINER: uma
        # `column()` (diferente de `row()`) pode dimensionar a propria
        # LARGURA pelo conteudo dos filhos, nao esticar sozinha pra
        # ocupar o espaco todo do painel -- ficando mais estreita que o
        # painel e ancorada a esquerda por padrao, o que faria QUALQUER
        # centralizacao acontecer dentro de uma area ja mais estreita
        # que a real, parecendo "puxada pra esquerda" no resultado
        # final. Corrigido envolvendo a column NUM `row()` primeiro --
        # `row()` sempre ocupa a largura inteira do pai (padrao ja
        # comprovado em uso em todo este arquivo), entao a column
        # filha dela deveria herdar essa largura cheia em vez de
        # encolher pro proprio conteudo.
        outer = body.row().column(align=True)

        # grid_flow (ferramenta NATIVA do Blender pra grade, com
        # even_columns/even_rows garantindo celula uniforme -- mesma
        # tecnica ja usada na grade de Colors) na grade de Secao/
        # Categoria. Testadas 3 tecnicas pra essa grade (linha comum,
        # split(), grid_flow, ver DEVELOPER_NOTES.md) -- as 3 esticam
        # em retangulo em painel EXTREMAMENTE largo (usuario confirmou:
        # so acontece nesse extremo, nao numa largura real de uso, e
        # ate a grade de Colors -- padrao recomendado do proprio
        # Blender -- tem o mesmo problema nesse extremo). Decisao do
        # usuario: manter grid_flow aqui mesmo assim (nao vale a pena
        # perseguir mais uma correcao pra um caso que nao acontece no
        # uso real).
        # is_active nao passado (fica no default `lambda e: False`) --
        # a selecao ja fica visivel no proprio icone "Selected", sem
        # precisar de overlay azul de "botao pressionado" por cima.
        _draw_operator_grid_flow(
            outer, entries=list(groups.keys()), columns=5,
            operator_idname=HYBLENDCC_OT_select_section.bl_idname,
            bind_fn=lambda op, key: setattr(op, "section", key),
            icon_kwargs_fn=lambda key: _icon_kwargs_for("section", key, active=(key == active_section)),
            scale=2.6,
        )

        subcats = groups.get(active_section, [])
        if subcats:
            gap_row = outer.row()
            gap_row.scale_y = 0.15
            gap_row.operator(HYBLENDCC_OT_select_section.bl_idname, text="", icon="BLANK1", emboss=False)
            gap_row.enabled = False

            category_entries = [
                {"key": c, "icon_kwargs": _icon_kwargs_for("category", c, active=(c == active_category))}
                for c in subcats
            ]
            _draw_fixed_icon_grid(
                outer, category_entries, columns=5, icon_scale=1.7,
                is_active=lambda e: False,
                operator_idname=HYBLENDCC_OT_select_category.bl_idname,
                bind_fn=lambda op, e: setattr(op, "category", e["key"]),
                fill_gaps=False,
                center_incomplete_row=True,
                # SO a grade de Sub-categoria usa unify_rows -- ver
                # docstring de _draw_fixed_icon_grid (revertido do item
                # 49/51). Categoria (chamada acima) NAO usa isso.
                unify_rows=True,
            )

    # -- <Categoria> -> <Sub-categoria> (grade de item) --

    def _draw_items(self, layout, context, active_section, active_category, slot):
        """VOLTADO pro mecanismo que ja rodava em producao antes da
        reestruturacao visual desta sessao (ver panel.py do addon
        antigo, HyblendCharacterCustomizer.zip) -- `template_icon_view`
        ligado direto em `slot.item_id` (EnumProperty ja existente,
        `_slot_item_enum_items`, que NUNCA tocou bpy.data de dentro do
        `items()` -- so chama `_ensure_item_thumbnail_icon`, que so
        LE um arquivo ja pre-cortado, ver item 19 do DEVELOPER_NOTES).
        Diferente da tentativa de Categoria/Sub-categoria que crashou
        (itens 14-16): aqui nao e um EnumProperty novo com logica nova,
        e o mesmo item_id que ja existia, com o mesmo items() ja
        testado -- risco muito mais baixo.

        Mostra so a selecao ATUAL (um icone grande); clicar abre um
        popup com a grade completa pra escolher (`scale_popup`) -- por
        isso nao precisa mais de busca nem de grade permanente na tela
        (pedido do usuario: UI mais leve)."""
        title = f"{_prettify_key(active_section)} \u2192 {_prettify_key(active_category)}"
        header, body = self._panel(layout, "hyblendcc_items", title)

        build_row = header.row()
        build_row.alignment = "RIGHT"
        build_op = build_row.operator(
            HYBLENDCC_OT_build_category_thumbnails.bl_idname, text="", icon="RENDER_STILL", emboss=False,
        )
        build_op.category = active_category

        if body is None or slot is None:
            return

        # Coluna de LARGURA FIXA (split com factor), igual o addon
        # antigo ja fazia -- sem isso o widget estica pra ocupar a
        # linha inteira (mesma classe de bug ja vista com operator()
        # comum, so que agora no template_icon_view -- reportado pelo
        # usuario com print, corrigido aqui). `scale` maior que o
        # original (3.0 -> 6.0) -- pedido explicito de icone maior,
        # ainda mantendo formato fixo (nao esticado).
        #
        # Centralizado com a MESMA tecnica fracionaria (split() aninhado)
        # ja validada em _draw_centered_partial_row pra Categoria/Sub-
        # categoria -- reserva vazio EXATO e igual dos dois lados da
        # coluna do icone (0.5 de largura pro icone, 0.25 de cada lado),
        # em vez de deixar a coluna colada na esquerda.
        icon_frac = 0.5
        leading_frac = (1.0 - icon_frac) / 2.0
        row = body.row()
        outer = row.split(factor=leading_frac)
        outer.label(text="")
        inner_factor = icon_frac / (1.0 - leading_frac)
        inner = outer.split(factor=inner_factor)
        icon_col = inner.column()
        icon_col.template_icon_view(slot, "item_id", show_labels=False, scale=6.0, scale_popup=6.0)
        inner.label(text="")

    # -- Colors (swatch + Materials/GradientSet, Variant se houver) --

    def _draw_colors(self, layout, context, category, slot):
        """Paleta de bolinhas (swatch) -- mesma aparencia de sempre.

        PERFORMANCE (item 58): cada valor do slot e lido UMA vez por
        redesenho (cor/fundo antes do loop, item_id via espelho
        `_slot_item_value`). A versao antiga lia `slot.color` uma vez POR
        BOLINHA, e cada leitura de EnumProperty dinamica dispara o items()
        dela -- que lia item_id/gradient_set (cascata): ~870 chamadas de
        items() e ~80 mil tuplas por redesenho (medido)."""
        header, body = self._panel(layout, "hyblendcc_colors", "Colors")
        if body is None:
            return
        item_id = _slot_item_value(slot) if slot is not None else ""
        if slot is None or item_id in ("", _SLOT_NONE_VALUE):
            body.label(text="No item selected.", icon="INFO")
            return

        cache = get_cache()
        item = cache.find_item(category, item_id)
        if item is None:
            body.label(text="Invalid item (catalog reloaded?).", icon="ERROR")
            return

        variant = slot.variant
        if item.variants:
            row = body.row(align=True)
            row.label(text="Variant:")
            for v in item.variants:
                v_label = cache.display_name(v.name_key) if v.name_key else v.key
                op = row.operator(
                    HYBLENDCC_OT_select_variant.bl_idname, text=v_label, depress=(variant == v.key),
                )
                op.category = category
                op.variant = v.key

        entries = []
        if item.coloring_mode in ("gradient", "discrete"):
            entries = _grid_color_entries(context, slot)
            current_color = slot.color      # UMA leitura por redesenho (nao uma por bolinha)
            _draw_operator_grid_flow(
                body, entries=entries, columns=6,
                operator_idname=HYBLENDCC_OT_select_color.bl_idname,
                bind_fn=lambda op, e: (setattr(op, "category", category), setattr(op, "color", e[0])),
                icon_kwargs_fn=lambda e: {"icon_value": _swatch_icon_id(e[1])},
                is_active=lambda e: current_color == e[0],
            )

            if item.coloring_mode == "gradient" and len(cache.gradient_sets) > 1:
                body.separator(factor=0.5)
                gset_row = body.row(align=True)
                gset_row.label(text="Materials:")
                gset_row.prop(slot, "gradient_set", text="")
        else:
            body.label(text="This item has no color options.", icon="INFO")

        if category in _LINKED_SKIN_CATEGORIES:
            skin_linked = slot.skin_linked
            link_row = body.row(align=True)
            link_row.label(text="Link Color:")
            toggle_op = link_row.operator(
                HYBLENDCC_OT_toggle_skin_link.bl_idname, text="",
                depress=skin_linked, **_link_toggle_icon_kwargs(skin_linked),
            )
            toggle_op.category = category

        has_variant = variant and variant != _SLOT_NONE_VALUE
        if item.coloring_mode == "gradient" and _item_model_has_background_node(
            context, category, item, variant_key=(variant if has_variant else None),
        ):
            body.separator(factor=0.5)
            background_linked = slot.background_linked
            link_row = body.row(align=True)
            link_row.label(text="Background:")
            toggle_op = link_row.operator(
                HYBLENDCC_OT_toggle_background_link.bl_idname, text="",
                depress=background_linked, **_link_toggle_icon_kwargs(background_linked),
            )
            toggle_op.category = category
            if not background_linked:
                current_bg = slot.background_color   # UMA leitura por redesenho
                _draw_operator_grid_flow(
                    body, entries=entries, columns=6,
                    operator_idname=HYBLENDCC_OT_select_background_color.bl_idname,
                    bind_fn=lambda op, e: (setattr(op, "category", category), setattr(op, "color", e[0])),
                    icon_kwargs_fn=lambda e: {"icon_value": _swatch_icon_id(e[1])},
                    is_active=lambda e: current_bg == e[0],
                )


    def _draw_create(self, layout):
        header, body = self._panel(layout, "hyblendcc_create", "Create")
        if body is None:
            return
        row = body.row(align=True)
        row.scale_y = 2.0
        row.operator(HYBLENDCC_OT_create_player.bl_idname, text="Create Player", icon="ARMATURE_DATA")
        if _hyblend_generate_rig_available():
            row.operator(HYBLENDCC_OT_create_rig.bl_idname, text="Create Rig", icon="CON_KINEMATIC")

    # -- More Options (Presets / Assets) --

    def _draw_more_options(self, layout, context):
        header, body = self._panel(layout, "hyblendcc_more", "More Options (Presets / Assets)", default_closed=True)
        if body is None:
            return
        wm = context.window_manager

        body.operator(HYBLENDCC_OT_locate_game.bl_idname, text="Locate Game", icon="FILE_FOLDER")

        save_row = body.row(align=True)
        save_row.prop(wm, "hyblendcc_preset_name", text="")
        save_row.operator(HYBLENDCC_OT_save_preset.bl_idname, text="", icon="EXPORT")

        load_row = body.row(align=True)
        load_row.prop(wm, "hyblendcc_preset_selected", text="")
        load_row.operator(HYBLENDCC_OT_load_preset.bl_idname, text="", icon="IMPORT")
        load_row.operator(HYBLENDCC_OT_delete_preset.bl_idname, text="", icon="TRASH")

        body.operator(HYBLENDCC_OT_reload_catalog.bl_idname, icon="FILE_REFRESH")

    @staticmethod
    def _panel(layout, idname, title, default_closed=False):
        """layout.panel() (Blender 4.1+, ver blender_manifest.toml --
        blender_version_min ja e 4.5) persiste o estado aberto/fechado
        sozinho, por idname -- substitui as N BoolProperty manuais
        (hyblendcc_section_*_expand, hyblendcc_presets_expand) que a UI
        antiga precisava registrar/desregistrar uma por uma. Fallback em
        box() mantido por seguranca, mesmo sem versao minima exigir."""
        if hasattr(layout, "panel"):
            header, body = layout.panel(idname, default_closed=default_closed)
            header.label(text=title)
            return header, body
        box = layout.box()
        box.label(text=title)
        return box, box


# --------------------------------------------------------------------------
# Seletor dos addons Hyblend (hyblend_hub.py) -- chamado pelo __init__.py raiz
# --------------------------------------------------------------------------

def _hub_migrate(prefs):
    """Versões antigas guardavam o modo em outra property (assets_source_mode):
    quem tinha uma pasta própria voltou em Automático com o campo travado.
    Pasta preenchida que não é a padrão = Manual."""
    from ..scanner import hytale_install
    if prefs.hytale_path_mode == "AUTO" and prefs.hytale_path:
        default = hytale_install.default_hytale_dir()
        found = hytale_install.find_hytale_dir(bpy.path.abspath(prefs.hytale_path))
        if default is not None and found is not None and found != default:
            prefs.hytale_path_mode = "MANUAL"


def hub_register():
    """Seletor nativo (painel bl_order 0, só aparece com 2+ addons Hyblend),
    inscrição no hub e pasta do Hytale no boot (hyblend_hub.register_addon).
    Antes dos outros painéis da aba."""
    hyblend_hub.register_addon(HUB_ID, "Character Creator", ADDON_PACKAGE, "hyblendcc", game_found=game_found,
                               gpu_ui=gpu_ui, migrate=_hub_migrate,
                               reason="Hytale folder not found: set it in the Hyblend Character Creator Preferences")


def hub_unregister():
    hyblend_hub.unregister_addon(HUB_ID, ADDON_PACKAGE)
