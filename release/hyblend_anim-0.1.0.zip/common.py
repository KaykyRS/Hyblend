"""Conversão de posição/rotação Blender <-> .blockymodel/.blockyanim, compartilhada pelo export e a animação.
IMPORTANTE: mudar aqui muda os dois lados; senão o round-trip quebra. As propriedades gravadas pelo import vêm do
núcleo (api.model.props)."""
import json

from bpy.props import StringProperty
from bpy.types import Operator

# game_found: pasta do Hytale do núcleo (Preferences do Hyblend Toolkit); barato (cacheado), pode ir em poll/draw.
from .toolkit import api, game_found  # noqa: F401
from .translations import localized_props, register_localized_class, tooltip, tr, unregister_localized_class

# Constantes do .blockymodel e propriedades que o import grava (bone/Armature): moram no núcleo (model/props.py),
# o mesmo import pra todos os addons. Reexportadas aqui com os nomes de sempre (export, rig e animação usam).
_props = api.model.props
UNIT_SCALE_DEFAULT = _props.UNIT_SCALE_DEFAULT
MODEL_FORMAT_CHARACTER = _props.MODEL_FORMAT_CHARACTER
MODEL_FORMAT_PROP = _props.MODEL_FORMAT_PROP
BLOCK_SIZE_BY_MODEL_FORMAT = _props.BLOCK_SIZE_BY_MODEL_FORMAT
ARMATURE_MODEL_FORMAT_PROP = _props.ARMATURE_MODEL_FORMAT_PROP
normalize_model_format = _props.normalize_model_format
armature_model_format = _props.armature_model_format
effective_unit_scale = _props.effective_unit_scale
BONE_SHAPE_OFFSET_PROP = _props.BONE_SHAPE_OFFSET_PROP
BONE_SHAPE_JSON_PROP = _props.BONE_SHAPE_JSON_PROP
BONE_IMPORT_REST_PROP = _props.BONE_IMPORT_REST_PROP
store_import_rest = _props.store_import_rest
import_rest_matrix = _props.import_rest_matrix
BONE_ORIGINAL_NAME_PROP = _props.BONE_ORIGINAL_NAME_PROP
BONE_RENAMED_FROM_PROP = _props.BONE_RENAMED_FROM_PROP
bone_file_name = _props.bone_file_name
vec3 = _props.vec3
quat_xyzw = _props.quat_xyzw

# O .blockyanim grava "duration"/"time" em frames a 60 FPS fixos,
# independente do FPS da cena do Blender.
FPS_HYTALE = 60

# Sufixos dos bones gerados pelo rigger (fallback do export sem a collection "Hytale Export").
SUFFIX_MCH = "_MCH"
SUFFIX_CTRL = "_CTRL"
SUFFIX_IK = "_IK"

# Bone "ORG" criado pelo rigger (Origin automático / Root "New Bone"): fora do export, sai no Remove Generated.
BONE_RIGGER_CREATED_PROP = "hytale_rigger_created"

# vec3/quat_xyzw: arquivo -> Blender; vec_to_dict/quat_to_dict: Blender -> arquivo.


def vec_to_dict(v):
    """Converte mathutils.Vector em {'x':,'y':,'z':} (.blockyanim)."""
    return {"x": v.x, "y": v.y, "z": v.z}


def quat_to_dict(q):
    """Converte mathutils.Quaternion em {'x':,'y':,'z':,'w':} (ordem do arquivo)."""
    return {"x": q.x, "y": q.y, "z": q.z, "w": q.w}


def shape_offsets(armature_obj, rest_by_bone, names, unit_scale):
    """{bone: centro da caixa no espaço da rest dada} dos bones com caixa (o jogo estica a caixa pelo centro)."""
    out = {}
    bones = armature_obj.data.bones
    for name in names:
        bone = bones.get(name)
        raw = bone.get(BONE_SHAPE_JSON_PROP) if bone is not None else None
        try:
            parsed = json.loads(raw) if raw else None
        except (TypeError, ValueError):
            continue
        shape = (parsed[0] if parsed else None) if isinstance(parsed, list) else parsed
        if not isinstance(shape, dict) or shape.get("type", "none") in ("none", None) or name not in rest_by_bone:
            continue
        rest = import_rest_matrix(bone) or bone.matrix_local
        center = rest @ (vec3(shape.get("offset", {})) * unit_scale)
        out[name] = rest_by_bone[name].inverted() @ center
    return out


def is_active_armature(context):
    """True se o objeto ativo é um Armature."""
    obj = context.active_object
    return obj is not None and obj.type == "ARMATURE"


# Pacote raiz do Anim (o idioma e as Preferences são do núcleo, ver toolkit.py).
ADDON_PACKAGE = __package__


def _pick_bone_into_field_props(lang):
    return {
        "data_path": StringProperty(
            description=tr("common.prop.pick_bone_data_path", lang),
        ),
        "field": StringProperty(description=tr("common.prop.pick_bone_field", lang)),
    }


@localized_props(_pick_bone_into_field_props)
class HYTALE_OT_pick_bone_into_field(Operator):
    """Copia o nome do bone ativo pra uma StringProperty de um datablock do Armature ativo (botão "pegar bone")."""

    bl_idname = "hytale.pick_bone_into_field"
    bl_label = "Pick Bone From Selection"
    description = tooltip("common.tooltip.pick_bone_into_field")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return is_active_armature(context)

    def execute(self, context):
        obj = context.active_object
        bone_name = None
        if context.mode == "EDIT_ARMATURE" and context.active_bone is not None:
            bone_name = context.active_bone.name
        elif context.mode == "POSE" and context.active_pose_bone is not None:
            bone_name = context.active_pose_bone.name
        elif obj.data.bones.active is not None:
            bone_name = obj.data.bones.active.name

        if not bone_name:
            self.report({"WARNING"}, "No active bone to pick -- select one in Edit or Pose Mode first.")
            return {"CANCELLED"}

        try:
            target = obj.path_resolve(self.data_path) if self.data_path else obj
        except ValueError:
            self.report({"WARNING"}, f"Invalid data_path '{self.data_path}'.")
            return {"CANCELLED"}

        if not hasattr(target, self.field):
            self.report({"WARNING"}, f"Unknown field '{self.field}'.")
            return {"CANCELLED"}

        setattr(target, self.field, bone_name)
        self.report({"INFO"}, f"{self.field} = '{bone_name}'.")
        return {"FINISHED"}


_CLASSES = (HYTALE_OT_pick_bone_into_field,)


def register():
    for cls in _CLASSES:
        register_localized_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        unregister_localized_class(cls)
