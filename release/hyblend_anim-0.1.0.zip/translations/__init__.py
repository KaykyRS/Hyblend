"""Textos do Anim: en.py/pt_br.py daqui (LANGUAGE_CODE, LANGUAGE_NAME, TRANSLATIONS), registrados no carregador
do Hyblend Toolkit. O idioma é o do núcleo (um só pra todos os addons Hyblend); key que não existe aqui cai na
tabela do núcleo e depois no inglês. Mesma API de antes pros módulos do Anim (tr, tooltip, localized_props...).

Tooltips traduzidos, dois mecanismos (iguais no núcleo):
1. Botão (Operator): `description = tooltip("arquivo.tooltip.foo")` (o Blender chama a cada hover).
2. Campo (bpy.props): `_props(lang)` + @localized_props(_props), registrada com register_localized_class; trocar o
   idioma (no núcleo) re-registra. Classe usada como type= numa atribuição direta precisa refazer a atribuição num
   register_refresh_hook (ver exporter._redo_armature_property_assignments).
"""

import os

from ..toolkit import api

OWNER = "anim"
_DIR = os.path.dirname(__file__)

get_language = api.get_language
localized_props = api.localized_props
register_localized_class = api.register_localized_class
unregister_localized_class = api.unregister_localized_class
register_refresh_hook = api.register_refresh_hook
unregister_refresh_hook = api.unregister_refresh_hook


def tr(key, lang):
    """Texto de `key` em `lang` (tabela do Anim, depois a do núcleo); senão inglês; senão a própria key."""
    return api.tr_for(OWNER, key, lang)


def tooltip(key):
    """classmethod description(cls, context, properties) pra `description = tooltip(...)` num Operator."""
    return api.tooltip_for(OWNER, key)


def _load():
    return api.load_tables(__package__, _DIR)


def register():
    """Primeiro módulo do main._MODULES: as classes @localized_props dos outros montam os textos no register() delas."""
    api.register_table(OWNER, _load)


def unregister():
    api.unregister_table(OWNER)
