"""Changelog sincronizado com as releases do GitHub.

  * fonte: https://api.github.com/repos/KaykyRS/Hyblend/releases (pública,
    sem login; limite do GitHub sem token = 60 consultas/hora por IP);
  * a descrição de cada release é exibida como está (Markdown, ui/markdown.py);
  * busca numa THREAD (só urllib/json -- nada de bpy fora da thread principal);
    um timer recolhe o resultado, grava o cache e redesenha a Home;
  * cache em <dados da extensão>/releases.json: a Home abre na hora com o
    último resultado, e sem internet continua mostrando ele;
  * busca de novo no máximo a cada REFRESH_EVERY (ou no botão de atualizar);
  * respeita Preferences > System > "Allow Online Access" do Blender
    (bpy.app.online_access): desligado = nenhuma conexão, só o cache.
"""

import json
import os
import threading
import time

import bpy

from ...common import ADDON_PACKAGE

API_URL = "https://api.github.com/repos/KaykyRS/Hyblend/releases?per_page=30"
PAGE_URL = "https://github.com/KaykyRS/Hyblend/releases"
REFRESH_EVERY = 6 * 3600
TIMEOUT = 10.0
_FIELDS = ("tag_name", "name", "body", "published_at", "html_url", "prerelease")

_state = {"loaded": False, "releases": [], "fetched_at": 0.0, "status": "idle", "error": ""}
_job = {"thread": None, "result": None, "lock": threading.Lock()}


def _cache_file(create=False):
    try:
        base = bpy.utils.extension_path_user(ADDON_PACKAGE, create=create)
    except Exception:
        base = bpy.utils.user_resource("CONFIG", path="hyblend_toolkit", create=create)
    return os.path.join(base, "releases.json")


def _load_cache():
    if _state["loaded"]:
        return
    _state["loaded"] = True
    try:
        with open(_cache_file(), encoding="utf-8") as handle:
            data = json.load(handle)
        _state["releases"] = [r for r in data.get("releases", []) if isinstance(r, dict)]
        _state["fetched_at"] = float(data.get("fetched_at", 0.0))
    except (OSError, ValueError, TypeError):
        pass


def _save_cache():
    try:
        with open(_cache_file(create=True), "w", encoding="utf-8") as handle:
            json.dump({"fetched_at": _state["fetched_at"], "releases": _state["releases"]}, handle)
    except OSError as error:
        print("[Hyblend] Home: could not save releases cache:", error)


def online_allowed():
    """Preferences > System > Allow Online Access (Blender 4.2+)."""
    return bool(getattr(bpy.app, "online_access", True))


def releases():
    _load_cache()
    return _state["releases"]


def status():
    """"idle" | "loading" | "ok" | "error" | "offline" -- e quando atualizou."""
    _load_cache()
    return _state["status"], _state["error"], _state["fetched_at"]


def refresh(force=False):
    """Busca em segundo plano (se permitido e se o cache estiver velho)."""
    _load_cache()
    if _job["thread"] is not None:
        return
    if not online_allowed():
        _state["status"] = "offline"
        return
    if not force and _state["releases"] and time.time() - _state["fetched_at"] < REFRESH_EVERY:
        _state["status"] = "ok"
        return
    _state["status"], _state["error"] = "loading", ""
    _job["result"] = None
    thread = threading.Thread(target=_worker, args=(API_URL,), name="hyblend_releases", daemon=True)
    _job["thread"] = thread
    thread.start()
    if not bpy.app.timers.is_registered(_poll):
        bpy.app.timers.register(_poll, first_interval=0.25)


def _worker(url):
    """THREAD: só rede + json. Resultado: ("ok", [releases]) ou ("error", texto)."""
    import ssl
    import urllib.request
    try:
        # O Python do Blender (macOS principalmente) nem sempre acha os
        # certificados do sistema: usa os do certifi, que vem com o Blender.
        try:
            import certifi
            context = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            context = ssl.create_default_context()
        request = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json",
                                                       "User-Agent": "Hyblend-Toolkit"})
        with urllib.request.urlopen(request, timeout=TIMEOUT, context=context) as response:
            data = json.loads(response.read().decode("utf-8"))
        if not isinstance(data, list):
            raise ValueError(data.get("message", "unexpected answer") if isinstance(data, dict) else "unexpected answer")
        items = [{k: r.get(k) for k in _FIELDS} for r in data if isinstance(r, dict) and not r.get("draft")]
        result = ("ok", items)
    except Exception as error:                       # sem internet, limite do GitHub, JSON estranho...
        result = ("error", str(error)[:200])
    with _job["lock"]:
        _job["result"] = result


def _poll():
    """Timer (thread principal): pega o resultado da thread quando chegar."""
    with _job["lock"]:
        result = _job["result"]
    if result is None:
        thread = _job["thread"]
        if thread is not None and thread.is_alive():
            return 0.25
        result = ("error", "no answer")
    _job["thread"], _job["result"] = None, None
    kind, payload = result
    if kind == "ok":
        _state["releases"], _state["fetched_at"] = payload, time.time()
        _state["status"], _state["error"] = "ok", ""
        _save_cache()
    else:
        _state["status"], _state["error"] = "error", payload
        print("[Hyblend] Home: releases:", payload)
    from ..gpu_ui import home_host as host
    host.refresh_all()
    return None


def cancel():
    if bpy.app.timers.is_registered(_poll):
        bpy.app.timers.unregister(_poll)
