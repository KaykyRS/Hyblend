"""Aba Animation -- visibilidade das Bone Collections, FK/IK e Head
Free/Lock, espelhando HYTALE_PT_main._draw_animation."""

from ..framework.core import Column, Label, Row, Style
import bpy

from ..widgets import CONTROL_H, Hint, SwipeButton, card
from ....anim import (
    ANIM_OT_hytale_keyframe_switch,
    ANIM_OT_hytale_set_fk_ik,
    ANIM_OT_hytale_set_head_follow,
    ANIM_OT_hytale_snap_selected,
    get_fk_ik_state,
    get_head_follow_state,
)
from ....common import is_active_armature
from ....rigger import (
    SUFFIX_CTRL,
    SUFFIX_IK,
    _collection_sort_key,
    _iter_sections_in_order,
    _resolve_collection_section_name,
)
from ....rigger.helpers import control_name


def _undo_push(message):
    try:
        bpy.ops.ed.undo_push(message=message)
    except Exception:
        pass


def _run(ui, f, idname, **props):
    """Roda o operador pela MESMA ponte do resto da UI (erros viram toast)."""
    return ui.run_op(f, idname, props, label=idname)


class VisibilityButton(SwipeButton):
    """Mostrar/esconder uma Bone Collection (is_visible).
    Segurar e passar por cima de outras = mesmo estado em todas.
    I (ou botão direito) com o mouse em cima = keyframe em is_visible."""

    def __init__(self, key, coll, ui):
        self.coll, self.ui = coll, ui
        visible = coll.is_visible
        name = coll.name
        armature = coll.id_data

        def apply(f, value):
            target = armature.collections_all.get(name)
            if target is not None:
                target.is_visible = value          # sem undo por botão: um só no fim

        def finish(f, count):
            _undo_push(ui.t("gpu_ui.undo_visibility"))

        super().__init__(key, name, swipe_group="vis", swipe_id=name, swipe_value=not visible,
                         swipe_apply=apply, swipe_finish=finish, on_insert_key=self._keyframe,
                         icon="eye" if visible else "eye_off", selected=visible,
                         tooltip=lambda: ui.t("gpu_ui.tip_visibility"),
                         style=Style(height=30, flex=1.0))

    def _keyframe(self, f):
        try:
            self.coll.keyframe_insert("is_visible")
            f.toast(self.ui.t("gpu_ui.toast_keyframe").format(name=self.coll.name))
        except Exception as error:
            f.toast(str(error), error=True)

    def on_context(self, f, x, y):
        self._keyframe(f)


def build(ui):
    t = ui.t
    obj = ui.context.active_object
    if not is_active_armature(ui.context):
        return [card(Hint(t("panel.hint_anim_none"), icon="error", tone="danger"))]
    armature = obj.data
    widgets = [_collections(ui, armature), _fk_ik(ui, obj, armature)]
    head_state = get_head_follow_state(obj)
    if head_state is not None:
        widgets.append(card(
            Row(
                _head_button(ui, "FREE", "Free", head_state == 0),
                _head_button(ui, "LOCK", "Lock", head_state == 1),
                ui.op("hf.key", ANIM_OT_hytale_keyframe_switch, "", icon="key", props={"switch": "HEAD_FOLLOW"}),
                style=Style(gap=4)),
            title=t("panel.anim_head_follow_box"), icon="head"))
    return widgets


def _collections(ui, armature):
    """Grade de botões por Section (mesma ordem/agrupamento do clássico)."""
    t = ui.t
    parts = []
    found = [False]

    def button(name):
        coll = armature.collections_all.get(name)
        if coll is None:
            return None
        found[0] = True
        return VisibilityButton("vis.%s" % name, coll, ui)

    by_section = {}
    for item in armature.hytale_bone_collections:
        if not item.name or item.entry_type != "COLLECTION":
            continue
        by_section.setdefault(_resolve_collection_section_name(armature, item), []).append(item)

    def grid(items, depth):
        rows, current, row = [], None, None
        for item in sorted(items, key=_collection_sort_key):
            if not item.show_in_animation_tab:
                continue
            if item.row != current or row is None:
                current, row = item.row, []
                rows.append(row)
            b = button(item.name)
            if b is not None:
                row.append(b)
        return [Row(r, style=Style(gap=4, padding=(14 * depth, 0, 0, 0))) for r in rows if r]

    visited = set()
    for sec, depth in _iter_sections_in_order(armature):
        items = by_section.get(sec.name, [])
        visited.add(sec.name)
        if not items:
            continue
        if not any(i.show_in_animation_tab and armature.collections_all.get(i.name) is not None for i in items):
            continue
        parts.append(Row(Label(sec.name.upper(), size=10, weight="SemiBold", color=ui.theme.text_muted),
                         style=Style(height=18, padding=(14 * depth + 2, 0, 0, 0))))
        parts += grid(items, depth)
    for name, items in by_section.items():
        if name not in visited:
            parts += grid(items, 0)
    if not found[0]:
        parts.append(Hint(t("panel.hint_anim_no_rig"), icon="info"))
    return card(parts, title=t("panel.anim_collections_box"), icon="eye", gap=6)


def _fk_ik(ui, obj, armature):
    t = ui.t
    parts = [ui.op("fkik.snap", ANIM_OT_hytale_snap_selected, t("panel.btn_snap_selected"), icon="magnet",
                   height=30)]

    known = {c.name for c in armature.hytale_bone_collections if c.name}

    def chain_collection(item):
        # Mesma resolução do painel clássico: a collection REAL em que o
        # bone raiz/ponta (_CTRL ou _IK) caiu.
        for base in (item.root_bone, item.tip_bone):
            if not base:
                continue
            for suffix in (SUFFIX_CTRL, SUFFIX_IK):
                bone = armature.bones.get(control_name(armature, base, suffix))
                if bone is None:
                    continue
                for coll in bone.collections:
                    if coll.name in known:
                        return coll.name
        return None

    ordered = sorted((c for c in armature.hytale_bone_collections if c.name), key=_collection_sort_key)
    order = {c.name: i for i, c in enumerate(ordered)}
    grid_row = {c.name: c.row for c in armature.hytale_bone_collections if c.name}

    entries = []
    for index, item in enumerate(armature.hytale_ik_chains):
        state = get_fk_ik_state(obj, item)
        if state is None:
            continue
        coll = chain_collection(item)
        bucket = ("row", grid_row[coll]) if coll in grid_row else ("solo", index)
        entries.append((order.get(coll, len(order)), index, item, state, bucket))
    entries.sort(key=lambda e: (e[0], e[1]))

    groups, current = [], None
    for _, index, item, state, bucket in entries:
        if bucket != current or not groups:
            current = bucket
            groups.append([])
        groups[-1].append(_chain_switch(ui, index, item, state))
    for group in groups:
        parts.append(Row(group, style=Style(gap=10)))
    if not entries:
        parts.append(Hint(t("panel.hint_anim_no_fkik"), icon="info"))
    return card(parts, title=t("panel.anim_fkik_box"), icon="arm", gap=6)


def _chain_switch(ui, index, item, state):
    return Column(
        Label(item.label or item.root_bone or "(?)", size=11, color=ui.theme.text_muted, style=Style(height=16)),
        Row(
            _fk_ik_button(ui, index, "FK", state == 0),
            _fk_ik_button(ui, index, "IK", state == 1),
            ui.op("fkkey.%d" % index, ANIM_OT_hytale_keyframe_switch, "", icon="key",
                  props={"switch": "FK_IK", "chain_index": index}),
            style=Style(gap=3)),
        style=Style(gap=2, flex=1.0))


def _fk_ik_button(ui, index, mode, selected):
    """FK ou IK de uma cadeia. Segurar e passar por cima das outras
    cadeias aplica o MESMO modo (FK e IK da mesma cadeia contam uma vez).
    I com o mouse em cima = keyframe no switch (mesmo operador do botão
    de chave)."""
    enabled = ui.op_poll(ANIM_OT_hytale_set_fk_ik)

    def apply(f, value):
        _run(ui, f, ANIM_OT_hytale_set_fk_ik.bl_idname, chain_index=index, mode=value)

    def keyframe(f):
        if "FINISHED" in (_run(ui, f, ANIM_OT_hytale_keyframe_switch.bl_idname, switch="FK_IK",
                                chain_index=index) or ()):
            f.toast(ui.t("gpu_ui.toast_keyframe").format(name="FK/IK"))

    return SwipeButton("%s.%d" % (mode.lower(), index), mode, swipe_group="fkik",
                       swipe_id="chain.%d" % index, swipe_value=mode, swipe_apply=apply,
                       on_insert_key=keyframe, selected=selected, enabled=enabled,
                       tooltip=lambda: ui.t("gpu_ui.tip_fk_ik"),
                       style=Style(height=CONTROL_H, flex=1.0))


def _head_button(ui, mode, label, selected):
    enabled = ui.op_poll(ANIM_OT_hytale_set_head_follow)

    def apply(f, value):
        _run(ui, f, ANIM_OT_hytale_set_head_follow.bl_idname, mode=value)

    def keyframe(f):
        if "FINISHED" in (_run(ui, f, ANIM_OT_hytale_keyframe_switch.bl_idname, switch="HEAD_FOLLOW") or ()):
            f.toast(ui.t("gpu_ui.toast_keyframe").format(name="Head Free/Lock"))

    return SwipeButton("hf.%s" % mode.lower(), label, swipe_group="head", swipe_id="head",
                       swipe_value=mode, swipe_apply=apply, on_insert_key=keyframe,
                       selected=selected, enabled=enabled,
                       tooltip=lambda: ui.t("gpu_ui.tip_head_follow"),
                       style=Style(height=CONTROL_H, flex=1.0))
