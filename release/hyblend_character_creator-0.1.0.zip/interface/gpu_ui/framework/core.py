"""Árvore de widgets + layout flex + lógica de interação, em Python puro.

Nada aqui importa `bpy`: o desenho é delegado a um "renderer" e os eventos
chegam já traduzidos pelo runtime. Isso deixa o framework testável fora do
Blender.

Coordenadas: unidades lógicas (antes da escala de DPI), origem no canto
inferior esquerdo da região, Y para cima — igual ao Blender.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .motion import animate, forget, mix

Color = tuple


# --------------------------------------------------------------------------
# Tipos básicos
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Rect:
    x: float
    y: float
    w: float
    h: float

    @property
    def right(self):
        return self.x + self.w

    @property
    def top(self):
        return self.y + self.h

    def contains(self, px, py):
        return self.x <= px <= self.right and self.y <= py <= self.top

    def inset(self, left, top, right, bottom):
        return Rect(self.x + left, self.y + bottom,
                    max(0.0, self.w - left - right), max(0.0, self.h - top - bottom))

    def expand(self, d):
        return Rect(self.x - d, self.y - d, self.w + 2 * d, self.h + 2 * d)

    def intersect(self, o):
        x, y = max(self.x, o.x), max(self.y, o.y)
        return Rect(x, y, max(0.0, min(self.right, o.right) - x), max(0.0, min(self.top, o.top) - y))


def pad(all=0.0, x=None, y=None):
    """Atalho para padding (esquerda, topo, direita, baixo)."""
    x = all if x is None else x
    y = all if y is None else y
    return (x, y, x, y)


@dataclass(frozen=True)
class Style:
    """Um "CSS" mínimo."""
    width: Optional[float] = None
    height: Optional[float] = None
    flex: float = 0.0                      # divide o espaço que sobrar
    padding: tuple = (0.0, 0.0, 0.0, 0.0)  # esquerda, topo, direita, baixo
    gap: float = 0.0
    background: Optional[Color] = None
    border: Optional[Color] = None
    radius: float = 6.0
    align: str = "stretch"                 # eixo cruzado: stretch|start|center|end
    shadow: bool = False
    pattern: Optional[str] = None          # "dots" = fundo pontilhado via shader
    min_height: Optional[float] = None     # áreas que crescem (ScrollView): menor altura aceitável
    max_height: Optional[float] = None     # teto opcional de crescimento
    clip: bool = False                     # recortar os filhos ao próprio retângulo
    frame: Optional[tuple] = None          # moldura 9-slice: (png, (esq, topo, dir, baixo), escala)
    frame_base: Optional[Color] = None     # cor sólida por baixo da moldura, no formato dela (moldura opaca)


@dataclass(frozen=True)
class Theme:
    """Paleta própria: ardósia azulada + acento violeta."""
    canvas: Color = (0.071, 0.075, 0.094, 1.0)          # #121318
    surface: Color = (0.106, 0.110, 0.137, 1.0)         # #1B1C23
    surface_raised: Color = (0.141, 0.145, 0.180, 1.0)  # #24252E
    surface_hover: Color = (0.184, 0.188, 0.231, 1.0)   # #2F303B
    surface_pressed: Color = (0.220, 0.224, 0.275, 1.0)
    input: Color = (0.055, 0.059, 0.075, 1.0)
    border: Color = (0.60, 0.62, 0.85, 0.10)
    text: Color = (0.925, 0.925, 0.960, 1.0)
    text_muted: Color = (0.545, 0.553, 0.627, 1.0)
    accent: Color = (0.545, 0.482, 1.0, 1.0)            # #8B7BFF
    accent_hover: Color = (0.627, 0.573, 1.0, 1.0)
    accent_pressed: Color = (0.451, 0.388, 0.902, 1.0)
    accent_soft: Color = (0.545, 0.482, 1.0, 0.16)
    accent_text: Color = (1.0, 1.0, 1.0, 1.0)
    track_off: Color = (0.255, 0.259, 0.318, 1.0)
    shadow: Color = (0.0, 0.0, 0.02, 0.6)
    dots: Color = (0.75, 0.72, 1.0, 0.12)
    danger: Color = (1.0, 0.45, 0.50, 1.0)
    danger_soft: Color = (1.0, 0.45, 0.50, 0.14)
    warning: Color = (1.0, 0.76, 0.35, 1.0)
    warning_soft: Color = (1.0, 0.76, 0.35, 0.12)
    success: Color = (0.40, 0.85, 0.60, 1.0)
    # Botão "primary" (None = usa o acento).
    primary: Optional[Color] = None
    primary_hover: Optional[Color] = None
    primary_pressed: Optional[Color] = None
    primary_text: Optional[Color] = None
    # Títulos/botões/abas: peso de fonte, caixa alta e espaço entre letras.
    heading_weight: str = "Medium"
    heading_upper: bool = False
    heading_tracking: float = 0.0
    radius_scale: float = 1.0          # cantos procedurais (0.5 = mais retos)
    # Do CC: borda do TextField focado e barra de rolagem por COR. Sem
    # scroll_thumb (None, padrão) a barra usa a skin do app (arte do jogo)
    # ou o desenho procedural do Toolkit; com ela, o desenho do CC.
    focus: Color = (0.545, 0.482, 1.0, 1.0)
    scroll_thumb: Optional[Color] = None
    scroll_thumb_hot: Optional[Color] = None
    scroll_track: Optional[Color] = None


def heading(th, text):
    """(texto, peso, tracking) de um título/botão conforme o tema."""
    return (text.upper() if th.heading_upper else text), th.heading_weight, th.heading_tracking


def fit_text(r, text, width, size, weight="Regular", tracking=0.0, min_size=9.5):
    """Encaixa um texto numa largura, como o ShrinkTextToFit do jogo:
    primeiro tira o espaço entre letras, depois diminui a fonte até
    `min_size`; se ainda não couber, quem desenha corta com "…" (o
    renderer faz isso sozinho com tracking 0). Devolve (tamanho, tracking)."""
    if width <= 0 or r.text_width(text, size, weight, tracking) <= width:
        return size, tracking
    tracking = 0.0
    while size > min_size and r.text_width(text, size, weight) > width:
        size = max(min_size, size - 0.5)
    return size, tracking


# --------------------------------------------------------------------------
# Skin: arte (PNG) por peça de interface, fornecida pelo app
# --------------------------------------------------------------------------

_skin = None


def set_skin(fn):
    """fn(peça) -> (png, bordas 9-slice em px ou None, escala) | None.
    Peças usadas pelo framework: btn_primary/secondary/danger[_hover|_pressed],
    btn_disabled, btn_active (contorno de selecionado), input[_hover|_edit],
    inset (fundo afundado), tab_marker, tab_separator, checkbox, checkmark,
    scroll_track, scroll_handle[_hover|_drag]. None = tudo procedural."""
    global _skin
    _skin = fn


def has_skin(part):
    return _skin is not None and bool(_skin(part))


def skin(f, rect, part, *, opacity=1.0, tint=None, fallback=None):
    """Desenha a arte da peça (9-slice, ou imagem esticada sem bordas).
    Sem arte (ou PNG ainda carregando): tenta `fallback` (outra peça) e
    devolve False -- quem chama desenha o procedural."""
    if _skin is None:
        return False
    for name in (part, fallback):
        spec = _skin(name) if name else None
        if not spec:
            continue
        path, slices, scale = spec
        r = f.renderer
        if slices:
            drew = r.nine_slice(rect, path, slices, scale=scale, tint=tint, opacity=opacity)
        else:
            drew = r.image(rect, path, fit="stretch", tint=tint, opacity=opacity)
        if drew:
            return True
        # PNG existe mas ainda decodificando: tenta a peça de reserva
        # (ex.: hover ainda carregando -> botão normal, sem piscar).
    return False


@dataclass(frozen=True)
class KeyEvent:
    type: str
    unicode: str = ""
    ctrl: bool = False


class Frame:
    """Tudo que um widget precisa num quadro (ou num evento)."""

    def __init__(self, renderer, state, theme, context=None, now=0.0, host=None):
        self.renderer = renderer
        self.state = state
        self.theme = theme
        self.context = context   # bpy.context (só o app usa; o framework não)
        self.now = now
        self.host = host         # a sessão do runtime (janela/área/região)

    hover = property(lambda self: self.state.get("_hover"))
    pressed = property(lambda self: self.state.get("_pressed"))
    focus = property(lambda self: self.state.get("_focus"))
    mouse = property(lambda self: self.state.get("_mouse", (-1e9, -1e9)))

    def animate(self, key, target, duration=0.14, **kw):
        return animate(self.state, key, target, duration, now=self.now, **kw)

    def track_mouse(self, rect):
        """Widget cujo desenho depende da posição do mouse (não só do hover)."""
        self.state.setdefault("_mouse_rects", []).append(rect)

    def wake_at(self, moment):
        """Pede uma re-renderização num instante futuro (sem animar até lá)."""
        current = self.state.get("_wake_at")
        self.state["_wake_at"] = moment if current is None else min(current, moment)

    def toast(self, text, error=False):
        self.state["_toast"] = (text, self.now, error)


# --------------------------------------------------------------------------
# Widget base
# --------------------------------------------------------------------------

class Widget:
    interactive = False   # recebe clique
    focusable = False     # recebe teclado
    fills = False         # ocupa a largura toda (campo, dropdown...): numa Row divide a sobra
    cursor = None         # cursor do Blender durante arrasto (ex.: "MOVE_Y")
    keeps_focus = False   # True: clicar aqui NÃO tira o foco do campo (ex.: lista de sugestões)

    def __init__(self, key=None, style=None, tooltip=None, children=()):
        self.key = key
        self.style = style or Style()
        self.tooltip = tooltip
        self.children = list(children)
        self.rect = Rect(0, 0, 0, 0)
        self.clip = None   # recorte herdado de um ScrollView

    # ---- layout ----
    _ext_width = None

    def measure(self, f, max_w):
        """Tamanho natural (largura, altura) dado um limite de largura."""
        return (self.style.width if self.style.width is not None else max_w,
                self.style.height if self.style.height is not None else 0.0)

    def extent(self, f, width):
        """(mínima, preferida, máxima) altura para esta largura.

        É a base da altura automática: o painel mede a raiz e escolhe uma
        altura entre a mínima e a máxima. Memorizado por largura: a árvore é
        nova a cada renderização, então o cache nunca fica velho, e medir a
        raiz não re-mede os mesmos filhos várias vezes.
        """
        if self._ext_width != width:
            self._ext_width, self._ext = width, self._extent(f, width)
        return self._ext

    def _extent(self, f, width):
        """Padrão: altura fixa (não cresce nem encolhe)."""
        h = self.style.height if self.style.height is not None else self.measure(f, width)[1]
        return (h, h, h)

    def layout(self, f, rect, clip=None):
        self.rect, self.clip = rect, clip

    # ---- desenho ----
    def draw(self, f):
        self.draw_box(f)
        if self.style.clip:
            f.renderer.push_clip(self.rect if self.clip is None else self.clip.intersect(self.rect))
        try:
            for child in self.children:
                if child.clip is not None and not _overlaps(child.rect, child.clip):
                    continue          # fora da área visível (rolagem): nem desenha
                child.draw(f)
        finally:
            if self.style.clip:
                f.renderer.pop_clip()

    def draw_box(self, f):
        s, r = self.style, f.renderer
        if s.shadow:
            r.shadow(self.rect, s.radius, f.theme.shadow)
        drew_frame = False
        if s.frame:
            path, slices, scale = s.frame
            if s.frame_base:
                r.nine_slice(self.rect, path, slices, scale=scale, tint=s.frame_base, silhouette=True)
            drew_frame = r.nine_slice(self.rect, path, slices, scale=scale)
        if (s.background or s.border) and not drew_frame:
            # Sem a moldura (PNG ausente/ainda carregando): fundo + borda de reserva.
            r.rect(self.rect, s.background or (0, 0, 0, 0), radius=s.radius, border=s.border)
        if s.pattern == "dots":
            r.dots(self.rect.inset(4, 4, 4, 4), f.theme.dots)

    # ---- interação ----
    def visible_at(self, x, y):
        return self.rect.contains(x, y) and (self.clip is None or self.clip.contains(x, y))

    def hit(self, x, y):
        """Widget mais profundo sob o mouse que liga para eventos/tooltip."""
        if not self.visible_at(x, y):
            return None
        for child in reversed(self.children):
            found = child.hit(x, y)
            if found is not None:
                return found
        return self if (self.interactive or self.tooltip) and self.key else None

    def walk(self):
        yield self
        for child in self.children:
            yield from child.walk()

    def on_click(self, f, x, y):
        pass

    def on_focus(self, f, x, y):
        pass

    def on_blur(self, f):
        """Perdeu o foco do teclado (clique fora / Enter). Chamado pelo
        runtime FORA do desenho -- nunca no _measure."""
        pass

    def begin_drag(self, f, x, y):
        """Retorne um dict para iniciar um arrasto; None para clique normal."""
        return None

    def drag(self, f, x, y, data):
        pass

    def end_drag(self, f, data, cancelled):
        pass


def _overlaps(a, b, margin=24.0):
    """Retângulos se cruzam (com folga pra sombra/brilho que vaza do widget)."""
    return (a.x - margin < b.right and b.x < a.right + margin
            and a.y - margin < b.top and b.y < a.top + margin)


def wrap_text(renderer, text, width, size=12.0, weight="Regular", max_lines=None, break_words=False):
    """Quebra `text` em linhas que cabem em `width` (unidades lógicas).
    Respeita \\n. Palavra maior que a linha: fica sozinha (e quem desenha
    trunca) -- ou, com break_words=True, é cortada em pedaços (versão do CC).
    Passando de `max_lines`, a última linha ganha "…"."""
    def measure(t):
        return renderer.text_width(t, size, weight)
    lines = []
    for paragraph in str(text).split("\n"):
        line = ""
        for word in paragraph.split(" "):
            candidate = word if not line else line + " " + word
            if not line or measure(candidate) <= width:
                if line or not break_words or measure(word) <= width:
                    line = candidate
                    continue
            if line:
                lines.append(line)
            while break_words and measure(word) > width and len(word) > 1:     # palavra enorme: corta
                cut = max(1, next((i for i in range(len(word), 0, -1) if measure(word[:i]) <= width), 1))
                lines.append(word[:cut])
                word = word[cut:]
            line = word
        lines.append(line)
    if max_lines is not None and len(lines) > max_lines:
        lines = lines[:max_lines]
        last = lines[-1]
        while last and measure(last + "…") > width:
            last = last[:-1]
        lines[-1] = last.rstrip() + "…"
    return lines


def tooltip_text(widget):
    """String, ou função chamada só na hora de mostrar. Vazio = sem tooltip.
    Exceção dentro da função NÃO derruba o desenho (vira "sem tooltip")."""
    tip = getattr(widget, "tooltip", None)
    if callable(tip):
        try:
            tip = tip()
        except Exception:
            return ""
    return tip or ""


def draw_tooltip(f, key, text, mouse, bounds):
    """Balão de tooltip (com quebra de linha) perto de `mouse`, sempre
    dentro de `bounds`. Usado pelo painel (runtime) e pelas janelas
    flutuantes (overlay). A espera antes de aparecer é de quem chama."""
    a = f.animate("tip." + key, 1.0, 0.16, initial=0.0)
    r, th = f.renderer, f.theme
    mx, my = mouse
    p = bounds
    limit = max(80.0, min(p.w - 8, 300.0)) - 20
    lines = wrap_text(r, str(text), limit, 11, "Medium")[:12]
    line_h = 16.0
    w = min(p.w - 8, max(r.text_width(line, 11, "Medium") for line in lines) + 20)
    h = line_h * len(lines) + 10
    x = min(max(p.x + 4, mx + 10), p.right - w - 4)
    y = my - 14 - h if my - 14 - h > p.y else my + 18
    y = max(p.y + 4, min(y, p.top - h - 4))      # nunca fora da área
    box = Rect(x, y - 4 * (1 - a), w, h)
    old, r.opacity = r.opacity, r.opacity * a
    r.shadow(box, 6, th.shadow, blur=8, dy=-2)
    r.rect(box, th.surface_raised, radius=6, border=th.border)
    top = box.top - 5
    for line in lines:
        r.text(Rect(box.x + 10, top - line_h, box.w - 20, line_h), line, th.text, size=11, weight="Medium")
        top -= line_h
    r.opacity = old


def find_by_key(root, key):
    if root is None or key is None:
        return None
    return next((w for w in root.walk() if w.key == key), None)


def scroll_target(root, x, y):
    """ScrollView mais interno sob o mouse."""
    found = None
    for w in root.walk():
        if isinstance(w, ScrollView) and w.visible_at(x, y):
            found = w
    return found


# --------------------------------------------------------------------------
# Layout flex (Row / Column)
# --------------------------------------------------------------------------

class Flex(Widget):
    def __init__(self, *children, key=None, style=None, tooltip=None):
        if len(children) == 1 and isinstance(children[0], (list, tuple)):
            children = children[0]
        super().__init__(key, style, tooltip, [c for c in children if c is not None])

    @staticmethod
    def _natural_h(f, child, width):
        return child.extent(f, width)[1]

    @staticmethod
    def _natural_w(f, child, max_w):
        return child.style.width if child.style.width is not None else child.measure(f, max_w)[0]

    def _cross(self, f, child, inner, main_is_x, child_w=None):
        """Posição/tamanho no eixo cruzado conforme style.align."""
        align = self.style.align
        if main_is_x:
            width = inner.w if child_w is None else child_w
            size = inner.h if align == "stretch" else min(inner.h, self._natural_h(f, child, width))
            if child.style.height is not None:
                size = min(inner.h, child.style.height)
            start = inner.y
            if align == "center":
                start = inner.y + (inner.h - size) / 2
            elif align == "start":
                start = inner.top - size
            return start, size
        size = inner.w if child.style.width is None else min(inner.w, child.style.width)
        start = inner.x
        if align == "center":
            start = inner.x + (inner.w - size) / 2
        elif align == "end":
            start = inner.right - size
        return start, size


def distribute(sizes, extents, free, flexes):
    """Reparte a sobra (ou a falta) de altura entre os filhos.

    Falta: quem pode encolher (preferida > mínima) cede, proporcional à folga.
    Sobra: quem pode crescer (máxima > preferida) ganha, proporcional à folga;
    o que ainda sobrar vai para quem tem `flex` (ex.: Spacer).
    """
    if free < 0:
        room = [p - lo for lo, p, hi in extents]
        total = sum(room)
        if total > 0:
            k = min(1.0, -free / total)
            sizes = [v - r * k for v, r in zip(sizes, room)]
    elif free > 0:
        room = [hi - p for lo, p, hi in extents]
        total = sum(room)
        if total > 0:
            k = min(1.0, free / total)
            sizes = [v + r * k for v, r in zip(sizes, room)]
            free -= min(free, total)
        flex_total = sum(flexes)
        if free > 0 and flex_total > 0:
            sizes = [v + free * fl / flex_total for v, fl in zip(sizes, flexes)]
    return sizes


class Column(Flex):
    fills = True          # mede a largura toda: numa Row, divide a sobra (ver _row_flex)

    def _child_width(self, child, inner):
        return inner if child.style.width is None else min(inner, child.style.width)

    def _extent(self, f, width):
        s = self.style
        if s.height is not None:
            return (s.height, s.height, s.height)
        l, t, r, b = s.padding
        inner = max(0.0, width - l - r)
        extents = [c.extent(f, self._child_width(c, inner)) for c in self.children]
        extra = s.gap * max(0, len(extents) - 1) + t + b
        return tuple(sum(e[i] for e in extents) + extra for i in range(3))

    def measure(self, f, max_w):
        w = self.style.width if self.style.width is not None else max_w
        return (w, self.extent(f, w)[1])

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        s = self.style
        inner = rect.inset(*s.padding)
        extents = [c.extent(f, self._child_width(c, inner.w)) for c in self.children]
        gaps = s.gap * max(0, len(extents) - 1)
        sizes = distribute([e[1] for e in extents], extents, inner.h - sum(e[1] for e in extents) - gaps,
                           [c.style.flex for c in self.children])
        top = inner.top
        for c, h in zip(self.children, sizes):
            h = max(0.0, h)
            x, w = self._cross(f, c, inner, main_is_x=False)
            c.layout(f, Rect(x, top - h, w, h), clip)
            top -= h + s.gap


def _row_flex(child):
    """Peso de `child` na divisão da sobra de uma Row (0 = tamanho natural).
    Widget que "preenche" (campo de número/texto, dropdown) sem largura
    nem flex explícitos vira flex=1 -- senão o primeiro mede a largura
    toda e empurra os vizinhos pra fora da Row."""
    if child.style.width is not None:
        return 0.0
    if child.style.flex > 0:
        return child.style.flex
    return 1.0 if child.fills else 0.0


class Row(Flex):
    @property
    def fills(self):
        """Row dentro de Row: a interna mede a soma dos naturais (os campos
        que preenchem contam 0), e a externa lhe daria largura quase zero.
        Se algum filho é elástico, a Row inteira também é."""
        return any(_row_flex(c) for c in self.children)

    def _extent(self, f, width):
        s = self.style
        if s.height is not None:
            return (s.height, s.height, s.height)
        l, t, r, b = s.padding
        inner = max(0.0, width - l - r)
        # Cada filho é medido na largura que REALMENTE vai receber (texto que
        # quebra linha muda de altura conforme a largura).
        extents = [c.extent(f, w) for c, w in zip(self.children, self._widths(f, inner))]
        extents = extents or [(0.0, 0.0, 0.0)]
        return tuple(max(e[i] for e in extents) + t + b for i in range(3))

    def measure(self, f, max_w):
        s = self.style
        l, t, r, b = s.padding
        inner = max(0.0, (s.width or max_w) - l - r)
        widths = [0.0 if _row_flex(c) else self._natural_w(f, c, inner) for c in self.children]
        w = s.width if s.width is not None else sum(widths) + s.gap * max(0, len(widths) - 1) + l + r
        return (w, self.extent(f, s.width or max_w)[1])

    def _widths(self, f, inner_w):
        """Largura de cada filho: fixa/natural, e a sobra dividida por
        _row_flex (inclui os widgets que "preenchem"). Usado pelo _extent
        E pelo layout, pros dois nunca divergirem."""
        s = self.style
        sizes, flex_total = [], 0.0
        for c in self.children:
            weight = _row_flex(c)
            if weight > 0:
                sizes.append(None)
                flex_total += weight
            else:
                sizes.append(self._natural_w(f, c, inner_w))
        free = inner_w - sum(v for v in sizes if v is not None) - s.gap * max(0, len(sizes) - 1)
        return [v if v is not None else max(0.0, free) * _row_flex(c) / flex_total
                for v, c in zip(sizes, self.children)]

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        s = self.style
        inner = rect.inset(*s.padding)
        x = inner.x
        for c, w in zip(self.children, self._widths(f, inner.w)):
            y, h = self._cross(f, c, inner, main_is_x=True, child_w=w)
            c.layout(f, Rect(x, y, w, h), clip)
            x += w + s.gap


class Spacer(Widget):
    def __init__(self, flex=1.0, size=None):
        super().__init__(style=Style(flex=flex if size is None else 0.0, width=size, height=size))


class Divider(Widget):
    """Linha de 1 px. vertical=True dentro de uma Row (ocupa a altura toda)."""

    def __init__(self, vertical=False, color=None, thickness=1.0):
        super().__init__(style=Style(width=thickness) if vertical else Style(height=thickness))
        self.color = color

    def draw(self, f):
        f.renderer.rect(self.rect, self.color or f.theme.border)


# --------------------------------------------------------------------------
# Widgets de conteúdo
# --------------------------------------------------------------------------

class Label(Widget):
    def __init__(self, text, size=12.0, weight="Regular", color=None, align="LEFT",
                 key=None, style=None, tooltip=None):
        super().__init__(key, style, tooltip)
        self.text, self.size, self.weight, self.color, self.align = str(text), size, weight, color, align

    def measure(self, f, max_w):
        w = f.renderer.text_width(self.text, self.size, self.weight)
        return (min(w, max_w), round(self.size * 1.7))

    def draw(self, f):
        self.draw_box(f)
        s = self.style
        f.renderer.text(self.rect.inset(*s.padding), self.text, self.color or f.theme.text,
                        size=self.size, weight=self.weight, align=self.align)


class Icon(Widget):
    """Ícone gerado proceduralmente numa textura GPU e tingido no shader."""

    def __init__(self, name, size=16.0, color=None, key=None, style=None, tooltip=None):
        super().__init__(key, style, tooltip)
        self.name, self.size, self.color = name, size, color

    def measure(self, f, max_w):
        return (self.size, self.size)

    def draw(self, f):
        self.draw_box(f)
        r = self.rect
        box = Rect(r.x + (r.w - self.size) / 2, r.y + (r.h - self.size) / 2, self.size, self.size)
        f.renderer.icon(box, self.name, self.color or f.theme.text)


class Image(Widget):
    """PNG do disco. fit: cover | contain | stretch. tint: pinta ícones monocromáticos."""

    def __init__(self, path, fit="contain", radius=0.0, tint=None, placeholder=None,
                 key=None, style=None, tooltip=None):
        super().__init__(key, style, tooltip)
        self.path, self.fit, self.radius, self.tint, self.placeholder = path, fit, radius, tint, placeholder

    def draw(self, f):
        self.draw_box(f)
        if not f.renderer.image(self.rect, self.path, fit=self.fit, radius=self.radius, tint=self.tint) \
                and self.placeholder:
            f.renderer.rect(self.rect, self.placeholder, radius=self.radius)


class Fade(Widget):
    """Envolve um filho aplicando opacidade e deslocamento só no desenho."""

    @property
    def fills(self):
        return self.children[0].fills

    def __init__(self, child, alpha=1.0, dy=0.0, style=None):
        super().__init__(style=style or child.style, children=[child])
        self.alpha, self.dy = alpha, dy

    def measure(self, f, max_w):
        return self.children[0].measure(f, max_w)

    def _extent(self, f, width):
        return self.children[0].extent(f, width)

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        self.children[0].layout(f, rect, clip)

    def draw(self, f):
        r = f.renderer
        old = r.opacity, r.offset_y
        r.opacity *= self.alpha
        r.offset_y += self.dy
        try:
            self.children[0].draw(f)
        finally:
            r.opacity, r.offset_y = old


# --------------------------------------------------------------------------
# Controles interativos
# --------------------------------------------------------------------------

class Button(Widget):
    interactive = True

    def __init__(self, key, text="", on_click=None, icon=None, variant="secondary",
                 selected=False, enabled=True, align="CENTER", style=None, tooltip=None, icon_color=None):
        super().__init__(key, style, tooltip)
        self.text, self.callback, self.icon = text, on_click, icon
        self.variant, self.selected, self.enabled, self.align = variant, selected, enabled, align
        self.icon_color = icon_color      # cor fixa do ícone (ex.: check verde); None = segue o texto

    _SKINNED = {"primary": "btn_primary", "secondary": "btn_secondary", "danger": "btn_danger",
                "tab": "btn_secondary"}

    def _label(self, th):
        """(texto, peso, tracking, tamanho): variantes "de botão" seguem o
        estilo de título do tema; ghost/list continuam texto comum."""
        if self.variant in self._SKINNED:
            text, weight, tracking = heading(th, self.text)
            return text, weight, tracking, 11.0 if th.heading_upper else 12.0
        return self.text, "Medium", 0.0, 12.0

    def measure(self, f, max_w):
        text, weight, tracking, size = self._label(f.theme)
        w = f.renderer.text_width(text, size, weight, tracking) + 24
        if self.icon:
            w += 16 + (6 if self.text else 0)
        return (min(w, max_w), 28.0)

    def _draw_skin(self, f, rect, h, p, sel):
        """Fundo com a arte do jogo (se houver). True = desenhou."""
        part = self._SKINNED.get(self.variant)
        if part is None:
            return False
        if not self.enabled:
            ok = skin(f, rect, "btn_disabled")
        else:
            state = "_pressed" if p > 0.5 else ("_hover" if h > 0.5 else "")
            ok = skin(f, rect, part + state, fallback=part)
        if ok and sel > 0.01:
            skin(f, rect, "btn_active", opacity=sel)
        return ok

    def draw(self, f):
        th, r = f.theme, f.renderer
        hovered = f.hover == self.key and self.enabled
        pressed = hovered and f.pressed == self.key
        h = f.animate(self.key + ".hover", 1.0 if hovered else 0.0, 0.12)
        p = f.animate(self.key + ".press", 1.0 if pressed else 0.0, 0.06)
        sel = f.animate(self.key + ".sel", 1.0 if self.selected else 0.0, 0.18)

        if self.variant == "primary":
            base = th.primary or th.accent
            hov = th.primary_hover or th.accent_hover
            prs = th.primary_pressed or th.accent_pressed
            fg = th.primary_text or th.accent_text
        elif self.variant == "danger":
            base = th.surface_raised
            hov = mix(th.surface_raised, th.danger, 0.35)
            prs = mix(th.surface_raised, th.danger, 0.5)
            fg = th.text
        elif self.variant == "secondary":
            base, hov, prs, fg = th.surface_raised, th.surface_hover, th.surface_pressed, th.text
        elif self.variant == "tab":        # aba: inativa discreta, ativa com acento
            base, hov, prs = th.surface, th.surface_hover, th.surface_pressed
            fg = mix(th.text_muted, th.text, max(h, sel))
        else:  # "ghost" / "list": fundo só aparece no hover
            clear = th.surface_hover[:3] + (0.0,)
            base, hov, prs, fg = clear, th.surface_hover, th.surface_pressed, th.text
        color = mix(mix(base, hov, h), prs, p)
        if sel > 0.001:
            if self.variant == "tab":
                # tema com títulos em caixa alta (Hytale): só um toque do acento,
                # o contorno dourado marca a aba (como o Tertiary_Active do jogo)
                amount = 0.12 if th.heading_upper else 0.30
                color = mix(color, mix(th.surface_raised, th.accent, amount), sel)
            else:
                color = mix(color, th.accent_soft, sel)
        if not self.enabled:
            fg = th.text_muted
            if self.variant == "primary":
                color = mix(th.surface_raised, th.accent, 0.25)

        rect = self.rect.expand(-0.75 * p)   # "afunda" levemente ao clicar
        if self._draw_skin(f, self.rect, h, p, sel):
            if self.variant == "tab" or (self.selected and self.variant == "secondary"):
                fg = mix(fg, th.accent, sel)      # aba/selecionado: texto no acento
        else:
            border = th.border if self.variant in {"secondary", "danger", "tab"} else None
            if sel > 0.001 and self.variant in {"tab", "secondary"} and th.heading_upper:
                border = mix(border or th.border, th.accent, sel)
            r.rect(rect, color, radius=self.style.radius * th.radius_scale, border=border)

        # conteúdo (ícone + texto)
        label, weight, tracking, size = self._label(th)
        icon_w = 16.0 if self.icon else 0.0
        gap = 6.0 if self.icon and self.text else 0.0
        if self.text:     # botão estreito: sem tracking, fonte menor, e só então "…"
            size, tracking = fit_text(r, label, rect.w - 18 - icon_w - gap, size, weight, tracking)
        text_w = r.text_width(label, size, weight, tracking) if self.text else 0.0
        total = icon_w + gap + text_w
        if self.text:
            x = rect.x + 10 if self.align == "LEFT" else rect.x + max(9.0, (rect.w - total) / 2)
        else:     # só ícone: centro exato (a margem de 10 empurrava pra direita)
            x = rect.x + (rect.w - total) / 2
        if self.icon:
            icon_color = mix(th.text_muted, th.accent, sel) if self.variant == "list" else fg
            if self.variant == "tab":
                icon_color = mix(th.text_muted, th.accent_hover, sel)
            if self.variant == "danger" and self.enabled:
                icon_color = mix(th.danger, th.text, h)
            if self.icon_color is not None and self.enabled:
                icon_color = self.icon_color
            r.icon(Rect(x, rect.y + (rect.h - 16) / 2, 16, 16), self.icon, icon_color)
            x += icon_w + gap
        if self.text:
            r.text(Rect(x, rect.y, rect.right - x - 8, rect.h), label, fg, size=size, weight=weight,
                   tracking=tracking)

    def on_click(self, f, x, y):
        if self.enabled and self.callback:
            self.callback(f)


class Toggle(Widget):
    interactive = True
    fills = True

    def __init__(self, key, label, value, on_change, tooltip=None, style=None):
        super().__init__(key, style, tooltip)
        self.label, self.value, self.callback = label, bool(value), on_change

    def measure(self, f, max_w):
        return (max_w, 28.0)

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        hovered = f.hover == self.key
        h = f.animate(self.key + ".hover", 1.0 if hovered else 0.0, 0.12)
        t = f.animate(self.key + ".value", 1.0 if self.value else 0.0, 0.22)
        r.rect(rect, mix(th.surface_hover[:3] + (0.0,), th.surface_hover, h * 0.6),
               radius=6 * th.radius_scale)
        r.text(Rect(rect.x + 8, rect.y, rect.w - 60, rect.h), self.label,
               mix(th.text_muted, th.text, max(t, h)), size=12)
        box = Rect(rect.right - 8 - 18, rect.y + (rect.h - 18) / 2, 18, 18)
        if skin(f, box, "checkbox"):             # arte do jogo: caixinha + check
            if t > 0.02:
                skin(f, box.inset(3, 3, 3, 3), "checkmark", tint=th.accent, opacity=t)
            return
        track = Rect(rect.right - 8 - 30, rect.y + (rect.h - 16) / 2, 30, 16)
        r.rect(track, mix(th.track_off, th.accent, t), radius=8)
        knob_x = track.x + 2 + (track.w - 16) * t
        r.rect(Rect(knob_x, track.y + 2, 12, 12), (1, 1, 1, 1), radius=6)

    def on_click(self, f, x, y):
        self.callback(f, not self.value)


class Segmented(Widget):
    """Abas com um indicador que desliza (animação interrompível).

    options = [(id, rótulo) ou (id, rótulo, ícone)]. Com ícone e pouco
    espaço, mostra só os ícones e o rótulo sob o mouse vira tooltip."""
    interactive = True
    fills = True

    def __init__(self, key, options, value, on_change, style=None, tooltip=None):
        super().__init__(key, style or Style(height=30.0))
        self.options, self.value, self.callback = list(options), value, on_change
        self._fixed_tooltip = tooltip
        self._compact = False
        self._mouse_x = None
        if tooltip or any(len(o) > 2 and o[2] for o in self.options):
            self.tooltip = self._segment_tooltip

    def _segment_tooltip(self):
        """No modo só-ícones, o tooltip é o nome do segmento sob o mouse."""
        if self._compact and self._mouse_x is not None:
            inner, seg = self._segments()
            i = int(min(len(self.options) - 1, max(0, (self._mouse_x - inner.x) // max(seg, 1))))
            return self.options[i][1]
        fixed = self._fixed_tooltip
        return fixed() if callable(fixed) else fixed

    def measure(self, f, max_w):
        return (max_w, 30.0)

    def _segments(self):
        inner = self.rect.inset(2, 2, 2, 2)
        return inner, inner.w / max(1, len(self.options))

    def draw(self, f):
        th, r = f.theme, f.renderer
        skinned = skin(f, self.rect, "inset")
        if not skinned:
            r.rect(self.rect, th.surface, radius=8 * th.radius_scale, border=th.border)
        inner, seg = self._segments()
        ids = [o[0] for o in self.options]
        # Estreito demais pra algum rótulo? Com ícone, a linha inteira vira
        # só ícones (misturar os dois fica torto); o nome vai pro tooltip.
        compact = any(len(o) > 2 and o[2] and r.text_width(o[1], 12, "Medium") > seg - 10
                      for o in self.options)
        index = ids.index(self.value) if self.value in ids else 0
        pos = f.animate(self.key + ".pos", float(index), 0.28)
        if skinned:
            # estilo das abas do jogo: sem "pílula"; separadores + marcador dourado
            for i in range(1, len(self.options)):
                skin(f, Rect(inner.x + i * seg - 1, inner.y + 5, 2, inner.h - 10), "tab_separator")
            marker = Rect(inner.x + pos * seg + seg / 2 - 16, inner.y - 1, 32, 9)
            if not skin(f, marker, "tab_marker"):
                r.rect(Rect(marker.x + 6, inner.y, 20, 2), th.accent, radius=1)
        else:
            r.rect(Rect(inner.x + pos * seg, inner.y, seg, inner.h), th.surface_hover,
                   radius=6 * th.radius_scale)
        f.track_mouse(self.rect)
        mx, my = f.mouse
        self._compact = compact
        self._mouse_x = mx if self.rect.contains(mx, my) else None
        for i, option in enumerate(self.options):
            label = option[1]
            icon = option[2] if len(option) > 2 else None
            cell = Rect(inner.x + i * seg, inner.y, seg, inner.h)
            near = max(0.0, 1.0 - abs(pos - i))
            hov = f.animate(f"{self.key}.hover{i}",
                          1.0 if f.hover == self.key and cell.contains(mx, my) else 0.0, 0.12)
            color = mix(th.text_muted, th.text, max(near, hov * 0.7))
            if skinned:
                color = mix(color, th.accent, near)
            if compact and icon:
                r.icon(Rect(cell.x + (cell.w - 15) / 2, cell.y + (cell.h - 15) / 2, 15, 15),
                       icon, mix(color, th.accent, near * 0.6))
            else:
                text, weight, tracking = heading(th, label)
                size, tracking = fit_text(r, text, cell.w - 8, 10.5 if th.heading_upper else 12, weight,
                                          tracking, min_size=9.0)
                r.text(cell.inset(4, 0, 4, 0), text, color, size=size, weight=weight, align="CENTER",
                       tracking=tracking)

    def on_click(self, f, x, y):
        inner, seg = self._segments()
        i = int(min(len(self.options) - 1, max(0, (x - inner.x) // max(seg, 1))))
        self.callback(f, self.options[i][0])


class TextField(Widget):
    """Campo de texto 100% feito à mão: cursor, piscar, setas, Ctrl+V..."""
    fills = True
    interactive = True
    focusable = True

    def __init__(self, key, placeholder="", on_change=None, icon=None, style=None, tooltip=None,
                 on_commit=None):
        super().__init__(key, style, tooltip)
        self.placeholder, self.callback, self.icon = placeholder, on_change, icon
        self.commit = on_commit        # (f, texto) no Enter e no clique fora; Esc NÃO confirma

    def on_blur(self, f):
        if self.commit:
            self.commit(f, f.state.get(self.key, ""))

    def measure(self, f, max_w):
        return (max_w, 30.0)

    def _text_rect(self):
        left = 30.0 if self.icon else 10.0
        return self.rect.inset(left, 0, 10, 0)

    def _get(self, f):
        text = f.state.get(self.key, "")
        caret = min(len(text), max(0, f.state.get(self.key + ".caret", len(text))))
        return text, caret

    def _set(self, f, text, caret):
        changed = text != f.state.get(self.key, "")
        f.state[self.key] = text
        f.state[self.key + ".caret"] = caret
        f.state[self.key + ".blink"] = f.now          # cursor fica aceso ao digitar
        if changed and self.callback:
            self.callback(f, text)

    def draw(self, f):
        th, r, rect = f.theme, f.renderer, self.rect
        focused = f.focus == self.key
        ft = f.animate(self.key + ".focus", 1.0 if focused else 0.0, 0.16)
        h = f.animate(self.key + ".hover", 1.0 if f.hover == self.key else 0.0, 0.12)
        border = mix(mix(th.border, (1, 1, 1, 0.18), h), th.focus, ft)
        r.rect(rect, th.input, radius=7, border=border, border_width=1.0 + 0.5 * ft)
        if self.icon:
            r.icon(Rect(rect.x + 9, rect.y + (rect.h - 14) / 2, 14, 14), self.icon,
                   mix(th.text_muted, th.focus, ft))
        area = self._text_rect()
        text, caret = self._get(f)
        if not text and not focused:
            r.text(area, self.placeholder, th.text_muted, size=12)
            return
        # rolagem horizontal para manter o cursor visível
        caret_x = r.text_width(text[:caret], 12)
        scroll = max(0.0, caret_x - area.w + 2)
        r.push_clip(area)
        try:
            if text:
                full = r.text_width(text, 12) + 4
                r.text(Rect(area.x - scroll, area.y, full, area.h), text, th.text, size=12, truncate=False)
            elif focused:
                r.text(area, self.placeholder, mix(th.text_muted, th.input, 0.4), size=12)
            blink = (f.now - f.state.get(self.key + ".blink", f.now)) % 1.0 < 0.55
            if focused and blink:
                r.rect(Rect(area.x - scroll + caret_x, area.y + (area.h - 14) / 2, 1.2, 14), th.focus)
        finally:
            r.pop_clip()

    def on_focus(self, f, x, y):
        """Clique posiciona o cursor no caractere mais próximo."""
        text, _ = self._get(f)
        area = self._text_rect()
        caret_x = f.renderer.text_width(text[:f.state.get(self.key + ".caret", len(text))], 12)
        local = x - area.x + max(0.0, caret_x - area.w + 2)
        best = min(range(len(text) + 1), key=lambda i: abs(f.renderer.text_width(text[:i], 12) - local))
        self._set(f, text, best)

    def handle_key(self, f, ev, clipboard):
        text, caret = self._get(f)
        t = ev.type

        def word_left(i):
            while i > 0 and text[i - 1] == " ":
                i -= 1
            while i > 0 and text[i - 1] != " ":
                i -= 1
            return i

        def word_right(i):
            while i < len(text) and text[i] == " ":
                i += 1
            while i < len(text) and text[i] != " ":
                i += 1
            return i

        if t in {"RET", "NUMPAD_ENTER"}:
            f.state.pop("_focus", None)
            self.on_blur(f)
        elif t == "ESC":
            if text:
                self._set(f, "", 0)
            else:
                f.state.pop("_focus", None)
        elif t == "BACK_SPACE":
            start = word_left(caret) if ev.ctrl else max(0, caret - 1)
            self._set(f, text[:start] + text[caret:], start)
        elif t == "DEL":
            end = word_right(caret) if ev.ctrl else min(len(text), caret + 1)
            self._set(f, text[:caret] + text[end:], caret)
        elif t == "LEFT_ARROW":
            self._set(f, text, word_left(caret) if ev.ctrl else max(0, caret - 1))
        elif t == "RIGHT_ARROW":
            self._set(f, text, word_right(caret) if ev.ctrl else min(len(text), caret + 1))
        elif t == "HOME":
            self._set(f, text, 0)
        elif t == "END":
            self._set(f, text, len(text))
        elif ev.ctrl and t == "V":
            paste = clipboard.get().replace("\n", " ").replace("\r", "")
            self._set(f, text[:caret] + paste + text[caret:], caret + len(paste))
        elif ev.ctrl and t == "C":
            clipboard.set(text)
        elif ev.unicode and not ev.ctrl and ev.unicode.isprintable():
            self._set(f, text[:caret] + ev.unicode + text[caret:], caret + len(ev.unicode))
        else:
            return False
        return True


class ScrollView(Widget):
    """Área rolável: recorte via scissor, rolagem suave e barra arrastável."""
    interactive = True
    fills = True
    BAR = 10.0

    def __init__(self, key, content, style=None):
        super().__init__(key, style, None, [content])
        self.content_h = 0.0
        self.max_scroll = 0.0
        self.offset = 0.0

    MIN_VISIBLE = 56.0

    def measure(self, f, max_w):
        w = self.style.width if self.style.width is not None else max_w
        return (w, self.extent(f, w)[1])

    def _extent(self, f, width):
        """A peça que CRESCE: mínima pequena, preferida = style.height, máxima = conteúdo.

        Nunca pede mais altura do que o conteúdo tem (sem espaço vazio).
        """
        s = self.style
        l, t, r, b = s.padding
        content = self.children[0].extent(f, max(0.0, width - l - r - self.BAR))[1]
        full = content + t + b
        high = full if s.max_height is None else min(full, s.max_height)
        preferred = high if s.height is None else min(s.height, high)
        low = min(s.min_height if s.min_height is not None else self.MIN_VISIBLE, preferred)
        return (low, preferred, high)

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        content = self.children[0]
        view = rect.inset(*self.style.padding)
        self._keep_anchor(f, content, view.w - self.BAR)
        self.content_h = content.measure(f, view.w - self.BAR)[1]
        self.max_scroll = max(0.0, self.content_h - view.h)
        target = min(self.max_scroll, max(0.0, f.state.get(self.key, 0.0)))
        f.state[self.key] = target
        self.offset = min(self.max_scroll, max(0.0, f.animate(self.key + ".anim", target, 0.2)))
        bar = self.BAR if self.max_scroll > 0 else 0.0
        inner_clip = view if clip is None else clip.intersect(view)
        content.layout(f, Rect(view.x, view.top - self.content_h + self.offset,
                               view.w - bar, self.content_h), inner_clip)

    def _keep_anchor(self, f, content, width):
        """Largura do conteúdo mudou (redimensionar o painel/sidebar):
        preserva O QUE está no topo da vista, não os pixels.

        Bug herdado do protótipo (DEVELOPER_NOTES item 60): a posição de
        rolagem é guardada em PIXELS. Numa grade, mudar a largura muda o
        número de colunas e o tamanho das células -- os mesmos 400 px
        passam a cair num item completamente diferente, e a grade inteira
        "troca de conteúdo" de uma vez (parece que resetou). Conteúdo que
        sabe se ancorar (`scroll_anchor`/`scroll_offset_for`, ex.
        VirtualGrid) é reposicionado pelo item; a mola da rolagem é
        esquecida pra não deslizar até a posição nova (salto direto)."""
        key_w, key_anchor, key_auto = self.key + ".w", self.key + ".anchor", self.key + ".auto"
        old_w = f.state.get(key_w)
        f.state[key_w] = width
        saved = f.state.get(self.key, 0.0)
        anchored = hasattr(content, "scroll_anchor")
        if old_w is None or abs(old_w - width) < 0.01:
            # Largura estável: a âncora só é (re)gravada quando a rolagem
            # mudou por AÇÃO DO USUÁRIO (roda/arrasto da barra) -- nunca a
            # partir de uma posição que nós mesmos calculamos num reflow,
            # senão cada reancoragem arredonda pro começo da linha e o
            # item do topo DERIVA a cada virada de colunas (achado na
            # simulação: item 8 -> 0 depois de um arrasto completo).
            auto = f.state.get(key_auto)
            if anchored and (auto is None or abs(saved - auto) > 0.5):
                f.state[key_anchor] = content.scroll_anchor(saved, width)
                f.state.pop(key_auto, None)
            return
        if saved > 0 and anchored:
            anchor = f.state.get(key_anchor) or content.scroll_anchor(saved, old_w)
            f.state[key_anchor] = anchor
            f.state[self.key] = f.state[key_auto] = content.scroll_offset_for(anchor, width)
        forget(f.state, self.key + ".anim")

    def _thumb(self):
        if self.max_scroll <= 0:
            return None
        view = self.rect.inset(*self.style.padding)
        track = Rect(self.rect.right - 7, view.y + 2, 4, view.h - 4)
        size = max(24.0, track.h * view.h / max(self.content_h, 1))
        progress = self.offset / self.max_scroll
        return Rect(track.x, track.top - size - (track.h - size) * progress, 4, size), track

    def draw(self, f):
        self.draw_box(f)
        r = f.renderer
        view = self.rect.inset(*self.style.padding)
        r.push_clip(view if self.clip is None else self.clip.intersect(view))
        try:
            self.children[0].draw(f)
        finally:
            r.pop_clip()
        thumb = self._thumb()
        if thumb:
            f.track_mouse(thumb[0].expand(6))
            mx, my = f.mouse
            active = f.state.get("_drag", {}).get("key") == self.key
            near = active or thumb[0].expand(4).contains(mx, my)
            a = f.animate(self.key + ".thumb", 1.0 if near else 0.0, 0.12)
            th = f.theme
            if th.scroll_thumb is not None:        # barra por cor do tema (desenho do CC)
                track_color = th.scroll_track or (0.0, 0.0, 0.0, 0.0)
                if track_color[3] > 0:
                    r.rect(thumb[1], track_color, radius=2)
                r.rect(thumb[0].expand(a * 0.5), mix(th.scroll_thumb, th.scroll_thumb_hot or th.scroll_thumb, a),
                       radius=2)
                return
            if skin(f, thumb[1], "scroll_track"):
                part = "scroll_handle_drag" if active else ("scroll_handle_hover" if near else "scroll_handle")
                if skin(f, thumb[0], part, fallback="scroll_handle"):
                    return
            r.rect(thumb[0].expand(a), (1, 1, 1, 0.18 + 0.22 * a), radius=3)

    def hit(self, x, y):
        if not self.visible_at(x, y):
            return None
        thumb = self._thumb()
        if thumb and thumb[0].expand(4).contains(x, y):
            return self
        return self.children[0].hit(x, y) or self

    def scroll_by(self, f, pixels):
        f.state[self.key] = min(self.max_scroll, max(0.0, f.state.get(self.key, 0.0) + pixels))

    def begin_drag(self, f, x, y):
        thumb = self._thumb()
        if thumb and thumb[0].expand(4).contains(x, y):
            return {"y": y, "start": f.state.get(self.key, 0.0)}
        return None

    def drag(self, f, x, y, data):
        thumb, track = self._thumb() or (None, None)
        if not thumb:
            return
        ratio = self.max_scroll / max(1.0, track.h - thumb.h)
        f.state[self.key] = min(self.max_scroll, max(0.0, data["start"] + (data["y"] - y) * ratio))
        forget(f.state, self.key + ".anim")      # arrasto é direto, sem mola


class VirtualColumn(Widget):
    """Lista virtual: só cria/desenha as linhas visíveis.

    Com 10.000 objetos, uma Column comum criaria 10.000 botões a cada
    reconstrução; esta cria só os ~10 que cabem na tela.
    """
    fills = True

    def __init__(self, key, count, row_height, build_row, gap=0.0):
        super().__init__(key)
        self.count, self.row_h, self.build_row, self.gap = count, row_height, build_row, gap

    def measure(self, f, max_w):
        return (max_w, max(0.0, self.count * (self.row_h + self.gap) - self.gap))

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        step = self.row_h + self.gap
        view = clip or rect
        first = max(0, int((rect.top - view.top) // step))
        last = min(self.count - 1, int((rect.top - view.y) // step))
        self.children = []
        for i in range(first, last + 1):
            row = self.build_row(i)
            if row is None:
                continue
            top = rect.top - i * step
            row.layout(f, Rect(rect.x, top - self.row_h, rect.w, self.row_h), clip)
            self.children.append(row)


class VirtualGrid(Widget):
    """Grade virtual: N colunas, células com proporção fixa; só as visíveis existem.

    columns=None escolhe quantas cabem perto de `cell_width`. build_cell(i, rect)
    devolve o widget da célula i (ou None).
    """
    fills = True

    def __init__(self, key, count, build_cell, *, cell_width=84.0, aspect=1.0, gap=8.0, columns=None):
        super().__init__(key)
        self.count, self.build_cell = count, build_cell
        self.cell_width, self.aspect, self.gap, self.fixed_columns = cell_width, aspect, gap, columns

    def _geometry(self, width):
        cols = self.fixed_columns or max(1, int(round((width + self.gap) / (self.cell_width + self.gap))))
        cell_w = max(1.0, (width - self.gap * (cols - 1)) / cols)
        return cols, cell_w, cell_w * self.aspect

    def measure(self, f, max_w):
        cols, _, cell_h = self._geometry(max_w)
        rows = -(-self.count // cols)
        return (max_w, max(0.0, rows * (cell_h + self.gap) - self.gap))

    # Âncora de rolagem (ver ScrollView._keep_anchor): (índice do primeiro
    # item da linha no topo, fração dessa linha já rolada).
    def scroll_anchor(self, offset, width):
        cols, _, cell_h = self._geometry(width)
        step = cell_h + self.gap
        row = int(offset // step)
        return (row * cols, (offset - row * step) / step)
        # (índice do 1º item da linha do topo; a âncora EXATA é preservada
        # entre reflows por ScrollView._keep_anchor, não re-derivada)

    def scroll_offset_for(self, anchor, width):
        index, frac = anchor
        cols, _, cell_h = self._geometry(width)
        return (index // cols + frac) * (cell_h + self.gap)

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        cols, cell_w, cell_h = self._geometry(rect.w)
        step = cell_h + self.gap
        view = clip or rect
        first = max(0, int((rect.top - view.top) // step))
        last = int((rect.top - view.y) // step)
        self.children = []
        for row in range(first, last + 1):
            for col in range(cols):
                i = row * cols + col
                if i >= self.count:
                    break
                cell = Rect(rect.x + col * (cell_w + self.gap), rect.top - row * step - cell_h, cell_w, cell_h)
                widget = self.build_cell(i)
                if widget is not None:
                    widget.layout(f, cell, clip)
                    self.children.append(widget)


class Wrap(Widget):
    """Itens de tamanho fixo que quebram linha quando não cabem (ex.: bolinhas de cor)."""
    fills = True

    def __init__(self, children, *, item_width, item_height, gap=8.0, row_gap=None, key=None, style=None):
        super().__init__(key, style, None, [c for c in children if c is not None])
        self.iw, self.ih, self.gap = item_width, item_height, gap
        self.row_gap = gap if row_gap is None else row_gap

    def _cols(self, width):
        return max(1, int((width + self.gap) // (self.iw + self.gap)))

    def measure(self, f, max_w):
        rows = -(-len(self.children) // self._cols(max_w)) if self.children else 0
        return (max_w, max(0.0, rows * (self.ih + self.row_gap) - self.row_gap))

    def layout(self, f, rect, clip=None):
        super().layout(f, rect, clip)
        cols = self._cols(rect.w)
        for i, child in enumerate(self.children):
            row, col = divmod(i, cols)
            child.layout(f, Rect(rect.x + col * (self.iw + self.gap),
                                 rect.top - row * (self.ih + self.row_gap) - self.ih, self.iw, self.ih), clip)
