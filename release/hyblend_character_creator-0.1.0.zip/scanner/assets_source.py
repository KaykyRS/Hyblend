"""assets_source.py -- le os arquivos do Assets.zip do jogo DIRETO, sem
extrair tudo de uma vez. O caminho do zip vem da pasta Hytale
configurada nas Preferences (ver hytale_install.py). Pasta Assets ja
extraida nao e mais suportada: o usuario aponta sempre a pasta Hytale.

ESTE ARQUIVO É IDÊNTICO no Character Creator e no Prefabs
(scanner/assets_source.py). Mudou num -> copiar pro outro. A pasta de cache
vem de quem cria a fonte (Documentos/Hyblend/<addon>/assets_cache).

Confirmado: o Assets.zip que o jogo instala e um .zip de verdade, com a
MESMA estrutura da pasta "Assets" que a gente ja mapeou inteira (nao um
formato proprietario que precisaria engenharia reversa) -- por isso da
pra ler com o modulo `zipfile` da biblioteca padrao do Python, sem
dependencia nova nenhuma.

bpy.data.images.load() e json.load() precisam de um caminho REAL no
disco (nao da pra "abrir direto de dentro do zip" sem passar por algum
arquivo intermediario) -- por isso ZipAssetsSource extrai sob demanda,
so o arquivo que for realmente pedido, pra uma pasta de cache, e
reaproveita se ja tiver extraido antes. Isso
significa que a PRIMEIRA vez que um item e usado tem um custo pequeno de
descompactar aquele arquivo especifico; da segunda vez em diante e
leitura direta do cache, sem tocar no .zip de novo.
"""

from __future__ import annotations

import zipfile
from pathlib import Path
from typing import Optional


class AssetsSource:
    """Interface da fonte de Assets (hoje so ZipAssetsSource implementa;
    mantida separada pra quem usa nao depender do formato)."""

    def resolve_common(self, *parts: str) -> Path:
        """Caminho pra UM ARQUIVO relativo a Assets/Common/ (onde moram
        os .blockymodel/texturas de verdade)."""
        raise NotImplementedError

    def resolve_root(self, *parts: str) -> Path:
        """Caminho pra UM ARQUIVO relativo a Assets/ DIRETO."""
        raise NotImplementedError

    def resolve_root_dir(self, *parts: str) -> Path:
        """Caminho pra uma PASTA INTEIRA relativa a Assets/ DIRETO (ex:
        Cosmetics/CharacterCreator/, que o manifest_parser precisa
        listar com glob("*.json")) -- diferente de resolve_root, que so
        serve pra um arquivo especifico."""
        raise NotImplementedError

    def resolve_common_dir(self, *parts: str) -> Path:
        """Idem, mas relativo a Assets/Common/ (ex: Languages/, que
        precisa ser listada recursivamente pra achar os .lang de cada
        idioma)."""
        raise NotImplementedError

    def close(self) -> None:
        """Libera recursos (ex: fecha o .zip aberto). Chamar quando a
        fonte nao for mais usada (ex: usuario trocou de pasta/zip nas
        Preferences, ou o addon foi desabilitado)."""


class ZipAssetsSource(AssetsSource):
    """Le direto de um Assets.zip -- extrai sob demanda (arquivo a
    arquivo, ou pasta inteira quando precisa listar conteudo) pra uma
    pasta de cache espelhando a mesma estrutura interna do zip.

    Detecta uma vez, na construcao, se as entradas do zip tem um prefixo
    de pasta raiz (ex. "Assets/Common/..." em vez de so "Common/...") --
    evita ter que testar isso toda vez que algo e resolvido."""

    def __init__(self, zip_path: Path, cache_dir: Path):
        self.zip_path = zip_path
        self.cache_dir = cache_dir
        self._zf = zipfile.ZipFile(zip_path, "r")
        # Dict (nao lista) de proposito -- _find_entry e chamado MUITO
        # (inclusive de dentro de callbacks de EnumProperty, que o
        # Blender re-executa a cada redraw da UI). Um dict e O(1) por
        # busca; a versao anterior usava list.index(), O(n) -- pouco
        # importa num .zip de teste pequeno, mas um Assets.zip de
        # verdade pode ter milhares de entradas.
        entries = [n for n in self._zf.namelist() if not n.endswith("/")]
        self._entries_by_lower: dict = {n.lower(): n for n in entries}
        self._root_prefix = self._detect_root_prefix()
        # Pastas ja extraidas por completo (ver resolve_root_dir/
        # resolve_common_dir) -- sem isso, cada redraw do dropdown de
        # Categoria reescaneia TODAS as entradas do zip de novo (mesmo
        # que nenhum arquivo novo precise ser escrito, o loop de
        # comparacao de prefixo sozinho ja e desperdicio repetido).
        self._extracted_dirs: set = set()

    def _detect_root_prefix(self) -> str:
        """Devolve "" se as entradas ja comecam direto com "common/"/
        "cosmetics/", ou "algumprefixo/" se tiverem esse prefixo extra
        por cima (confirmado: o Assets.zip real tem "Assets/" como
        prefixo) -- escrito de um jeito que aceita qualquer nome de
        prefixo de 1 nivel, nao so "assets" literal."""
        for lower_name in self._entries_by_lower:
            if lower_name.startswith("common/") or lower_name.startswith("cosmetics/"):
                return ""
        for lower_name in self._entries_by_lower:
            parts = lower_name.split("/", 2)
            if len(parts) >= 2 and parts[1] in ("common", "cosmetics"):
                return parts[0] + "/"
        return ""

    def _find_entry(self, posix_relative: str) -> Optional[str]:
        needle = (self._root_prefix + posix_relative).lower()
        return self._entries_by_lower.get(needle)

    def _extract(self, entry_name: str, dest_relative: str) -> Path:
        dest = self.cache_dir / dest_relative
        if not dest.is_file():
            dest.parent.mkdir(parents=True, exist_ok=True)
            with self._zf.open(entry_name) as src, dest.open("wb") as out:
                out.write(src.read())
        return dest

    def resolve_common(self, *parts: str) -> Path:
        posix_relative = "Common/" + "/".join(parts)
        entry = self._find_entry(posix_relative)
        if entry is None:
            # Path que nao existe de verdade -- quem chama ja confere
            # is_file() antes de usar (mesmo contrato de sempre), entao
            # isso se comporta identico ao caso "pasta solta, arquivo
            # faltando" (ver conversa sobre a Royal Emissary Cape).
            return self.cache_dir / posix_relative
        return self._extract(entry, posix_relative)

    def resolve_root(self, *parts: str) -> Path:
        posix_relative = "/".join(parts)
        entry = self._find_entry(posix_relative)
        if entry is None:
            return self.cache_dir / posix_relative
        return self._extract(entry, posix_relative)

    def resolve_root_dir(self, *parts: str) -> Path:
        """Extrai TODOS os arquivos daquela pasta (dentro do zip) pra
        cache_dir/<pasta>/, e devolve o caminho da pasta de destino --
        necessario pra qualquer coisa que precise listar conteudo (ex.
        manifest_parser.parse_character_creator_folder faz glob("*.json")
        num Path real, nao da pra fingir isso com um arquivo so)."""
        return self._extract_dir("/".join(parts))

    def resolve_common_dir(self, *parts: str) -> Path:
        return self._extract_dir("Common/" + "/".join(parts))

    def _extract_dir(self, posix_dir: str) -> Path:
        dest_dir = self.cache_dir / posix_dir
        if posix_dir in self._extracted_dirs:
            return dest_dir

        full_prefix = (self._root_prefix + posix_dir + "/").lower()
        for lower_name, real_name in self._entries_by_lower.items():
            if lower_name.startswith(full_prefix):
                rel = real_name[len(full_prefix):]
                self._extract(real_name, f"{posix_dir}/{rel}")
        dest_dir.mkdir(parents=True, exist_ok=True)  # garante que existe mesmo se a pasta no zip estiver vazia
        self._extracted_dirs.add(posix_dir)
        return dest_dir

    def close(self) -> None:
        self._zf.close()
