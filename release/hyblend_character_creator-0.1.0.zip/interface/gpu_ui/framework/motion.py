"""Animação por mola (spring) criticamente amortecida, em forma fechada.

Em vez de curvas de easing com duração fixa, cada valor animado se comporta
como uma mola que "puxa" o valor até o alvo sem passar dele. Vantagens:
  * trocar o alvo no meio do caminho preserva a VELOCIDADE atual, então o
    movimento nunca dá "tranco" (ex.: passar o mouse rápido por vários botões);
  * não precisa integrar quadro a quadro: a posição em qualquer instante t é
    calculada por uma fórmula, então quadros atrasados não mudam o resultado.

Solução da mola criticamente amortecida (ω = rigidez):
    x(t) = alvo + (c1 + c2·t)·e^(−ωt),   c1 = x0 − alvo,   c2 = v0 + ω·c1
"""

import math
import time

SETTLE = 6.6   # ω·t em que a mola chega a ~1% do caminho restante


class Spring:
    __slots__ = ("target", "origin", "velocity", "start", "omega")

    def __init__(self, value, omega, now):
        self.target = self.origin = value
        self.velocity = 0.0
        self.start = now
        self.omega = omega

    def sample(self, now):
        """Retorna (valor, velocidade) no instante `now`."""
        t = max(0.0, now - self.start)
        w = self.omega
        c1 = self.origin - self.target
        c2 = self.velocity + w * c1
        decay = math.exp(-w * t)
        value = self.target + (c1 + c2 * t) * decay
        velocity = (c2 - w * (c1 + c2 * t)) * decay
        return value, velocity

    def retarget(self, target, now):
        value, velocity = self.sample(now)
        self.origin, self.velocity, self.start, self.target = value, velocity, now, target

    def settled(self, now):
        return (now - self.start) * self.omega >= SETTLE


def animate(state, key, target, duration=0.15, *, initial=None, now=None):
    """Valor animado de `key` indo em direção a `target` (~`duration` segundos)."""
    now = time.monotonic() if now is None else now
    springs = state.setdefault("_springs", {})
    spring = springs.get(key)
    omega = SETTLE / max(duration, 1e-3)
    if spring is None:
        if initial is None or initial == target:
            # Nasce parada no alvo: já conta como "assentada" (senão cada widget
            # novo, ex. linhas surgindo na lista, forçaria quadros extras).
            springs[key] = Spring(target, omega, now - 1e6)
            return target
        spring = springs[key] = Spring(initial, omega, now)
        spring.target = target
    elif spring.target != target:
        spring.omega = omega
        spring.retarget(target, now)
    if spring.settled(now):
        return spring.target
    state["_motion_active"] = True        # avisa o runtime: continuar animando
    return spring.sample(now)[0]


def forget(state, key):
    """Esquece uma animação (a próxima começa do zero / do `initial`)."""
    state.get("_springs", {}).pop(key, None)


def prune(state, now):
    """Descarta molas paradas em 0.0: recriadas, já nascem no alvo."""
    springs = state.get("_springs")
    if not springs or len(springs) < 64:
        return
    for key, spring in list(springs.items()):
        if spring.target == 0.0 and spring.settled(now):
            del springs[key]


def mix(a, b, t):
    """Interpola duas cores RGBA."""
    t = min(1.0, max(0.0, t))
    return tuple(x + (y - x) * t for x, y in zip(a, b))
