"""compat.py -- camada de compatibilidade Blender 4.5 LTS <-> 5.x (5.0/5.1/
5.2 LTS). UNICO lugar do addon que pode perguntar "qual versao do Blender
e esta?" -- todo o resto chama as funcoes daqui em vez de espalhar
`if bpy.app.version >= ...` pelo codigo.

Camada 0 na hierarquia de import: depende SO de `bpy` (nada interno do
addon), entao qualquer modulo (common, builder/, thumbnails/, interface/)
pode importar daqui sem risco de import circular.

REGRA DE DESIGN: sempre que der, detectar pela PRESENCA do recurso
(hasattr / enum_items / try-except) e usar a versao so como desempate
ou pra escolher a ORDEM de tentativa. Motivo: versao e um proxy -- um
build alpha/beta, ou um patch de manutencao, pode ter o recurso antes/
depois do numero "oficial". Detectar pelo recurso real nunca erra.

Mudancas de API cobertas aqui (fonte: release notes oficiais do
Blender, docs/release_notes/5.0|5.1|5.2/python_api.md -- conferido
durante a sessao que criou este arquivo, ver DEVELOPER_NOTES item 56):

  5.0  - EEVEE: id do engine voltou de BLENDER_EEVEE_NEXT (4.2-4.5) pra
         BLENDER_EEVEE.                          -> set_eevee_engine()
  Materiais (use_nodes, blend_method, Non-Color): no núcleo, api.model.materials.
  5.0  - ImageFormatSettings exige `media_type` ANTES de `file_format`.
                                                  -> set_png_output()
  5.0  - Propriedades registradas via bpy.props NAO sao mais acessiveis
         por `obj["nome"]` (separadas das custom properties). Custom
         property de verdade (`obj["x"] = ...` sem registro) continua
         funcionando igual.                       -> get_id_prop()
  5.1  - Python 3.11 -> 3.13 (nenhum modulo da stdlib usado pelo addon
         foi removido -- conferido: json/zlib/struct/zipfile/tempfile/
         pathlib/dataclasses/re/os/math/shutil).
  5.2  - Nenhuma mudanca que toque este addon (GN modifier API,
         automasking, asset library index, template_palette -- nada
         disso e usado aqui).
"""

from __future__ import annotations

import bpy

# ---------------------------------------------------------------------------
# Versao
# ---------------------------------------------------------------------------

BLENDER_VERSION: tuple = tuple(bpy.app.version[:3])
IS_BLENDER_5_OR_NEWER: bool = BLENDER_VERSION >= (5, 0, 0)


def version_at_least(major: int, minor: int = 0, patch: int = 0) -> bool:
    """Usado pela trava da UI por GPU (interface/gpu_ui, so 5.0+). Pra
    diferenca de API, preferir detectar o recurso (ver cabecalho)."""
    return BLENDER_VERSION >= (major, minor, patch)


# ---------------------------------------------------------------------------
# Render engine
# ---------------------------------------------------------------------------

_EEVEE_ID_5X = "BLENDER_EEVEE"
_EEVEE_ID_4X = "BLENDER_EEVEE_NEXT"


def eevee_engine_candidates() -> tuple:
    """Ordem de tentativa do id do EEVEE -- o nome "certo" da versao
    atual primeiro, o outro como reserva (build intermediario, etc.)."""
    if IS_BLENDER_5_OR_NEWER:
        return (_EEVEE_ID_5X, _EEVEE_ID_4X)
    return (_EEVEE_ID_4X, _EEVEE_ID_5X)


def set_eevee_engine(scene) -> bool:
    """Seta EEVEE no `scene.render.engine` com o id certo pra versao.
    Devolve False (sem lancar) se nenhum dos ids for aceito -- nesse
    caso o engine fica como estava."""
    for engine_id in eevee_engine_candidates():
        try:
            scene.render.engine = engine_id
            return True
        except TypeError:
            continue
    return False


# ---------------------------------------------------------------------------
# Imagens
# ---------------------------------------------------------------------------

def set_png_output(image_settings, color_mode: str = "RGBA") -> None:
    """Configura saida PNG num ImageFormatSettings (ex.
    `scene.render.image_settings`). 5.0+: `media_type` TEM que vir antes
    de `file_format` (senao o formato pode ser recusado). 4.5 nao tem
    `media_type` -- pula direto pro file_format."""
    if hasattr(image_settings, "media_type"):
        try:
            image_settings.media_type = "IMAGE"
        except (AttributeError, TypeError):
            pass
    image_settings.file_format = "PNG"
    image_settings.color_mode = color_mode


# ---------------------------------------------------------------------------
# Propriedades em ID/Bone
# ---------------------------------------------------------------------------

_MISSING = object()


def get_id_prop(owner, name: str, default=None):
    """Le uma propriedade "hytale_*"/"hyblendcc_*" de um Object/Bone/etc.
    independente de COMO ela foi gravada:

      1. custom property de verdade (`owner["name"] = ...`) -- como este
         addon grava, e como o Hyblend gravava ate aqui. Funciona igual
         no 4.5 e no 5.x.
      2. propriedade REGISTRADA via bpy.props (ex. se uma versao futura
         do Hyblend Anim passar a registrar `hytale_shape_offset`
         como property de verdade). No 5.0+ essa NAO aparece mais em
         `owner["name"]`/`owner.get()` -- so via getattr.

    Nao usa `bl_system_properties_get()` de proposito: a propria doc do
    5.0 desaconselha contornar o sistema de RNA assim."""
    try:
        value = owner.get(name, _MISSING)
    except (AttributeError, TypeError):
        value = _MISSING
    if value is not _MISSING:
        return value
    try:
        rna_props = owner.bl_rna.properties
    except AttributeError:
        return default
    if name in rna_props:
        return getattr(owner, name, default)
    return default


# ---------------------------------------------------------------------------
# Icones nativos
# ---------------------------------------------------------------------------

_native_icon_names = None


def _load_native_icon_names():
    global _native_icon_names
    if _native_icon_names is None:
        try:
            items = bpy.types.UILayout.bl_rna.functions["label"].parameters["icon"].enum_items
            _native_icon_names = frozenset(item.identifier for item in items)
        except (AttributeError, KeyError, TypeError):
            # Sem introspeccao disponivel -- confia no nome pedido.
            _native_icon_names = frozenset()
    return _native_icon_names


def native_icon(name: str, fallback: str = "QUESTION") -> str:
    """Nome de icone nativo que EXISTE nesta versao do Blender. Icone
    inexistente em `layout.operator(icon=...)` lanca TypeError e quebra
    o draw() do painel inteiro -- o 5.0 ja removeu icones (ex. RNA_ADD),
    entao qualquer icone novo usado pela UI passa por aqui. Lookup num
    frozenset cacheado: barato o bastante pra rodar em todo draw()."""
    names = _load_native_icon_names()
    if not names or name in names:
        return name
    return fallback if fallback in names else "NONE"
