"""Auto-Rigger -- RIG_OT_hytale_generate_rig, o operador principal ("Create Rig")."""

import math
import os

import bpy
from bpy.types import Operator
from mathutils import Matrix, Vector

from ..common import BONE_RIGGER_CREATED_PROP, is_active_armature
from ..templates import (
    get_shape_template,
)
from ..translations import get_language, tooltip, tr

from .constants import (
    ATTACHMENT_SHAPE_SCALE,
    BODY_COLLECTION_BONES,
    BONE_COLOR_ATTACHMENT,
    BONE_COLOR_FIXED,
    BONE_COLOR_LEFT,
    BONE_COLOR_NAME_FALLBACK,
    BONE_COLOR_RIGHT,
    BONE_COLOR_ROOT_HEAD,
    BONE_COLOR_SPINE,
    BONE_PROPERTIES,
    BONE_ROOT_MASTER,
    BONE_ROOT_PELVIS,
    BONE_ROOT_SPINE,
    COLL_ATTACHMENTS,
    COLL_ATTACHMENTS_IMPORTED,
    COLL_CTRL,
    COLL_CTRL_IK,
    COLL_HYTALE_EXPORT,
    COLL_INTERNAL,
    COLL_MAIN,
    COLL_MAIN_ARM_L,
    COLL_MAIN_ARM_R,
    COLL_MAIN_BODY,
    COLL_MAIN_CHAIN,
    COLL_MAIN_HEAD,
    COLL_MAIN_LEG_L,
    COLL_MAIN_LEG_R,
    COLL_MAIN_ROOT,
    COLL_MAIN_SPINE,
    COLL_MAIN_TEXTURE_PICKER,
    COLL_MCH,
    COLL_MCH_IK,
    COLL_ORG,
    CONSTRAINT_CHILD_OF_GLOBAL,
    CONSTRAINT_CHILD_OF_LOCAL,
    CONSTRAINT_FK_LOC,
    CONSTRAINT_FK_ROT,
    CONSTRAINT_FK_SCALE,
    CONSTRAINT_HEAD_FOLLOW_LOC,
    CONSTRAINT_HEAD_FOLLOW_ROOT,
    CONSTRAINT_HEAD_FOLLOW_ROT,
    CONSTRAINT_IK,
    CONSTRAINT_IK_LOC,
    CONSTRAINT_IK_ROT,
    CONSTRAINT_IK_SCALE,
    CONSTRAINT_TWEAK_FK,
    CONSTRAINT_TWEAK_PARENT,
    CONSTRAINT_ORG_TO_MCH,
    CONSTRAINT_POLE_LINE_STRETCH,
    CONSTRAINT_SPINE_FOLLOW,
    CONTROL_ROTATION_MODE,
    CTRL_PARENT_OVERRIDES,
    CTRL_TAIL_TO_CHILD_TYPES,
    HEAD_FOLLOW_LOC_HEAD_TAIL,
    IK_HINGE_MIN_ALIGNMENT,
    IK_STRETCH_FOLLOWS_PARENT,
    LIMB_X_FROM_Z_TYPES,
    ORIGIN_FALLBACK_LENGTH,
    ORIGIN_ORG_NAME,
    ROOT_CREATED_LENGTH_STEP,
    ROOT_WIDGET_SIZE_STEP,
    ROTATION_EULER_LAYERS,
    PROPERTIES_BONE_OFFSET_Y,
    PROP_CTRL_TAIL_TO_CHILD,
    PROP_HEAD_FOLLOW_SWITCH,
    PROP_RIG_LAYER,
    PROP_SOURCE_ORG,
    ROOT_COLLECTION_BONES,
    ROOT_MASTER_PARENT,
    ROOT_SPINE_LENGTH,
    SPINE_COLLECTION_BONES,
    SPINE_FOLLOW_INFLUENCES,
    SPINE_FOLLOW_TARGET,
    SUFFIX_CTRL,
    SUFFIX_IK,
    SUFFIX_MCH,
    SUFFIX_MCH_IK_TRANSFER,
    SUFFIX_MCH_TWEAK_FK,
    SUFFIX_MCH_TWEAK_PARENT,
    SUFFIX_MCH_TRANSFER,
    SUFFIX_POLE,
    SUFFIX_POLE_LINE,
    SUFFIX_TWEAK,
    TWEAK_COLLECTION_SUFFIX,
    TWEAK_FALLBACK_COLLECTION,
    TWEAK_SHAPE_SCALE,
    WGT_DEFAULT_FALLBACK,
    WIDGET_WIRE_WIDTH,
)

from .rename import normalize_bone_fields
from .helpers import control_name, normalize_org_name, source_org_of, _find_bone_collection_anywhere, _resolve_main_limb_roots, _resolve_parent_override, bone_side_prefix, collect_descendants_inclusive, create_bone_like, ensure_bone_collection, find_attachment_child, find_layer_bone, find_non_attachment_children, find_org_path, ik_solver_target_index, is_attachment_bone, parent_override_candidates, parent_would_loop, resolve_origin_ctrl_name, resolve_root_org_names, resolve_root_slots, resolve_master_source_org_name, resolve_pelvis_org_name, resolve_spine_segment_org_names, is_excluded_from_main_collections, resolve_head_chain_item, resolve_head_ctrl_name, rotate_edit_bone_local_axis, set_bone_collection_visibility
from .constraints import add_custom_shape_scale_switch_driver, add_switch_driver, compute_pole_angle, ensure_child_of_constraint, ensure_copy_constraint, ensure_copy_set, ensure_ik_constraint, ensure_local_add_constraint, ensure_stretch_to_constraint, ensure_switch_parent_constraint, ensure_switch_property, switch_property_name
from .widgets import _ensure_bone_widget_copy, _widget_candidates_for_bone, _widgets_library_path, ensure_widget_objects, get_or_create_widgets_collection, list_widget_library_names
from .bone_collections import COLLECTION_OVERRIDE_AUTO, _head_spine_bone_names, _spine_ctrl_override_transform_bone_name, ensure_default_bone_collection_entries, ensure_default_bone_collections, ensure_default_bone_section_backfill, ensure_texture_picker_collection_entry, ensure_tweak_collection_entry, remove_collection_entry, resolve_collection_override_target, sync_bone_collection_order
from .texture_picker import _texture_picker_cursor_name, _texture_picker_ui_root_name


def _is_right_side(item, org_name):
    """Lado R de um bone de Arm/Leg pro roll espelhado: o Side da entrada; "Center" cai no nome (L-/R-, _left...)."""
    if item.side in ("LEFT", "RIGHT"):
        return item.side == "RIGHT"
    return bone_side_prefix(org_name) == "R"


_RIGGER_ROLE_PALETTES = (
    BONE_COLOR_LEFT, BONE_COLOR_RIGHT, BONE_COLOR_ROOT_HEAD, BONE_COLOR_SPINE, BONE_COLOR_ATTACHMENT,
)


def _is_rigger_palette(normal_color):
    """True se `normal_color` é a cor "normal" de uma das palettes de
    papel que _build_bone_colors aplica (tolerância de float)."""
    return any(
        all(abs(a - b) < 1e-3 for a, b in zip(normal_color, palette[0]))
        for palette in _RIGGER_ROLE_PALETTES
    )


class RIG_OT_hytale_generate_rig(Operator):
    """Cria/atualiza o rig (ORG/MCH/CTRL/IK, utilitários e collections) a partir do Bone Settings; seguro pra rodar de novo."""

    bl_idname = "armature.hytale_generate_rig"
    bl_label = "Create Rig"
    description = tooltip("rigger.tooltip.generate_rig")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not is_active_armature(context):
            return False
        if getattr(obj.data, "hytale_shape_edit_mode", False):
            cls.poll_message_set(
                "Finish Shape Edit Mode first -- rebuilding the rig now would discard the sizes you're editing.",
            )
            return False
        return True

    def execute(self, context):
        obj = context.active_object
        armature = obj.data

        # Garante a lista do Collection Settings (draw() não pode escrever em dados de ID).
        ensure_default_bone_collections(armature)
        ensure_texture_picker_collection_entry(armature)  # v0.10.5 -- backfill p/ armatures já
        # inicializados antes do Texture Picker existir na grade default, ver docstring da função
        ensure_default_bone_section_backfill(armature)  # v0.7.8 -- mesmo padrão, backfill da Section "Main"
        # Campo do Bone Settings apontando pra bone gerado (conta-gotas no Pose Mode) vira o ORG dele.
        normalized_fields = normalize_bone_fields(armature)
        if normalized_fields:
            self.report(
                {"WARNING"},
                f"{normalized_fields} Bone Settings field(s) pointed at generated control bones (e.g. '_CTRL') "
                f"-- switched to the original bones.",
            )
        ensure_default_bone_collection_entries(armature)  # v0.7.9 -- idem, pros outros 10 defaults

        # "Pra baixo" (fallback do Foot_IK) no espaço local do Armature.
        world_down_local = obj.matrix_world.inverted().to_3x3() @ Vector((0.0, 0.0, -1.0))

        bpy.ops.object.mode_set(mode="EDIT")
        try:
            stats, chains_data, tail_chains_data = self._build_edit_bones(armature, world_down_local)
        finally:
            bpy.ops.object.mode_set(mode="OBJECT")

        self._build_pose_constraints(obj, chains_data)
        tail_constraint_count = self._build_tail_pose_constraints(obj, tail_chains_data)
        # Sem root.spine_CTRL não há Spine Follow (evita o aviso de bone não encontrado).
        if stats["spine_ctrl_enabled"]:
            self._build_spine_follow(obj)
        head_follow_built = self._build_head_follow(obj, stats["head_follow_active"], stats["head_follow_source"])
        self._apply_pole_childof_inverses(obj, chains_data, head_follow_built)
        widget_stats = self._build_custom_shapes(obj, chains_data)
        shape_switch_count = self._build_ik_fk_shape_visibility(obj, chains_data)
        colored_count = self._build_bone_colors(obj, chains_data, tail_chains_data)
        self._set_control_rotation_mode(obj)

        # Termina em Pose Mode com o X-Ray do Pose Mode (bones na frente, malha sólida).
        self._enter_pose_with_xray(context, obj)

        self.report(
            {"INFO"},
            f"Rig ready: {stats['mch']} MCH, {stats['ctrl']} CTRL, {stats['ik']} CTRL-IK, {stats['tweak']} Tweak, "
            f"{stats['ik_mch']} MCH-IK, {stats['mch_transfer']} MCH-Transfer, {stats['root']} root control "
            f"bone(s) created; "
            f"{len(chains_data)} IK chain(s) and {len(tail_chains_data)} tail chain(s) processed "
            f"({tail_constraint_count} tail bridge bone(s) constrained); "
            f"{widget_stats['assigned']} custom shape(s) assigned"
            + (f" ({widget_stats['fallback']} via fallback)" if widget_stats["fallback"] else "")
            + (f", {widget_stats['missing']} widget(s) missing (see warnings))" if widget_stats["missing"] else "")
            + f"; {shape_switch_count} FK/IK shape-scale driver(s) set; "
            + f"{colored_count} bone(s) colored"
            + (f"; {stats['ctrl_tail_to_child']} CTRL tail(s) pointed at the child" if stats["ctrl_tail_to_child"] else "")
            + (
                f"; Head Follow active (following '{stats['head_follow_source']}')" if stats["head_follow_active"]
                else "; Head Follow inactive"
            )
            + ".",
        )
        return {"FINISHED"}

    @staticmethod
    def _enter_pose_with_xray(context, obj):
        """Pose Mode + X-Ray do Pose Mode (overlay.show_xray_bone) em todo viewport 3D; headless só troca o modo."""
        if obj.mode != "POSE":
            bpy.ops.object.mode_set(mode="POSE")
        screen = getattr(context, "screen", None)
        for area in (screen.areas if screen is not None else ()):
            if area.type != "VIEW_3D":
                continue
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    space.overlay.show_xray_bone = True
            area.tag_redraw()

    @staticmethod
    def _set_control_rotation_mode(obj):
        """Controles (`*_CTRL`, `*_IK`, `*_Tweak`) em Euler XYZ a cada geração; ORG/MCH em Quaternion.
        Rig antigo com animação em rotation_quaternion nos controles perde essa rotação (reimporte a animação)."""
        for pb in obj.pose.bones:
            if pb.bone.get(PROP_RIG_LAYER) not in ROTATION_EULER_LAYERS:
                continue
            if pb.name.endswith((SUFFIX_CTRL, SUFFIX_IK, SUFFIX_TWEAK)):
                pb.rotation_mode = CONTROL_ROTATION_MODE

    def _build_custom_shapes(self, obj, chains_data):
        """custom_shape dos bones de controle a partir de hytale_widgets.blend (cópia por bone; papel sem shape usa o fallback).
        Só cosmético: sem a biblioteca, avisa e segue. Guarda o Shape Template ativo em self._shape_template_bones."""
        armature = obj.data
        shape_template = get_shape_template(getattr(armature, "hytale_active_shape_template", "")) or {}
        self._shape_template_bones = shape_template.get("bones", {})

        pose_bones = obj.pose.bones
        ik_tip_names = {data["ik_tip"] for data in chains_data}
        head_ctrl_name = resolve_head_ctrl_name(armature)
        # Todo root usa o widget do Origin (comprimentos crescentes -> concêntricos).
        root_ctrl_names = {control_name(armature, name, SUFFIX_CTRL) for name in resolve_root_org_names(armature)}

        wanted = {}
        for pb in pose_bones:
            # layer None só em override de bone nunca gerado (_widget_candidates_for_bone trata).
            layer = pb.bone.get(PROP_RIG_LAYER)
            candidates = _widget_candidates_for_bone(
                pb.name, layer, ik_tip_names, self._shape_template_bones, head_ctrl_name, root_ctrl_names
            )
            if candidates:
                wanted[pb.name] = candidates

        # Apenda de uma vez todo widget candidato; nomes por bone (do template) não estão na biblioteca, resolvidos depois.
        all_candidate_names = {name for candidates in wanted.values() for name in candidates}
        ensure_widget_objects(all_candidate_names, obj)

        widgets_collection = get_or_create_widgets_collection(obj)
        assigned = 0
        used_fallback = 0
        left_default = []
        for bone_name, candidates in wanted.items():
            pb = pose_bones[bone_name]
            # Candidatos em ordem (mais específico primeiro); "mesh" do template só vale pro candidato 0 (o do template).
            bone_mesh_override = self._shape_template_bones.get(bone_name, {}).get("mesh")
            new_shape_obj = None
            resolved_name = None
            for index, candidate in enumerate(candidates):
                embedded_mesh = bone_mesh_override if index == 0 else None
                new_shape_obj = _ensure_bone_widget_copy(
                    candidate, obj, bone_name, widgets_collection, embedded_mesh=embedded_mesh,
                )
                if new_shape_obj is not None:
                    resolved_name = candidate
                    break
            if new_shape_obj is None:
                left_default.append(bone_name)
                continue
            if resolved_name == WGT_DEFAULT_FALLBACK:
                used_fallback += 1
            # Reseta translation/rotation/scale só na primeira atribuição (reruns mantêm ajustes).
            is_first_assignment = pb.custom_shape != new_shape_obj
            pb.custom_shape = new_shape_obj
            pb.use_custom_shape_bone_size = True
            pb.custom_shape_wire_width = WIDGET_WIRE_WIDTH
            if is_first_assignment:
                pb.custom_shape_scale_xyz = (1.0, 1.0, 1.0)
                pb.custom_shape_translation = (0.0, 0.0, 0.0)
                pb.custom_shape_rotation_euler = (0.0, 0.0, 0.0)
            self._apply_widget_transform_override(pb, bone_name)
            assigned += 1

        if left_default:
            # Diz se o problema é "arquivo .blend não encontrado" ou
            # "arquivo encontrado, mas nem o fallback existe dentro dele".
            lib_path = _widgets_library_path()
            if os.path.isfile(lib_path):
                available = list_widget_library_names()
                available_hint = ", ".join(sorted(available)) if available else "(none readable)"
                path_hint = (
                    f"library found at '{lib_path}', but not even '{WGT_DEFAULT_FALLBACK}' exists inside it "
                    f"-- library actually contains: {available_hint}"
                )
            else:
                path_hint = f"library file not found at '{lib_path}'"
            self.report(
                {"WARNING"},
                f"No widget shape could be resolved at all ({path_hint}) for {len(left_default)} bone(s): "
                f"{', '.join(sorted(left_default))} -- affected bone(s) left with Blender's default shape.",
            )
        elif used_fallback:
            self.report(
                {"INFO"},
                f"{used_fallback} bone(s) fell back to '{WGT_DEFAULT_FALLBACK}' -- their preferred shape "
                f"(character-specific override and/or the generic shape for their role) wasn't found. Check "
                f"the active Shape Template (Character Templates) and hytale_widgets.blend.",
            )

        self._size_root_widgets(armature, pose_bones)

        # Widget do root.spine_CTRL com Override Transform no `_CTRL` do último bone da Spine (só a orientação segue).
        spine_ctrl_pose = pose_bones.get(BONE_ROOT_SPINE)
        if spine_ctrl_pose is not None:
            override_bone_name = _spine_ctrl_override_transform_bone_name(armature)
            spine_ctrl_pose.custom_shape_transform = (
                pose_bones.get(override_bone_name) if override_bone_name else None
            )

        return {
            "assigned": assigned,
            "fallback": used_fallback,
            "missing": len(left_default),
        }

    def _size_root_widgets(self, armature, pose_bones):
        """Widget dos Roots 2..N = ROOT_WIDGET_SIZE_STEP × o do Root de baixo (independe do comprimento); "scale" do template vence."""
        names = [control_name(armature, n, SUFFIX_CTRL) for n in resolve_root_org_names(armature)]
        below = None
        for name in names:
            pb = pose_bones.get(name)
            if pb is None or pb.custom_shape is None:
                below = None
                continue
            if below is not None and "scale" not in self._shape_template_bones.get(name, {}):
                length = pb.bone.length
                if length > 1e-9:
                    factor = ROOT_WIDGET_SIZE_STEP * below.bone.length / length
                    pb.custom_shape_scale_xyz = tuple(v * factor for v in below.custom_shape_scale_xyz)
            below = pb

    def _apply_widget_transform_override(self, pose_bone, bone_name):
        """Aplica o Shape Template ativo (translation/rotation_deg/scale presentes); attachment sem "scale" usa ATTACHMENT_SHAPE_SCALE; Tweak sem translation: widget no pivô (o meio da peça)."""
        shape_bones = getattr(self, "_shape_template_bones", {})
        override = shape_bones.get(bone_name, {})
        if "translation" in override:
            pose_bone.custom_shape_translation = tuple(override["translation"])
        elif pose_bone.bone.get(PROP_RIG_LAYER) == "CTRL-TWEAK":
            pose_bone.custom_shape_translation = (0.0, 0.0, 0.0)  # o pivô já fica no meio da peça
        if "rotation_deg" in override:
            pose_bone.custom_shape_rotation_euler = tuple(math.radians(v) for v in override["rotation_deg"])
        if "scale" in override:
            pose_bone.custom_shape_scale_xyz = tuple(override["scale"])
        elif is_attachment_bone(pose_bone):
            pose_bone.custom_shape_scale_xyz = (ATTACHMENT_SHAPE_SCALE,) * 3

    @staticmethod
    def _show_tweak_widgets(pose_bones, names, shape_bones):
        """Tweak vale no FK e no IK: widget sempre visível (sem driver), no "scale" do template ou TWEAK_SHAPE_SCALE."""
        for name in names:
            pb = pose_bones.get(name)
            if pb is None:
                continue
            for i in range(3):
                pb.driver_remove("custom_shape_scale_xyz", i)
            scale = shape_bones.get(name, {}).get("scale")
            pb.custom_shape_scale_xyz = tuple(scale) if scale is not None else TWEAK_SHAPE_SCALE

    def _build_ik_fk_shape_visibility(self, obj, chains_data):
        """Drivers que escondem o widget do lado inativo (FK: `_CTRL`; IK: `_IK`, pole, pole line); Tweak sempre visível. Tamanho cheio = "scale" do template."""
        pose_bones = obj.pose.bones
        shape_bones = getattr(self, "_shape_template_bones", {})

        def _scale_target(bone_name):
            scale = shape_bones.get(bone_name, {}).get("scale")
            return tuple(scale) if scale is not None else (1.0, 1.0, 1.0)

        applied = 0
        for data in getattr(self, "_spine_tweak_data", ()):
            self._show_tweak_widgets(pose_bones, data["tweaks"], shape_bones)
        for data in chains_data:
            switch_prop = data["switch_property"]
            for org_name in data["org_names"]:
                fk_name = control_name(obj.data, org_name, SUFFIX_CTRL)
                ik_name = control_name(obj.data, org_name, SUFFIX_IK)

                fk_pb = pose_bones.get(fk_name)
                if fk_pb is not None:
                    target = _scale_target(fk_name)
                    add_custom_shape_scale_switch_driver(fk_pb, obj, BONE_PROPERTIES, switch_prop, target, mode="FK")
                    applied += 1

                ik_pb = pose_bones.get(ik_name)
                if ik_pb is not None:
                    target = _scale_target(ik_name)
                    add_custom_shape_scale_switch_driver(ik_pb, obj, BONE_PROPERTIES, switch_prop, target, mode="IK")
                    applied += 1

            self._show_tweak_widgets(pose_bones, data["tweaks"], shape_bones)

            # Pole e Pole Line: mesmo driver dos bones IK.
            for key in ("pole", "pole_line"):
                name = data.get(key)
                pb = pose_bones.get(name) if name else None
                if pb is not None:
                    target = _scale_target(name)
                    add_custom_shape_scale_switch_driver(pb, obj, BONE_PROPERTIES, switch_prop, target, mode="IK")
                    applied += 1
        return applied

    def _bone_settings_color_map(self, armature_data, chains_data, tail_chains_data):
        """{ORG: palette} pelo que está marcado no Bone Settings (independe do nome).
        Direta (campo do Bone Settings; ordem: Root, Head, Attachments, Arm/Leg, Neck, Spine, Chain) > herdada pelos filhos
        de Arm/Leg (attachments não herdam) > Root Parent de Arm/Leg (se não for de lados diferentes)."""
        side_palette = {"LEFT": BONE_COLOR_LEFT, "RIGHT": BONE_COLOR_RIGHT}
        items = list(getattr(armature_data, "hytale_ik_chains", []))
        direct = {}

        def claim(name, palette):
            if name and name not in direct:
                direct[name] = palette

        # Root (Origin + roots extras) -- amarelo, igual ao Origin_CTRL.
        for name in resolve_root_org_names(armature_data) if resolve_root_slots(armature_data) else ():
            claim(name, BONE_COLOR_ROOT_HEAD)
        # Head (todas as entradas HEAD -- criatura de várias cabeças).
        for item in items:
            if item.chain_type == "HEAD":
                claim(item.head_bone, BONE_COLOR_ROOT_HEAD)
        # Attachments.
        for item in items:
            if item.chain_type == "ATTACHMENTS":
                for name in _head_spine_bone_names(item):
                    claim(name, BONE_COLOR_ATTACHMENT)
        # Arm/Leg -- o caminho REAL que o gerador montou (chains_data),
        # não só root/tip: inclui todo bone do meio (antebraço etc.).
        limb_chains = []
        for data in chains_data:
            palette = side_palette.get(data.get("side"))
            if palette is None:
                continue  # lado "Center" -- sem cor de lado, cai no fallback
            for name in data.get("org_names", ()):
                claim(name, palette)
            limb_chains.append((data, palette))
        # Neck (1..neck_count de cada entrada HEAD).
        for item in items:
            if item.chain_type == "HEAD":
                neck_slots = [getattr(item, f"neck_bone_{i}", "") for i in range(1, 6)]
                for name in neck_slots[: item.neck_count]:
                    claim(name, BONE_COLOR_SPINE)
        # Spine (Pelvis + Spine 1..N).
        for item in items:
            if item.chain_type == "SPINE":
                for name in _head_spine_bone_names(item):
                    claim(name, BONE_COLOR_SPINE)
        # Chain -- o caminho inteiro montado pelo gerador.
        for data in tail_chains_data or ():
            for name in data.get("org_names", ()):
                claim(name, BONE_COLOR_SPINE)

        # Herança: descendentes ORG dos bones de Arm/Leg.
        inherited = {}
        bones = armature_data.bones
        for data, palette in limb_chains:
            stack = []
            for name in data.get("org_names", ()):
                bone = bones.get(name)
                if bone is not None:
                    stack.extend(bone.children)
            while stack:
                child = stack.pop()
                if child.get(PROP_RIG_LAYER) is not None:
                    continue  # bone gerado -- só anda pela árvore ORG
                if is_attachment_bone(child):
                    continue  # attachment fica cinza (fallback), e não repassa cor
                if child.name in direct:
                    continue  # tem papel próprio -- ele (e o que estiver abaixo) segue a entrada dele
                inherited.setdefault(child.name, palette)
                stack.extend(child.children)

        # Root Parent de Arm/Leg (ombro).
        root_parent_claims = {}
        for data, palette in limb_chains:
            name = (data.get("parent_override") or "").strip()
            if name.endswith(SUFFIX_CTRL):
                name = name[: -len(SUFFIX_CTRL)]
            # Root Parent pode vir como apelido de controle ("L-Shoulder"
            # de um ORG "torso") -- a cor é gravada pelo nome do ORG.
            name = normalize_org_name(armature_data.bones, name) if name else name
            candidates = parent_override_candidates(armature_data, name)
            if not name or not candidates or candidates[0] == BONE_ROOT_PELVIS:
                continue  # o Pelvis (-> root.pelvis_CTRL) não é bone do membro
            root_parent_claims.setdefault(name, set()).add(palette)

        result = dict(inherited)
        for name, palettes in root_parent_claims.items():
            if len(palettes) == 1 and name not in result:
                result[name] = next(iter(palettes))
        result.update(direct)
        return result

    def _build_bone_colors(self, obj, chains_data=(), tail_chains_data=None):
        """Cor de exibição dos bones (bone.color): 1) BONE_COLOR_FIXED; 2) Bone Settings; 3) fallback por nome.
        ORG e bones de UI do Texture Picker ficam de fora."""
        role_palettes = self._bone_settings_color_map(obj.data, chains_data or (), tail_chains_data)
        colored = 0
        for bone in obj.data.bones:
            layer = bone.get(PROP_RIG_LAYER)
            if layer is None:
                # ORG sem cor (e limpa a de rigs antigos).
                if bone.color.palette == "CUSTOM":
                    bone.color.palette = "DEFAULT"
                continue
            if layer == "UI-CTRL":
                continue

            palette = BONE_COLOR_FIXED.get(bone.name)
            if palette is None:
                org_name = source_org_of(bone)
                if org_name is not None:
                    palette = role_palettes.get(org_name)
            if palette is None:
                palette = BONE_COLOR_NAME_FALLBACK.get(bone.name)
            if palette is None and is_attachment_bone(bone):
                # Attachment vence o lado no nome (fica cinza).
                palette = BONE_COLOR_ATTACHMENT
            if palette is None:
                side = bone_side_prefix(bone.name)
                if side == "L":
                    palette = BONE_COLOR_LEFT
                elif side == "R":
                    palette = BONE_COLOR_RIGHT
            if palette is None:
                # Bone que perdeu o papel: tira a cor só se for uma do rigger (cor manual fica).
                if bone.color.palette == "CUSTOM" and _is_rigger_palette(bone.color.custom.normal):
                    bone.color.palette = "DEFAULT"
                continue
            normal, select, active = palette
            bone.color.palette = "CUSTOM"
            bone.color.custom.normal = normal
            bone.color.custom.select = select
            bone.color.custom.active = active
            colored += 1
        return colored

    def _apply_pole_childof_inverses(self, obj, chains_data, head_follow_built=False):
        """Set Inverse dos Child Of do pole, da ponta IK e do Head Follow, sempre na rest (Action/NLA/pose desligadas e restauradas no fim)."""
        prev_mode = obj.mode
        if obj.mode != "POSE":
            bpy.ops.object.mode_set(mode="POSE")

        view_layer = bpy.context.view_layer
        prev_active = view_layer.objects.active
        view_layer.objects.active = obj

        # Desliga a Action e muta as NLA tracks, pra nada reaplicar pose no meio do Set Inverse.
        anim_data = obj.animation_data
        prev_action = anim_data.action if anim_data is not None else None
        if anim_data is not None and prev_action is not None:
            anim_data.action = None
        prev_track_mutes = []
        if anim_data is not None:
            for track in anim_data.nla_tracks:
                prev_track_mutes.append((track, track.mute))
                track.mute = True

        # Zera a pose de cada bone (guardando pra restaurar).
        saved_pose = {pb.name: pb.matrix_basis.copy() for pb in obj.pose.bones}
        for pb in obj.pose.bones:
            pb.matrix_basis = Matrix.Identity(4)
        view_layer.update()

        try:
            targets_by_bone = []
            for data in chains_data:
                targets_by_bone.append((data["pole"], (CONSTRAINT_CHILD_OF_LOCAL, CONSTRAINT_CHILD_OF_GLOBAL)))
                targets_by_bone.append((data["ik_tip"], (CONSTRAINT_CHILD_OF_GLOBAL,)))
            if head_follow_built:
                targets_by_bone.append(
                    (resolve_head_ctrl_name(obj.data), (CONSTRAINT_HEAD_FOLLOW_ROT, CONSTRAINT_HEAD_FOLLOW_ROOT))
                )

            for bone_name, constraint_names in targets_by_bone:
                pose_bone = obj.pose.bones.get(bone_name)
                if pose_bone is None:
                    continue
                obj.data.bones.active = pose_bone.bone
                for cname in constraint_names:
                    if cname not in pose_bone.constraints:
                        continue
                    try:
                        with bpy.context.temp_override(object=obj, active_object=obj, active_pose_bone=pose_bone):
                            bpy.ops.constraint.childof_set_inverse(constraint=cname, owner="BONE")
                    except Exception as exc:
                        self.report(
                            {"WARNING"},
                            f"Could not auto Set Inverse for '{cname}' on '{bone_name}': {exc}. "
                            f"Set it manually in the constraint panel.",
                        )
        finally:
            # Restaura a pose PRIMEIRO -- antes de religar a Action,
            # senão seria imediatamente sobrescrita por ela.
            for pb in obj.pose.bones:
                mb = saved_pose.get(pb.name)
                if mb is not None:
                    pb.matrix_basis = mb
            for track, was_muted in prev_track_mutes:
                track.mute = was_muted
            if anim_data is not None and prev_action is not None:
                anim_data.action = prev_action
            view_layer.update()

        view_layer.objects.active = prev_active
        if obj.mode != prev_mode:
            bpy.ops.object.mode_set(mode=prev_mode)

    # --- Etapa 1 (Edit Mode): collections + bones ---

    def _create_rigger_root_bone(self, edit_bones, name, world_down_local, length):
        """Bone "ORG" criado pelo rigger (Origin automático / Root "New Bone"), sem pai, na origem; fora do export."""
        bone = edit_bones.new(name)
        bone.head = Vector((0.0, 0.0, 0.0))
        down = world_down_local if world_down_local.length > 1e-9 else Vector((0.0, 0.0, -1.0))
        bone.tail = bone.head - down.normalized() * length
        bone.roll = 0.0
        bone.parent = None
        bone.use_deform = False
        bone[BONE_RIGGER_CREATED_PROP] = True
        return bone

    def _ensure_root_bones(self, armature, edit_bones, world_down_local):
        """Bones de root antes do loop genérico: com entrada ROOT, cria os slots "New Bone" (comprimento crescente);
        sem ela (legado), cria o Origin se o modelo não tiver (fora do export)."""
        slots = resolve_root_slots(armature)
        if not slots:
            if ORIGIN_ORG_NAME in edit_bones:
                return 0
            self._create_rigger_root_bone(edit_bones, ORIGIN_ORG_NAME, world_down_local, ORIGIN_FALLBACK_LENGTH)
            self.report(
                {"INFO"},
                f"No '{ORIGIN_ORG_NAME}' bone found on this armature -- created one at the world center so "
                f"'{ROOT_MASTER_PARENT}' and the rest of the rig can still be generated normally (Blender "
                f"only, not exported). Add a ROOT entry in Bone Settings to use one of the model's bones instead.",
            )
            return 1

        # Bones do rigger fora de qualquer slot são removidos com as camadas (bone do modelo nunca).
        wanted = {name for _slot, name, _create in slots}
        stale = [b.name for b in edit_bones if b.get(BONE_RIGGER_CREATED_PROP) and b.name not in wanted]
        for stale_name in stale:
            for suffix in ("", SUFFIX_CTRL, SUFFIX_MCH, SUFFIX_MCH_TRANSFER):
                bone = edit_bones.get(stale_name + suffix)
                if bone is not None:
                    edit_bones.remove(bone)
        if stale:
            self.report(
                {"INFO"},
                f"Removed {len(stale)} root bone(s) created by an earlier Create Rig that are no longer in the "
                f"Root entry: {', '.join(stale)}.",
            )

        created = 0
        for slot, name, create in slots:
            if name in edit_bones:
                continue
            if not create:
                self.report(
                    {"WARNING"},
                    f"Root {slot}: bone '{name}' not found -- pick an existing bone or turn on 'New Bone'.",
                )
                continue
            length = ORIGIN_FALLBACK_LENGTH * (1.0 + ROOT_CREATED_LENGTH_STEP * (slot - 1))
            self._create_rigger_root_bone(edit_bones, name, world_down_local, length)
            created += 1
        if created:
            self.report({"INFO"}, f"Created {created} root bone(s) (Blender only, not exported).")
        return created

    # Roots encadeados na última geração, um nome por linha (ID property não aceita lista de strings).
    _ROOT_CHAIN_APPLIED_PROP = "hytale_root_chain_applied"

    @staticmethod
    def _natural_ctrl_parent(edit_bones, ctrl):
        """Pai "natural" de um _CTRL -- o que o loop genérico daria,
        espelhando o ORG (o _CTRL do pai do ORG), ou None."""
        org = edit_bones.get(source_org_of(ctrl))
        if org is None or org.parent is None:
            return None
        return find_layer_bone(edit_bones, org.parent.name, SUFFIX_CTRL)

    def _reset_ctrl_to_natural_parent(self, edit_bones, ctrl):
        natural = self._natural_ctrl_parent(edit_bones, ctrl)
        if natural is None or not parent_would_loop(ctrl, natural):
            ctrl.parent = natural
            ctrl.use_connect = False

    def _apply_root_chain_parents(self, armature, edit_bones):
        """Root N > ... > Root 1 na camada `_CTRL` (a hierarquia ORG exportada não muda).
        Antes, os roots da geração anterior voltam pro pai natural."""
        previous = armature.get(self._ROOT_CHAIN_APPLIED_PROP, "")
        previous_names = previous.split("\n") if isinstance(previous, str) else []
        for name in previous_names:
            if not name:
                continue
            ctrl = find_layer_bone(edit_bones, name, SUFFIX_CTRL)
            if ctrl is not None:
                self._reset_ctrl_to_natural_parent(edit_bones, ctrl)

        slots = resolve_root_slots(armature)
        ctrls = []
        for _slot, name, _create in slots:
            ctrl = find_layer_bone(edit_bones, name, SUFFIX_CTRL)
            if ctrl is not None:
                ctrls.append(ctrl)

        for child, parent in zip(ctrls, ctrls[1:]):
            if parent_would_loop(child, parent):
                self.report(
                    {"WARNING"},
                    f"Root '{parent.name}' is already below '{child.name}' in the hierarchy -- can't make it "
                    f"the parent (would create a loop), skipped.",
                )
                continue
            child.parent = parent
            child.use_connect = False

        applied = [source_org_of(c) for c in ctrls] if len(ctrls) > 1 else []
        if applied:
            armature[self._ROOT_CHAIN_APPLIED_PROP] = "\n".join(applied)
        elif self._ROOT_CHAIN_APPLIED_PROP in armature:
            del armature[self._ROOT_CHAIN_APPLIED_PROP]

    def _build_edit_bones(self, armature, world_down_local):
        coll_export = ensure_bone_collection(armature, COLL_HYTALE_EXPORT)
        coll_internal = ensure_bone_collection(armature, COLL_INTERNAL)
        coll_org = ensure_bone_collection(armature, COLL_ORG, parent=coll_internal)
        coll_mch = ensure_bone_collection(armature, COLL_MCH, parent=coll_internal)
        coll_mch_ik = ensure_bone_collection(armature, COLL_MCH_IK, parent=coll_internal)
        coll_ctrl = ensure_bone_collection(armature, COLL_CTRL, parent=coll_internal)
        coll_ctrl_ik = ensure_bone_collection(armature, COLL_CTRL_IK, parent=coll_internal)
        coll_attachments_imported = ensure_bone_collection(armature, COLL_ATTACHMENTS_IMPORTED, parent=coll_internal)

        edit_bones = armature.edit_bones
        self._ensure_root_bones(armature, edit_bones, world_down_local)

        org_bones = [b for b in edit_bones if PROP_RIG_LAYER not in b.keys()]
        org_by_name = {b.name: b for b in org_bones}
        ordered = self._order_top_down(org_bones, org_by_name)

        stats = {
            "mch": 0, "ctrl": 0, "ik": 0, "ik_mch": 0, "tweak": 0, "root": 0, "mch_transfer": 0, "ctrl_tail_to_child": 0,
            "head_follow_active": False, "head_follow_source": None,
            "spine_ctrl_enabled": True,
        }

        for org in ordered:
            coll_org.assign(org)
            if org.get(BONE_RIGGER_CREATED_PROP):
                # Bone criado pelo rigger: sai da collection de export.
                coll_export.unassign(org)
            else:
                coll_export.assign(org)
            if is_attachment_bone(org):
                coll_attachments_imported.assign(org)

            parent_name = org.parent.name if (org.parent and org.parent.name in org_by_name) else None

            mch, is_new = create_bone_like(edit_bones, org, org.name + SUFFIX_MCH)
            mch[PROP_SOURCE_ORG] = org.name
            if is_new:
                mch.parent = find_layer_bone(edit_bones, parent_name, SUFFIX_MCH)
                mch.use_connect = bool(org.use_connect and mch.parent is not None)
                mch[PROP_RIG_LAYER] = "MCH"
                stats["mch"] += 1
            coll_mch.assign(mch)

            # Nome do `_CTRL` por control_name() (apelido); PROP_SOURCE_ORG gravado toda vez.
            ctrl, is_new = create_bone_like(edit_bones, org, control_name(armature, org.name, SUFFIX_CTRL))
            ctrl[PROP_SOURCE_ORG] = org.name
            if is_new:
                ctrl.parent = find_layer_bone(edit_bones, parent_name, SUFFIX_CTRL)
                ctrl.use_connect = bool(org.use_connect and ctrl.parent is not None)
                ctrl[PROP_RIG_LAYER] = "CTRL"
                stats["ctrl"] += 1
            coll_ctrl.assign(ctrl)

            # Ponte genérica: rest do ORG, nunca connected, filha do `_CTRL` (reatribuída toda vez).
            transfer, is_new = create_bone_like(edit_bones, org, org.name + SUFFIX_MCH_TRANSFER)
            transfer[PROP_SOURCE_ORG] = org.name
            if is_new:
                transfer[PROP_RIG_LAYER] = "MCH-TRANSFER"
                stats["mch_transfer"] += 1
            transfer.parent = ctrl
            transfer.use_connect = False
            coll_mch_ik.assign(transfer)

        # Utilitários antes da camada IK; root.spine_CTRL opcional (lido da 1ª entrada SPINE).
        spine_item = next((it for it in armature.hytale_ik_chains if it.chain_type == "SPINE"), None)
        stats["spine_ctrl_enabled"] = spine_item.spine_ctrl_enabled if spine_item is not None else True
        stats["root"] += self._build_root_controls(armature, edit_bones, coll_ctrl, stats["spine_ctrl_enabled"])
        self._apply_ctrl_parent_overrides(armature, edit_bones)
        self._apply_root_chain_parents(armature, edit_bones)

        resolved_chains = self._resolve_chains(edit_bones, armature)
        chains_data = self._build_ik_layer(
            armature, edit_bones, coll_ctrl_ik, coll_mch_ik, resolved_chains, stats, world_down_local
        )

        # Continuous Chain: depois de criar/reparentar os `_CTRL` e antes da camada Chain (que vence).
        self._ctrl_tail_redirected = self._apply_ctrl_tail_to_child(armature, edit_bones)
        stats["ctrl_tail_to_child"] = len(self._ctrl_tail_redirected)

        resolved_tail_chains = self._resolve_tail_chains(edit_bones, armature)
        tail_chains_data = self._build_tail_layer(armature, edit_bones, resolved_tail_chains)

        # Head Follow: redirect próprio; stats leva (ativo, fonte) pro Pose Mode.
        stats["head_follow_active"], stats["head_follow_source"] = self._apply_head_follow_parent(
            armature, edit_bones
        )
        self._align_tweaks_to_ctrl(armature, edit_bones, chains_data)
        self._spine_tweak_data = self._build_spine_tweaks(armature, edit_bones, coll_ctrl, coll_mch_ik, stats)

        self._build_main_collections(armature, edit_bones)
        self._move_main_child_before(armature, COLL_MAIN_CHAIN, COLL_MAIN_ROOT)
        self._propagate_pole_and_tip_to_main_collections(edit_bones, chains_data)
        self._apply_bone_collection_overrides(armature, edit_bones, chains_data, tail_chains_data)
        self._assign_tweak_collections(armature, edit_bones, chains_data + self._spine_tweak_data)
        # Ordem do painel nativo igual ao Collection Settings (com todas as collections já criadas).
        sync_bone_collection_order(armature)
        self._apply_collection_visibility(armature)

        return stats, chains_data, tail_chains_data

    def _resolve_chains(self, edit_bones, armature):
        """Cadeias ARM/LEG do Bone Settings como caminho de edit bones ORG (raiz -> ponta); TAIL e as outras entradas ficam de fora."""
        resolved = []
        for item in armature.hytale_ik_chains:
            if item.chain_type in ("CHAIN", "HEAD", "SPINE", "ATTACHMENTS", "TEXTURE_PICKER", "ROOT"):
                continue
            label = item.label or item.root_bone or "(sem nome)"
            if not item.root_bone or not item.tip_bone:
                self.report({"WARNING"}, f"IK chain '{label}': root/tip bone name is empty -- skipped.")
                continue
            root = edit_bones.get(item.root_bone)
            if root is None:
                self.report({"WARNING"}, f"IK chain '{label}': root bone '{item.root_bone}' not found -- skipped.")
                continue
            if edit_bones.get(item.tip_bone) is None:
                self.report({"WARNING"}, f"IK chain '{label}': tip bone '{item.tip_bone}' not found -- skipped.")
                continue
            path = find_org_path(root, item.tip_bone)
            if path is None:
                self.report(
                    {"WARNING"},
                    f"IK chain '{label}': no path from '{item.root_bone}' to '{item.tip_bone}' -- skipped.",
                )
                continue
            if len(path) < 3:
                self.report(
                    {"WARNING"},
                    f"IK chain '{label}' has only {len(path)} bone(s) -- for a proper 2-joint IK, root->tip "
                    f"should pass through at least one bone in between.",
                )
            pole_ref = edit_bones.get(item.pole_bone) if item.pole_bone else None
            if pole_ref is None:
                pole_ref = path[len(path) // 2]
            resolved.append({"item": item, "path": path, "pole_ref": pole_ref})
        return resolved

    def _resolve_tail_chains(self, edit_bones, armature):
        """Entradas Chain: caminho ORG raiz -> ponta (sem IK; 2 bones já valem)."""
        resolved = []
        for item in armature.hytale_ik_chains:
            if item.chain_type != "CHAIN":
                continue
            label = item.label or item.root_bone or "(sem nome)"
            if not item.root_bone or not item.tip_bone:
                self.report({"WARNING"}, f"Chain '{label}': root/tip bone name is empty -- skipped.")
                continue
            root = edit_bones.get(item.root_bone)
            if root is None:
                self.report({"WARNING"}, f"Chain '{label}': root bone '{item.root_bone}' not found -- skipped.")
                continue
            if edit_bones.get(item.tip_bone) is None:
                self.report({"WARNING"}, f"Chain '{label}': tip bone '{item.tip_bone}' not found -- skipped.")
                continue
            path = find_org_path(root, item.tip_bone)
            if path is None:
                self.report(
                    {"WARNING"},
                    f"Chain '{label}': no path from '{item.root_bone}' to '{item.tip_bone}' -- skipped.",
                )
                continue
            resolved.append({"item": item, "path": path})
        return resolved

    def _build_tail_layer(self, armature, edit_bones, resolved_tail_chains):
        """Cadeia Chain: o Tail de cada `_CTRL` vai pro Head do próximo (Connected opcional, nunca na raiz).
        Usa a ponte genérica `_MCH_Transfer` (rest do ORG, filha do `_CTRL`) que o MCH já copia.
        O `_CTRL` fica em Main (onde se anima ou se prende física); a ponte, oculta em Internal."""
        coll_main = ensure_bone_collection(armature, COLL_MAIN)
        # Só cria Main/Tail se houver pelo menos uma cadeia de verdade
        # -- senão sobrava uma collection vazia à toa.
        coll_tail = ensure_bone_collection(armature, COLL_MAIN_CHAIN, parent=coll_main) if resolved_tail_chains else None

        tail_chains_data = []
        for resolved in resolved_tail_chains:
            chain = resolved["path"]
            item = resolved["item"]
            tip_index = len(chain) - 1

            # `_CTRL` da cadeia (já criados); faltando um, pula a cadeia.
            ctrl_bones = []
            for org in chain:
                ctrl = find_layer_bone(edit_bones, org.name, SUFFIX_CTRL)
                if ctrl is None:
                    self.report(
                        {"WARNING"},
                        f"Chain: CTRL bone '{control_name(armature, org.name, SUFFIX_CTRL)}' not found -- skipped.",
                    )
                    ctrl_bones = []
                    break
                ctrl_bones.append(ctrl)
            if not ctrl_bones:
                continue

            # Tail de cada `_CTRL` no Head do próximo; a ponta volta pro Tail/roll do ORG e então leva a rotação manual.
            for i, ctrl in enumerate(ctrl_bones):
                if i < tip_index:
                    ctrl.tail = chain[i + 1].head.copy()
                    ctrl.align_roll(chain[i].z_axis)
                else:
                    ctrl.tail = chain[i].tail.copy()
                    ctrl.roll = chain[i].roll
                    rotate_edit_bone_local_axis(
                        ctrl, item.tail_tip_rotation_axis, item.tail_tip_rotation_deg
                    )
                # Connected só nos segmentos internos (o pai da raiz é externo).
                if i > 0:
                    ctrl.use_connect = item.tail_use_connect
                coll_tail.assign(ctrl)

            # Parent override ("Attach To") no `_CTRL` raiz, só se pedido.
            if item.parent_override:
                override_parent = _resolve_parent_override(edit_bones, item.parent_override, armature)
                if override_parent is not None and parent_would_loop(ctrl_bones[0], override_parent):
                    self.report(
                        {"WARNING"},
                        f"Parent override '{item.parent_override}' for '{ctrl_bones[0].name}' is inside this "
                        f"same chain (would create a loop) -- left as-is.",
                    )
                elif override_parent is not None:
                    ctrl_bones[0].parent = override_parent
                    ctrl_bones[0].use_connect = False
                else:
                    self.report(
                        {"WARNING"},
                        f"Parent override '{item.parent_override}' not found for '{ctrl_bones[0].name}' -- "
                        f"left as-is.",
                    )

            # Ponte `_MCH_Transfer` de cada segmento (já criada); faltando, pula a cadeia.
            tail_bones = []
            missing_bridge = False
            for org in chain:
                bridge = edit_bones.get(org.name + SUFFIX_MCH_TRANSFER)
                if bridge is None:
                    self.report(
                        {"WARNING"},
                        f"Chain: bridge bone '{org.name + SUFFIX_MCH_TRANSFER}' not found -- skipped.",
                    )
                    missing_bridge = True
                    break
                tail_bones.append(bridge)
            if missing_bridge:
                continue

            tail_chains_data.append(
                {
                    "org_names": [b.name for b in chain],
                    "tail_bones": [b.name for b in tail_bones],
                    "ctrl_names": [b.name for b in ctrl_bones],
                    # "Auto" = fica em Main/Tail; um nome redireciona os
                    # _CTRL desta cauda (ver _apply_bone_collection_overrides).
                    "collection_override": item.collection_override,
                }
            )

        return tail_chains_data

    @staticmethod
    def _point_bone_tail(bone, org, tail, x_from_z=False, right_side=False):
        """Aponta o Tail pra `tail` com o roll pelos eixos do ORG (x_from_z em Arm/Leg, espelhado no lado R); False se o bone ficaria com tamanho zero."""
        direction = tail - bone.head
        if direction.length < 1e-6:
            return False
        bone.tail = tail.copy()
        new_y = direction.normalized()
        ref_z = org.z_axis.normalized()
        if abs(new_y.dot(ref_z)) >= 0.999:
            ref_z = org.y_axis.normalized().rotation_difference(new_y) @ ref_z
        # X = proj(ref_z)  =>  Z = X × Y = ref_z × Y (a parte paralela a Y some).
        if x_from_z:
            target_z = ref_z.cross(new_y)
            bone.align_roll(-target_z if right_side else target_z)
        else:
            bone.align_roll(ref_z)
        return True

    def _ctrl_tail_to_child_sequences(self, armature, edit_bones):
        """[(entrada, [ORG raiz -> ponta])] de HEAD/SPINE/ARM/LEG, só com ORG e `_CTRL` existentes."""
        sequences = []
        for item in armature.hytale_ik_chains:
            if item.chain_type not in CTRL_TAIL_TO_CHILD_TYPES:
                continue
            if item.chain_type in ("HEAD", "SPINE"):
                names = _head_spine_bone_names(item)
            else:
                root = edit_bones.get((item.root_bone or "").strip())
                tip_name = (item.tip_bone or "").strip()
                path = find_org_path(root, tip_name) if root is not None and tip_name else None
                names = [b.name for b in path] if path else []
            names = [
                n for n in names
                if (org := edit_bones.get(n)) is not None
                and PROP_RIG_LAYER not in org.keys()
                and find_layer_bone(edit_bones, n, SUFFIX_CTRL) is not None
            ]
            if names:
                sequences.append((item, names))
        return sequences

    def _apply_ctrl_tail_to_child(self, armature, edit_bones):
        """Continuous Chain: o Tail do `_CTRL` vai pro Head do próximo bone da entrada (o Head do `_CTRL` não muda).
          - Fim da SPINE: o 1º bone da HEAD filha; ponta de Arm/Leg: o attachment; sem próximo: direção do anterior.
          - O bone Head não segue (fica como o ORG).
          - Arm/Leg: roll com X no Z do ORG (R no -Z) mesmo com a opção desligada; o ombro ganha só o roll.
        Idempotente: devolve à rest do ORG os atuais e os marcados antes (PROP_CTRL_TAIL_TO_CHILD) e só então aplica.
        O import e o snap compensam pela ponte. Devolve os `_CTRL` com Tail redirecionado (pro Head Follow)."""
        sequences = self._ctrl_tail_to_child_sequences(armature, edit_bones)

        # Baseline idempotente: marcados na geração anterior + entradas atuais.
        baseline = {}  # nome do _CTRL -> ORG
        for ctrl in edit_bones:
            if PROP_CTRL_TAIL_TO_CHILD not in ctrl.keys():
                continue
            del ctrl[PROP_CTRL_TAIL_TO_CHILD]
            org = edit_bones.get(source_org_of(ctrl))
            if org is not None and org.name != ctrl.name and PROP_RIG_LAYER not in org.keys():
                baseline[ctrl.name] = org
        for _item, names in sequences:
            for name in names:
                baseline[find_layer_bone(edit_bones, name, SUFFIX_CTRL).name] = edit_bones[name]
        for ctrl_name, org in baseline.items():
            ctrl = edit_bones[ctrl_name]
            ctrl.tail = org.tail.copy()
            ctrl.roll = org.roll

        enabled = getattr(armature, "hytale_ctrl_tail_to_child", True)
        # Continuação da SPINE: primeiro bone de uma HEAD filho do último
        # bone da SPINE. Main Head primeiro.
        main_head = resolve_head_chain_item(armature)
        head_firsts = [names[0] for item, names in sequences if item.chain_type == "HEAD" and item == main_head]
        head_firsts += [names[0] for item, names in sequences if item.chain_type == "HEAD" and item != main_head]

        configured = {n for _item, names in sequences for n in names}  # papel próprio numa entrada
        changed = set()  # nomes dos _CTRL que saíram da rest do ORG
        redirected = set()  # ... e destes, os que tiveram o Tail redirecionado
        done = set()
        for item, names in sequences:
            limb = item.chain_type in LIMB_X_FROM_Z_TYPES
            if not enabled and not limb:
                continue  # opção desligada: HEAD/SPINE ficam na rest do ORG
            head_name = (item.head_bone or "").strip() if item.chain_type == "HEAD" else ""
            for i, name in enumerate(names):
                if name in done:
                    continue  # mesmo bone em duas entradas -- a primeira vence
                done.add(name)
                if name == head_name:
                    continue  # o Head fica com a rest do ORG (o baseline acima já devolveu)
                org = edit_bones[name]
                ctrl = find_layer_bone(edit_bones, name, SUFFIX_CTRL)
                right = limb and _is_right_side(item, name)

                # Alvo do Tail: próximo da lista (fim da SPINE: a HEAD filha) -> attachment da ponta -> direção do anterior.
                targets = []
                if enabled:
                    next_name = names[i + 1] if i + 1 < len(names) else None
                    if next_name is None and item.chain_type == "SPINE":
                        next_name = next(
                            (h for h in head_firsts if edit_bones[h].parent is not None and edit_bones[h].parent.name == name),
                            None,
                        )
                    if next_name is not None:
                        targets.append(edit_bones[next_name].head)
                    elif limb:
                        attachment = find_attachment_child(org)
                        if attachment is not None:
                            targets.append(attachment.head)
                    prev_org = edit_bones.get(names[i - 1]) if i > 0 else org.parent
                    length = (org.tail - org.head).length
                    if prev_org is not None and length > 1e-6 and (org.head - prev_org.head).length > 1e-6:
                        targets.append(org.head + (org.head - prev_org.head).normalized() * length)

                if any(self._point_bone_tail(ctrl, org, t, x_from_z=limb, right_side=right) for t in targets):
                    redirected.add(ctrl.name)
                    changed.add(ctrl.name)
                elif limb and self._point_bone_tail(ctrl, org, org.tail, x_from_z=True, right_side=right):
                    changed.add(ctrl.name)  # Arm/Leg: o giro do roll vale mesmo sem redirect

        # Ombro (Root Parent de ARM): só o roll, se for um `_CTRL` comum sem papel em outra entrada.
        for item in armature.hytale_ik_chains:
            if item.chain_type != "ARM" or not (item.parent_override or "").strip():
                continue
            ctrl = _resolve_parent_override(edit_bones, item.parent_override, armature)
            if ctrl is None or ctrl.get(PROP_RIG_LAYER) != "CTRL":
                continue
            org = edit_bones.get(source_org_of(ctrl))
            if org is None or org.name == ctrl.name or PROP_RIG_LAYER in org.keys() or org.name in configured:
                continue
            configured.add(org.name)
            if self._point_bone_tail(ctrl, org, org.tail, x_from_z=True, right_side=_is_right_side(item, org.name)):
                changed.add(ctrl.name)

        for ctrl_name in changed:
            edit_bones[ctrl_name][PROP_CTRL_TAIL_TO_CHILD] = True
        return redirected

    def _build_tail_pose_constraints(self, obj, tail_chains_data):
        """Reafirma os FK_Copy* do MCH das cadeias Chain mirando a ponte (idempotente; conta pro resumo)."""
        pose_bones = obj.pose.bones
        count = 0
        for data in tail_chains_data:
            for i, org_name in enumerate(data["org_names"]):
                bridge_name = data["tail_bones"][i]
                mch_name = org_name + SUFFIX_MCH
                if bridge_name not in pose_bones or mch_name not in pose_bones:
                    continue
                mch_pose = pose_bones[mch_name]
                for con_name in (CONSTRAINT_FK_ROT, CONSTRAINT_FK_SCALE, CONSTRAINT_FK_LOC):
                    con = mch_pose.constraints.get(con_name)
                    if con is not None:
                        con.target = obj
                        con.subtarget = bridge_name
                count += 1
        return count

    def _build_root_controls(self, armature, edit_bones, coll_ctrl, spine_ctrl_enabled=True):
        """Cria root.master_CTRL, root.spine_CTRL (opcional, nunca apagado) e root.pelvis_CTRL a partir de bones de referência."""
        created = 0
        # Papéis da SPINE ("Belly" = Spine 1); sem entrada SPINE, nomes legados.
        master_source_name = resolve_master_source_org_name(armature)
        pelvis_name = resolve_pelvis_org_name(armature)
        master_source = edit_bones.get(master_source_name)
        belly_ctrl = find_layer_bone(edit_bones, master_source_name, SUFFIX_CTRL)
        pelvis_ctrl = find_layer_bone(edit_bones, pelvis_name, SUFFIX_CTRL)

        master = edit_bones.get(BONE_ROOT_MASTER)
        if master is None and master_source is not None:
            master, is_new = create_bone_like(edit_bones, master_source, BONE_ROOT_MASTER)
            if is_new:
                master[PROP_RIG_LAYER] = "ROOT-CTRL"
                created += 1
        elif master_source is None:
            self.report(
                {"WARNING"},
                f"'{master_source_name}' not found -- skipping {BONE_ROOT_MASTER}. Set the SPINE entry "
                f"(Pelvis/Spine 1) in Bone Settings to the character's real bones.",
            )
        if master is not None:
            # Pai = `_CTRL` do Origin principal, reaplicado a toda geração.
            origin_ctrl_name = resolve_origin_ctrl_name(armature)
            origin_ctrl = edit_bones.get(origin_ctrl_name)
            if origin_ctrl is None:
                self.report(
                    {"WARNING"},
                    f"'{origin_ctrl_name}' not found -- {BONE_ROOT_MASTER} left without a parent.",
                )
                master.parent = None
            elif parent_would_loop(master, origin_ctrl):
                self.report(
                    {"WARNING"},
                    f"'{origin_ctrl_name}' is below {BONE_ROOT_MASTER} in the hierarchy -- can't be its "
                    f"parent (would create a loop). Pick a higher bone as Root 1 (Origin).",
                )
            else:
                master.parent = origin_ctrl
            master.use_connect = False
            coll_ctrl.assign(master)

        if master_source is not None and spine_ctrl_enabled:
            spine, is_new = create_bone_like(edit_bones, master_source, BONE_ROOT_SPINE)
            if is_new:
                spine.parent = master
                direction = spine.tail - spine.head
                if direction.length > 1e-9:
                    spine.tail = spine.head + direction.normalized() * ROOT_SPINE_LENGTH
                else:
                    spine.tail = spine.head + Vector((0.0, ROOT_SPINE_LENGTH, 0.0))
                spine[PROP_RIG_LAYER] = "ROOT-CTRL"
                created += 1
            coll_ctrl.assign(spine)

        if belly_ctrl is not None and pelvis_ctrl is not None:
            pelvis, is_new = create_bone_like(edit_bones, belly_ctrl, BONE_ROOT_PELVIS)
            if is_new:
                if (pelvis_ctrl.head - belly_ctrl.head).length > 1e-6:
                    # Normal (Player): do Spine 1 ("Belly") até o Pelvis.
                    pelvis.head = belly_ctrl.head.copy()
                    pelvis.tail = pelvis_ctrl.head.copy()
                else:
                    # SPINE só com Pelvis: usa a forma do Pelvis_CTRL (senão comprimento zero).
                    pelvis.head = pelvis_ctrl.head.copy()
                    pelvis.tail = pelvis_ctrl.tail.copy()
                    pelvis.roll = pelvis_ctrl.roll
                pelvis.parent = master
                pelvis[PROP_RIG_LAYER] = "ROOT-CTRL"
                created += 1
            coll_ctrl.assign(pelvis)
        else:
            missing = [
                n for n, b in ((control_name(armature, master_source_name, SUFFIX_CTRL), belly_ctrl), (control_name(armature, pelvis_name, SUFFIX_CTRL), pelvis_ctrl))
                if b is None
            ]
            self.report(
                {"WARNING"},
                f"{' and '.join(dict.fromkeys(missing))} not found -- skipping {BONE_ROOT_PELVIS}. Set the "
                f"SPINE entry (Pelvis/Spine 1) in Bone Settings to the character's real bones.",
            )

        # PROPERTIES acima da cabeça, filho do `_CTRL` da cabeça do HEAD (não do nome fixo "Head_CTRL").
        head_ctrl_name = resolve_head_ctrl_name(armature)
        head_ctrl = edit_bones.get(head_ctrl_name)
        if head_ctrl is not None:
            properties_bone, is_new = create_bone_like(edit_bones, head_ctrl, BONE_PROPERTIES)
            if is_new:
                properties_bone.head = head_ctrl.head + Vector((0.0, PROPERTIES_BONE_OFFSET_Y, 0.0))
                properties_bone.tail = properties_bone.head + (head_ctrl.tail - head_ctrl.head)
                properties_bone.parent = head_ctrl
                properties_bone.use_connect = False
                properties_bone[PROP_RIG_LAYER] = "CTRL"
                created += 1
            coll_ctrl.assign(properties_bone)
        else:
            self.report(
                {"WARNING"},
                f"'{head_ctrl_name}' not found -- skipping {BONE_PROPERTIES}. Add a HEAD bone setting "
                f"pointing at the real head bone (Auto-Detect or manually) before Create Rig.",
            )

        return created

    def _resolve_ctrl_parent_overrides(self, armature, edit_bones):
        """{`_CTRL`: pai forçado} pelo Bone Settings: Pelvis -> root.pelvis_CTRL, Spine 1 -> root.master_CTRL,
        Root Bone de cada LEG -> o Root Parent do IK dela. Sem as entradas, as regras legadas."""
        overrides = {}
        pelvis_name = resolve_pelvis_org_name(armature)
        master_source_name = resolve_master_source_org_name(armature)

        pelvis_root = edit_bones.get(BONE_ROOT_PELVIS)
        master_root = edit_bones.get(BONE_ROOT_MASTER)
        if pelvis_root is not None:
            overrides[control_name(armature, pelvis_name, SUFFIX_CTRL)] = pelvis_root
        if master_root is not None and master_source_name != pelvis_name:
            overrides[control_name(armature, master_source_name, SUFFIX_CTRL)] = master_root

        leg_items = [
            it for it in getattr(armature, "hytale_ik_chains", [])
            if it.chain_type == "LEG" and (it.root_bone or "").strip()
        ]
        if leg_items:
            for item in leg_items:
                if not (item.parent_override or "").strip():
                    continue  # sem Root Parent -- coxa segue a hierarquia do modelo
                target = _resolve_parent_override(edit_bones, item.parent_override, armature)
                if target is None:
                    self.report(
                        {"WARNING"},
                        f"Leg '{item.label or item.root_bone}': Root Parent '{item.parent_override}' not found "
                        f"-- '{item.root_bone}{SUFFIX_CTRL}' keeps its normal parent.",
                    )
                    continue
                overrides[control_name(armature, item.root_bone.strip(), SUFFIX_CTRL)] = target
        else:
            for bone_name, parent_name in CTRL_PARENT_OVERRIDES.items():
                if "Thigh" in bone_name and edit_bones.get(parent_name) is not None:
                    overrides[bone_name] = edit_bones.get(parent_name)
        return overrides

    def _apply_ctrl_parent_overrides(self, armature, edit_bones):
        """Aplica os pais de _resolve_ctrl_parent_overrides a toda geração; pula (com aviso) pai que criaria ciclo."""
        for bone_name, parent in self._resolve_ctrl_parent_overrides(armature, edit_bones).items():
            bone = edit_bones.get(bone_name)
            if bone is None:
                continue
            if parent_would_loop(bone, parent):
                self.report(
                    {"WARNING"},
                    f"Parent '{parent.name}' for '{bone_name}' would create a loop (it's the bone itself or "
                    f"one of its children) -- skipped.",
                )
                continue
            bone.parent = parent
            bone.use_connect = False

    def _reparent_extra_children(self, edit_bones, org, mch, exclude_name=None):
        """Põe no `mch` os `_CTRL` dos filhos extras de `org` (attachment, dedos...; menos `exclude_name`), pra seguirem FK e IK; devolve os nomes."""
        reparented = []
        extra_orgs = []
        attachment_org = find_attachment_child(org)
        if attachment_org is not None and attachment_org.name != exclude_name:
            extra_orgs.append(attachment_org)
        for child in find_non_attachment_children(org):
            if child.name == exclude_name:
                continue
            extra_orgs.append(child)
        for extra_org in extra_orgs:
            extra_ctrl = find_layer_bone(edit_bones, extra_org.name, SUFFIX_CTRL)
            if extra_ctrl is None:
                continue
            extra_ctrl.parent = mch
            extra_ctrl.use_connect = False
            reparented.append(extra_ctrl.name)
        return reparented

    @staticmethod
    def _order_top_down(org_bones, org_by_name):
        ordered = []
        visited = set()

        def visit(bone):
            if bone.name in visited:
                return
            visited.add(bone.name)
            ordered.append(bone)
            for child in bone.children:
                if child.name in org_by_name:
                    visit(child)

        roots = [b for b in org_bones if b.parent is None or b.parent.name not in org_by_name]
        for root in roots:
            visit(root)
        for b in org_bones:
            if b.name not in visited:
                ordered.append(b)
        return ordered

    def _build_ik_layer(self, armature, edit_bones, coll_ctrl_ik, coll_mch_ik, resolved_chains, stats, world_down_local):
        """Camada IK por cadeia: `_IK` por segmento, Tweak (com o pai `_MCH_Tweak_Parent`) por peça do solver, bridge `_MCH_IK_Transfer` e pole; 3+ segmentos ganham jarretes."""
        chains_data = []

        for resolved in resolved_chains:
            chain = resolved["path"]
            item = resolved["item"]
            pole_ref = resolved["pole_ref"]

            tip_index = len(chain) - 1
            tip_org = chain[tip_index]
            # Attachments/dedos seguem o resultado final (FK ou IK): pai = `_MCH` da ponta.
            tip_mch = edit_bones.get(tip_org.name + SUFFIX_MCH) or tip_org
            reparented_ctrl_roots = self._reparent_extra_children(edit_bones, tip_org, tip_mch)
            attachment_org = find_attachment_child(tip_org)
            attachment_ctrl = find_layer_bone(edit_bones, attachment_org.name, SUFFIX_CTRL) if attachment_org else None

            # Idem nos segmentos do meio (menos o próximo elo da cadeia).
            for mid_index in range(tip_index):
                mid_org = chain[mid_index]
                mid_mch = edit_bones.get(mid_org.name + SUFFIX_MCH)
                if mid_mch is None:
                    continue
                reparented_ctrl_roots.extend(
                    self._reparent_extra_children(
                        edit_bones, mid_org, mid_mch, exclude_name=chain[mid_index + 1].name
                    )
                )

            tip_length = (tip_org.tail - tip_org.head).length
            target_index = ik_solver_target_index(len(chain))
            ik_bones = []

            for i, org in enumerate(chain):
                ik_bone, is_new = create_bone_like(edit_bones, org, control_name(armature, org.name, SUFFIX_IK))
                ik_bone[PROP_SOURCE_ORG] = org.name
                x_from_z = item.chain_type in LIMB_X_FROM_Z_TYPES
                right = x_from_z and _is_right_side(item, org.name)

                if target_index <= i < tip_index:
                    # Jarrete: desconecta antes de mover o Head (rig anterior era conectado).
                    ik_bone.use_connect = False
                    ik_bone.head = chain[i + 1].head.copy()
                    if not self._point_bone_tail(ik_bone, org, org.head, x_from_z=x_from_z, right_side=right):
                        self._point_bone_tail(ik_bone, org, org.tail, x_from_z=x_from_z, right_side=right)
                    if is_new:
                        ik_bone[PROP_RIG_LAYER] = "CTRL-IK"
                        stats["ik"] += 1
                    coll_ctrl_ik.assign(ik_bone)
                    ik_bones.append(ik_bone)
                    continue

                # Head/Tail/Roll pela rest do ORG a toda geração (idempotente).
                ik_bone.head = org.head.copy()
                ik_bone.tail = org.tail.copy()
                ik_bone.roll = org.roll
                ik_bone.inherit_scale = "FULL"  # desfaz o NONE de quem foi jarrete num rig anterior
                if i < tip_index:
                    # ORG do Hytale aponta pra cima: o Tail vai no Head do próximo (o solver precisa).
                    ik_target = chain[i + 1].head
                elif attachment_ctrl is not None:
                    # Ponta com socket de referência: tail no HEAD do
                    # "<attachment>_CTRL" correspondente.
                    ik_target = attachment_ctrl.head
                elif tip_length > 1e-9:
                    # Sem socket (ex.: pé): aponta pra baixo, mantendo o comprimento.
                    down = world_down_local if world_down_local.length > 1e-9 else Vector((0.0, 0.0, -1.0))
                    ik_target = ik_bone.head + down.normalized() * tip_length
                else:
                    ik_target = None
                # Roll igual ao do `_CTRL` (_point_bone_tail); alvo degenerado usa o Tail do ORG.
                if ik_target is None or not self._point_bone_tail(
                    ik_bone, org, ik_target, x_from_z=x_from_z, right_side=right
                ):
                    self._point_bone_tail(ik_bone, org, org.tail, x_from_z=x_from_z, right_side=right)

                if is_new:
                    if i == tip_index:
                        ik_bone.parent = None  # ponta solta -- alvo arrastável + switch
                        ik_bone.use_connect = False
                    elif i == 0:
                        # Alias, depois o `_CTRL` do bone marcado, depois o nome (parent_override_candidates).
                        override_parent = _resolve_parent_override(edit_bones, item.parent_override, armature)
                        loops = override_parent is not None and parent_would_loop(ik_bone, override_parent)
                        if loops:
                            override_parent = None  # aviso de ciclo sai no bloco de correção logo abaixo
                        elif item.parent_override and override_parent is None:
                            self.report(
                                {"WARNING"},
                                f"Parent override '{item.parent_override}' not found for '{ik_bone.name}' -- "
                                f"left unparented.",
                            )
                        ik_bone.parent = override_parent
                        ik_bone.use_connect = False
                    else:
                        prev_ik = ik_bones[i - 1]
                        ik_bone.parent = prev_ik
                        ik_bone.use_connect = bool(org.use_connect and prev_ik is not None)
                    ik_bone[PROP_RIG_LAYER] = "CTRL-IK"
                    stats["ik"] += 1
                coll_ctrl_ik.assign(ik_bone)
                ik_bones.append(ik_bone)

            # Parent da raiz reaplicado a toda geração (conserta rig anterior).
            if ik_bones and item.parent_override:
                override_parent = _resolve_parent_override(edit_bones, item.parent_override, armature)
                if override_parent is not None and parent_would_loop(ik_bones[0], override_parent):
                    self.report(
                        {"WARNING"},
                        f"Parent override '{item.parent_override}' for '{ik_bones[0].name}' would create a "
                        f"loop -- left unparented.",
                    )
                elif override_parent is not None:
                    ik_bones[0].parent = override_parent
                    ik_bones[0].use_connect = False

            # Jarretes: cada um filho do controle de baixo (o último, da
            # ponta) -- a toda geração, pra converter rig anterior.
            hock_names = []
            for i in range(tip_index - 1, target_index - 1, -1):
                ik_bones[i].parent = ik_bones[i + 1]
                ik_bones[i].use_connect = False
                ik_bones[i].inherit_scale = "NONE"  # esticar o pé não estica o calcanhar
                hock_names.append(ik_bones[i].name)

            # Tweaks: só nas peças do solver; a rest final vem de _align_tweaks_to_ctrl.
            tweak_names = []
            for i, org in enumerate(chain):
                tweak_name = control_name(armature, org.name, SUFFIX_TWEAK)
                holder_name = org.name + SUFFIX_MCH_TWEAK_PARENT
                fk_name = org.name + SUFFIX_MCH_TWEAK_FK
                transfer = edit_bones.get(org.name + SUFFIX_MCH_TRANSFER)
                ctrl = edit_bones.get(control_name(armature, org.name, SUFFIX_CTRL))
                if i >= target_index or transfer is None or ctrl is None:
                    for name, layer in ((tweak_name, "CTRL-TWEAK"), (holder_name, "MCH-IK"), (fk_name, "MCH-TRANSFER")):
                        stale = edit_bones.get(name)
                        if stale is not None and stale.get(PROP_RIG_LAYER) == layer:
                            edit_bones.remove(stale)  # virou jarrete/ponta desde o rig anterior
                    continue
                # No FK o Tweak entra entre o `_CTRL` e o `_MCH_Transfer`, girando no mesmo pivô do IK.
                fk_tweak, is_new = create_bone_like(edit_bones, org, fk_name)
                fk_tweak[PROP_RIG_LAYER] = "MCH-TRANSFER"
                if is_new:
                    stats["mch_transfer"] += 1
                fk_tweak.parent = ctrl
                fk_tweak.use_connect = False
                coll_mch_ik.assign(fk_tweak)
                transfer.parent = fk_tweak
                holder, is_new = create_bone_like(edit_bones, org, holder_name)
                holder[PROP_RIG_LAYER] = "MCH-IK"
                if is_new:
                    stats["ik_mch"] += 1
                holder.parent = None  # sem pai: a constraint Armature faz esse papel
                coll_mch_ik.assign(holder)
                tweak, is_new = create_bone_like(edit_bones, org, tweak_name)
                tweak[PROP_SOURCE_ORG] = org.name
                tweak[PROP_RIG_LAYER] = "CTRL-TWEAK"
                if is_new:
                    stats["tweak"] += 1
                tweak.parent = holder
                tweak.use_connect = False
                tweak.inherit_scale = "NONE"  # escala da peça = só a do Tweak; seguir o pai é no MCH
                coll_ctrl_ik.assign(tweak)
                tweak_names.append(tweak_name)

            for i, org in enumerate(chain):
                bridge, is_new = create_bone_like(edit_bones, org, org.name + SUFFIX_MCH_IK_TRANSFER)
                if is_new:
                    bridge[PROP_RIG_LAYER] = "MCH-IK"
                    stats["ik_mch"] += 1
                # Pai real do bridge: o Tweak, ou o `_IK` (ponta/jarrete) -- a toda geração.
                bridge.parent = edit_bones[tweak_names[i]] if i < len(tweak_names) else ik_bones[i]
                bridge.use_connect = False
                coll_mch_ik.assign(bridge)

            root_org = chain[0]
            pole, is_new_pole = create_bone_like(edit_bones, root_org, control_name(armature, root_org.name, SUFFIX_POLE))
            pole[PROP_SOURCE_ORG] = root_org.name
            if is_new_pole:
                pole.head, pole.tail = self._pole_position(pole_ref, item.pole_distance, item.pole_invert)
                # Roll do pole zerado (o IK só usa a posição dele).
                pole.roll = 0.0
                pole.parent = None
                pole[PROP_RIG_LAYER] = "CTRL-IK"
            coll_ctrl_ik.assign(pole)

            # Pole Line: só visual, filho do ORG do meio, esticado até o pole (Stretch To).
            pole_line, is_new_pole_line = create_bone_like(
                edit_bones, pole_ref, control_name(armature, root_org.name, SUFFIX_POLE_LINE)
            )
            pole_line[PROP_SOURCE_ORG] = root_org.name
            if is_new_pole_line:
                pole_line.head = pole_ref.head.copy()
                pole_line.tail = pole.head.copy()
                pole_line.roll = 0.0
                pole_line.parent = pole_ref
                pole_line.use_connect = False
                pole_line[PROP_RIG_LAYER] = "CTRL-IK"
            pole_line.hide_select = True
            coll_ctrl_ik.assign(pole_line)

            # Rig salvo antes da 0.9.6 com o modo "PRESET" (removido) lê
            # vazio -- vira Auto, que é o que a geração já usa.
            if item.pole_angle_mode not in ("AUTO", "MANUAL"):
                item.pole_angle_mode = "AUTO"

            chains_data.append(
                {
                    "org_names": [b.name for b in chain],
                    "ik_root": control_name(armature, chain[0].name, SUFFIX_IK),
                    "ik_solver_end": control_name(armature, chain[target_index - 1].name, SUFFIX_IK),
                    "ik_tip": control_name(armature, chain[tip_index].name, SUFFIX_IK),
                    # Alvo do solver: a ponta, ou (3+ segmentos) o bridge
                    # do 1º jarrete, cujo Head é a junta de cima dele.
                    "ik_target": (
                        control_name(armature, chain[tip_index].name, SUFFIX_IK) if target_index == tip_index
                        else chain[target_index].name + SUFFIX_MCH_IK_TRANSFER
                    ),
                    "ik_chain_count": target_index,
                    "ik_hocks": hock_names,
                    "tweaks": tweak_names,
                    "pole": pole.name,
                    "pole_line": pole_line.name,
                    "side": item.side,
                    # Root Parent: usado pra cor do lado.
                    "parent_override": item.parent_override,
                    "pole_angle_mode": item.pole_angle_mode,
                    "pole_angle_manual": item.pole_angle_manual,
                    "pole_angle_fine_tune": item.pole_angle_fine_tune,
                    "switch_property": switch_property_name(chain[tip_index].name, item.side),
                    # `_CTRL` presos no `_MCH`: fora da árvore de Main, propagados à mão.
                    "reparented_ctrl_roots": reparented_ctrl_roots,
                    # "Auto" = collection padrão; um nome redireciona a cadeia.
                    "collection_override": item.collection_override,
                }
            )

        return chains_data

    def _apply_head_follow_parent(self, armature, edit_bones):
        """Head Follow (Edit Mode), pelo toggle Head Free/Lock da Main Head: ligado, aponta o Tail do bone de cima
        (Neck ou Chest) pro Head e deixa o Head_CTRL sem pai (as constraints fazem o papel); desligado, desfaz.
        Devolve (ativo, `_CTRL` fonte). Limitação: só a Main Head (várias cabeças: ver o TODO em bone_settings.py)."""
        # Lê o toggle da mesma entrada HEAD principal que decide a cabeça.
        head_item = resolve_head_chain_item(armature)
        if head_item is None:
            return False, None
        head_ctrl_name = control_name(armature, head_item.head_bone, SUFFIX_CTRL)
        head_org = edit_bones.get(head_item.head_bone)
        head_ctrl = edit_bones.get(head_ctrl_name)
        if head_org is None or head_ctrl is None or head_org.parent is None:
            return False, None

        source_org = head_org.parent  # EditBone direto -- é o pai real do ORG "Head"
        source_name = control_name(armature, source_org.name, SUFFIX_CTRL)
        source_ctrl = edit_bones.get(source_name)
        if source_ctrl is None:
            return False, None

        enabled = head_item.head_follow_enabled

        if not enabled:
            # Devolve o Tail do predecessor à rest do ORG -- exceto se o
            # "CTRL Tail to Child" acabou de apontá-lo (aí fica como está).
            if source_ctrl.name not in getattr(self, "_ctrl_tail_redirected", ()):
                source_ctrl.tail = source_org.tail.copy()
                source_ctrl.roll = source_org.roll
            head_ctrl.parent = source_ctrl
            head_ctrl.use_connect = False
            return False, None

        # Tail do bone de cima no Head (mesmo cálculo de _point_bone_tail).
        self._point_bone_tail(source_ctrl, source_org, head_org.head)

        # Sem pai: com pai em Origin_CTRL o movimento do Origin entrava duas vezes.
        head_ctrl.parent = None
        head_ctrl.use_connect = False
        return True, source_name

    @staticmethod
    def _pole_position(pole_ref, distance, invert):
        """Pole pelo eixo Z local do bone de referência (ex.: Forearm), pra trás ou pra frente (pole_invert)."""
        z_axis = pole_ref.z_axis
        z_axis = z_axis.normalized() if z_axis.length > 1e-9 else Vector((0.0, 0.0, 1.0))

        sign = 1.0 if invert else -1.0
        head = pole_ref.head.copy() + z_axis * (distance * sign)
        tail = head + Vector((0.0, 0.0, distance * 0.2))
        return head, tail

    def _build_main_collections(self, armature, edit_bones):
        """Main (Head/Spine/Body/Arm/Leg/Root + as do usuário) e Attachments."""
        coll_main = ensure_bone_collection(armature, COLL_MAIN)
        coll_attachments = ensure_bone_collection(armature, COLL_ATTACHMENTS, parent=coll_main)

        coll_head = ensure_bone_collection(armature, COLL_MAIN_HEAD, parent=coll_main)
        coll_spine = ensure_bone_collection(armature, COLL_MAIN_SPINE, parent=coll_main)
        coll_body = ensure_bone_collection(armature, COLL_MAIN_BODY, parent=coll_main)
        coll_arm_l = ensure_bone_collection(armature, COLL_MAIN_ARM_L, parent=coll_main)
        coll_arm_r = ensure_bone_collection(armature, COLL_MAIN_ARM_R, parent=coll_main)
        coll_leg_l = ensure_bone_collection(armature, COLL_MAIN_LEG_L, parent=coll_main)
        coll_leg_r = ensure_bone_collection(armature, COLL_MAIN_LEG_R, parent=coll_main)
        coll_root = ensure_bone_collection(armature, COLL_MAIN_ROOT, parent=coll_main)

        # Main acima das outras raízes (melhor esforço; só visual).
        self._move_collection_to_index(armature, coll_main, 0)

        # Attachments só com os `_CTRL` de attachment; as outras camadas saem (limpa rigs antigos).
        for bone in edit_bones:
            if is_attachment_bone(bone):
                if bone.get(PROP_RIG_LAYER) == "CTRL":
                    coll_attachments.assign(bone)
                else:
                    coll_attachments.unassign(bone)

        def assign_descendants(coll, root_names):
            for root_name in root_names:
                for bone in collect_descendants_inclusive(
                    edit_bones, root_name, exclude_predicate=is_excluded_from_main_collections
                ):
                    coll.assign(bone)

        assign_descendants(coll_head, [resolve_head_ctrl_name(armature)])

        for name in SPINE_COLLECTION_BONES:
            bone = edit_bones.get(name)
            if bone is not None:
                coll_spine.assign(bone)

        for name in BODY_COLLECTION_BONES:
            bone = edit_bones.get(name)
            if bone is not None:
                coll_body.assign(bone)

        for name in ROOT_COLLECTION_BONES:
            bone = edit_bones.get(name)
            if bone is not None:
                coll_root.assign(bone)

        limb_roots = _resolve_main_limb_roots(armature, edit_bones)
        assign_descendants(coll_arm_l, limb_roots[COLL_MAIN_ARM_L])
        assign_descendants(coll_arm_r, limb_roots[COLL_MAIN_ARM_R])
        assign_descendants(coll_leg_l, limb_roots[COLL_MAIN_LEG_L])
        assign_descendants(coll_leg_r, limb_roots[COLL_MAIN_LEG_R])

    _MAIN_LIMB_COLLECTION_NAMES = {COLL_MAIN_ARM_L, COLL_MAIN_ARM_R, COLL_MAIN_LEG_L, COLL_MAIN_LEG_R}

    def _propagate_pole_and_tip_to_main_collections(self, edit_bones, chains_data):
        """Põe pole, pole line, ponta, jarretes e `_CTRL` presos no `_MCH` na mesma collection de Main do resto da cadeia."""
        for data in chains_data:
            ref_bone = edit_bones.get(data["ik_root"])
            if ref_bone is None:
                continue
            member_colls = [c for c in ref_bone.collections if c.name in self._MAIN_LIMB_COLLECTION_NAMES]
            if not member_colls:
                continue
            for name in (data["pole"], data["pole_line"], data["ik_tip"], *data["ik_hocks"]):
                bone = edit_bones.get(name)
                if bone is None:
                    continue
                for coll in member_colls:
                    coll.assign(bone)

            for root_name in data.get("reparented_ctrl_roots", ()):
                for bone in collect_descendants_inclusive(
                    edit_bones, root_name, exclude_predicate=is_excluded_from_main_collections
                ):
                    for coll in member_colls:
                        coll.assign(bone)

    @staticmethod
    def _align_tweaks_to_ctrl(armature, edit_bones, chains_data):
        """Tweak nos eixos do `_CTRL`, com o pivô no meio da peça (bone conectado: na junta); o pai dele = rest do `_CTRL`."""
        for data in chains_data:
            for org_name in data["org_names"][: len(data["tweaks"])]:
                tweak = edit_bones.get(control_name(armature, org_name, SUFFIX_TWEAK))
                ctrl = edit_bones.get(control_name(armature, org_name, SUFFIX_CTRL))
                piece = edit_bones.get(control_name(armature, org_name, SUFFIX_IK))
                if tweak is None or ctrl is None:
                    continue
                holder = edit_bones.get(org_name + SUFFIX_MCH_TWEAK_PARENT)
                if holder is not None:
                    holder.head, holder.tail, holder.roll = ctrl.head.copy(), ctrl.tail.copy(), ctrl.roll
                connected = edit_bones[org_name].use_connect
                pivot = ctrl.head if connected or piece is None else (piece.head + piece.tail) / 2.0
                for bone in (tweak, edit_bones.get(org_name + SUFFIX_MCH_TWEAK_FK)):
                    if bone is not None:
                        bone.head = pivot.copy()
                        bone.tail = pivot + (ctrl.tail - ctrl.head)
                        bone.roll = ctrl.roll

    def _build_spine_tweaks(self, armature, edit_bones, coll_ctrl, coll_mch_transfer, stats):
        """Tweak (só FK) em cada bone das entradas SPINE: filho do `_CTRL`, pivô no meio da peça, mexe só ela.

        Devolve [{"tweaks", "org_names", "ik_root"}] no formato que _assign_tweak_collections usa."""
        result, wanted = [], set()
        for item in armature.hytale_ik_chains:
            if item.chain_type != "SPINE":
                continue
            org_names = [n for n in _head_spine_bone_names(item) if n in edit_bones and n not in wanted]
            data = {"tweaks": [], "org_names": [], "ik_root": None}
            for index, org_name in enumerate(org_names):
                org = edit_bones[org_name]
                ctrl = edit_bones.get(control_name(armature, org_name, SUFFIX_CTRL))
                transfer = edit_bones.get(org_name + SUFFIX_MCH_TRANSFER)
                tweak_name = control_name(armature, org_name, SUFFIX_TWEAK)
                if ctrl is None or transfer is None or org_name + SUFFIX_MCH_TWEAK_PARENT in edit_bones:
                    continue  # sem controle, ou já é peça de um braço/perna
                tweak, is_new = create_bone_like(edit_bones, org, tweak_name)
                tweak[PROP_SOURCE_ORG] = org_name
                tweak[PROP_RIG_LAYER] = "CTRL-TWEAK"
                if is_new:
                    stats["tweak"] += 1
                tweak.parent = ctrl
                tweak.use_connect = False
                tweak.inherit_scale = "NONE"  # o widget não estica junto com o `_CTRL`
                coll_ctrl.assign(tweak)
                fk_tweak, is_new = create_bone_like(edit_bones, org, org_name + SUFFIX_MCH_TWEAK_FK)
                fk_tweak[PROP_RIG_LAYER] = "MCH-TRANSFER"
                if is_new:
                    stats["mch_transfer"] += 1
                fk_tweak.parent = ctrl
                fk_tweak.use_connect = False
                coll_mch_transfer.assign(fk_tweak)
                transfer.parent = fk_tweak
                # Pivô: meio entre esta junta e a próxima da Spine (a última usa o meio do `_CTRL`).
                nxt = edit_bones[org_names[index + 1]].head if index + 1 < len(org_names) else None
                pivot = ctrl.head if org.use_connect else ((org.head + nxt) / 2.0 if nxt is not None else (ctrl.head + ctrl.tail) / 2.0)
                for bone in (tweak, fk_tweak):
                    bone.head = pivot.copy()
                    bone.tail = pivot + (ctrl.tail - ctrl.head)
                    bone.roll = ctrl.roll
                data["tweaks"].append(tweak_name)
                data["org_names"].append(org_name)
                data["ik_root"] = data["ik_root"] or ctrl.name
                wanted.add(org_name)
            if data["tweaks"]:
                result.append(data)
        # Tweak de Spine que saiu da entrada (pai = `_CTRL`; os de braço/perna têm o `_MCH_Tweak_Parent`).
        stale = [
            (bone.name, source_org_of(bone)) for bone in edit_bones
            if bone.get(PROP_RIG_LAYER) == "CTRL-TWEAK" and source_org_of(bone) not in wanted
            and bone.parent is not None and bone.parent.name == control_name(armature, source_org_of(bone), SUFFIX_CTRL)
        ]
        for tweak_name, org_name in stale:
            fk_tweak = edit_bones.get(org_name + SUFFIX_MCH_TWEAK_FK)
            if fk_tweak is not None and fk_tweak.get(PROP_RIG_LAYER) == "MCH-TRANSFER":
                edit_bones.remove(fk_tweak)  # o `_MCH_Transfer` volta pro `_CTRL`
            edit_bones.remove(edit_bones[tweak_name])
        return result

    def _assign_tweak_collections(self, armature, edit_bones, chains_data):
        """Tweaks em "<membro> (Tweak)", logo abaixo do membro; "(Tweak)" que ficou vazio sai."""
        coll_main = ensure_bone_collection(armature, COLL_MAIN)
        for data in chains_data:
            tweaks = [edit_bones.get(name) for name in data["tweaks"]]
            tweaks = [bone for bone in tweaks if bone is not None]
            ref = edit_bones.get(data["ik_root"])
            if not tweaks or ref is None:
                continue
            member = next(
                (
                    c for c in ref.collections
                    if c.parent is not None and c.parent.name == COLL_MAIN
                    and not c.name.endswith(TWEAK_COLLECTION_SUFFIX)
                ),
                None,
            )
            name = member.name + TWEAK_COLLECTION_SUFFIX if member is not None else TWEAK_FALLBACK_COLLECTION
            coll = ensure_bone_collection(armature, name, parent=coll_main)
            for bone in tweaks:
                for other in list(bone.collections):
                    if other.parent is not None and other.parent.name == COLL_MAIN and other.name != name:
                        other.unassign(bone)
                coll.assign(bone)
            ensure_tweak_collection_entry(armature, name, member.name if member is not None else None)

        in_use = {c.name for bone in edit_bones for c in bone.collections}
        for coll in list(coll_main.children):
            if coll.name.endswith(TWEAK_COLLECTION_SUFFIX) and coll.name not in in_use:
                remove_collection_entry(armature, coll.name)
                armature.collections.remove(coll)

    @staticmethod
    def _move_collection_to_index(armature, coll, target_index):
        try:
            roots = list(armature.collections)
            current_index = roots.index(coll)
            if current_index != target_index:
                armature.collections.move(current_index, target_index)
        except Exception:
            pass  # cosmético -- não impede o rig de funcionar

    def _move_main_child_before(self, armature, child_name, before_name):
        """Põe a collection `child_name` (filha de Main) logo antes de `before_name`, por child_number (só entre irmãos)."""
        child = _find_bone_collection_anywhere(armature, child_name)
        target = _find_bone_collection_anywhere(armature, before_name)
        if child is None or target is None:
            self.report(
                {"WARNING"},
                f"Could not reorder bone collection '{child_name}' before '{before_name}' -- "
                f"'{child_name if child is None else before_name}' not found (purely cosmetic, rig still works).",
            )
            return
        if child.parent != target.parent:
            self.report(
                {"WARNING"},
                f"Could not reorder bone collection '{child_name}' before '{before_name}' -- they aren't "
                f"siblings (same parent collection) (purely cosmetic, rig still works).",
            )
            return
        try:
            current_number = child.child_number
            target_number = target.child_number
            new_number = target_number - 1 if current_number < target_number else target_number
            if current_number != new_number:
                child.child_number = new_number
        except Exception as exc:
            self.report(
                {"WARNING"},
                f"Could not reorder bone collection '{child_name}' before '{before_name}': {exc} "
                f"(purely cosmetic, rig still works).",
            )

    def _apply_bone_collection_overrides(self, armature, edit_bones, chains_data, tail_chains_data=()):
        """Redireciona quem tem collection_override e faz a atribuição de Head/Spine (o resto já tem default)."""

        def _resolve_target(target_name, context_label):
            # Lógica em resolve_collection_override_target (nível de
            # módulo), reaproveitada também por _build_texture_picker.
            target_coll = resolve_collection_override_target(armature, target_name)
            if target_coll is None:
                self.report(
                    {"WARNING"},
                    f"Bone Settings: collection '{target_name}' not found in Collection Settings (may "
                    f"have been deleted/renamed) -- '{context_label}' kept in the default collection instead.",
                )
            return target_coll

        def _redirect(bone, target_coll):
            # Só tira das sub-collections default de Main (as internas continuam).
            for coll in list(bone.collections):
                if coll.parent is not None and coll.parent.name == COLL_MAIN and coll.name != target_coll.name:
                    coll.unassign(bone)
            target_coll.assign(bone)

        # --- Arm/Leg (chains_data) ---------------------------------------
        for data in chains_data:
            target_name = (data.get("collection_override") or "").strip()
            if not target_name or target_name == COLLECTION_OVERRIDE_AUTO:
                continue  # Auto -- fica no default que _build_main_collections já montou

            target_coll = _resolve_target(target_name, data.get("ik_root", "?"))
            if target_coll is None:
                continue

            root_name = data.get("ik_root")
            if root_name is not None:
                for bone in collect_descendants_inclusive(
                    edit_bones, root_name, exclude_predicate=is_excluded_from_main_collections
                ):
                    _redirect(bone, target_coll)

            for name in (data.get("pole"), data.get("pole_line"), data.get("ik_tip"), *data.get("ik_hocks", ())):
                bone = edit_bones.get(name) if name else None
                if bone is not None:
                    _redirect(bone, target_coll)

            for reparented_root in data.get("reparented_ctrl_roots", ()):
                for bone in collect_descendants_inclusive(
                    edit_bones, reparented_root, exclude_predicate=is_excluded_from_main_collections
                ):
                    _redirect(bone, target_coll)

        # --- Chain: os `_CTRL` já estão em ctrl_names ---
        for data in tail_chains_data:
            target_name = (data.get("collection_override") or "").strip()
            if not target_name or target_name == COLLECTION_OVERRIDE_AUTO:
                continue  # Auto -- fica em Main/Tail, sem mudança

            target_coll = _resolve_target(target_name, data.get("ctrl_names", ["?"])[0])
            if target_coll is None:
                continue

            for name in data.get("ctrl_names", ()):
                bone = edit_bones.get(name)
                if bone is not None:
                    _redirect(bone, target_coll)

        # --- Head/Spine/Attachments: lidos do Bone Settings ("Auto" = a collection padrão do tipo) ---
        _organizational_defaults = {
            "HEAD": COLL_MAIN_HEAD, "SPINE": COLL_MAIN_SPINE, "ATTACHMENTS": COLL_ATTACHMENTS,
            "TEXTURE_PICKER": COLL_MAIN_TEXTURE_PICKER, "ROOT": COLL_MAIN_ROOT,
        }
        for item in armature.hytale_ik_chains:
            if item.chain_type not in _organizational_defaults:
                continue
            names = _head_spine_bone_names(item)
            if not names:
                continue  # nada configurado ainda -- nada pra fazer

            override = (item.collection_override or "").strip()
            if override and override != COLLECTION_OVERRIDE_AUTO:
                target_coll = _resolve_target(override, item.label or item.chain_type.title())
                if target_coll is None:
                    continue
            else:
                coll_main = ensure_bone_collection(armature, COLL_MAIN)
                target_coll = ensure_bone_collection(
                    armature, _organizational_defaults[item.chain_type], parent=coll_main
                )

            # Os campos guardam o nome do bone ORG -- quem precisa ir
            # pra collection é o _CTRL correspondente, não o ORG cru.
            for name in names:
                ctrl_name = control_name(armature, name, SUFFIX_CTRL)
                bone = edit_bones.get(ctrl_name)
                if bone is None:
                    self.report(
                        {"WARNING"},
                        f"{item.chain_type.title()} '{item.label or '?'}': control bone '{ctrl_name}' not "
                        f"found (expected an ORG bone named '{name}' with a matching '_CTRL') -- skipped.",
                    )
                    continue
                _redirect(bone, target_coll)

            # Bones do Texture Picker já existentes também seguem a collection nova.
            if item.chain_type == "TEXTURE_PICKER" and item.texture_picker_bone:
                for aux_name in (
                    _texture_picker_ui_root_name(item.texture_picker_bone),
                    _texture_picker_cursor_name(item.texture_picker_bone),
                ):
                    aux_bone = edit_bones.get(aux_name)
                    if aux_bone is not None:
                        _redirect(aux_bone, target_coll)

    def _apply_collection_visibility(self, armature):
        """Deixa visível só Main e todas as sub-collections (Attachments incluída); o resto fica oculto."""
        keep_visible = {COLL_MAIN, COLL_ATTACHMENTS}

        def add_children(c):
            keep_visible.add(c.name)
            for child in c.children:
                add_children(child)

        main_coll = _find_bone_collection_anywhere(armature, COLL_MAIN)
        if main_coll is not None:
            add_children(main_coll)

        set_bone_collection_visibility(armature, keep_visible)

    # --- Etapa 2 (Pose/Object Mode): constraints, custom properties, drivers ---

    @staticmethod
    def _lock_ik_hinges(obj, mid_org_names, ik_root, ik_solver_end, pole_name):
        """Trava o `_IK` do meio do solver no eixo da dobradiça (normal do plano raiz/fim/pole), pro IK não sair torcido do FK."""
        bones = obj.data.bones
        root, end, pole = bones.get(ik_root), bones.get(ik_solver_end), bones.get(pole_name)
        hinge = None
        if root is not None and end is not None and pole is not None:
            normal = (end.tail_local - root.head_local).cross(pole.head_local - root.head_local)
            if normal.length > 1e-9:
                hinge = normal.normalized()
        for org_name in mid_org_names:
            ik_pb = obj.pose.bones.get(control_name(obj.data, org_name, SUFFIX_IK))
            if ik_pb is None:
                continue
            free = None
            if hinge is not None:
                ik_axes = ik_pb.bone.matrix_local.to_3x3()
                alignment = {axis: abs((ik_axes @ vec).normalized().dot(hinge)) for axis, vec in (
                    ("x", Vector((1.0, 0.0, 0.0))), ("y", Vector((0.0, 1.0, 0.0))), ("z", Vector((0.0, 0.0, 1.0))),
                )}
                free = max(alignment, key=alignment.get)
                if alignment[free] < IK_HINGE_MIN_ALIGNMENT:
                    free = None  # dobradiça fora dos eixos do bone -- sem trava
            ik_pb.lock_ik_x = free is not None and free != "x"
            ik_pb.lock_ik_y = free is not None and free != "y"
            ik_pb.lock_ik_z = free is not None and free != "z"

    def _build_pose_constraints(self, obj, chains_data):
        pose_bones = obj.pose.bones
        # Alvo do Child Of "global" dos tips/poles de IK: o _CTRL do Origin
        # principal (Root 1 da entrada ROOT; legado "Origin_CTRL").
        child_of_global_target = resolve_origin_ctrl_name(obj.data)
        armature = obj.data

        marked_names = set()
        tweaked = set()  # ORG com Tweak numa cadeia atual (braço/perna ou Spine)
        for data in chains_data:
            marked_names.update(data["org_names"])
            tweaked.update(data["org_names"][: len(data["tweaks"])])
        for data in getattr(self, "_spine_tweak_data", ()):
            tweaked.update(data["org_names"])

        # Base: ORG copia o MCH; MCH copia o `_MCH_Transfer` (filho do `_CTRL`) no mundo, Location só se não for conectado.
        for bone in armature.bones:
            if PROP_RIG_LAYER in bone.keys():
                continue
            org_name = bone.name
            mch_name = org_name + SUFFIX_MCH
            ctrl_name = control_name(armature, org_name, SUFFIX_CTRL)
            transfer_name = org_name + SUFFIX_MCH_TRANSFER
            if mch_name not in pose_bones or ctrl_name not in pose_bones or transfer_name not in pose_bones:
                continue
            mch_pose = pose_bones[mch_name]

            # Mundo: o ORG fica igual ao MCH mesmo com o pai escalado só em alguns eixos.
            ensure_copy_set(pose_bones[org_name], obj, mch_name, CONSTRAINT_ORG_TO_MCH, space="WORLD")
            stale = pose_bones[transfer_name].constraints.get(CONSTRAINT_TWEAK_FK)
            if stale is not None:  # rig anterior: o Tweak_FK ficava no próprio Transfer
                pose_bones[transfer_name].constraints.remove(stale)
            tweak_name = control_name(armature, org_name, SUFFIX_TWEAK)
            fk_tweak = pose_bones.get(org_name + SUFFIX_MCH_TWEAK_FK)
            if fk_tweak is not None and tweak_name in pose_bones:
                ensure_local_add_constraint(fk_tweak, obj, tweak_name, CONSTRAINT_TWEAK_FK)
                fk_tweak.constraints[CONSTRAINT_TWEAK_FK].mute = org_name not in tweaked

            fk_rot = ensure_copy_constraint(
                mch_pose, obj, transfer_name, "ROTATION", CONSTRAINT_FK_ROT, space="WORLD"
            )
            fk_scale = ensure_copy_constraint(
                mch_pose, obj, transfer_name, "SCALE", CONSTRAINT_FK_SCALE, space="WORLD"
            )

            is_chain_bone = org_name in marked_names

            fk_loc = None
            if not bone.use_connect:
                fk_loc = ensure_copy_constraint(
                    mch_pose, obj, transfer_name, "LOCATION", CONSTRAINT_FK_LOC, space="WORLD"
                )
            else:
                old_loc = mch_pose.constraints.get(CONSTRAINT_FK_LOC)
                if old_loc is not None:
                    mch_pose.constraints.remove(old_loc)

            if not is_chain_bone:
                fk_rot.driver_remove("influence")
                fk_scale.driver_remove("influence")
                fk_rot.influence = 1.0
                fk_scale.influence = 1.0
                if fk_loc is not None:
                    fk_loc.driver_remove("influence")
                    fk_loc.influence = 1.0

        # Camada de IK, por cadeia.
        for data in chains_data:
            org_names = data["org_names"]
            ik_root = data["ik_root"]
            ik_solver_end = data["ik_solver_end"]
            ik_tip = data["ik_tip"]
            pole_name = data["pole"]
            switch_prop = data["switch_property"]

            if BONE_PROPERTIES in pose_bones:
                ensure_switch_property(pose_bones[BONE_PROPERTIES], switch_prop)
            else:
                self.report(
                    {"WARNING"},
                    f"'{BONE_PROPERTIES}' not found -- skipping FK/IK switch property '{switch_prop}' "
                    f"(and every driver that depends on it) for this chain.",
                )

            if data["pole_angle_mode"] == "MANUAL":
                pole_angle = math.radians(data["pole_angle_manual"])
            else:
                # Auto. Sinal invertido: convenção do pole_angle do Blender
                # (oposto do ângulo medido por _angle_on_plane).
                pole_angle = -compute_pole_angle(obj, ik_root, ik_solver_end, pole_name) + math.radians(
                    data["pole_angle_fine_tune"]
                )
            ensure_ik_constraint(
                pose_bones[ik_solver_end], obj, data["ik_target"], pole_name, data["ik_chain_count"], pole_angle
            )
            self._lock_ik_hinges(obj, org_names[1:data["ik_chain_count"]], ik_root, ik_solver_end, pole_name)
            # Jarretes ficam fora do solver: tira o IK e a trava de um rig
            # anterior.
            for name in data["ik_hocks"]:
                pb = pose_bones.get(name)
                if pb is None:
                    continue
                stale = pb.constraints.get(CONSTRAINT_IK)
                if stale is not None:
                    pb.constraints.remove(stale)
                pb.lock_ik_x = pb.lock_ik_y = pb.lock_ik_z = False

            # Ponta IK segue o Origin (Child Of, influência 1); Set Inverse em _apply_pole_childof_inverses.
            if child_of_global_target in pose_bones:
                ensure_child_of_constraint(
                    pose_bones[ik_tip], obj, child_of_global_target, CONSTRAINT_CHILD_OF_GLOBAL, 1.0
                )
            else:
                self.report(
                    {"WARNING"},
                    f"'{child_of_global_target}' not found -- skipping {CONSTRAINT_CHILD_OF_GLOBAL} on '{ik_tip}'.",
                )

            # Pole: Child Of local (ponta, ativo) e global (Origin, influência 0).
            if pole_name in pose_bones:
                pole_pose = pose_bones[pole_name]
                ensure_child_of_constraint(pole_pose, obj, ik_tip, CONSTRAINT_CHILD_OF_LOCAL, 1.0)

                if child_of_global_target in pose_bones:
                    ensure_child_of_constraint(
                        pole_pose, obj, child_of_global_target, CONSTRAINT_CHILD_OF_GLOBAL, 0.0
                    )
                else:
                    self.report(
                        {"WARNING"},
                        f"'{child_of_global_target}' not found -- skipping {CONSTRAINT_CHILD_OF_GLOBAL} on "
                        f"'{pole_name}'.",
                    )

            # "_Pole_Line" -- Stretch To simples, sempre mirando no
            # "_Pole_CTRL" desta mesma cadeia/lado. 100% visual.
            pole_line_name = data.get("pole_line")
            if pole_line_name and pole_line_name in pose_bones and pole_name in pose_bones:
                ensure_stretch_to_constraint(
                    pose_bones[pole_line_name], obj, pole_name, CONSTRAINT_POLE_LINE_STRETCH
                )

            # Pai do Tweak: segue o `_IK` no IK e o `_CTRL` no FK.
            for org_name in org_names[: len(data["tweaks"])]:
                holder = pose_bones.get(org_name + SUFFIX_MCH_TWEAK_PARENT)
                ik_name = control_name(armature, org_name, SUFFIX_IK)
                ctrl_name = control_name(armature, org_name, SUFFIX_CTRL)
                if holder is None or ik_name not in pose_bones or ctrl_name not in pose_bones:
                    continue
                con = ensure_switch_parent_constraint(holder, obj, ik_name, ctrl_name, CONSTRAINT_TWEAK_PARENT)
                add_switch_driver(con.targets[0], obj, BONE_PROPERTIES, switch_prop, expression="switch", path="weight")
                add_switch_driver(con.targets[1], obj, BONE_PROPERTIES, switch_prop, expression="1 - switch", path="weight")

            for org_name in org_names:
                mch_name = org_name + SUFFIX_MCH
                bridge_name = org_name + SUFFIX_MCH_IK_TRANSFER
                if mch_name not in pose_bones:
                    continue
                mch_pose = pose_bones[mch_name]

                fk_rot = mch_pose.constraints.get(CONSTRAINT_FK_ROT)
                fk_scale = mch_pose.constraints.get(CONSTRAINT_FK_SCALE)
                fk_loc = mch_pose.constraints.get(CONSTRAINT_FK_LOC)  # None se o bone for conectado ao pai
                if fk_rot is None or fk_scale is None:
                    continue

                # IK_Copy* no mundo, mirando o bridge (mesma rest do MCH).
                ik_rot = ensure_copy_constraint(
                    mch_pose, obj, bridge_name, "ROTATION", CONSTRAINT_IK_ROT, space="WORLD"
                )
                ik_scale = ensure_copy_constraint(
                    mch_pose, obj, bridge_name, "SCALE", CONSTRAINT_IK_SCALE, space="WORLD"
                )
                ik_scale.use_offset = IK_STRETCH_FOLLOWS_PARENT  # multiplica a escala herdada do MCH pai

                add_switch_driver(fk_rot, obj, BONE_PROPERTIES, switch_prop, expression="1 - switch")
                add_switch_driver(ik_rot, obj, BONE_PROPERTIES, switch_prop, expression="switch")
                add_switch_driver(fk_scale, obj, BONE_PROPERTIES, switch_prop, expression="1 - switch")
                add_switch_driver(ik_scale, obj, BONE_PROPERTIES, switch_prop, expression="switch")
                if fk_loc is not None:
                    add_switch_driver(fk_loc, obj, BONE_PROPERTIES, switch_prop, expression="1 - switch")

                # Toda peça fica onde o IK/Tweak dela manda (fora do alcance, a mão fica no controle).
                if fk_loc is not None:
                    ik_loc = ensure_copy_constraint(
                        mch_pose, obj, bridge_name, "LOCATION", CONSTRAINT_IK_LOC, space="WORLD"
                    )
                    add_switch_driver(ik_loc, obj, BONE_PROPERTIES, switch_prop, expression="switch")
                else:
                    stale = mch_pose.constraints.get(CONSTRAINT_IK_LOC)
                    if stale is not None:
                        stale.driver_remove("influence")
                        mch_pose.constraints.remove(stale)

    def _build_spine_follow(self, obj):
        """Spine Follow: os `_CTRL` de Spine 1..N seguem o root.spine_CTRL (Copy Transforms local, After Full, influência
        SPINE_FOLLOW_INFLUENCES). After Full soma por cima sem puxar a pose importada. Quem saiu da Spine perde a constraint."""
        pose_bones = obj.pose.bones
        if SPINE_FOLLOW_TARGET not in pose_bones:
            self.report(
                {"WARNING"}, f"'{SPINE_FOLLOW_TARGET}' not found -- skipping spine-follow constraints."
            )
            return

        segment_names = resolve_spine_segment_org_names(obj.data)
        followers = {}
        for index, org_name in enumerate(segment_names):
            influence = SPINE_FOLLOW_INFLUENCES[min(index, len(SPINE_FOLLOW_INFLUENCES) - 1)]
            followers[control_name(obj.data, org_name, SUFFIX_CTRL)] = influence

        pelvis_ctrl_name = control_name(obj.data, resolve_pelvis_org_name(obj.data), SUFFIX_CTRL)
        followers.pop(pelvis_ctrl_name, None)  # Pelvis nunca segue o root.spine_CTRL

        for pb in pose_bones:
            if pb.name in followers:
                continue
            stale = pb.constraints.get(CONSTRAINT_SPINE_FOLLOW)
            if stale is not None:
                pb.constraints.remove(stale)

        for bone_name, influence in followers.items():
            if bone_name not in pose_bones:
                self.report({"WARNING"}, f"'{bone_name}' not found -- skipping spine-follow.")
                continue
            pb = pose_bones[bone_name]
            con = pb.constraints.get(CONSTRAINT_SPINE_FOLLOW)
            if con is None:
                con = pb.constraints.new("COPY_TRANSFORMS")
                con.name = CONSTRAINT_SPINE_FOLLOW
            con.target = obj
            con.subtarget = SPINE_FOLLOW_TARGET
            con.target_space = "LOCAL"
            con.owner_space = "LOCAL"
            con.mix_mode = "AFTER_FULL"
            con.driver_remove("influence")
            con.influence = influence

    def _build_head_follow(self, obj, active, source):
        """Monta (ou limpa) as constraints do Head Follow já decidido em Edit Mode, na ordem _ROT, _ROOT, _LOC
        (ver CONSTRAINT_HEAD_FOLLOW_* em constants.py); reordena sempre. Set Inverse em _apply_pole_childof_inverses."""
        pose_bones = obj.pose.bones
        head_ctrl_name = resolve_head_ctrl_name(obj.data)
        if head_ctrl_name not in pose_bones:
            return False
        head_pose = pose_bones[head_ctrl_name]
        all_names = (CONSTRAINT_HEAD_FOLLOW_ROT, CONSTRAINT_HEAD_FOLLOW_ROOT, CONSTRAINT_HEAD_FOLLOW_LOC)

        if not active or source is None or source not in pose_bones:
            # Limpeza idempotente -- ver docstring acima.
            for cname in all_names:
                con = head_pose.constraints.get(cname)
                if con is not None:
                    head_pose.constraints.remove(con)
            if BONE_PROPERTIES in pose_bones:
                props_bone = pose_bones[BONE_PROPERTIES]
                if PROP_HEAD_FOLLOW_SWITCH in props_bone.keys():
                    del props_bone[PROP_HEAD_FOLLOW_SWITCH]
            return False

        if BONE_PROPERTIES not in pose_bones:
            self.report(
                {"WARNING"},
                f"'{BONE_PROPERTIES}' not found -- skipping Head Follow switch property "
                f"'{PROP_HEAD_FOLLOW_SWITCH}' (and its driver).",
            )
            return False

        ensure_switch_property(
            pose_bones[BONE_PROPERTIES],
            PROP_HEAD_FOLLOW_SWITCH,
            description=tr("rigger.runtime.head_follow_switch_description", get_language(bpy.context)).format(
                source=source
            ),
            default_value=1,
        )

        # 1. Child Of -> source (Lock).
        rot_con = ensure_child_of_constraint(head_pose, obj, source, CONSTRAINT_HEAD_FOLLOW_ROT, 1.0)
        rot_con.use_location_x = rot_con.use_location_y = rot_con.use_location_z = True
        rot_con.use_rotation_x = rot_con.use_rotation_y = rot_con.use_rotation_z = True
        rot_con.use_scale_x = rot_con.use_scale_y = rot_con.use_scale_z = True
        add_switch_driver(rot_con, obj, BONE_PROPERTIES, PROP_HEAD_FOLLOW_SWITCH, expression="switch")

        # 2. Child Of -> Origin_CTRL (Free).
        origin_ctrl_name = resolve_origin_ctrl_name(obj.data)
        if origin_ctrl_name in pose_bones:
            root_con = ensure_child_of_constraint(head_pose, obj, origin_ctrl_name, CONSTRAINT_HEAD_FOLLOW_ROOT, 1.0)
            root_con.use_location_x = root_con.use_location_y = root_con.use_location_z = True
            root_con.use_rotation_x = root_con.use_rotation_y = root_con.use_rotation_z = True
            root_con.use_scale_x = root_con.use_scale_y = root_con.use_scale_z = True
            add_switch_driver(root_con, obj, BONE_PROPERTIES, PROP_HEAD_FOLLOW_SWITCH, expression="not switch")
        else:
            stale = head_pose.constraints.get(CONSTRAINT_HEAD_FOLLOW_ROOT)
            if stale is not None:
                head_pose.constraints.remove(stale)
            self.report(
                {"WARNING"},
                f"'{origin_ctrl_name}' not found -- skipping '{CONSTRAINT_HEAD_FOLLOW_ROOT}' on '{head_ctrl_name}'.",
            )

        # 3. Copy Location -> tail do source, só no Free.
        loc_con = ensure_copy_constraint(
            head_pose, obj, source, "LOCATION", CONSTRAINT_HEAD_FOLLOW_LOC,
            space="WORLD", head_tail=HEAD_FOLLOW_LOC_HEAD_TAIL,
        )
        add_switch_driver(loc_con, obj, BONE_PROPERTIES, PROP_HEAD_FOLLOW_SWITCH, expression="1 - switch")

        # Reorder idempotente: cada um logo depois do anterior, na ordem
        # de all_names (outros constraints do bone ficam onde estão).
        constraints = head_pose.constraints
        prev_index = constraints.find(all_names[0])
        for cname in all_names[1:]:
            index = constraints.find(cname)
            if index == -1 or prev_index == -1:
                prev_index = index if index != -1 else prev_index
                continue
            target = prev_index + 1 if index > prev_index else prev_index
            if index != target:
                constraints.move(index, target)
            prev_index = constraints.find(cname)

        return True
