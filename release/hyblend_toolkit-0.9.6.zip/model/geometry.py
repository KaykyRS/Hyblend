"""Geometria do .blockymodel: caixa/quad de um nó (UV do textureLayout), posição dos nós e a malha única (sem bones).

UV: port do plugin oficial do Blockbench (blockymodel.ts), conferido contra .gltf exportados (0 divergências).
Normais: sempre pra fora (caixa) ou pro settings.normal (quad), com ou sem stretch negativo.
Stretch: entra nos vértices (o objeto fica com escala 1).
Posição: mundo(nó) = mundo(pai) @ Translação(position + shape.offset do PAI) @ Rotação(orientation);
a malha do nó ainda desloca pelo shape.offset DELE. Medidas ÷ 64 (unit_scale); stretch não escala.
"""

import bmesh
import bpy
from mathutils import Matrix, Vector

from .props import quat_xyzw, vec3

# Eixos (u, v) de cada face pelo eixo fixo: front/back = x×y; top/bottom = x×z; left/right = z×y.
FACE_AXES_BY_FIXED_AXIS = {"z": (0, 1), "y": (0, 2), "x": (2, 1)}
BOX_FACE_FIXED_AXIS = {"front": "z", "back": "z", "top": "y", "bottom": "y", "left": "x", "right": "x"}
BOX_FACES_LOOP_ORDER = (
    ("back", (0, 1, 2, 3)),
    ("front", (4, 7, 6, 5)),
    ("bottom", (0, 4, 5, 1)),
    ("right", (1, 5, 6, 2)),
    ("top", (2, 6, 7, 3)),
    ("left", (3, 7, 4, 0)),
)
OPPOSITE_FACE = {"front": "back", "back": "front", "top": "bottom", "bottom": "top", "left": "right", "right": "left"}
# Quad: o textureLayout fica em "front", mas o sinal da UV segue a face geométrica do settings.normal.
NORMAL_TO_FACE_KEY = {"+Z": "front", "-Z": "back", "+X": "right", "-X": "left", "+Y": "top", "-Y": "bottom"}
# Sinal base (s,t -> pixel) de cada face, sem rotação/espelho (engenharia reversa do .gltf do Blockbench).
BOX_FACE_BASE_SIGN = {
    "back": (-1, -1), "right": (-1, -1), "front": (+1, -1), "left": (+1, -1), "top": (+1, +1), "bottom": (+1, -1),
}
VISUAL_TYPES = ("box", "quad")


def face_size_raw(size_raw, fixed_axis):
    """Largura/altura da face (unidades do jogo, sem escala)."""
    au, av = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
    comps = (size_raw.x, size_raw.y, size_raw.z)
    return comps[au], comps[av]


def uv_rect(fw, fh, angle, mirror, offset):
    """Retângulo [x1, y1, x2, y2] em pixels (invertido = espelho) de uma face (blockymodel.ts, bloco "// UV")."""
    ux = offset.get("x", 0.0)
    uy = offset.get("y", 0.0)
    uv_size = [fw, fh]
    uv_mirror = [-1.0 if mirror.get("x") else 1.0, -1.0 if mirror.get("y") else 1.0]
    k = angle or 0
    if k == 90:
        uv_size[0], uv_size[1] = uv_size[1], uv_size[0]
        uv_mirror[0], uv_mirror[1] = uv_mirror[1], uv_mirror[0]
        uv_mirror[0] *= -1
        return ux, uy + uv_size[1] * uv_mirror[1], ux + uv_size[0] * uv_mirror[0], uy
    if k == 270:
        uv_size[0], uv_size[1] = uv_size[1], uv_size[0]
        uv_mirror[0], uv_mirror[1] = uv_mirror[1], uv_mirror[0]
        uv_mirror[1] *= -1
        return ux + uv_size[0] * uv_mirror[0], uy, ux, uy + uv_size[1] * uv_mirror[1]
    if k == 180:
        uv_mirror[0] *= -1
        uv_mirror[1] *= -1
        return ux + uv_size[0] * uv_mirror[0], uy + uv_size[1] * uv_mirror[1], ux, uy
    # 0° e qualquer ângulo fora de 0/90/180/270 (o Blockbench zeraria a UV; aqui cai no 0°).
    return ux, uy, ux + uv_size[0] * uv_mirror[0], uy + uv_size[1] * uv_mirror[1]


def face_uv(local_co, half_extents, axis_u, axis_v, face_key, tex_offset, face_w, face_h, mirror, angle, atlas_w,
            atlas_h):
    """UV de um vértice (posição local na caixa centrada) dentro do retângulo da face no atlas."""
    hu = half_extents[axis_u] or 1.0
    hv = half_extents[axis_v] or 1.0
    s = (local_co[axis_u] + hu) / (2.0 * hu)
    t = (local_co[axis_v] + hv) / (2.0 * hv)
    bs, bt = BOX_FACE_BASE_SIGN.get(face_key, (1, -1))
    s_bb = s if bs > 0 else 1.0 - s
    t_bb = t if bt > 0 else 1.0 - t
    # Cada 90° de rotação gira o ponto (s, t) -> (t, 1 - s) (cube.js do Blockbench, updateUV).
    for _ in range(int(round((angle or 0) / 90.0)) % 4):
        s_bb, t_bb = t_bb, 1.0 - s_bb
    x1, y1, x2, y2 = uv_rect(face_w, face_h, angle, mirror, tex_offset)
    return (x1 + (x2 - x1) * s_bb) / atlas_w, 1.0 - (y1 + (y2 - y1) * t_bb) / atlas_h


def atlas_size(root_nodes):
    """Tamanho do atlas pelo maior canto usado (pode sair 1-2 px menor que a textura: prefira o tamanho real dela)."""
    max_x, max_y = 1.0, 1.0
    for node in walk(root_nodes):
        shape = node.get("shape") or {}
        size_raw = vec3(shape.get("settings", {}).get("size", {}), default=1.0)
        for face_key, info in (shape.get("textureLayout") or {}).items():
            if shape.get("type") == "box":
                fixed_axis = BOX_FACE_FIXED_AXIS.get(face_key)
                if fixed_axis is None:
                    continue
                fw, fh = face_size_raw(size_raw, fixed_axis)
            else:
                fw, fh = size_raw.x, size_raw.y
            x1, y1, x2, y2 = uv_rect(fw, fh, info.get("angle", 0), info.get("mirror", {}), info.get("offset", {}))
            max_x = max(max_x, x1, x2)
            max_y = max(max_y, y1, y2)
    return max_x, max_y


def walk(root_nodes):
    """Todos os nós (pai antes dos filhos)."""
    stack = list(reversed(root_nodes or []))
    while stack:
        node = stack.pop()
        yield node
        stack.extend(reversed(node.get("children") or []))


def is_visual(node):
    """Nó com caixa/quad que aparece (shape.visible = false = hitbox/peça escondida)."""
    shape = node.get("shape") or {}
    return shape.get("type") in VISUAL_TYPES and shape.get("visible", True) is not False


def shape_offset(node, unit_scale):
    return vec3((node.get("shape") or {}).get("offset", {})) * unit_scale


def local_matrix(node, parent_shape_offset, unit_scale):
    """Matriz local do nó: position + shape.offset do pai, rotação por cima."""
    pos = vec3(node.get("position", {})) * unit_scale + parent_shape_offset
    return Matrix.Translation(pos) @ quat_xyzw(node.get("orientation", {"w": 1.0})).to_matrix().to_4x4()


def orient_outward(bm, center=(0.0, 0.0, 0.0)):
    """Toda face apontando pra fora de `center` (reverse_faces leva a UV junto). Vale com espelho (stretch < 0)."""
    c = Vector(center)
    bm.normal_update()
    wrong = [f for f in bm.faces if f.normal.dot(f.calc_center_median() - c) < 0.0]
    if wrong:
        bmesh.ops.reverse_faces(bm, faces=wrong)
    bm.normal_update()


def _box(bm, uv_layer, shape, size_scaled, size_raw, atlas_w, atlas_h, missing_face_mode):
    """Caixa centrada. Face sem entrada no textureLayout = sem textura no Blockbench: SKIP não cria;
    OPPOSITE_FALLBACK cria com a textura da face oposta."""
    hx, hy, hz = size_scaled.x / 2.0, size_scaled.y / 2.0, size_scaled.z / 2.0
    half_extents = (hx, hy, hz)
    corners = ((-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
               (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz))
    verts = [bm.verts.new(co) for co in corners]
    tex_layout = shape.get("textureLayout") or {}
    for face_key, idxs in BOX_FACES_LOOP_ORDER:
        lookup = face_key
        if face_key not in tex_layout:
            lookup = OPPOSITE_FACE[face_key] if missing_face_mode == "OPPOSITE_FALLBACK" else None
            if lookup not in tex_layout:
                continue
        face = bm.faces.new([verts[i] for i in idxs])
        if uv_layer is None:
            continue
        info = tex_layout[lookup]
        fixed_axis = BOX_FACE_FIXED_AXIS[face_key]
        axis_u, axis_v = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
        fw, fh = face_size_raw(size_raw, fixed_axis)
        for loop in face.loops:
            loop[uv_layer].uv = face_uv(loop.vert.co, half_extents, axis_u, axis_v, face_key, info.get("offset", {}),
                                        fw, fh, info.get("mirror", {}), info.get("angle", 0), atlas_w, atlas_h)
    orient_outward(bm)


def _quad(bm, uv_layer, shape, unit_scale, stretch, size_raw, atlas_w, atlas_h):
    """Plano (2 faces se doubleSided). A face principal olha pro settings.normal (invertido se o stretch desse
    eixo for negativo); a 2ª, pro lado oposto."""
    normal = (shape.get("settings") or {}).get("normal", "+Z") or "+Z"
    fixed_axis = normal[-1].lower() if normal[-1].lower() in ("x", "y", "z") else "z"
    axis_u, axis_v = FACE_AXES_BY_FIXED_AXIS[fixed_axis]
    geom_face_key = NORMAL_TO_FACE_KEY.get(normal, "front")
    # Size 2D (x, y) do settings vai pros eixos (u, v) do plano; o stretch é 3D (eixo do nó, não do size):
    # num quad deitado (+Y), stretch.z estica o lado v.
    hu = size_raw.x * unit_scale * stretch[axis_u] / 2.0
    hv = size_raw.y * unit_scale * stretch[axis_v] / 2.0
    half_extents = [0.0, 0.0, 0.0]
    half_extents[axis_u] = hu or 1.0
    half_extents[axis_v] = hv or 1.0

    def corner(u, v):
        co = [0.0, 0.0, 0.0]
        co[axis_u] = u
        co[axis_v] = v
        return co

    corners = (corner(-hu, -hv), corner(hu, -hv), corner(hu, hv), corner(-hu, hv))
    tex_layout = shape.get("textureLayout") or {}
    face_key = next(iter(tex_layout), None)
    faces = []
    for order in ((0, 1, 2, 3), (3, 2, 1, 0))[:2 if shape.get("doubleSided") else 1]:
        # Vértices próprios por face: o bmesh recusa duas faces com os mesmos vértices.
        face = bm.faces.new([bm.verts.new(corners[i]) for i in order])
        faces.append(face)
        if uv_layer is None or face_key is None:
            continue
        info = tex_layout[face_key]
        for loop in face.loops:
            loop[uv_layer].uv = face_uv(loop.vert.co, tuple(half_extents), axis_u, axis_v, geom_face_key,
                                        info.get("offset", {}), size_raw.x, size_raw.y, info.get("mirror", {}),
                                        info.get("angle", 0), atlas_w, atlas_h)
    sign = -1.0 if normal.startswith("-") else 1.0
    try:
        if float((shape.get("stretch") or {}).get(fixed_axis, 1.0)) < 0.0:
            sign = -sign
    except (TypeError, ValueError):
        pass
    axis_index = "xyz".index(fixed_axis)
    bm.normal_update()
    for i, face in enumerate(faces):
        want = sign if i == 0 else -sign
        if face.normal[axis_index] * want < 0.0:
            bmesh.ops.reverse_faces(bm, faces=[face])
    bm.normal_update()


def _fill_shape(bm, uv_layer, shape, unit_scale, atlas_w, atlas_h, missing_face_mode):
    settings = shape.get("settings") or {}
    size_raw = vec3(settings.get("size", {}), default=1.0)
    stretch = vec3(shape.get("stretch", {}), default=1.0)
    if shape.get("type") == "box":
        size_scaled = Vector((size_raw.x * unit_scale * stretch.x, size_raw.y * unit_scale * stretch.y,
                              size_raw.z * unit_scale * stretch.z))
        _box(bm, uv_layer, shape, size_scaled, size_raw, atlas_w, atlas_h, missing_face_mode)
    else:
        _quad(bm, uv_layer, shape, unit_scale, stretch, size_raw, atlas_w, atlas_h)


def shape_mesh(name, shape, unit_scale, atlas_w, atlas_h, generate_uvs=True, missing_face_mode="SKIP"):
    """Mesh de um shape box/quad, centrada na origem do próprio nó (quem chama posiciona o objeto)."""
    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap") if generate_uvs else None
    _fill_shape(bm, uv_layer, shape, unit_scale, atlas_w, atlas_h, missing_face_mode)
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    return mesh


def node_matrices(root_nodes, unit_scale, root=None):
    """[(nó, matriz da malha)] dos nós visíveis, compostos da raiz do arquivo (sem bones)."""
    out = []

    def visit(node, parent_world, parent_offset):
        world = parent_world @ local_matrix(node, parent_offset, unit_scale)
        own = shape_offset(node, unit_scale)
        if is_visual(node):
            out.append((node, world @ Matrix.Translation(own)))
        for child in node.get("children") or []:
            visit(child, world, own)

    for node in root_nodes or []:
        visit(node, root if root is not None else Matrix.Identity(4), Vector((0.0, 0.0, 0.0)))
    return out


def merged_mesh(name, root_nodes, unit_scale, atlas_w, atlas_h, root=None, generate_uvs=True):
    """O modelo inteiro numa mesh só, sem bones (prefab, miniatura). `root` = matriz aplicada na raiz."""
    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap") if generate_uvs else None
    for node, matrix in node_matrices(root_nodes, unit_scale, root):
        part = bmesh.new()
        part_uv = part.loops.layers.uv.new("UVMap") if generate_uvs else None
        _fill_shape(part, part_uv, node["shape"], unit_scale, atlas_w, atlas_h, "SKIP")
        part.transform(matrix)
        # Matriz espelhada (escala negativa na raiz) inverte o sentido das faces.
        if matrix.to_3x3().determinant() < 0.0:
            bmesh.ops.reverse_faces(part, faces=list(part.faces))
        _append(bm, uv_layer, part, part_uv)
        part.free()
    mesh = bpy.data.meshes.new(name)
    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    return mesh


def _append(dst, dst_uv, src, src_uv):
    verts = {v: dst.verts.new(v.co) for v in src.verts}
    for face in src.faces:
        try:
            new = dst.faces.new([verts[v] for v in face.verts])
        except ValueError:
            continue          # face repetida: não trava o modelo inteiro
        if dst_uv is not None and src_uv is not None:
            for a, b in zip(new.loops, face.loops):
                a[dst_uv].uv = b[src_uv].uv
