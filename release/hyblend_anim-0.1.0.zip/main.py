"""Registro do Anim com o núcleo pronto (chamado por __init__._activate): submódulos de _MODULES, em ordem.
translations primeiro: os outros montam os textos dos campos no register() deles."""

import traceback

from . import common, translations, templates, exporter, importer, anim, interface, rigger

_MODULES = (translations, common, templates, importer, anim, exporter, interface, rigger)
_registered = []      # na ordem; register() que falha no meio desfaz os que entraram (inclusive o que falhou)


def register():
    for module in _MODULES:
        _registered.append(module)     # antes: se falhar no meio, o unregister dele desfaz o que já registrou
        module.register()


def unregister():
    while _registered:
        module = _registered.pop()
        try:
            module.unregister()
        except Exception:         # segue desregistrando o resto (senão sobra classe registrada)
            traceback.print_exc()
