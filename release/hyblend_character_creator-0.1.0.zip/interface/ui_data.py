"""interface/ui_data.py -- prepara DADO pra UI desenhar (agrupamento
Categoria -> Sub-categoria, lista de swatches com hex real). Nao desenha
nada e nao muda estado -- so leitura do catalogo/slot. Movido de
picker.py (ver DEVELOPER_NOTES item 56): so a UI usava essas duas
funcoes."""

from __future__ import annotations

from ..common import _HIDDEN_CATEGORIES, _OUTROS_KEY, _SECTION_CATEGORIES
from ..picker import _slot_effective_gradient_set, _slot_item_value
from ..scanner.catalog import get_cache


def _group_categories(cache) -> dict:
    """Agrupamento pra grade de 'Categoria' da nova UI -- so grupos/
    sub-categorias que EXISTEM no catalogo carregado (generaliza o
    'present_categories' do panel.py antigo). Acrescenta um grupo
    sintetico _OUTROS_KEY com qualquer sub-categoria do catalogo que nao
    esta mapeada em nenhum grupo de _SECTION_CATEGORIES -- so aparece se
    houver pelo menos uma de verdade, nunca uma caixa vazia.
    `_HIDDEN_CATEGORIES` (ex. SkinFeatures) fica de fora completamente,
    nem no grupo mapeado nem no Outros -- confirmado pelo usuario que
    aparecia vazia, sem nenhum item de verdade dentro."""
    result = {}
    mapped = set(_HIDDEN_CATEGORIES)
    for group, subcats in _SECTION_CATEGORIES.items():
        mapped.update(subcats)
        present = [c for c in subcats if c in cache.catalogs]
        if present:
            result[group] = present
    outros = sorted(c for c in cache.catalogs.keys() if c not in mapped)
    if outros:
        result[_OUTROS_KEY] = outros
    return result


def _grid_color_entries(context, slot) -> list:
    """(nome, hex_ou_None) pra grade de swatch circular -- separado de
    _slot_color_enum_items porque a grade precisa do BaseColor DE
    VERDADE (pro circulo sair com a cor real do jogo), nao so do nome.
    Ordenado por nome (nao reaproveita _sorted_enum -- essa ordena pelo
    indice 1, que aqui e o hex, nao o label)."""
    cache = get_cache()
    item = cache.find_item(slot.category, _slot_item_value(slot))
    if item is None:
        return []
    if item.coloring_mode == "gradient":
        gset_id = _slot_effective_gradient_set(slot)
        gset = cache.gradient_sets.get(gset_id)
        if gset is None:
            return []
        entries = [(c.name, (c.base_color[0] if c.base_color else None)) for c in gset.colors]
    elif item.coloring_mode == "discrete":
        entries = [(t.name, (t.base_color[0] if t.base_color else None)) for t in item.textures]
    else:
        return []
    return sorted(entries, key=lambda e: e[0].lower())
