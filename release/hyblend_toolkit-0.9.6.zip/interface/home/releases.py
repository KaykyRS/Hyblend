"""Changelog e aba Add-ons = releases do GitHub (api.github.com/repos/KaykyRS/Hyblend/releases, sem login, 60/h por IP).
Busca numa thread (só urllib/json), cache em <dados da extensão>/releases.json (abre na hora e funciona offline),
no máximo a cada REFRESH_EVERY. Respeita o "Allow Online Access" do Blender.
Cada release guarda os zips anexados (`assets`: name, size, url, digest "sha256:...") pra aba Add-ons (addons.py).
"""

import json
import os
import threading
import time

import bpy

from ...common import ADDON_PACKAGE

API_URL = "https://api.github.com/repos/KaykyRS/Hyblend/releases?per_page=50"   # 4 addons: folga pro mais parado
PAGE_URL = "https://github.com/KaykyRS/Hyblend/releases"
REFRESH_EVERY = 6 * 3600
TIMEOUT = 10.0
_FIELDS = ("tag_name", "name", "body", "published_at", "html_url", "prerelease")

# Tag de release por addon (repo único): "<prefixo>-v<versão>" (ex.: "anim-v0.1.0");
# sem prefixo = Toolkit (tags antigas).
# Nomes próprios, sem tradução. Addon novo = uma linha aqui.
TAG_PREFIXES = {"toolkit": "Toolkit", "anim": "Anim", "cc": "Character Creator", "prefabs": "Prefabs"}


def split_tag(tag):
    """("toolkit"|"anim"|..., nome do addon, "v<versão>") de uma tag de release."""
    tag = (tag or "?").strip()
    prefix, sep, rest = tag.partition("-")
    if sep and prefix.lower() in TAG_PREFIXES:
        ident, version = prefix.lower(), rest
    else:
        ident, version = "toolkit", tag
    version = version if version.lower().startswith("v") else "v" + version
    return ident, TAG_PREFIXES[ident], version

_state = {"loaded": False, "releases": [], "fetched_at": 0.0, "status": "idle", "error": ""}
_job = {"thread": None, "result": None, "lock": threading.Lock()}


def _cache_file(create=False):
    try:
        base = bpy.utils.extension_path_user(ADDON_PACKAGE, create=create)
    except Exception:
        base = bpy.utils.user_resource("CONFIG", path="hyblend_toolkit", create=create)
    return os.path.join(base, "releases.json")


def _load_cache():
    if _state["loaded"]:
        return
    _state["loaded"] = True
    try:
        with open(_cache_file(), encoding="utf-8") as handle:
            data = json.load(handle)
        _state["releases"] = [r for r in data.get("releases", []) if isinstance(r, dict)]
        _state["fetched_at"] = float(data.get("fetched_at", 0.0))
    except (OSError, ValueError, TypeError):
        pass


def _save_cache():
    try:
        with open(_cache_file(create=True), "w", encoding="utf-8") as handle:
            json.dump({"fetched_at": _state["fetched_at"], "releases": _state["releases"]}, handle)
    except OSError as error:
        print("[Hyblend] Home: could not save releases cache:", error)


def online_allowed():
    """Preferences > System > Allow Online Access (Blender 4.2+)."""
    return bool(getattr(bpy.app, "online_access", True))


def releases():
    _load_cache()
    return _state["releases"]


def status():
    """"idle" | "loading" | "ok" | "error" | "offline" -- e quando atualizou."""
    _load_cache()
    return _state["status"], _state["error"], _state["fetched_at"]


def refresh(force=False):
    """Busca em segundo plano (se permitido e se o cache estiver velho)."""
    _load_cache()
    if _job["thread"] is not None:
        return
    if not online_allowed():
        _state["status"] = "offline"
        return
    # cache de antes da aba Add-ons (sem "assets") conta como velho
    fresh = all("assets" in r for r in _state["releases"])
    if not force and fresh and _state["releases"] and time.time() - _state["fetched_at"] < REFRESH_EVERY:
        _state["status"] = "ok"
        return
    _state["status"], _state["error"] = "loading", ""
    _job["result"] = None
    thread = threading.Thread(target=_worker, args=(API_URL,), name="hyblend_releases", daemon=True)
    _job["thread"] = thread
    thread.start()
    if not bpy.app.timers.is_registered(_poll):
        bpy.app.timers.register(_poll, first_interval=0.25)


def _worker(url):
    """THREAD: só rede + json. Resultado: ("ok", [releases]) ou ("error", texto)."""
    import ssl
    import urllib.request
    try:
        # O Python do Blender (macOS principalmente) nem sempre acha os
        # certificados do sistema: usa os do certifi, que vem com o Blender.
        try:
            import certifi
            context = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            context = ssl.create_default_context()
        request = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json",
                                                       "User-Agent": "Hyblend-Toolkit"})
        with urllib.request.urlopen(request, timeout=TIMEOUT, context=context) as response:
            data = json.loads(response.read().decode("utf-8"))
        if not isinstance(data, list):
            raise ValueError(data.get("message", "unexpected answer") if isinstance(data, dict) else "unexpected answer")
        items = [dict({k: r.get(k) for k in _FIELDS}, assets=_assets(r))
                 for r in data if isinstance(r, dict) and not r.get("draft")]
        result = ("ok", items)
    except Exception as error:                       # sem internet, limite do GitHub, JSON estranho...
        result = ("error", str(error)[:200])
    with _job["lock"]:
        _job["result"] = result


def _assets(release):
    """Zips anexados ao release (o resto da resposta do GitHub não interessa)."""
    found = []
    for asset in release.get("assets") or ():
        if isinstance(asset, dict) and str(asset.get("name", "")).lower().endswith(".zip"):
            found.append({"name": asset.get("name"), "size": asset.get("size"),
                          "url": asset.get("browser_download_url"), "digest": asset.get("digest")})
    return found


def _poll():
    """Timer (thread principal): pega o resultado da thread quando chegar."""
    with _job["lock"]:
        result = _job["result"]
    if result is None:
        thread = _job["thread"]
        if thread is not None and thread.is_alive():
            return 0.25
        result = ("error", "no answer")
    _job["thread"], _job["result"] = None, None
    kind, payload = result
    if kind == "ok":
        _state["releases"], _state["fetched_at"] = payload, time.time()
        _state["status"], _state["error"] = "ok", ""
        _save_cache()
    else:
        _state["status"], _state["error"] = "error", payload
        print("[Hyblend] Home: releases:", payload)
    from ..gpu_ui import home_host as host
    host.refresh_all()
    return None


def cancel():
    """unregister: sai o timer E a busca pela metade (o módulo sobrevive ao desligar; religado na mesma sessão,
    um _job["thread"] velho travaria o refresh() pra sempre)."""
    if bpy.app.timers.is_registered(_poll):
        bpy.app.timers.unregister(_poll)
    with _job["lock"]:
        _job["thread"], _job["result"] = None, None
    if _state["status"] == "loading":
        _state["status"] = "idle"
