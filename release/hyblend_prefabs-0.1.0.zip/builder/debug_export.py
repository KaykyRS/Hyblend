"""debug_export.py -- EXPORT_OT_hyblend_debug_dump, operador de DEPURACAO
(fora do fluxo normal de import). Exporta posicao/rotacao/escala final de
cada Object importado, junto com os valores crus do prefab (custom
properties), pra comparar numericamente contra o .prefab.json original."""

from __future__ import annotations

import json
from pathlib import Path

import bpy
from bpy.props import StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ExportHelper

from ..common import PREFAB_COLLECTION_PREFIX as _PREFIX


def _json_safe(value):
    """IDPropertyArray (custom property tipo tupla) nao serializa em JSON
    direto -- converte pra lista nativa."""
    if hasattr(value, "to_list"):
        return _json_safe(value.to_list())
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return value


def _custom_props(obj) -> dict:
    """So as custom properties do proprio addon (prefixo "hytale_")."""
    return {k: _json_safe(obj[k]) for k in obj.keys() if k.startswith("hytale_")}


def _dump_object(obj) -> dict:
    data = {
        "name": obj.name,
        "mesh": obj.data.name if obj.data else None,
        "parent": obj.parent.name if obj.parent else None,
        "location": tuple(obj.location),
        "rotation_mode": obj.rotation_mode,
        "scale": tuple(obj.scale),
        "custom_properties": _custom_props(obj),
    }
    if obj.rotation_mode == "QUATERNION":
        data["rotation_quaternion"] = tuple(obj.rotation_quaternion)
    else:
        data["rotation_euler"] = tuple(obj.rotation_euler)
    # World matrix decomposta -- posicao/rotacao/escala ja com o parent aplicado.
    loc, rot, scale = obj.matrix_world.decompose()
    data["world_location"] = tuple(loc)
    data["world_rotation_quaternion"] = tuple(rot)
    data["world_scale"] = tuple(scale)
    return data


class EXPORT_OT_hyblend_debug_dump(Operator, ExportHelper):
    """DEPURACAO -- exporta posicao/rotacao/escala (local e world) de cada
    Object de uma ou mais collections "Hyblend Prefab - ..." pra um .json."""

    bl_idname = "export_scene.hyblend_debug_dump"
    bl_label = "Export Hyblend Debug Dump (.json)"
    bl_options = {"REGISTER"}

    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        collections = [c for c in bpy.data.collections if c.name.startswith(_PREFIX)]
        if not collections:
            self.report({"ERROR"}, f"No collection starting with '{_PREFIX}' found -- import a prefab first.")
            return {"CANCELLED"}

        dump = {"collections": []}
        total_objects = 0
        for collection in collections:
            objects = [_dump_object(obj) for obj in collection.objects]
            dump["collections"].append({"name": collection.name, "objects": objects})
            total_objects += len(objects)

        out_path = Path(self.filepath)
        with out_path.open("w", encoding="utf-8") as f:
            json.dump(dump, f, indent=2, default=str)  # default=str: rede de seguranca

        self.report({"INFO"}, f"Hyblend Debug Dump: {total_objects} object(s) across {len(collections)} collection(s) -> {out_path.name}")
        return {"FINISHED"}


def menu_func_export(self, context):
    # So em Developer Mode (Preferences) -- ferramenta de depuracao.
    from ..preferences import is_developer_mode

    if not is_developer_mode(context):
        return
    self.layout.operator(EXPORT_OT_hyblend_debug_dump.bl_idname, text="Hyblend Debug Dump (.json)")


_CLASSES = (EXPORT_OT_hyblend_debug_dump,)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
