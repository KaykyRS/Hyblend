"""item_index.py -- indice {item_id: Path} sobre Server/Item/Items/ (blocks)
e Server/Models/ (model entities). O "name" de um block no prefab sempre bate
com um filename (sem extensao) em algum lugar dessas arvores; a subpasta nao
segue padrao fixo, entao a arvore inteira e escaneada uma vez e cacheada por
filename."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from .assets_source import AssetsSource

_ITEMS_SUBDIR = ("Server", "Item", "Items")
_MODELS_SUBDIR = ("Server", "Models")  # model entities (Server/Models/**/<Id>.json)

# Cache em memoria, chaveado por id(AssetsSource) -- reconstruido sozinho se a
# fonte mudar (ver preferences.py/_invalidate_assets_source).
_index_cache: dict = {}
_model_index_cache: dict = {}


class ItemIndexError(Exception):
    pass


def clear_index_caches() -> None:
    """Descarta os indices em memoria. Chamado sempre que o AssetsSource e
    invalidado (preferences.py/_invalidate_assets_source) -- a chave do
    cache e id(AssetsSource), e o Python pode reaproveitar esse id pra um
    AssetsSource novo depois que o antigo e coletado, devolvendo um indice
    velho (apontando pra arquivos de cache ja apagados, por exemplo)."""
    _index_cache.clear()
    _model_index_cache.clear()


def _scan_items_dir(items_dir: Path, what: str = "The game's item folder") -> dict:
    if not items_dir.is_dir():
        raise ItemIndexError(
            f"{what} was not found in Assets.zip ('{items_dir}'). The Hytale install may be incomplete: "
            "repair it in the launcher, then use Clear Cache in the add-on Preferences."
        )
    index: dict = {}
    for path in items_dir.rglob("*.json"):
        index.setdefault(path.stem, path)  # primeiro nome duplicado encontrado vence
    return index


def get_item_index(assets_source: AssetsSource) -> dict:
    """{item_id: Path} para cada .json em Server/Item/Items/, cacheado por AssetsSource."""
    key = id(assets_source)
    cached = _index_cache.get(key)
    if cached is not None:
        return cached

    items_dir = assets_source.resolve_root_dir(*_ITEMS_SUBDIR)
    index = _scan_items_dir(items_dir)
    _index_cache[key] = index
    return index


def load_item_json(assets_source: AssetsSource, item_id: str) -> Optional[dict]:
    """JSON do item, ou None se item_id nao estiver no indice."""
    index = get_item_index(assets_source)
    path = index.get(item_id)
    if path is None:
        return None
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def get_model_index(assets_source: AssetsSource) -> dict:
    """Igual a get_item_index, mas para Server/Models/ (model entities)."""
    key = id(assets_source)
    cached = _model_index_cache.get(key)
    if cached is not None:
        return cached

    models_dir = assets_source.resolve_root_dir(*_MODELS_SUBDIR)
    index = _scan_items_dir(models_dir, what="The game's Server/Models folder")
    _model_index_cache[key] = index
    return index


def load_model_json(assets_source: AssetsSource, model_id: str) -> Optional[dict]:
    """JSON de Server/Models/**/<model_id>.json, ou None se nao estiver no indice."""
    index = get_model_index(assets_source)
    path = index.get(model_id)
    if path is None:
        return None
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)
