"""picker.py -- a LOGICA por tras da UI: o slot por categoria
(HYBLENDCC_ItemSlot), toda a logica de EnumProperty dinamico (Item/Cor/
Variante/GradientSet), sincronizacao com o Armature ativo, aplicar
automatico, e os operadores de catalogo/miniatura por categoria. O que
e SO de interface (operadores de clique, agrupamento de Categoria,
entradas de swatch) mora em interface/ desde o item 56 do
DEVELOPER_NOTES.

Camada 3 na hierarquia de import -- depende de common.py e preferences.py
(pra resolver caminho de arquivo), alem dos modulos externos (builder/
scanner/thumbnails). NAO importa de presets_ops.py/player_ops.py/
interface/ (interface/ e quem importa daqui, nunca o contrario).

Ver DEVELOPER_NOTES.md pra entender a mecanica de "por que tantos
callbacks fazem tao pouca coisa e so agendam _defer_apply_slot" (bug
real de EnumProperty + timer, ja documentado la) e o esquema de cache
(_item_enum_cache/_thumbnail_negative_cache) que existe especificamente
por causa de um problema de performance real encontrado no teste."""

from __future__ import annotations

import json

import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy.types import Operator, PropertyGroup

from .builder.character_assembly import (
    AssemblyError,
    assemble_item,
    equipped_slot_record,
    get_equipped_item,
    recolor_equipped_slot,
    record_equipped_slot,
    remove_equipped_slot,
)
from .builder.material_setup import (
    build_flat_material,
    build_flat_preview_material,
    build_gradient_tint_material,
    build_gradient_tint_preview_material,
)
from .builder.model_tree import UNIT_SCALE_DEFAULT, estimate_atlas_size
from .compat import set_image_non_color
from .common import (
    ADDON_PACKAGE,
    _LINKED_SKIN_CATEGORIES,
    _MANDATORY_CATEGORIES,
    _SKIN_GRADIENT_SET_ID,
    _SLOT_NONE_VALUE,
    _crop_transparent_margin_inplace,
    _get_preview_collection,
    _prettify_key,
    _sorted_enum,
    game_found,
)
from .preferences import _character_creator_dir, _languages_dir, _resolve_assets_path
from .scanner.catalog import get_cache
from .thumbnails.cache import thumbnail_path
from .thumbnails.render import render_item_thumbnail


def _report_warnings(operator, warnings):
    for w in warnings:
        operator.report({"WARNING"}, w)

_slots_syncing = False


_pending_applies: dict = {}
# categoria -> funcao do timer agendado (closure): guardada so pra poder
# remover no unregister (timer pendente trava a saida do Blender 4.5 --
# correcao 2 do Hyblend Toolkit 0.9.3).
_apply_timers: dict = {}


def cancel_pending_applies() -> None:
    """unregister: remove timers de aplicar ainda pendentes."""
    for fn in list(_apply_timers.values()):
        try:
            if bpy.app.timers.is_registered(fn):
                bpy.app.timers.unregister(fn)
        except Exception:
            pass
    _apply_timers.clear()
    _pending_applies.clear()
# category -> (item_id, color, variant, gradient_set) -- a aplicacao mais
# RECENTE pedida pra essa categoria, ainda nao rodada. Existe pra
# deduplicar: uma unica troca de Item hoje agenda ATE 2 chamadas
# separadas (uma do reset de cor, outra explicita no final -- ver
# _slot_on_item_update), cada uma refazendo a peca inteira do zero E
# forcando redraw de toda area de toda janela. Sem dedup, isso e
# trabalho em DOBRO por clique -- pouco perceptivel com dropdown de
# texto, mas fica pesado com as miniaturas ativadas (confirmado no teste
# real: usuario sentiu queda de performance especificamente nessa
# combinacao). Categorias diferentes tem entradas independentes (nao
# competem entre si), entao trocar Skintone (que mexe em varias
# categorias de uma vez) continua aplicando cada uma normalmente.


def _defer_apply_slot(
    category: str, item_id: str, color: str, variant: str = "", gradient_set: str = "",
    background_color: str = "", background_linked: bool = False, skin_linked: bool = True,
) -> None:
    """Roda hyblendcc.apply_slot no PROXIMO tick do event loop, em vez de
    direto -- chamar um operador de dentro do update() de uma
    EnumProperty as vezes nao "pega" na hora (o Blender ainda esta no
    meio de processar a troca da property). bpy.app.timers e o workaround
    padrao pra isso (adia a chamada pro loop de eventos processar DEPOIS
    que a mudanca da property ja assentou).

    CRASH REAL #1 CORRIGIDO (log de crash real analisado -- nao teoria):
    dentro de assemble_item, o mode_set(EDIT)/mode_set(OBJECT) precisa
    resolver CTX_data_view_layer() -- e um callback de bpy.app.timers NAO
    tem um contexto completo por padrao. O temp_override anterior so
    passava window+screen, o que NAO bastava: o Blender tentava ler o
    view_layer de um ponteiro nulo e derrubava o processo inteiro
    (EXCEPTION_ACCESS_VIOLATION dentro de python311.dll, pilha real:
    py_timer_execute -> ... -> mode_set_ex -> CTX_data_view_layer ->
    PyDict_GetItem). Passar view_layer e scene EXPLICITAMENTE no
    temp_override resolveu ESSE caso.

    CRASH REAL #2 CORRIGIDO (segundo log de crash real, ver
    DEVELOPER_NOTES.md item 34) -- window+screen+scene+view_layer NAO
    bastou pra todo caso: mode_set as vezes invoca editmode_toggle
    internamente, e esse caminho especifico precisa TAMBEM de
    area/region no override (cai num fallback de resolucao de contexto
    via Python -- ctx_wm_python_context_get -- que so funciona com eles
    presentes). Intermitente (centenas de trocas de GradientSet bem
    sucedidas antes de falhar) -- bate com "depende do estado exato da
    UI no momento em que o timer dispara". Busca uma area VIEW_3D (onde
    o N-panel deste addon vive) + region WINDOW dentro dela; se nao
    encontrar, cai pro override antigo sem quebrar.

    DEDUP: se ja existe uma aplicacao pendente pra essa MESMA categoria
    (timer ja registrado, ainda nao rodou), so atualiza o valor guardado
    e sai -- nao registra um segundo timer. Quando o timer rodar, ele le
    o valor MAIS RECENTE (nao o que estava valendo quando foi agendado),
    entao o resultado final e sempre o correto mesmo com so uma execucao."""
    already_pending = category in _pending_applies
    _pending_applies[category] = (item_id, color, variant, gradient_set, background_color, background_linked, skin_linked)
    if already_pending:
        return

    def _run():
        _apply_timers.pop(category, None)
        pending = _pending_applies.pop(category, None)
        if pending is None:
            return None  # ja foi consumido por algum motivo (nao deveria acontecer, mas nao trava)
        if not game_found():
            return None  # a pasta do jogo sumiu antes do timer: apply_slot esta travado (poll)
        item_id, color, variant, gradient_set, background_color, background_linked, skin_linked = pending

        wm = bpy.context.window_manager
        window = wm.windows[0] if wm.windows else None
        try:
            if window is not None:
                # CRASH REAL #2 CORRIGIDO (log de crash real analisado --
                # nao teoria, ver DEVELOPER_NOTES.md): window+screen+scene+
                # view_layer resolveu o crash ORIGINAL (CTX_data_view_layer
                # dentro do mode_set), mas NAO bastou pra um segundo crash
                # depois de centenas de trocas de GradientSet bem-sucedidas
                # (pilha real: object_mode_set_exec -> ... ->
                # editmode_toggle_exec -> CTX_data_main ->
                # ctx_wm_python_context_get -> BPY_context_member_get ->
                # PyDict_GetItem = NULL). `mode_set` as vezes invoca
                # `editmode_toggle` internamente, e esse caminho especifico
                # cai no fallback de resolucao de contexto "via Python"
                # (ctx_wm_python_context_get) quando nao encontra o membro
                # pelo caminho normal -- esse fallback so funciona com
                # `area`/`region` tambem presentes no override, que a versao
                # anterior nao fornecia. Intermitente (funcionou centenas de
                # vezes antes de falhar) bate com "depende do estado exato
                # da UI no momento em que o timer dispara" -- exatamente o
                # tipo de bug que falta de area/region costuma causar.
                area = next((a for a in window.screen.areas if a.type == "VIEW_3D"), None)
                region = next((r for r in area.regions if r.type == "WINDOW"), None) if area is not None else None
                override_kwargs = {"window": window, "screen": window.screen, "scene": window.scene, "view_layer": window.view_layer}
                if area is not None:
                    override_kwargs["area"] = area
                if region is not None:
                    override_kwargs["region"] = region
                with bpy.context.temp_override(**override_kwargs):
                    bpy.ops.hyblendcc.apply_slot(
                        "EXEC_DEFAULT", category=category, item_id=item_id, color=color, variant=variant,
                        gradient_set=gradient_set, background_color=background_color, background_linked=background_linked,
                        skin_linked=skin_linked,
                    )
            else:
                bpy.ops.hyblendcc.apply_slot(
                    "EXEC_DEFAULT", category=category, item_id=item_id, color=color, variant=variant,
                    gradient_set=gradient_set, background_color=background_color, background_linked=background_linked,
                    skin_linked=skin_linked,
                )
        except RuntimeError as exc:
            # poll falhou (o objeto ativo mudou antes do timer) ou o operador
            # reportou erro: sem traceback no console, o painel segue normal.
            print("Hyblend Character Creator: could not apply %s (%s)" % (category, exc))

        # So VIEW_3D precisa redesenhar (o painel deste addon e um N-panel
        # DENTRO do VIEW_3D -- bl_space_type = "VIEW_3D" -- e e la que a
        # geometia nova tambem aparece). Redesenhar TODA area de TODA
        # janela (como era antes) e trabalho desperdicado nas outras
        # (Outliner, Timeline, etc.) que nunca mudam por causa disso.
        for w in wm.windows:
            for area in w.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()

        return None  # None = roda so uma vez, nao repete

    _apply_timers[category] = _run
    bpy.app.timers.register(_run, first_interval=0.0)


def _defer_apply_slot_from(slot, color_override=None):
    """Chama `_defer_apply_slot` com os 8 argumentos extraidos do
    proprio slot -- consolida um padrao que se repetia IDENTICO em 9
    lugares diferentes deste arquivo (_slot_on_item_update,
    _slot_on_color_update, _slot_on_gradient_set_update,
    _slot_on_variant_update, _slot_on_background_color_update,
    _slot_on_background_linked_update, _slot_on_skin_linked_update,
    _propagate_linked_skin_color -- cada um reescrevendo a MESMA
    chamada de 8 argumentos por conta propria).

    `color_override`, se dado, usa esse valor no lugar de `slot.color`
    -- caso de `_propagate_linked_skin_color`, que precisa despachar
    a nova cor ANTES dela ser de fato escrita no proprio slot."""
    _defer_apply_slot(
        slot.category, slot.item_id,
        color_override if color_override is not None else slot.color,
        slot.variant, slot.gradient_set,
        slot.background_color, slot.background_linked, slot.skin_linked,
    )


def _item_reference_color(cache, item):
    """Uma cor "representativa" pro item -- usada SO pra gerar a
    miniatura do grid de Item (nao e a cor equipada de verdade, essa
    continua sendo escolhida a parte, na paleta de Cor). Sempre a
    primeira em ordem alfabetica, pra ser deterministico (mesmo item
    sempre gera a mesma miniatura, nao importa a ordem de iteracao)."""
    if item.coloring_mode == "gradient":
        gset = cache.gradient_sets.get(item.gradient_set)
        if gset and gset.colors:
            return sorted(gset.colors, key=lambda c: c.name.lower())[0].name
        return None
    if item.coloring_mode == "discrete":
        if item.textures:
            return sorted(item.textures, key=lambda t: t.name.lower())[0].name
        return None
    return None


def _ensure_item_thumbnail_icon(cache, category: str, item) -> int:
    """Devolve o icon_id (int) pro grid de miniaturas -- CARREGA do disco
    se ja estiver gerado e ainda nao estiver no preview collection desta
    sessao (rapido, so leitura de arquivo). NUNCA renderiza aqui --
    quem gera de verdade e HYBLENDCC_OT_build_category_thumbnails,
    chamado a parte (via botao), porque renderizar e lento demais pra
    rodar dentro de um items() de EnumProperty (chamado a cada redraw).
    Devolve 0 (sem icone -- template_icon_view mostra so o texto) se a
    miniatura ainda nao foi gerada.

    Cacheia o resultado NEGATIVO tambem (_thumbnail_negative_cache) --
    sem isso, todo item sem miniatura ainda gerada bate no disco
    (path.is_file()) EM TODO REDRAW, pra sempre. Ver _invalidate_item_enum_cache
    pra quando isso e limpo (categoria teve miniatura gerada, ou reload)."""
    pcoll = _get_preview_collection()
    key = f"{category}__{item.id}"
    if key in pcoll:
        return pcoll[key].icon_id
    if key in _thumbnail_negative_cache:
        return 0

    color_name = _item_reference_color(cache, item)
    if color_name is None:
        _thumbnail_negative_cache.add(key)
        return 0
    path = thumbnail_path(category, item.id, color_name)
    if not path.is_file():
        _thumbnail_negative_cache.add(key)
        return 0
    preview = pcoll.load(key, str(path), "IMAGE")
    return preview.icon_id

_item_enum_cache: dict = {}
_color_enum_cache: dict = {}
_gradient_set_enum_cache: dict = {}
_variant_enum_cache: dict = {}

_thumbnail_negative_cache: set = set()


def _invalidate_item_enum_cache(category=None) -> None:
    """category=None limpa tudo (ex: recarregar catalogo). Categoria
    especifica limpa so aquela (ex: depois de gerar miniaturas dela --
    os icones que estavam "negativos" podem existir agora)."""
    if category is None:
        _item_enum_cache.clear()
        _color_enum_cache.clear()
        _gradient_set_enum_cache.clear()
        _variant_enum_cache.clear()
        _background_node_cache.clear()
        _thumbnail_negative_cache.clear()
        return
    for cache_dict in (_item_enum_cache, _color_enum_cache, _gradient_set_enum_cache, _variant_enum_cache, _background_node_cache):
        for key in [k for k in cache_dict if k[0] == category]:
            del cache_dict[key]
    prefix = f"{category}__"
    for key in [k for k in _thumbnail_negative_cache if k.startswith(prefix)]:
        _thumbnail_negative_cache.discard(key)


def _slot_item_value(slot) -> str:
    """item_id do slot SEM ler a EnumProperty -- via espelho `item_key`.

    PERFORMANCE (bug real, DEVELOPER_NOTES item 58): no Blender, LER uma
    EnumProperty dinamica chama o callback items() dela e o C converte a
    lista INTEIRA de volta. Os callbacks de Cor/GradientSet/Variante liam
    `self.item_id`/`self.gradient_set` (varias vezes cada), e cada leitura
    disparava o items() DELES -- cascata. Somado a UI ler `slot.color` uma
    vez POR BOLINHA, eram ~870 chamadas de items() e ~80 mil tuplas
    convertidas por redesenho so na secao de cor (medido: item de 112
    opcoes + paleta Skin de 53 cores). Espelho vazio (nunca escrito) cai
    pra leitura normal da enum."""
    key = slot.item_key
    return key if key else slot.item_id


def _slot_gradient_value(slot) -> str:
    """gradient_set do slot SEM ler a EnumProperty (espelho `gradient_key`)
    -- mesmo motivo de `_slot_item_value`."""
    key = slot.gradient_key
    return key if key else slot.gradient_set


def _slot_item_enum_items(self, context):
    prefs = context.preferences.addons[ADDON_PACKAGE].preferences
    use_icons = prefs.show_previews
    cache_key = (self.category, use_icons, prefs.language)
    cached = _item_enum_cache.get(cache_key)
    if cached is not None:
        return cached

    cache = get_cache()
    try:
        cache.ensure_lang_loaded(_languages_dir(context), prefs.language)
    except AssemblyError:
        pass

    items_list = cache.catalogs.get(self.category, [])
    labeled = sorted(
        ((it.id, cache.display_name(it.name_key), it) for it in items_list),
        key=lambda e: e[1].lower(),
    )

    # NAO filtramos por bone-do-Armature aqui de proposito (ver conversa
    # de design -- tentativa revertida): inferir compatibilidade por nome
    # de bone e indireto e arriscado de dar falso negativo (esconder um
    # item que na verdade funcionaria), sem nenhum personagem customizado
    # real pra validar contra. Mais seguro deixar a lista sempre
    # completa: se o bone raiz de um item nao existir no Armature ativo,
    # o assemble_item cria um bone novo e emite um AVISO (warnings,
    # reportado pelo operador) -- melhor que o item sumir silenciosamente
    # da lista. (Comentario antigo citava um "validate_against_armature"
    # que nao existe no codigo -- corrigido na limpeza das notas.)

    result = []
    if self.category not in _MANDATORY_CATEGORIES:
        result.append((_SLOT_NONE_VALUE, "(Nenhum)", "", "X", 0) if use_icons else (_SLOT_NONE_VALUE, "(Nenhum)", ""))

    for idx, (item_id, label, it) in enumerate(labeled, start=1):
        if use_icons:
            icon_id = _ensure_item_thumbnail_icon(cache, self.category, it)
            result.append((item_id, label, item_id, icon_id, idx))
        else:
            result.append((item_id, label, item_id))

    if not result:
        result.append((_SLOT_NONE_VALUE, "(vazio)", "", "X", 0) if use_icons else (_SLOT_NONE_VALUE, "(vazio)", ""))

    _item_enum_cache[cache_key] = result
    return result


def _slot_color_enum_items(self, context):
    item_id = _slot_item_value(self)
    gradient_set = _slot_gradient_value(self)
    if not item_id or item_id == _SLOT_NONE_VALUE:
        return [(_SLOT_NONE_VALUE, "-", "")]

    # BUG DE PERFORMANCE REAL corrigido: so o dropdown de Item era
    # cacheado -- Cor/GradientSet/Variante recalculavam do zero (com
    # find_item() + ordenar ate 53 cores) a CADA REDRAW, pra CADA linha
    # visivel. Com varias secoes abertas ao mesmo tempo, isso repete
    # dezenas de vezes por movimento de mouse sobre o painel -- exatamente
    # o padrao "mais abas abertas, mais lento" relatado no teste real,
    # e acontecia mesmo com miniaturas desligadas.
    cache_key = (self.category, item_id, gradient_set)
    cached = _color_enum_cache.get(cache_key)
    if cached is not None:
        return cached

    cache = get_cache()
    item = cache.find_item(self.category, item_id)
    if item is None:
        return [(_SLOT_NONE_VALUE, "-", "")]

    if item.coloring_mode == "gradient":
        gset_id = gradient_set if (gradient_set and gradient_set != _SLOT_NONE_VALUE) else item.gradient_set
        gset = cache.gradient_sets.get(gset_id)
        if gset is None or not gset.colors:
            result = [(_SLOT_NONE_VALUE, f"(GradientSet '{gset_id}' nao encontrado)", "")]
        else:
            result = _sorted_enum([(c.name, c.name, "") for c in gset.colors])
    elif item.coloring_mode == "discrete":
        if not item.textures:
            result = [(_SLOT_NONE_VALUE, "(sem cor)", "")]
        else:
            result = _sorted_enum([(t.name, t.name, "") for t in item.textures])
    else:
        result = [(_SLOT_NONE_VALUE, "(sem cor)", "")]

    _color_enum_cache[cache_key] = result
    return result


def _slot_gradient_set_enum_items(self, context):
    """Lista TODOS os GradientSets que existem no catalogo (nao so o que
    o manifest do item declara como padrao) -- pedido explicito: o
    proprio editor do Hytale deixa trocar livremente (confirmado num
    print: Skin, Hair, Faded_Leather... todos disponiveis pra qualquer
    item). So mostra alguma coisa pra itens em modo gradiente -- Modo B
    (Textures discretas) nao tem esse conceito."""
    item_id = _slot_item_value(self)
    if not item_id or item_id == _SLOT_NONE_VALUE:
        return [(_SLOT_NONE_VALUE, "-", "")]

    cache_key = (self.category, item_id)
    cached = _gradient_set_enum_cache.get(cache_key)
    if cached is not None:
        return cached

    cache = get_cache()
    item = cache.find_item(self.category, item_id)
    if item is None or item.coloring_mode != "gradient":
        result = [(_SLOT_NONE_VALUE, "-", "")]
    else:
        names = sorted(cache.gradient_sets.keys(), key=lambda n: n.lower())
        result = [(n, n, "") for n in names] if names else [(_SLOT_NONE_VALUE, "(nenhum GradientSet encontrado)", "")]

    _gradient_set_enum_cache[cache_key] = result
    return result


def _slot_effective_gradient_set(slot) -> str:
    """GradientSet que sera USADO de verdade pro slot -- o que o usuario
    escolheu manualmente (slot.gradient_set), ou o declarado no manifest
    do item se nada foi trocado ainda."""
    item = get_cache().find_item(slot.category, _slot_item_value(slot))
    if item is None:
        return ""
    gradient_set = _slot_gradient_value(slot)
    if gradient_set and gradient_set != _SLOT_NONE_VALUE:
        return gradient_set
    return item.gradient_set or ""


def _slot_uses_skin_gradient(slot) -> bool:
    item_id = _slot_item_value(slot)
    if not item_id or item_id == _SLOT_NONE_VALUE:
        return False
    item = get_cache().find_item(slot.category, item_id)
    if item is None or item.coloring_mode != "gradient":
        return False
    return _slot_effective_gradient_set(slot) == _SKIN_GRADIENT_SET_ID


def _slot_is_active_skin_link(slot) -> bool:
    """True se este slot participa AGORA do grupo de link de pele --
    categoria linkavel (_LINKED_SKIN_CATEGORIES), toggle ligado
    (skin_linked) E de fato usando o GradientSet Skin no momento
    (_slot_uses_skin_gradient). Consolida as MESMAS 3 condicoes que
    `_find_linked_skin_color` e `_propagate_linked_skin_color`
    repetiam cada uma por conta propria."""
    return (
        slot.category in _LINKED_SKIN_CATEGORIES
        and slot.skin_linked
        and _slot_uses_skin_gradient(slot)
    )


def _find_linked_skin_color(wm, exclude_slot=None) -> str:
    """Acha a cor de outro slot do grupo _LINKED_SKIN_CATEGORIES que JA
    esteja linkado (`skin_linked=True`) e de fato usando o GradientSet
    Skin no momento (considerando troca manual de GradientSet, ver
    _slot_uses_skin_gradient) -- usado tanto por um slot que acabou de
    ligar o link (adota a cor do grupo, ver _slot_on_skin_linked_update)
    quanto por um ITEM NOVO escolhido numa categoria ja linkada (herda
    a cor do grupo em vez de resetar pra primeira da lista, ver
    _slot_on_item_update). Devolve "" se nenhum outro slot linkado com
    cor valida for encontrado (ex: e o primeiro/unico linkado no
    momento)."""
    for slot in wm.hyblendcc_slots:
        if slot is exclude_slot:
            continue
        if not _slot_is_active_skin_link(slot):
            continue
        if slot.color:
            return slot.color
    return ""


def _propagate_linked_skin_color(context, source_slot) -> None:
    """Chamado quando a cor de um slot LINKADO muda por escolha direta
    do usuario (ver _slot_on_color_update) -- copia essa cor pra TODAS
    as outras categorias do grupo _LINKED_SKIN_CATEGORIES que TAMBEM
    estejam linkadas no momento (`skin_linked=True`) e de fato usando o
    GradientSet Skin. Categorias com o link desligado ficam de fora,
    mantendo a propria cor independente -- diferenca chave pro
    mecanismo antigo (wm.hyblendcc_skintone, removido), que nao dava
    essa opcao."""
    global _slots_syncing
    wm = context.window_manager
    color = source_slot.color
    for slot in wm.hyblendcc_slots:
        if slot is source_slot:
            continue
        if not _slot_is_active_skin_link(slot):
            continue
        if slot.color == color:
            continue
        _defer_apply_slot_from(slot, color_override=color)
        was_syncing = _slots_syncing
        _slots_syncing = True
        try:
            slot.color = color
        finally:
            _slots_syncing = was_syncing


def _slot_on_item_update(self, context):
    global _slots_syncing
    # Espelho barato ANTES do early-return: tem que acompanhar TODA
    # escrita, inclusive a da sincronizacao (ver _slot_item_value).
    self.item_key = self.item_id
    if _slots_syncing:
        return
    wm = context.window_manager

    variants = _slot_variant_enum_items(self, context)
    self.variant = variants[0][0]

    # Reseta o GradientSet pro que o MANIFEST do item declara como
    # padrao (nao pro primeiro da lista alfabetica) -- trocar de item
    # deveria voltar pro comportamento "normal" daquele item; o usuario
    # escolhe um GradientSet diferente so quando quiser de proposito.
    item = get_cache().find_item(self.category, self.item_id)
    if item is not None and item.coloring_mode == "gradient" and item.gradient_set:
        self.gradient_set = item.gradient_set
    else:
        gsets = _slot_gradient_set_enum_items(self, context)
        self.gradient_set = gsets[0][0]

    if self.category in _LINKED_SKIN_CATEGORIES and self.skin_linked and _slot_uses_skin_gradient(self):
        # Herda a cor de outro slot do grupo JA linkado (se houver) em
        # vez de resetar pra primeira cor da lista -- e o ponto todo de
        # estar linkado. Se ninguem mais estiver linkado no momento
        # (ex: este e o primeiro), cai pro reset normal abaixo.
        ref_color = _find_linked_skin_color(wm, exclude_slot=self)
        if ref_color:
            was_syncing = _slots_syncing
            _slots_syncing = True
            try:
                self.color = ref_color
                self.background_color = ref_color
            finally:
                _slots_syncing = was_syncing
            _defer_apply_slot_from(self)
            return

    colors = _slot_color_enum_items(self, context)
    self.color = colors[0][0]
    # background_color usa a MESMA lista de cores que 'color' (mesmo
    # GradientSet) -- reseta junto por consistencia, mesmo motivo do
    # 'color' acima (o valor anterior pode nem existir na paleta do
    # item novo).
    was_syncing = _slots_syncing
    _slots_syncing = True
    try:
        self.background_color = colors[0][0]
    finally:
        _slots_syncing = was_syncing
    # Chamado explicitamente (nao so confiando nos updates de 'color'/
    # 'variant'/'gradient_set' acima dispararem sozinhos) -- se o novo
    # valor for IGUAL ao que ja estava (ex: trocando entre dois itens que
    # por coincidencia tem uma cor/variante de mesmo nome), o Blender NAO
    # dispara o update deles, e a troca de item ficaria sem efeito
    # nenhum. Chamar de novo aqui (mesmo que algum update TAMBEM
    # disparar) e so um pouco de trabalho redundante, nao um bug -- mais
    # simples e seguro que tentar suprimir com precisao.
    _defer_apply_slot_from(self)


def _slot_on_color_update(self, context):
    if _slots_syncing:
        return
    _defer_apply_slot_from(self)
    if self.category in _LINKED_SKIN_CATEGORIES and self.skin_linked and _slot_uses_skin_gradient(self):
        _propagate_linked_skin_color(context, self)


def _slot_on_gradient_set_update(self, context):
    """Trocar o GradientSet manualmente (ex: Skin -> Hair) reseta a Cor
    pra primeira disponivel NESSE set -- a cor anterior pode nem existir
    nele (ids de cor variam de set pra set, ex. Skin usa "01".."53",
    Faded_Leather usa nomes como "Brown")."""
    global _slots_syncing
    self.gradient_key = self.gradient_set   # espelho (ver _slot_gradient_value)
    if _slots_syncing:
        return
    colors = _slot_color_enum_items(self, context)
    was_syncing = _slots_syncing
    _slots_syncing = True
    try:
        self.color = colors[0][0]
        self.background_color = colors[0][0]
    finally:
        _slots_syncing = was_syncing
    _defer_apply_slot_from(self)


def _slot_variant_enum_items(self, context):
    item_id = _slot_item_value(self)
    if not item_id or item_id == _SLOT_NONE_VALUE:
        return [(_SLOT_NONE_VALUE, "-", "")]

    prefs = context.preferences.addons[ADDON_PACKAGE].preferences
    cache_key = (self.category, item_id, prefs.language)
    cached = _variant_enum_cache.get(cache_key)
    if cached is not None:
        return cached

    cache = get_cache()
    item = cache.find_item(self.category, item_id)
    if item is None or not item.variants:
        result = [(_SLOT_NONE_VALUE, "-", "")]
    else:
        result = _sorted_enum([(v.key, cache.display_name(v.name_key) if v.name_key else v.key, "") for v in item.variants])

    _variant_enum_cache[cache_key] = result
    return result


def _slot_on_variant_update(self, context):
    if _slots_syncing:
        return
    _defer_apply_slot_from(self)


def _slot_on_background_color_update(self, context):
    """Cor do no '*Background*' (ex. Eye-Background) quando NAO esta
    linkada com a cor principal -- ver _slot_on_background_linked_update
    e HYBLENDCC_OT_apply_slot."""
    if _slots_syncing:
        return
    _defer_apply_slot_from(self)


def _slot_on_background_linked_update(self, context):
    """Liga/desliga o botao de link (icone MatchHairColorsIcon*) --
    ligado, o no '*Background*' usa a MESMA cor do item principal
    (`self.color`); desligado, usa `self.background_color` (por padrao
    a primeira cor da paleta, ver _slot_on_item_update). So tem efeito
    visivel em itens que realmente tem um no '*Background*' separado na
    malha (ver _item_model_has_background_node, usado pra UI decidir se
    mostra esse controle) -- pra outros itens, fica gravado mas sem uso
    nenhum, igual `variant`/`gradient_set` ja fazem pra itens que nao
    precisam deles."""
    if _slots_syncing:
        return
    _defer_apply_slot_from(self)


def _slot_on_skin_linked_update(self, context):
    """Liga/desliga o link de cor compartilhada entre
    BodyCharacteristics/Faces/Mouths/Ears (feature pedida pelo usuario
    -- ANTES desta feature, essas categorias eram SEMPRE linkadas, sem
    opcao de desligar; agora cada uma mantem a PROPRIA paleta sempre
    visivel, e o link so decide se escolher uma cor propaga pras outras
    linkadas no momento, ver _propagate_linked_skin_color/
    _find_linked_skin_color). Ligando, adota a cor de outro slot do
    grupo que ja esteja linkado (se houver algum); desligando, so para
    de propagar/receber mudanca futura -- a cor atual do slot fica como
    esta, sem reset nenhum."""
    global _slots_syncing
    if _slots_syncing:
        return
    if self.skin_linked and _slot_uses_skin_gradient(self):
        wm = context.window_manager
        ref_color = _find_linked_skin_color(wm, exclude_slot=self)
        if ref_color and self.color != ref_color:
            was_syncing = _slots_syncing
            _slots_syncing = True
            try:
                self.color = ref_color
            finally:
                _slots_syncing = was_syncing
            _defer_apply_slot_from(self)


class HYBLENDCC_ItemSlot(PropertyGroup):
    category: StringProperty()
    # Espelhos BARATOS de item_id/gradient_set (StringProperty: ler NAO
    # chama callback nenhum). Escritos pelos update() das enums; lidos
    # pelos items() de Cor/GradientSet/Variante e pelas UIs -- ver
    # _slot_item_value (bug de performance real, DEVELOPER_NOTES item 58).
    item_key: StringProperty(options={"HIDDEN"})
    gradient_key: StringProperty(options={"HIDDEN"})
    item_id: EnumProperty(name="Item", items=_slot_item_enum_items, update=_slot_on_item_update)
    variant: EnumProperty(name="Variant", items=_slot_variant_enum_items, update=_slot_on_variant_update)
    gradient_set: EnumProperty(name="GradientSet", items=_slot_gradient_set_enum_items, update=_slot_on_gradient_set_update)
    color: EnumProperty(name="Color", items=_slot_color_enum_items, update=_slot_on_color_update)
    # Feature pedida pelo usuario: alguns itens (ex. olhos) tem um no
    # "*Background*" separado na malha que pode ter cor PROPRIA. Mesma
    # lista de cores que 'color' (reaproveita _slot_color_enum_items --
    # e a mesma paleta/GradientSet do item, so muda QUAL cor da paleta
    # cada no usa). `background_linked=True` ignora `background_color`
    # por completo e usa `color` pros dois nos (ver
    # HYBLENDCC_OT_apply_slot.execute()).
    background_color: EnumProperty(name="Background Color", items=_slot_color_enum_items, update=_slot_on_background_color_update)
    background_linked: BoolProperty(name="Background Follows Item Color", default=False, update=_slot_on_background_linked_update)
    # Feature pedida pelo usuario: BodyCharacteristics/Faces/Mouths/Ears
    # (_LINKED_SKIN_CATEGORIES) cada um mantem a PROPRIA paleta sempre
    # visivel (diferente do Eye/Eye-Background acima -- aqui NAO existe
    # uma segunda grade separada). O link so decide se escolher uma cor
    # aqui propaga pras outras categorias do grupo que TAMBEM estiverem
    # linkadas no momento (ver _propagate_linked_skin_color). Default
    # True pra bater com o comportamento ANTES desta feature existir
    # (eram sempre linkados, sem opcao de desligar) -- so importa pras
    # 4 categorias do grupo, gravado sem uso nenhum nas demais.
    skin_linked: BoolProperty(name="Link Color With Group", default=True, update=_slot_on_skin_linked_update)


def _ensure_slots_populated(context):
    """Garante que exista um slot (linha da UI) por categoria do
    catalogo -- idempotente, so adiciona o que ainda nao existe."""
    cache = get_cache()
    try:
        cache.ensure_loaded(_character_creator_dir(context))
    except AssemblyError:
        return
    wm = context.window_manager
    existing = {slot.category for slot in wm.hyblendcc_slots}
    for category in cache.catalogs.keys():
        if category in existing:
            continue
        slot = wm.hyblendcc_slots.add()
        slot.category = category


def _sync_slots_from_armature(context, armature_obj):
    """Le o que esta REALMENTE equipado no Armature ativo (custom
    properties hyblendcc_slot_<categoria>, ver character_assembly.py) e
    atualiza os dropdowns pra bater -- sem isso, trocar de Armature ativo
    (ou reabrir o .blend) deixaria a UI mostrando um estado que nao
    corresponde ao que esta na cena de verdade."""
    global _slots_syncing
    wm = context.window_manager
    _slots_syncing = True
    try:
        for slot in wm.hyblendcc_slots:
            equipped = get_equipped_item(armature_obj, slot.category)
            if equipped is None:
                # BUG REAL corrigido (usuario reportou com traceback real
                # do Blender): pra categoria OBRIGATORIA (_MANDATORY_
                # CATEGORIES, ex. BodyCharacteristics), "(Nenhum)" nem
                # e uma opcao valida do enum (ver _slot_item_enum_items --
                # de proposito, nao da pra ficar sem corpo) -- tentar
                # forcar item_id pra _SLOT_NONE_VALUE nesse caso crasha
                # ("enum '__NONE__' not found"). Acontece na pratica com
                # um Armature que nao foi criado pelo fluxo deste addon
                # (ex. mod de custom skin feito por fora) -- nao tem a
                # custom property hyblendcc_slot_<categoria> gravada,
                # entao get_equipped_item devolve None mesmo a categoria
                # sendo obrigatoria. Sem dado nenhum pra sincronizar,
                # so deixa o dropdown como esta (nao tenta zerar).
                if slot.category in _MANDATORY_CATEGORIES:
                    continue
                if slot.item_id != _SLOT_NONE_VALUE:
                    slot.item_id = _SLOT_NONE_VALUE
                continue
            item_id, color, variant, gradient_set, background_color, background_linked, skin_linked = equipped
            if not variant:
                # Blinda contra dado antigo (de antes desta correcao) que
                # possa ter gravado "" -- Blender nao aceita string vazia
                # como valor de EnumProperty (ver bug real corrigido:
                # "enum '' not found"). Normaliza pro sentinela valido.
                variant = _SLOT_NONE_VALUE
            if not gradient_set:
                # BUG REAL corrigido (mesma classe do bug da variante):
                # "__NONE__" so e uma opcao valida quando o item NAO e
                # gradiente -- pra um item em modo gradiente (ex.
                # BodyCharacteristics, gravado por HYBLENDCC_OT_create_player
                # ANTES desta feature existir, sem gradient_set nenhum),
                # a lista de opcoes so tem os GradientSets de verdade,
                # "__NONE__" nao esta la -- setar ele crashava. Cai pro
                # que o MANIFEST do item declara como padrao, que sempre
                # e uma opcao valida quando o item e gradiente.
                found_item = get_cache().find_item(slot.category, item_id)
                if found_item is not None and found_item.coloring_mode == "gradient" and found_item.gradient_set:
                    gradient_set = found_item.gradient_set
                else:
                    gradient_set = _SLOT_NONE_VALUE
            if not background_color:
                # Dado antigo (gravado antes desta feature existir) ou
                # nunca definido -- 'color' e sempre uma opcao valida na
                # MESMA lista (background_color usa o mesmo items()).
                background_color = color
            if slot.item_id != item_id:
                slot.item_id = item_id
            if slot.variant != variant:
                slot.variant = variant
            if slot.gradient_set != gradient_set:
                slot.gradient_set = gradient_set
            if slot.color != color:
                slot.color = color
            if slot.background_color != background_color:
                slot.background_color = background_color
            if slot.background_linked != background_linked:
                slot.background_linked = background_linked
            if slot.skin_linked != skin_linked:
                slot.skin_linked = skin_linked
    finally:
        _slots_syncing = False


def _ensure_slots_synced(context, armature_obj):
    """So faz o trabalho de _sync_slots_from_armature quando o Armature
    ativo mudou desde a ultima vez (evita reler as custom properties a
    cada redraw do painel -- e chamado com muita frequencia)."""
    wm = context.window_manager
    _ensure_slots_populated(context)
    if wm.get("hyblendcc_synced_for") == armature_obj.name:
        return
    _sync_slots_from_armature(context, armature_obj)
    wm["hyblendcc_synced_for"] = armature_obj.name


def _find_slot(wm, category: str):
    """Acha o HYBLENDCC_ItemSlot de uma sub-categoria em
    wm.hyblendcc_slots (populado por _ensure_slots_populated, chamado
    todo draw() via _ensure_slots_synced -- por isso aqui e so busca,
    nunca cria)."""
    for slot in wm.hyblendcc_slots:
        if slot.category == category:
            return slot
    return None


class HYBLENDCC_OT_apply_slot(Operator):
    """Aplica (ou remove, se item_id for "Nenhum") um item numa
    categoria especifica -- chamado automaticamente pelos updates dos
    EnumProperty de HYBLENDCC_ItemSlot, nunca precisa ser clicado
    manualmente."""

    bl_idname = "hyblendcc.apply_slot"
    bl_label = "Apply Item (category)"
    bl_description = "Apply the selected item, color and options to this category's slot"
    bl_options = {"REGISTER", "UNDO"}

    category: StringProperty()
    item_id: StringProperty()
    color: StringProperty()
    variant: StringProperty()
    gradient_set: StringProperty()
    background_color: StringProperty()
    background_linked: BoolProperty(default=False)
    skin_linked: BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return game_found() and obj is not None and obj.type == "ARMATURE"   # sem o jogo: travado (common.game_found)

    def execute(self, context):
        armature_obj = context.active_object
        cache = get_cache()

        if not self.item_id or self.item_id == _SLOT_NONE_VALUE:
            remove_equipped_slot(context, armature_obj, self.category)
            self.report({"INFO"}, f"'{self.category}' removed from '{armature_obj.name}'.")
            return {"FINISHED"}

        item = cache.find_item(self.category, self.item_id)
        if item is None:
            self.report({"ERROR"}, f"Item '{self.item_id}' not found in '{self.category}' -- catalog out of date?")
            return {"CANCELLED"}

        # Sub-variante posicional (rara -- ex. Spiked_Bracelets "Left"/
        # "Right", ver manifest_parser.ItemVariant). model_for_variant ja
        # resolve o fallback certo (variante -> item -> primeira variante
        # com Model, ver manifest_parser.py -- corrige o bug real de
        # itens com Model vazio no nivel do Item, ex. "Slickback"/
        # "Dreadlocks" em Haircuts.json).
        has_variant = self.variant and self.variant != _SLOT_NONE_VALUE
        model_rel = item.model_for_variant(self.variant if has_variant else None)
        if not model_rel:
            self.report({"ERROR"}, f"'{item.id}' has no Model at all (neither its own nor any variant's).")
            return {"CANCELLED"}

        try:
            model_path = _resolve_assets_path(context, model_rel)
            if not model_path.is_file():
                self.report({"ERROR"}, f"File not found: {model_path}")
                return {"CANCELLED"}

            has_gradient_override = self.gradient_set and self.gradient_set != _SLOT_NONE_VALUE
            mat, reference_image = _resolve_item_material(
                context, cache, item, self.color,
                variant_key=(self.variant if has_variant else None),
                gradient_set_override=(self.gradient_set if has_gradient_override else None),
            )
            atlas_w, atlas_h = _resolve_atlas_size(reference_image, model_path)

            # Feature pedida pelo usuario: alguns itens (ex. olhos) tem
            # um no "*Background*" separado na malha que pode ter cor
            # PROPRIA -- so resolve o segundo material quando ha um no
            # assim (a maioria nao tem: UM material pra tudo).
            bg_mat_cache: list = []

            def material_for(obj):
                if mat is None:
                    return None
                if "background" not in obj.name.lower():
                    return mat
                if not bg_mat_cache:
                    bg_color_name = self.color if self.background_linked else (self.background_color or self.color)
                    bg_mat, _ = _resolve_item_material(
                        context, cache, item, bg_color_name,
                        variant_key=(self.variant if has_variant else None),
                        gradient_set_override=(self.gradient_set if has_gradient_override else None),
                    )
                    bg_mat_cache.append(bg_mat)
                return bg_mat_cache[0] if bg_mat_cache[0] is not None else mat

            # Mesmo item e mesma variante (so cor/GradientSet/fundo mudou,
            # ex. o link de pele propagando pro corpo): troca so o
            # material, sem recriar bones -- recriar o corpo soltava
            # rosto/boca/orelhas do Head e apagava o que o Create Rig do
            # Toolkit pos nesses bones. Registro antigo ou atlas diferente
            # caem na reconstrucao normal (recolor devolve False).
            equipped = get_equipped_item(armature_obj, self.category)
            same_model = (
                equipped is not None
                and equipped[0] == item.id
                and (equipped[2] or _SLOT_NONE_VALUE) == (self.variant or _SLOT_NONE_VALUE)
            )
            if same_model and recolor_equipped_slot(armature_obj, self.category, (atlas_w, atlas_h), material_for):
                created_objs_names, created_bone_names = equipped_slot_record(armature_obj, self.category)
                created_objs = [bpy.data.objects[n] for n in created_objs_names]
            else:
                # Bones de outros slots pendurados nos que vao ser
                # recriados (ver remove_equipped_slot) -- religados por nome.
                orphans = remove_equipped_slot(context, armature_obj, self.category)

                created_objs, created_bone_names, warnings = assemble_item(
                    context, armature_obj, model_path, atlas_w, atlas_h, unit_scale=UNIT_SCALE_DEFAULT,
                    reattach_children=orphans,
                )
                _report_warnings(self, warnings)

                for obj in created_objs:
                    target_mat = material_for(obj)
                    if target_mat is not None:
                        obj.data.materials.append(target_mat)

            record_equipped_slot(
                armature_obj, self.category, created_objs, created_bone_names,
                item_id=item.id, color=self.color, variant=self.variant, gradient_set=self.gradient_set,
                background_color=self.background_color, background_linked=self.background_linked,
                skin_linked=self.skin_linked, atlas_size=(atlas_w, atlas_h),
            )

        except AssemblyError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        self.report({"INFO"}, f"'{item.id}' ({self.color}) applied to '{armature_obj.name}'.")
        return {"FINISHED"}


class HYBLENDCC_OT_reload_catalog(Operator):
    """Reparseia Cosmetics/CharacterCreator/ do zero -- usar depois de
    trocar a pasta Assets nas Preferences, ou editar/adicionar um .json
    manualmente."""

    bl_idname = "hyblendcc.reload_catalog"
    bl_label = "Reload Catalog"
    bl_description = "Re-scan the Assets folder for cosmetic items from scratch"

    @classmethod
    def poll(cls, context):
        return game_found()          # sem a pasta do jogo o addon fica travado (common.game_found)

    def execute(self, context):
        get_cache().invalidate()
        _invalidate_item_enum_cache()
        self.report({"INFO"}, "Catalog reloaded.")
        return {"FINISHED"}


_background_node_cache: dict = {}


def _any_node_named_background(nodes) -> bool:
    for node in nodes:
        if "background" in node.get("name", "").lower():
            return True
        if _any_node_named_background(node.get("children", [])):
            return True
    return False


def _item_model_has_background_node(context, category: str, item, variant_key=None) -> bool:
    """Espia o .blockymodel do item (SO leitura de JSON, nao monta
    geometria nenhuma -- seguro de chamar durante draw()) procurando um
    no com "background" no nome (ex. "Eye-Background") -- usado pra
    decidir se mostra o controle de "cor do fundo separada" + botao de
    link na UI (ver interface/panel.py). Cacheado por (categoria, item, variante)
    -- o .blockymodel nao muda em tempo de execucao, so recarrega se o
    catalogo for recarregado (ver _invalidate_item_enum_cache)."""
    cache_key = (category, item.id, variant_key)
    cached = _background_node_cache.get(cache_key)
    if cached is not None:
        return cached
    result = False
    try:
        model_rel = item.model_for_variant(variant_key)
        if model_rel:
            model_path = _resolve_assets_path(context, model_rel)
            if model_path.is_file():
                with model_path.open(encoding="utf-8") as f:
                    data = json.load(f)
                result = _any_node_named_background(data.get("nodes", []))
    except Exception:
        result = False
    _background_node_cache[cache_key] = result
    return result


def _resolve_item_material(context, cache, item, color_name, variant_key=None, gradient_set_override=None, gradient_builder=build_gradient_tint_material, flat_builder=build_flat_material):
    """Resolve o material (e a imagem de referencia, usada pro tamanho do
    atlas) pra um Item+cor -- reaproveitado pelo operador de aplicar E
    pelo gerador de thumbnail, pra nao duplicar essa logica em dois
    lugares. `gradient_builder`/`flat_builder` decidem se o material final
    e o "de verdade" (Principled BSDF, reage a luz da cena de verdade) ou
    a versao "preview" (Emission, shadeless -- ver material_setup.py) --
    a logica de ACHAR as imagens certas e identica nos dois casos, so o
    jeito de montar o material no final muda.

    `variant_key`: pra itens raros com sub-variantes posicionais (ex.
    Spiked_Bracelets "Left"/"Right", ver manifest_parser.ItemVariant) --
    so afeta qual GreyscaleTexture e usada (ver Item.greyscale_for_variant);
    o Modo B (Textures discretas) nao tem esse conceito, so ignora.

    `gradient_set_override`: GradientSet ESCOLHIDO PELO USUARIO (ex:
    trocar Skin por Hair numa roupa, pedido explicito -- o proprio editor
    do Hytale permite isso livremente) -- se None, usa o que o manifest
    do item declara como padrao (`item.gradient_set`). So faz sentido
    pra Modo A (gradiente); Modo B ignora.

    Levanta AssemblyError com uma mensagem pronta pra reportar se algo
    nao resolver (textura faltando, cor invalida, etc.)."""
    if item.coloring_mode == "gradient":
        greyscale_rel = item.greyscale_for_variant(variant_key)
        greyscale_path = _resolve_assets_path(context, greyscale_rel)
        if not greyscale_path.is_file():
            raise AssemblyError(f"GreyscaleTexture not found: {greyscale_path}")
        greyscale_image = bpy.data.images.load(str(greyscale_path), check_existing=True)
        # A GreyscaleTexture guarda LUMINANCIA (coordenada de busca na
        # rampa), NAO uma cor de verdade -- precisa ser lida como dado
        # LINEAR (Non-Color). Sem isso, o Blender assume 'sRGB' (padrao
        # pra qualquer imagem carregada sem isso explicito) e aplica
        # gamma na luminancia antes dela virar coordenada -- desloca
        # QUAL parte da rampa e amostrada em cada pixel, fazendo a cor
        # final sair errada (mais escura/dessaturada que o jogo real,
        # sintoma reportado pelo usuario com print comparando olhos
        # vermelhos do Hytale vs Blender). Bug sistemico: afeta TODO
        # item em Modo A (gradiente) -- cabelo, pele, roupa tingivel,
        # olhos -- porque todos passam por esta mesma funcao.
        set_image_non_color(greyscale_image)  # compat: nome do colorspace/is_data

        gset_id = gradient_set_override or item.gradient_set
        gset = cache.gradient_sets.get(gset_id)
        gcolor = gset.get(color_name) if gset is not None else None
        if gcolor is None:
            raise AssemblyError(f"Color '{color_name}' is invalid for GradientSet '{gset_id}' (item '{item.id}').")
        ramp_path = _resolve_assets_path(context, gcolor.texture)
        if not ramp_path.is_file():
            raise AssemblyError(f"Ramp texture not found: {ramp_path}")
        gradient_image = bpy.data.images.load(str(ramp_path), check_existing=True)

        mat, _ramp_node = gradient_builder(f"HyChar_{item.id}_{gset_id}_{color_name}", greyscale_image, gradient_image)
        return mat, greyscale_image

    if item.coloring_mode == "discrete":
        texture_variant = next((t for t in item.textures if t.name == color_name), None)
        if texture_variant is None:
            raise AssemblyError(f"Variant '{color_name}' is invalid for '{item.id}'.")
        texture_path = _resolve_assets_path(context, texture_variant.texture)
        if not texture_path.is_file():
            raise AssemblyError(f"Texture not found: {texture_path}")
        image = bpy.data.images.load(str(texture_path), check_existing=True)
        mat = flat_builder(f"HyChar_{item.id}_{color_name}", image)
        return mat, image

    return None, None


def _resolve_atlas_size(reference_image, model_path):
    """Tamanho do atlas de textura pras contas de UV -- vem da imagem
    de referencia do material se disponivel (mais preciso), ou
    estimado a partir do proprio .blockymodel como fallback (ver
    estimate_atlas_size). Consolida um padrao de 4 linhas que se
    repetia identico em 2 lugares (aplicar equipamento de verdade em
    HYBLENDCC_OT_apply_slot, e gerar thumbnail em
    _generate_category_thumbnails)."""
    if reference_image is not None:
        return reference_image.size
    return estimate_atlas_size(model_path)


def _generate_category_thumbnails(context, category: str, progress_fn=None):
    """Nucleo de geracao de miniatura de UMA categoria -- reaproveitado
    por HYBLENDCC_OT_build_category_thumbnails (uma categoria por vez,
    botao dentro do picker) e HYBLENDCC_OT_build_all_thumbnails (todas
    de uma vez, botao pedido pelo usuario em Preferences). So gera as
    que ainda faltam (reaproveita o cache em disco), na cor de
    referencia de cada item (ver _item_reference_color).

    `progress_fn`, se dado, e chamado com o INDICE do item dentro desta
    categoria (0-based) -- quem chama decide o que fazer com isso (o
    Operator de uma categoria so usa pra granularidade fina por item;
    o de todas prefere granularidade por categoria, ver seu execute()).

    Devolve `None` (nao uma tupla) se a categoria estiver vazia ou nao
    existir -- quem chama decide se isso e erro (uma categoria: sim,
    reporta e cancela) ou so "pula essa e segue" (todas: normal, nem
    toda categoria tem item)."""
    cache = get_cache()
    items_list = cache.catalogs.get(category, [])
    if not items_list:
        return None

    generated = 0
    skipped = 0
    failed_ids = []
    for i, item in enumerate(items_list):
        if progress_fn is not None:
            progress_fn(i)
        color_name = _item_reference_color(cache, item)
        if color_name is None:
            print(f"[HyChar] Skipped '{item.id}' ({category}): no reference color (coloring_mode={item.coloring_mode!r}, gradient_set={item.gradient_set!r}, textures={len(item.textures)})")
            skipped += 1
            failed_ids.append(item.id)
            continue

        output_path = thumbnail_path(category, item.id, color_name)
        if output_path.is_file():
            continue  # ja cacheada, nao regenera

        try:
            model_rel = item.model_for_variant()
            if not model_rel:
                print(f"[HyChar] Skipped '{item.id}' ({category}): no Model (neither its own nor any variant's)")
                skipped += 1
                failed_ids.append(item.id)
                continue
            model_path = _resolve_assets_path(context, model_rel)
            if not model_path.is_file():
                print(f"[HyChar] Skipped '{item.id}' ({category}): Model not found on disk -> {model_path}")
                skipped += 1
                failed_ids.append(item.id)
                continue

            mat, reference_image = _resolve_item_material(
                context, cache, item, color_name,
                gradient_builder=build_gradient_tint_preview_material,
                flat_builder=build_flat_preview_material,
            )
            atlas_w, atlas_h = _resolve_atlas_size(reference_image, model_path)

            ok = render_item_thumbnail(model_path, mat, atlas_w, atlas_h, output_path)
            if ok:
                generated += 1
                # A camera de render.py enquadra pela diagonal 3D
                # inteira da peca (+ 20% de folga) -- o que aparece de
                # fato na imagem costuma ser BEM menor que o quadro
                # (mesmo problema que ja resolvemos pros icones fixos
                # de Categoria). Corta a margem vazia AQUI (dentro do
                # Operator, contexto seguro) em vez de deixar pro
                # carregamento na UI -- se falhar por qualquer motivo,
                # o arquivo original sem corte continua valendo.
                _crop_transparent_margin_inplace(output_path)
            else:
                print(f"[HyChar] Skipped '{item.id}' ({category}): render_item_thumbnail returned False (no visible geometry in the file)")
                skipped += 1
                failed_ids.append(item.id)
        except Exception as exc:
            # Deliberadamente amplo (nao so AssemblyError) -- BUG REAL
            # encontrado no teste: um erro de QUALQUER tipo vindo de
            # dentro do render (ex: um item com geometria fora do
            # padrao) nao capturado abortava O LOTE INTEIRO no meio,
            # deixando os itens seguintes sem gerar -- exatamente o
            # sintoma "a maioria foi, sobrou uns 2-3". Um item
            # problematico agora so pula ELE MESMO, sem travar os
            # outros.
            print(f"[HyChar] Failed to generate thumbnail for '{item.id}' ({category}): {exc!r}")
            failed_ids.append(item.id)
            skipped += 1
            continue

    _invalidate_item_enum_cache(category)
    return generated, skipped, failed_ids


class HYBLENDCC_OT_build_category_thumbnails(Operator):
    """Gera (so as que ainda faltam -- reaproveita o cache em disco) a
    miniatura de TODOS os itens de uma categoria, na cor de referencia de
    cada um (ver _item_reference_color). Usado pra alimentar o grid
    visual do picker (template_icon_view) -- sem isso rodado ao menos
    uma vez, o grid aparece so com texto, sem icone (fallback normal,
    nao quebra nada, so fica menos util)."""

    bl_idname = "hyblendcc.build_category_thumbnails"
    bl_label = "Generate Thumbnails for this Category"
    bl_description = "Render missing item thumbnails for this category (cached to disk)"
    bl_options = {"REGISTER"}

    category: StringProperty()

    @classmethod
    def poll(cls, context):
        return game_found()          # sem a pasta do jogo o addon fica travado (common.game_found)

    @classmethod
    def description(cls, context, properties):
        return f"Generate thumbnails for {_prettify_key(properties.category)}"

    def execute(self, context):
        cache = get_cache()
        items_list = cache.catalogs.get(self.category, [])
        if not items_list:
            self.report({"WARNING"}, f"Category '{self.category}' is empty or not found.")
            return {"CANCELLED"}

        wm = context.window_manager
        wm.progress_begin(0, len(items_list))
        try:
            generated, skipped, failed_ids = _generate_category_thumbnails(
                context, self.category, progress_fn=wm.progress_update,
            )
        finally:
            wm.progress_end()

        # Forca o picker a reconsultar o disco pros itens recem-gerados --
        # sem isso, _ensure_item_thumbnail_icon so acharia o PNG novo na
        # PROXIMA vez que o addon fosse reiniciado (o preview collection
        # em si nao precisa de limpeza, ele so carrega o que faltava).
        for area in context.screen.areas:
            area.tag_redraw()

        msg = f"{generated} thumbnail(s) generated for '{self.category}'"
        if skipped:
            msg += f" ({skipped} skipped)"
        if failed_ids:
            msg += f" -- failed: {', '.join(failed_ids[:5])}" + ("..." if len(failed_ids) > 5 else "")
        self.report({"INFO"}, msg + ".")
        return {"FINISHED"}


class HYBLENDCC_OT_build_all_thumbnails(Operator):
    """Gera as miniaturas que faltam de TODAS as categorias do catalogo
    de uma vez, reaproveitando o MESMO nucleo
    (_generate_category_thumbnails) que HYBLENDCC_OT_build_category_
    thumbnails usa pra uma categoria so -- pedido explicito do usuario,
    pra nao precisar visitar categoria por categoria manualmente.

    Botao mora em Preferences (nao no N-panel do picker) -- chamado la
    via bl_idname CRU (string, `\"hyblendcc.build_all_thumbnails\"`),
    sem import direto da classe, pra nao violar a hierarquia de
    dependencia do addon (preferences.py e camada 2, nao pode importar
    de picker.py, camada 3 -- ver cabecalho de preferences.py)."""

    bl_idname = "hyblendcc.build_all_thumbnails"
    bl_label = "Generate All Thumbnails"
    bl_description = "Render missing thumbnails for every category in the catalog (can take a while)"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return game_found()          # sem a pasta do jogo o addon fica travado (common.game_found)

    def execute(self, context):
        cache = get_cache()
        categories = sorted(cache.catalogs.keys())
        if not categories:
            self.report({"WARNING"}, "Catalog is empty -- nothing to generate.")
            return {"CANCELLED"}

        # Granularidade por CATEGORIA (nao por item) de proposito --
        # somar o total de itens de TODAS as categorias primeiro so pra
        # ter uma barra mais fina nao vale o codigo extra aqui; com
        # dezenas de categorias a barra por-categoria ja da feedback
        # visivel o suficiente.
        wm = context.window_manager
        wm.progress_begin(0, len(categories))
        total_generated = 0
        total_skipped = 0
        all_failed = []
        try:
            for i, category in enumerate(categories):
                wm.progress_update(i)
                result = _generate_category_thumbnails(context, category)
                if result is None:
                    continue
                generated, skipped, failed_ids = result
                total_generated += generated
                total_skipped += skipped
                all_failed.extend(f"{category}/{fid}" for fid in failed_ids)
        finally:
            wm.progress_end()

        for area in context.screen.areas:
            area.tag_redraw()

        msg = f"{total_generated} thumbnail(s) generated across {len(categories)} categorie(s)"
        if total_skipped:
            msg += f" ({total_skipped} skipped)"
        if all_failed:
            msg += f" -- failed: {', '.join(all_failed[:5])}" + ("..." if len(all_failed) > 5 else "")
        self.report({"INFO"}, msg + ".")
        return {"FINISHED"}
