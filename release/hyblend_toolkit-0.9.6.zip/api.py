"""API do núcleo pros addons que dependem dele (Anim, ...): o que eles podem usar daqui.
IMPORTANTE: mudou assinatura ou removeu algo -> subir HYBLEND_CORE_API (__init__.py) e o `requires` dos
dependentes. Acrescentar não exige subir. Os dependentes leem tudo daqui, nunca dos módulos internos
(exceção: as peças da UI por GPU, por gpu_module())."""

import importlib
import importlib.util
import os
import sys
import types

from . import hyblend_hub as hub
from . import model
from .assets_source import AssetsSource, ZipAssetsSource
from .common import ADDON_PACKAGE, HUB_ID, game_found
from .interface.gpu_ui import game, hytale_install
from .translations import (
    get_language,
    load_tables,
    localized_props,
    register_localized_class,
    register_refresh_hook,
    register_table,
    tooltip_for,
    tr_for,
    unregister_localized_class,
    unregister_refresh_hook,
    unregister_table,
)

__all__ = (
    "hub", "HUB_ID", "game_found", "documents_dir", "hytale_dir", "hytale_install", "game", "AssetsSource",
    "ZipAssetsSource", "preferences", "LOCATE_GAME_OP", "register_hub_entry", "unregister_hub_entry",
    "mount_gpu_framework", "info",
    "get_language", "load_tables", "localized_props", "register_localized_class",
    "register_refresh_hook", "register_table", "tooltip_for", "tr_for", "unregister_localized_class",
    "unregister_refresh_hook", "unregister_table",
    "App", "register_app", "unregister_app", "current_app",
    "gpu_supported", "gpu_enabled", "gpu_module", "draw_info", "PREFS_BUTTON_PROP",
    "model", "IMPORT_BLOCKYMODEL_OP", "IMPORT_CHARACTER_OP",
)

documents_dir = hub.documents_dir

# "Localizar jogo" (local padrão; senão seletor de pasta): o mesmo botão pra todos (grava nas Preferences do núcleo).
LOCATE_GAME_OP = "hyblend.welcome_locate_game"


def hytale_dir():
    """Raiz da instalação do Hytale (Path) ou None. Barato (cacheado, re-testa o disco a cada 3 s)."""
    return game.hytale_dir()


def preferences(context=None):
    """AddonPreferences do núcleo (idioma, pasta do Hytale, use_gpu_ui, gpu_ui_scale/_panel_width/_height...)
    ou None durante register/unregister."""
    import bpy
    context = context or bpy.context
    addon = context.preferences.addons.get(ADDON_PACKAGE)
    return getattr(addon, "preferences", None) if addon is not None else None


def info():
    """Constantes da aba Info (créditos/links) e a pasta dos logos, pra quem desenha a própria versão dela."""
    from . import interface
    names = [n for n in dir(interface) if n.startswith("HYBLEND_")]
    icons_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "icons")
    return types.SimpleNamespace(icons_dir=icons_dir, **{n: getattr(interface, n) for n in names})

# --- Modelos (.blockymodel) ---
# `model` = pacote model/ do núcleo: model.build (Armature nova/anexo), model.geometry (caixa/quad com UV, malha
# única), model.materials, model.props (propriedades gravadas nos bones), model.options (opções das janelas de
# import), model.textures (textura ao lado de um modelo solto), model.catalog/model.character (personagens do jogo).
IMPORT_BLOCKYMODEL_OP = "import_scene.hytale_blockymodel"     # File > Import (janela com as opções)
IMPORT_CHARACTER_OP = "hyblend.import_character"              # character_id = id de Server/Models

# Engrenagem das Preferences no painel clássico: prop_enum(wm, PREFS_BUTTON_PROP, "OPEN").
PREFS_BUTTON_PROP = "hytale_prefs_button"


# --- Tela do addon no seletor (painel clássico e UI por GPU) ---

def App(*, title, version, hub_label, tab_prop, tabs, tab_rows, signature):
    """Tela de um dependente na UI por GPU do núcleo.
    tabs = ((id, rótulo, ícone, key do tooltip, build(ui)), ...); tab_rows = (((ids...), altura), ...);
    tab_prop = EnumProperty do WindowManager com a aba ativa; signature(context) -> tupla barata (ver app.signature)."""
    return types.SimpleNamespace(title=title, version=version, hub_label=hub_label, tab_prop=tab_prop,
                                 tabs=tuple(tabs), tab_rows=tuple(tab_rows), signature=signature)


_apps = {}      # dono -> App (ordem de registro)


def register_app(owner, app):
    """Dependente com tela na aba "Hyblend" (o botão do núcleo no seletor passa a mostrar app.hub_label)."""
    _apps[owner] = app
    _apps_changed()


def unregister_app(owner):
    if _apps.pop(owner, None) is not None:
        _apps_changed()


def current_app():
    """Tela mostrada na aba (a primeira registrada) ou None (o núcleo mostra a espera + Info)."""
    return next(iter(_apps.values()), None)


def _apps_changed():
    from . import interface, model
    app = current_app()
    interface.set_hub_label(app.hub_label if app is not None else "Toolkit")
    interface.gpu_ui.hub_refresh()
    model.check_operator_later()      # o Anim 0.1.0 saindo leva o import .blockymodel junto: devolve o do núcleo


# --- Seletor dos addons (hub) ---

_hub_entries = {}     # id -> classes do seletor nativo


def register_hub_entry(ident, label, package, namespace, *, gpu_ui, reason=None, on_hytale=None):
    """Entra no seletor da aba "Hyblend" (como o hyblend_hub.register_addon, mas SEM os campos da pasta do Hytale,
    que agora são só do núcleo). `gpu_ui` = módulo com is_enabled/host_ok/hub_refresh/on_preference_changed;
    `on_hytale(modo, pasta)` = a pasta mudou no núcleo (limpar caches). Chamar no register(), antes dos painéis."""
    import bpy
    classes = list(hub.make_classes(namespace, ident))
    for cls in classes:
        bpy.utils.register_class(cls)
    _hub_entries[ident] = classes

    def gpu_showing(context):
        return gpu_ui.is_enabled(context) and game_found() and gpu_ui.host_ok(context)

    hub.register(ident, label, owner=package, available=lambda context: game_found(),
                 reason=(lambda context: reason) if reason else None, gpu_showing=gpu_showing,
                 refresh=gpu_ui.hub_refresh, on_gpu_changed=gpu_ui.on_preference_changed, on_hytale=on_hytale)


def unregister_hub_entry(ident, package):
    import bpy
    hub.unregister(ident, owner=package)
    for cls in reversed(_hub_entries.pop(ident, ())):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


# --- UI ---

def gpu_supported():
    """Blender com a UI por GPU (5.0+)? Abaixo disso as páginas por GPU de um dependente nem são importadas."""
    from .interface import gpu_ui
    return gpu_ui.is_supported()


def gpu_enabled(context=None):
    """UI por GPU ligada agora (o painel clássico do dependente some)."""
    from .interface import gpu_ui
    return gpu_ui.is_enabled(context)


def gpu_module(name):
    """Módulo da UI por GPU do núcleo pras páginas de um dependente: "framework.core", "framework.motion",
    "widgets", "pages.common", "pages.info_page"..."""
    return importlib.import_module("%s.interface.gpu_ui.%s" % (__package__, name))


def mount_gpu_framework(name):
    """Instância PRÓPRIA do framework da UI por GPU pra um addon, com o código daqui: carrega a pasta framework/
    do núcleo como o pacote `name` (ex.: "<addon>.interface.gpu_ui.framework"), então os `from .framework import`
    do addon continuam valendo. Estado separado por addon (app, CONFIG, caches), como quando cada um tinha a cópia.
    Chamar antes de qualquer import do framework no addon."""
    module = sys.modules.get(name)
    if module is not None:
        return module
    folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "interface", "gpu_ui", "framework")
    spec = importlib.util.spec_from_file_location(name, os.path.join(folder, "__init__.py"),
                                                  submodule_search_locations=[folder])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        del sys.modules[name]
        raise
    parent, _, child = name.rpartition(".")
    if parent in sys.modules:
        setattr(sys.modules[parent], child, module)
    return module


def draw_info(layout, context, lang):
    """Aba Info no painel clássico de um dependente (créditos/links, botão do Welcome)."""
    from . import interface
    interface.draw_info(layout, context, lang)

